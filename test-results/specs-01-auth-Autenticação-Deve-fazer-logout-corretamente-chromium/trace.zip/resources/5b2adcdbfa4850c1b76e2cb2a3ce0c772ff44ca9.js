import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/main.js");var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b ||= {})
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// src/main.ts
import * as __NgCli_bootstrap_1 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_platform-browser.js?v=6e2f77a0";

// src/app/app.module.ts
import { NgModule as NgModule2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { BrowserModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_platform-browser.js?v=6e2f77a0";
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
import { FormsModule, ReactiveFormsModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";

// src/app/app-routing.module.ts
import { NgModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { RouterModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";

// src/app/pages/home/home.component.ts
import { Component as Component26 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i037 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i113 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
import * as i29 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i33 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common.js?v=6e2f77a0";
import * as i43 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_card.js?v=6e2f77a0";
import * as i5 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_bidi.js?v=6e2f77a0";
import * as i6 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_scrolling.js?v=6e2f77a0";
import * as i7 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_sidenav.js?v=6e2f77a0";
import * as i8 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_list.js?v=6e2f77a0";
import * as i9 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_divider.js?v=6e2f77a0";
import * as i10 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_icon.js?v=6e2f77a0";
import * as i11 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_toolbar.js?v=6e2f77a0";
import * as i122 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_button.js?v=6e2f77a0";
import * as i132 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_datepicker.js?v=6e2f77a0";
import * as i142 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_form-field.js?v=6e2f77a0";
import * as i152 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_input.js?v=6e2f77a0";
import * as i162 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_text-field.js?v=6e2f77a0";
import * as i172 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ng2-charts.js?v=6e2f77a0";
import * as i182 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ngx-skeleton-loader.js?v=6e2f77a0";

// src/app/app.component.ts
var app_component_exports = {};
__export(app_component_exports, {
  AppComponent: () => AppComponent
});
import { NavigationEnd } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
import { Component, ViewChild } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i03 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i12 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";

// src/app/services/login/login.service.ts
var login_service_exports = {};
__export(login_service_exports, {
  LoginService: () => LoginService
});
import { Injectable as Injectable2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { tap, catchError, throwError } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";

// src/environments/environment.ts
var environment = {
  production: false,
  //baseApiUrl: "",
  baseApiUrl: "http://192.168.1.110/"
};

// src/app/services/login/login.service.ts
import * as i02 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i1 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";

// src/app/services/mensagens/mensagens.service.ts
var mensagens_service_exports = {};
__export(mensagens_service_exports, {
  MensagensService: () => MensagensService
});
import { Injectable } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import Swal from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/sweetalert2.js?v=6e2f77a0";
import * as i0 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var MensagensService = class _MensagensService {
  constructor() {
  }
  mensagem(icon, title, text, html) {
    Swal.fire({
      icon,
      title,
      text,
      html
    });
  }
  static {
    this.\u0275fac = function MensagensService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _MensagensService)();
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _MensagensService, factory: _MensagensService.\u0275fac, providedIn: "root" });
  }
};

// src/app/services/login/login.service.ts
var LoginService = class _LoginService {
  constructor(http, mensagensService) {
    this.http = http;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  postLogin(loginData) {
    console.log(loginData);
    return this.http.post(`${this.baseApiUrl}api/auth/login`, loginData).pipe(tap((response) => {
      this.storeTokens(response);
    }), catchError((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro no login: ${error.status}`, void 0);
      return throwError(error);
    }));
  }
  // Método para armazenar os tokens
  storeTokens(tokens) {
    sessionStorage.setItem("authToken", tokens.token);
    localStorage.setItem("refreshToken", tokens.refreshToken);
    localStorage.setItem("idUsuario", tokens.idUsuario.toString());
  }
  getAuthToken() {
    return sessionStorage.getItem("authToken");
  }
  getIdUsuario() {
    return localStorage.getItem("idUsuario");
  }
  // Método para obter o refreshToken do localStorage
  getRefreshToken() {
    return localStorage.getItem("refreshToken");
  }
  // Método para renovar o token
  refreshToken() {
    const refreshToken = this.getRefreshToken();
    return this.http.post(
      `${this.baseApiUrl}api/auth/refresh`,
      { refreshToken },
      { withCredentials: true }
      // Permite enviar os cookies automaticamente, se necessário
    ).pipe(catchError((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao renovar token: ${error.status}`, void 0);
      return throwError(error);
    }));
  }
  clearTokens() {
    sessionStorage.removeItem("authToken");
    localStorage.removeItem("idUsuario");
    localStorage.removeItem("refreshToken");
  }
  logout() {
    this.clearTokens();
    window.location.href = "/login";
  }
  static {
    this.\u0275fac = function LoginService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LoginService)(i02.\u0275\u0275inject(i1.HttpClient), i02.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i02.\u0275\u0275defineInjectable({ token: _LoginService, factory: _LoginService.\u0275fac, providedIn: "root" });
  }
};

// src/app/app.component.ts
var _c0 = ["sidenav"];
function AppComponent_mat_toolbar_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275elementStart(0, "mat-toolbar", 10);
    i03.\u0275\u0275listener("click", function AppComponent_mat_toolbar_0_Template_mat_toolbar_click_0_listener() {
      i03.\u0275\u0275restoreView(_r2);
      i03.\u0275\u0275nextContext();
      const sidenav_r3 = i03.\u0275\u0275reference(3);
      return i03.\u0275\u0275resetView(sidenav_r3.toggle());
    });
    i03.\u0275\u0275elementStart(1, "button")(2, "mat-icon");
    i03.\u0275\u0275text(3, "menu");
    i03.\u0275\u0275elementEnd()();
    i03.\u0275\u0275elementStart(4, "span");
    i03.\u0275\u0275text(5, "Gest\xE3o Financeira");
    i03.\u0275\u0275elementEnd()();
  }
}
var AppComponent = class _AppComponent {
  // Método para alternar o estado da sidebar
  toggleSidebar() {
    this.sidenav.toggle();
  }
  // Método chamado ao selecionar uma opção no menu
  selectOption() {
    this.sidenav.close();
  }
  constructor(router, loginService) {
    this.router = router;
    this.loginService = loginService;
    this.title = "gestaoFinanceira";
    this.showHeaderFooter = true;
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.showHeaderFooter = event.url !== "/login";
      }
    });
  }
  isLoginPage() {
    return this.router.url === "/login";
  }
  selectSair() {
    this.loginService.logout();
  }
  static {
    this.\u0275fac = function AppComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _AppComponent)(i03.\u0275\u0275directiveInject(i12.Router), i03.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i03.\u0275\u0275defineComponent({ type: _AppComponent, selectors: [["app-root"]], viewQuery: function AppComponent_Query(rf, ctx) {
      if (rf & 1) {
        i03.\u0275\u0275viewQuery(_c0, 5);
      }
      if (rf & 2) {
        let _t;
        i03.\u0275\u0275queryRefresh(_t = i03.\u0275\u0275loadQuery()) && (ctx.sidenav = _t.first);
      }
    }, standalone: false, decls: 36, vars: 1, consts: [["sidenav", ""], ["mat-icon-button", "", "color", "primary", 3, "click", 4, "ngIf"], ["mode", "over", 3, "click"], ["mat-list-item", "", "routerLink", "/", "routerLinkActive", "selected", 3, "click"], ["mat-list-item", "", "routerLink", "/graficos", "routerLinkActive", "selected", 3, "click"], ["mat-list-item", "", "routerLink", "/centro-custo", "routerLinkActive", "selected", 3, "click"], ["mat-list-item", "", "routerLink", "/lancamento-fixo", "routerLinkActive", "selected", 3, "click"], ["mat-list-item", "", "routerLink", "/configuracoes-ia", "routerLinkActive", "selected", 3, "click"], ["mat-list-item", "", "routerLink", "/login", "routerLinkActive", "selected", 3, "click"], [1, "content-container"], ["mat-icon-button", "", "color", "primary", 3, "click"]], template: function AppComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i03.\u0275\u0275getCurrentView();
        i03.\u0275\u0275template(0, AppComponent_mat_toolbar_0_Template, 6, 0, "mat-toolbar", 1);
        i03.\u0275\u0275elementStart(1, "mat-sidenav-container")(2, "mat-sidenav", 2, 0);
        i03.\u0275\u0275listener("click", function AppComponent_Template_mat_sidenav_click_2_listener() {
          i03.\u0275\u0275restoreView(_r1);
          const sidenav_r3 = i03.\u0275\u0275reference(3);
          return i03.\u0275\u0275resetView(sidenav_r3.close());
        });
        i03.\u0275\u0275elementStart(4, "mat-nav-list")(5, "a")(6, "mat-icon");
        i03.\u0275\u0275text(7, "list");
        i03.\u0275\u0275elementEnd()();
        i03.\u0275\u0275elementStart(8, "a", 3);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_8_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectOption());
        });
        i03.\u0275\u0275elementStart(9, "mat-icon");
        i03.\u0275\u0275text(10, "list");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(11, " Lan\xE7amentos ");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275elementStart(12, "a", 4);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_12_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectOption());
        });
        i03.\u0275\u0275elementStart(13, "mat-icon");
        i03.\u0275\u0275text(14, "bar_chart");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(15, " Gr\xE1ficos ");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275elementStart(16, "a", 5);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_16_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectOption());
        });
        i03.\u0275\u0275elementStart(17, "mat-icon");
        i03.\u0275\u0275text(18, "category");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(19, " Centros de Custo ");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275elementStart(20, "a", 6);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_20_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectOption());
        });
        i03.\u0275\u0275elementStart(21, "mat-icon");
        i03.\u0275\u0275text(22, "event");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(23, " Lan\xE7amentos Fixos ");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275elementStart(24, "a", 7);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_24_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectOption());
        });
        i03.\u0275\u0275elementStart(25, "mat-icon");
        i03.\u0275\u0275text(26, "auto_awesome");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(27, " Configura\xE7\xF5es IA ");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275elementStart(28, "a", 8);
        i03.\u0275\u0275listener("click", function AppComponent_Template_a_click_28_listener() {
          i03.\u0275\u0275restoreView(_r1);
          return i03.\u0275\u0275resetView(ctx.selectSair());
        });
        i03.\u0275\u0275elementStart(29, "mat-icon");
        i03.\u0275\u0275text(30, "logout");
        i03.\u0275\u0275elementEnd();
        i03.\u0275\u0275text(31, " Sair ");
        i03.\u0275\u0275elementEnd()()();
        i03.\u0275\u0275elementStart(32, "mat-sidenav-content")(33, "div", 9);
        i03.\u0275\u0275element(34, "router-outlet");
        i03.\u0275\u0275elementEnd()()();
        i03.\u0275\u0275element(35, "app-footer");
      }
      if (rf & 2) {
        i03.\u0275\u0275property("ngIf", ctx.showHeaderFooter);
      }
    }, styles: ["\n\n.content-container[_ngcontent-%COMP%] {\n  width: 100%;\n  margin: 0 auto;\n  padding: 5px;\n  background-color: white;\n  padding-top: 80px;\n}\nmat-toolbar[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  z-index: 1000;\n  background-color: rgb(200, 200, 200);\n  color: black;\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  padding: 0px;\n  height: 60px;\n}\nmat-sidenav[_ngcontent-%COMP%] {\n  background-color: rgb(210, 210, 210);\n  padding: 10px;\n  position: fixed;\n  top: 0px;\n  left: 0;\n  height: 100vh;\n  width: 250px;\n  z-index: 1000;\n  transition: transform 0.3s ease-in-out;\n}\nmat-nav-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\nmat-nav-list[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  padding: 10px;\n  text-decoration: none;\n  color: black;\n}\nmat-nav-list[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background-color: #FFF;\n}\nmat-list-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\nmat-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  vertical-align: middle;\n}\n.selected[_ngcontent-%COMP%] {\n  background-color: #FFF;\n  color: white;\n}\nbutton[_ngcontent-%COMP%]:focus {\n  outline: none;\n}\nbutton[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  cursor: pointer;\n}\n/*# sourceMappingURL=app.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(AppComponent, { className: "AppComponent", filePath: "src/app/app.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fapp.component.ts%40AppComponent";
  function AppComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i03.\u0275\u0275replaceMetadata(AppComponent, m.default, [i03, i12, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && AppComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && AppComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/footer/footer.component.ts
var footer_component_exports = {};
__export(footer_component_exports, {
  FooterComponent: () => FooterComponent
});
import { Component as Component2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i04 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var FooterComponent = class _FooterComponent {
  static {
    this.\u0275fac = function FooterComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FooterComponent)();
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i04.\u0275\u0275defineComponent({ type: _FooterComponent, selectors: [["app-footer"]], standalone: false, decls: 7, vars: 0, template: function FooterComponent_Template(rf, ctx) {
      if (rf & 1) {
        i04.\u0275\u0275elementStart(0, "footer")(1, "h3");
        i04.\u0275\u0275text(2, "Controle seus gastos :D");
        i04.\u0275\u0275elementEnd();
        i04.\u0275\u0275elementStart(3, "p")(4, "span");
        i04.\u0275\u0275text(5, "Gest\xE3o Financeira");
        i04.\u0275\u0275elementEnd();
        i04.\u0275\u0275text(6, " \xA9 2023");
        i04.\u0275\u0275elementEnd()();
      }
    }, styles: ['\n\nfooter[_ngcontent-%COMP%] {\n  border-top: 1px solid rgb(73, 73, 73);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  height: 200px;\n}\nfooter[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-bottom: 1.2em;\n}\nfooter[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: bold;\n  color: "#494949";\n}\n/*# sourceMappingURL=footer.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(FooterComponent, { className: "FooterComponent", filePath: "src/app/components/footer/footer.component.ts", lineNumber: 9 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Ffooter%2Ffooter.component.ts%40FooterComponent";
  function FooterComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i04.\u0275\u0275replaceMetadata(FooterComponent, m.default, [i04], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && FooterComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && FooterComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/graficos/graficos.component.ts
var graficos_component_exports = {};
__export(graficos_component_exports, {
  GraficosComponent: () => GraficosComponent
});
import { Component as Component3 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/utils/colors.ts
function hexToRgb(hex) {
  const h = hex.replace("#", "");
  const bigint = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return { r: bigint >> 16 & 255, g: bigint >> 8 & 255, b: bigint & 255 };
}
function rgbToHex(r, g, b) {
  const toHex = (n) => {
    const h = Math.round(Math.max(0, Math.min(255, n))).toString(16);
    return h.length === 1 ? "0" + h : h;
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}
function interpolateHex(hex1, hex2, t) {
  const c1 = hexToRgb(hex1);
  const c2 = hexToRgb(hex2);
  const r = lerp(c1.r, c2.r, t);
  const g = lerp(c1.g, c2.g, t);
  const b = lerp(c1.b, c2.b, t);
  return rgbToHex(r, g, b);
}
function getColorForSobra(sobra) {
  const GREEN = "#00A859";
  const YELLOW = "#FFD100";
  const RED = "#FF0000";
  if (sobra >= 2e3) {
    return GREEN;
  }
  if (sobra < 0) {
    return RED;
  }
  const t = 1 - sobra / 2e3;
  return interpolateHex(GREEN, YELLOW, t);
}

// src/app/pages/graficos/graficos.component.ts
import { Validators } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i08 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/gastos-mensais/gastos-mensais.service.ts
var gastos_mensais_service_exports = {};
__export(gastos_mensais_service_exports, {
  GastosMensaisService: () => GastosMensaisService
});
import { Injectable as Injectable3 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError2, throwError as throwError2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i05 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i13 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var GastosMensaisService = class _GastosMensaisService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getGastosMensais(dataDe, dataAte) {
    const idUsuario = this.loginService.getIdUsuario();
    if (dataDe && dataAte) {
      return this.http.get(`${this.baseApiUrl}api/gastosmensais?idUsuario=${idUsuario}&dataDe=${dataDe}&dataAte=${dataAte}`).pipe(catchError2((error) => {
        return throwError2(error);
      }));
    } else {
      return this.http.get(`${this.baseApiUrl}api/gastosmensais?idUsuario=${idUsuario}`).pipe(catchError2((error) => {
        return throwError2(error);
      }));
    }
  }
  static {
    this.\u0275fac = function GastosMensaisService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _GastosMensaisService)(i05.\u0275\u0275inject(i13.HttpClient), i05.\u0275\u0275inject(LoginService), i05.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i05.\u0275\u0275defineInjectable({ token: _GastosMensaisService, factory: _GastosMensaisService.\u0275fac, providedIn: "root" });
  }
};

// src/app/services/gastos-centro-custo/gastos-centro-custo.service.ts
var gastos_centro_custo_service_exports = {};
__export(gastos_centro_custo_service_exports, {
  GastosCentroCustoService: () => GastosCentroCustoService
});
import { Injectable as Injectable4 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError3, throwError as throwError3 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i06 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i14 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var GastosCentroCustoService = class _GastosCentroCustoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getAllGastosCentroMesAno(mesAno) {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/gastoscentrocustos/usuario/${idUsuario}/mesano/${mesAno}`).pipe(catchError3((error) => {
      return throwError3(error);
    }));
  }
  static {
    this.\u0275fac = function GastosCentroCustoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _GastosCentroCustoService)(i06.\u0275\u0275inject(i14.HttpClient), i06.\u0275\u0275inject(LoginService), i06.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i06.\u0275\u0275defineInjectable({ token: _GastosCentroCustoService, factory: _GastosCentroCustoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/services/detalhamento-gastos-custo/detalhamento-gastos-centro-custo.service.ts
var detalhamento_gastos_centro_custo_service_exports = {};
__export(detalhamento_gastos_centro_custo_service_exports, {
  DetalhamentoGastosCentroCustoService: () => DetalhamentoGastosCentroCustoService
});
import { Injectable as Injectable5 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError4, throwError as throwError4 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i07 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i15 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var DetalhamentoGastosCentroCustoService = class _DetalhamentoGastosCentroCustoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getAllDetalhamentoGastosCentroMesAno(mesAno, descCC) {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/detalhamentogastoscentrocustos/descricaoCC?idUsuario=${idUsuario}&mesAno=${mesAno}&descCC=${descCC}`).pipe(catchError4((error) => {
      return throwError4(error);
    }));
  }
  static {
    this.\u0275fac = function DetalhamentoGastosCentroCustoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _DetalhamentoGastosCentroCustoService)(i07.\u0275\u0275inject(i15.HttpClient), i07.\u0275\u0275inject(LoginService), i07.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i07.\u0275\u0275defineInjectable({ token: _DetalhamentoGastosCentroCustoService, factory: _DetalhamentoGastosCentroCustoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/pages/graficos/graficos.component.ts
import * as i4 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
var _c02 = () => [0, 1, 2];
var _c1 = () => [0, 1, 2, 3];
var _c2 = () => ({ height: "14px", "margin-bottom": "6px", "border-radius": "4px" });
var _c3 = () => [0, 1, 2, 3, 4];
var _c4 = () => ({ width: "60%", height: "16px", "border-radius": "4px" });
var _c5 = () => ({ width: "30%", height: "16px", "border-radius": "4px" });
var _c6 = () => ({ width: "100%", height: "8px", "border-radius": "4px" });
var _c7 = () => ({ width: "40%", height: "14px", "border-radius": "4px" });
function GraficosComponent_mat_error_8_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, " Ano \xE9 obrigat\xF3rio ");
    i08.\u0275\u0275elementEnd();
  }
}
function GraficosComponent_div_9_div_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainerStart(0);
    i08.\u0275\u0275elementStart(1, "div", 16);
    i08.\u0275\u0275element(2, "ngx-skeleton-loader", 17);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("theme", i08.\u0275\u0275pureFunction0(1, _c2));
  }
}
function GraficosComponent_div_9_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 14);
    i08.\u0275\u0275template(1, GraficosComponent_div_9_div_1_ng_container_1_Template, 3, 2, "ng-container", 15);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngForOf", i08.\u0275\u0275pureFunction0(1, _c1));
  }
}
function GraficosComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 12);
    i08.\u0275\u0275template(1, GraficosComponent_div_9_div_1_Template, 2, 2, "div", 13);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngForOf", i08.\u0275\u0275pureFunction0(1, _c02));
  }
}
function GraficosComponent_ng_container_10_div_1_div_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementContainerStart(0);
    i08.\u0275\u0275elementStart(1, "div", 20);
    i08.\u0275\u0275listener("click", function GraficosComponent_ng_container_10_div_1_div_1_ng_container_1_ng_container_1_Template_div_click_1_listener() {
      i08.\u0275\u0275restoreView(_r3);
      const c_r4 = i08.\u0275\u0275nextContext().index;
      const l_r5 = i08.\u0275\u0275nextContext().index;
      const ctx_r5 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r5.selecionarMes(ctx_r5.gGMMesAno[l_r5 * 4 + c_r4]));
    });
    i08.\u0275\u0275elementStart(2, "strong", 21);
    i08.\u0275\u0275text(3);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "p", 22);
    i08.\u0275\u0275text(5);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(6, "p", 22);
    i08.\u0275\u0275text(7);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(8, "p", 22);
    i08.\u0275\u0275text(9);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const c_r4 = i08.\u0275\u0275nextContext().index;
    const l_r5 = i08.\u0275\u0275nextContext().index;
    const ctx_r5 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275styleProp("background-color", ctx_r5.gGMCordoQuadrante[l_r5 * 4 + c_r4]);
    i08.\u0275\u0275classProp("quadrante-selecionado", ctx_r5.gGMMesAno[l_r5 * 4 + c_r4] === ctx_r5.mesAnoSelecionado);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1(" ", ctx_r5.gGMLabelMes[l_r5 * 4 + c_r4], " ");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1(" + R$ ", ctx_r5.gGMDataValorRecebidoMes[l_r5 * 4 + c_r4], " ");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1(" - R$ ", ctx_r5.gGMDataValor[l_r5 * 4 + c_r4], " ");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1(" = R$ ", ctx_r5.gGMDataSobraMes[l_r5 * 4 + c_r4], " ");
  }
}
function GraficosComponent_ng_container_10_div_1_div_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainerStart(0);
    i08.\u0275\u0275template(1, GraficosComponent_ng_container_10_div_1_div_1_ng_container_1_ng_container_1_Template, 10, 8, "ng-container", 19);
    i08.\u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const c_r4 = ctx.index;
    const l_r5 = i08.\u0275\u0275nextContext().index;
    i08.\u0275\u0275nextContext();
    const semRegistro_r7 = i08.\u0275\u0275reference(3);
    const ctx_r5 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngIf", ctx_r5.temRegistro(l_r5 * 4 + c_r4))("ngIfElse", semRegistro_r7);
  }
}
function GraficosComponent_ng_container_10_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 14);
    i08.\u0275\u0275template(1, GraficosComponent_ng_container_10_div_1_div_1_ng_container_1_Template, 2, 2, "ng-container", 15);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngForOf", i08.\u0275\u0275pureFunction0(1, _c1));
  }
}
function GraficosComponent_ng_container_10_div_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 23)(1, "span", 24);
    i08.\u0275\u0275text(2, "\u2715");
    i08.\u0275\u0275elementEnd()();
  }
}
function GraficosComponent_ng_container_10_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 12);
    i08.\u0275\u0275template(1, GraficosComponent_ng_container_10_div_1_div_1_Template, 2, 2, "div", 13)(2, GraficosComponent_ng_container_10_div_1_ng_template_2_Template, 3, 0, "ng-template", null, 2, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngForOf", i08.\u0275\u0275pureFunction0(1, _c02));
  }
}
function GraficosComponent_ng_container_10_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 23)(1, "span");
    i08.\u0275\u0275text(2, "Registros n\xE3o encontrados!");
    i08.\u0275\u0275elementEnd()();
  }
}
function GraficosComponent_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainerStart(0);
    i08.\u0275\u0275template(1, GraficosComponent_ng_container_10_div_1_Template, 4, 2, "div", 18)(2, GraficosComponent_ng_container_10_ng_template_2_Template, 3, 0, "ng-template", null, 1, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const registrosNaoEncontrados_r8 = i08.\u0275\u0275reference(3);
    const ctx_r5 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngIf", ctx_r5.gGMMesAno.length > 0)("ngIfElse", registrosNaoEncontrados_r8);
  }
}
function GraficosComponent_ng_container_12_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 25)(1, "div", 26);
    i08.\u0275\u0275element(2, "ngx-skeleton-loader", 27)(3, "ngx-skeleton-loader", 27);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "div", 28);
    i08.\u0275\u0275element(5, "ngx-skeleton-loader", 27);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(6, "div", 29);
    i08.\u0275\u0275element(7, "ngx-skeleton-loader", 27);
    i08.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("theme", i08.\u0275\u0275pureFunction0(4, _c4));
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("theme", i08.\u0275\u0275pureFunction0(5, _c5));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("theme", i08.\u0275\u0275pureFunction0(6, _c6));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("theme", i08.\u0275\u0275pureFunction0(7, _c7));
  }
}
function GraficosComponent_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainerStart(0);
    i08.\u0275\u0275template(1, GraficosComponent_ng_container_12_div_1_Template, 8, 8, "div", 10);
    i08.\u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    i08.\u0275\u0275advance();
    i08.\u0275\u0275property("ngForOf", i08.\u0275\u0275pureFunction0(1, _c3));
  }
}
function GraficosComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "div", 25)(1, "div", 30);
    i08.\u0275\u0275listener("click", function GraficosComponent_div_13_Template_div_click_1_listener() {
      const item_r10 = i08.\u0275\u0275restoreView(_r9).$implicit;
      const ctx_r5 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r5.buscarDetalhamentoGastosCentroCusto(item_r10.mesEAno, item_r10.descricaoCentroCusto));
    });
    i08.\u0275\u0275elementStart(2, "span", 31);
    i08.\u0275\u0275text(3);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "span", 32);
    i08.\u0275\u0275text(5);
    i08.\u0275\u0275pipe(6, "number");
    i08.\u0275\u0275pipe(7, "number");
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(8, "div", 28);
    i08.\u0275\u0275element(9, "div", 33)(10, "div", 34);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(11, "div", 29);
    i08.\u0275\u0275text(12);
    i08.\u0275\u0275pipe(13, "number");
    i08.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r10 = ctx.$implicit;
    const ctx_r5 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate(item_r10.descricaoCentroCusto);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate2(" R$ ", i08.\u0275\u0275pipeBind2(6, 9, item_r10.gasto, "1.2-2"), " / ", i08.\u0275\u0275pipeBind2(7, 12, item_r10.limite, "1.2-2"), " ");
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275styleProp("width", ctx_r5.getPercentual(item_r10), "%");
    i08.\u0275\u0275property("ngClass", ctx_r5.getClasse(item_r10));
    i08.\u0275\u0275advance();
    i08.\u0275\u0275styleProp("left", 100, "%");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1(" ", i08.\u0275\u0275pipeBind2(13, 15, ctx_r5.getPercentual(item_r10), "1.0-0"), "% ");
  }
}
var GraficosComponent = class _GraficosComponent {
  constructor(saldoService, gastosCentroCustoService, detalhamentoGastosCentroCusto, fb) {
    this.saldoService = saldoService;
    this.gastosCentroCustoService = gastosCentroCustoService;
    this.detalhamentoGastosCentroCusto = detalhamentoGastosCentroCusto;
    this.fb = fb;
    this.gGMLabelMes = [];
    this.gGMMesAno = [];
    this.gGMDataValor = [];
    this.gGMDataSobraMes = [];
    this.gGMCordoQuadrante = [];
    this.gGMDataValorRecebidoMes = [];
    this.gGCCValor = [];
    this.gGCCValorLimite = [];
    this.gGCCDescricao = [];
    this.gGCCmesAnoAtual = [];
    this.popupAberto = false;
    this.detalhamentoGastosCC = [];
    this.anos = [];
    this.loadingGastosMensais = true;
    this.loadingCentrosCusto = true;
    this.mesAnoSelecionado = null;
    this.centrosCustoVisual = [];
  }
  ngOnInit() {
    this.form = this.fb.group({
      ano: [null, Validators.required]
    });
    this.buscarInformacoesGastosMensais("", "");
  }
  get ano() {
    return this.form.get("ano");
  }
  anoSelecionado(data, datepicker) {
    const ano = data.getFullYear();
    this.form.get("ano")?.setValue(new Date(ano, 0, 1));
    datepicker.close();
    const dataDe = `${ano}-01-01`;
    const dataAte = `${ano}-12-31`;
    this.gGMLabelMes = [];
    this.gGMMesAno = [];
    this.gGMDataValor = [];
    this.gGMDataSobraMes = [];
    this.gGMCordoQuadrante = [];
    this.gGMDataValorRecebidoMes = [];
    this.centrosCustoVisual = [];
    this.mesAnoSelecionado = null;
    this.buscarInformacoesGastosMensais(dataDe, dataAte);
  }
  temRegistro(index) {
    return !!this.gGMCordoQuadrante[index];
  }
  selecionarMes(mesAno) {
    this.mesAnoSelecionado = mesAno;
    this.buscarInformacoesCentroCusto(mesAno);
  }
  buscarInformacoesGastosMensais(dataDe, dataAte) {
    this.loadingGastosMensais = true;
    this.saldoService.getGastosMensais(dataDe, dataAte).subscribe((item) => {
      if (!item || item.length === 0) {
        this.loadingGastosMensais = false;
        return;
      }
      for (let i = 0; i < item.length; i++) {
        this.gGMLabelMes.push(item[i].mes);
        this.gGMMesAno.push(item[i].mes + " - " + item[i].ano);
        this.gGMDataValor.push(item[i].valor);
        this.gGMDataSobraMes.push(item[i].sobraMes);
        this.gGMCordoQuadrante.push(this.getColor(item[i].sobraMes));
        this.gGMDataValorRecebidoMes.push(item[i].valorRecebidoMes);
      }
      this.loadingGastosMensais = false;
      const ultimoMes = this.gGMMesAno[this.gGMMesAno.length - 1];
      this.mesAnoSelecionado = ultimoMes;
      this.buscarInformacoesCentroCusto(ultimoMes);
    });
  }
  buscarInformacoesCentroCusto(mesAno) {
    this.loadingCentrosCusto = true;
    this.gastosCentroCustoService.getAllGastosCentroMesAno(mesAno).subscribe((item) => {
      this.chartInfoCC = item;
      this.gGCCValor = [];
      this.gGCCValorLimite = [];
      this.gGCCDescricao = [];
      this.gGCCmesAnoAtual = [];
      this.centrosCustoVisual = [];
      if (this.chartInfoCC != null) {
        for (let i = 0; i < this.chartInfoCC.length; i++) {
          const registro = this.chartInfoCC[i];
          this.gGCCValor.push(this.chartInfoCC[i].valor);
          this.gGCCValorLimite.push(this.chartInfoCC[i].valorLimite);
          this.gGCCDescricao.push(this.chartInfoCC[i].descricao);
          this.gGCCmesAnoAtual.push(this.chartInfoCC[i].mesAno);
          this.centrosCustoVisual.push({
            gasto: registro.valor,
            limite: registro.valorLimite,
            mesEAno: registro.mesAno,
            descricaoCentroCusto: registro.descricao
          });
          console.log(this.centrosCustoVisual);
        }
        this.loadingCentrosCusto = false;
      }
    });
  }
  getPercentual(item) {
    if (!item.limite)
      return 0;
    return Math.min(item.gasto / item.limite * 100);
  }
  getClasse(item) {
    const percentual = this.getPercentual(item);
    if (percentual > 100)
      return "estourado";
    if (percentual >= 80)
      return "alerta";
    return "ok";
  }
  formatarData(data) {
    const d = new Date(data);
    return d.toLocaleDateString("pt-BR") + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }
  /*
    trataMesAnoAtual() {
      let dataAtual = new Date().toLocaleDateString('pt-BR');
      let mes: string = dataAtual.toString().substring(3, 5);
      let ano: string = dataAtual.toString().substring(6, 10);
  
      switch (mes) {
        case "01": {
          mes = "Janeiro";
          break;
        }
        case "02": {
          mes = "Fevereiro";
          break;
        }
        case "03": {
          mes = "Março";
          break;
        }
        case "04": {
          mes = "Abril";
          break;
        }
        case "05": {
          mes = "Maio";
          break;
        }
        case "06": {
          mes = "Junho";
          break;
        }
        case "07": {
          mes = "Julho";
          break;
        }
        case "08": {
          mes = "Agosto";
          break;
        }
        case "09": {
          mes = "Setembro";
          break;
        }
        case "10": {
          mes = "Outubro";
          break;
        }
        case "11": {
          mes = "Novembro";
          break;
        }
        case "12": {
          mes = "Dezembro";
          break;
        }
  
      }
      let mesAno: string = mes + " - " + ano;
      return mesAno;
  
    }*/
  buscarDetalhamentoGastosCentroCusto(mesAno, desCC) {
    this.detalhamentoGastosCentroCusto.getAllDetalhamentoGastosCentroMesAno(mesAno, desCC).subscribe((item) => {
      this.detalhamentoGastosCC = [];
      if (item && item.length > 0) {
        this.detalhamentoGastosCC = item;
        this.popupAberto = true;
        document.body.classList.add("no-scroll");
      }
    });
  }
  getColor(valor) {
    return getColorForSobra(valor);
  }
  static {
    this.\u0275fac = function GraficosComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _GraficosComponent)(i08.\u0275\u0275directiveInject(GastosMensaisService), i08.\u0275\u0275directiveInject(GastosCentroCustoService), i08.\u0275\u0275directiveInject(DetalhamentoGastosCentroCustoService), i08.\u0275\u0275directiveInject(i4.FormBuilder));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i08.\u0275\u0275defineComponent({ type: _GraficosComponent, selectors: [["app-graficos"]], standalone: false, decls: 15, vars: 10, consts: [["picker", ""], ["registrosNaoEncontrados", ""], ["semRegistro", ""], [3, "formGroup"], ["appearance", "outline", 1, "campo-ano"], ["matInput", "", "formControlName", "ano", "readonly", "", 3, "matDatepicker"], ["matSuffix", "", 3, "for"], ["startView", "multi-year", 3, "yearSelected"], [4, "ngIf"], ["class", "grafico-calendario", 4, "ngIf"], ["class", "cc-card", 4, "ngFor", "ngForOf"], [3, "fechar", "aberto", "detalhamentoGastosCC"], [1, "grafico-calendario"], ["class", "calendario-linha", 4, "ngFor", "ngForOf"], [1, "calendario-linha"], [4, "ngFor", "ngForOf"], [1, "quadrante"], ["count", "4", "appearance", "line", 3, "theme"], ["class", "grafico-calendario", 4, "ngIf", "ngIfElse"], [4, "ngIf", "ngIfElse"], [1, "quadrante", 3, "click"], [1, "nome-mes"], [1, "valores"], [1, "quadrante", "quadrante-vazio"], [1, "sem-dados"], [1, "cc-card"], [1, "cc-header"], ["appearance", "line", 3, "theme"], [1, "cc-bar-container"], [1, "cc-percentual"], [1, "cc-header", 3, "click"], [1, "cc-nome"], [1, "cc-valor"], [1, "cc-bar", 3, "ngClass"], [1, "cc-limite"]], template: function GraficosComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i08.\u0275\u0275getCurrentView();
        i08.\u0275\u0275elementStart(0, "form", 3)(1, "mat-form-field", 4)(2, "mat-label");
        i08.\u0275\u0275text(3, "Ano");
        i08.\u0275\u0275elementEnd();
        i08.\u0275\u0275element(4, "input", 5)(5, "mat-datepicker-toggle", 6);
        i08.\u0275\u0275elementStart(6, "mat-datepicker", 7, 0);
        i08.\u0275\u0275listener("yearSelected", function GraficosComponent_Template_mat_datepicker_yearSelected_6_listener($event) {
          i08.\u0275\u0275restoreView(_r1);
          const picker_r2 = i08.\u0275\u0275reference(7);
          return i08.\u0275\u0275resetView(ctx.anoSelecionado($event, picker_r2));
        });
        i08.\u0275\u0275elementEnd();
        i08.\u0275\u0275template(8, GraficosComponent_mat_error_8_Template, 2, 0, "mat-error", 8);
        i08.\u0275\u0275elementEnd()();
        i08.\u0275\u0275template(9, GraficosComponent_div_9_Template, 2, 2, "div", 9)(10, GraficosComponent_ng_container_10_Template, 4, 2, "ng-container", 8);
        i08.\u0275\u0275element(11, "br");
        i08.\u0275\u0275template(12, GraficosComponent_ng_container_12_Template, 2, 2, "ng-container", 8)(13, GraficosComponent_div_13_Template, 14, 18, "div", 10);
        i08.\u0275\u0275elementStart(14, "app-pop-up-centro-custo", 11);
        i08.\u0275\u0275listener("fechar", function GraficosComponent_Template_app_pop_up_centro_custo_fechar_14_listener() {
          i08.\u0275\u0275restoreView(_r1);
          return i08.\u0275\u0275resetView(ctx.popupAberto = false);
        });
        i08.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        const picker_r2 = i08.\u0275\u0275reference(7);
        i08.\u0275\u0275property("formGroup", ctx.form);
        i08.\u0275\u0275advance(4);
        i08.\u0275\u0275property("matDatepicker", picker_r2);
        i08.\u0275\u0275advance();
        i08.\u0275\u0275property("for", picker_r2);
        i08.\u0275\u0275advance(3);
        i08.\u0275\u0275property("ngIf", ctx.ano.invalid);
        i08.\u0275\u0275advance();
        i08.\u0275\u0275property("ngIf", ctx.loadingGastosMensais);
        i08.\u0275\u0275advance();
        i08.\u0275\u0275property("ngIf", !ctx.loadingGastosMensais);
        i08.\u0275\u0275advance(2);
        i08.\u0275\u0275property("ngIf", ctx.loadingCentrosCusto);
        i08.\u0275\u0275advance();
        i08.\u0275\u0275property("ngForOf", ctx.centrosCustoVisual);
        i08.\u0275\u0275advance();
        i08.\u0275\u0275property("aberto", ctx.popupAberto)("detalhamentoGastosCC", ctx.detalhamentoGastosCC);
      }
    }, styles: ["\n\n.chart-wrapper[_ngcontent-%COMP%] {\n  width: 100%;\n  overflow-x: auto;\n  -webkit-overflow-scrolling: touch;\n}\n.chart-container-gcc[_ngcontent-%COMP%] {\n  width: 1000px;\n}\n.chart-container-gmcc[_ngcontent-%COMP%] {\n  width: 1500px;\n}\ncanvas[_ngcontent-%COMP%] {\n  width: 100%;\n  height: auto;\n}\nth[_ngcontent-%COMP%] {\n  font-family: Arial, sans-serif;\n  font-size: 11px;\n  background-color: #302f2f;\n}\ntd[_ngcontent-%COMP%] {\n  font-family: Arial, sans-serif;\n  font-size: 11px;\n  color: #616161;\n}\n.botao-editar[_ngcontent-%COMP%] {\n  background-color: #e7e7fd;\n}\n.botao-remover[_ngcontent-%COMP%] {\n  background-color: #fda6a6;\n}\n@media (max-width: 600px) {\n  .campo-ano[_ngcontent-%COMP%] {\n    display: flex;\n    width: auto;\n  }\n}\n.grafico-calendario[_ngcontent-%COMP%] {\n  display: block;\n  width: auto;\n  height: auto;\n  align-items: center;\n  justify-content: center;\n  border-color: #c7c7c7;\n  border-radius: 8px;\n}\n.calendario-linha[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: auto;\n  border-radius: 8px;\n  gap: 1px;\n}\n.quadrante[_ngcontent-%COMP%] {\n  display: block;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 100px;\n  border-color: #727272;\n  border-radius: 8px;\n  cursor: pointer;\n}\n.quadrante[_ngcontent-%COMP%]:hover {\n  border: 2px solid #4e78b8;\n  border-top-right-radius: 10px;\n  border-top-left-radius: 10px;\n}\n.quadrante-selecionado[_ngcontent-%COMP%] {\n  border: 2px solid #4e78b8;\n  border-top-right-radius: 10px;\n  border-top-left-radius: 10px;\n}\n.nome-mes[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: auto;\n  height: 15px;\n  border-top-right-radius: 8px;\n  border-top-left-radius: 8px;\n  background-color: #000000;\n  color: #ffffff;\n  font-size: 12px;\n  gap: 2px;\n}\n.valores[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 10px;\n  margin: 3px;\n  padding: 0;\n}\n.quadrante-vazio[_ngcontent-%COMP%] {\n  background-color: #f0f0f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.sem-dados[_ngcontent-%COMP%] {\n  font-size: 24px;\n  font-weight: bold;\n  color: #999;\n}\n.cc-card[_ngcontent-%COMP%] {\n  padding: 12px;\n  border-radius: 8px;\n  background: #ffffff;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n  margin-bottom: 12px;\n}\n.cc-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  font-size: 14px;\n  margin-bottom: 6px;\n}\n.cc-nome[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n.cc-valor[_ngcontent-%COMP%] {\n  color: #666;\n}\n.cc-bar-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: 10px;\n  background: #eaeaea;\n  border-radius: 5px;\n  overflow: hidden;\n}\n.cc-bar[_ngcontent-%COMP%] {\n  height: 100%;\n  border-radius: 5px;\n  transition: width 0.3s ease;\n}\n.cc-bar.ok[_ngcontent-%COMP%] {\n  background-color: #4caf50;\n}\n.cc-bar.alerta[_ngcontent-%COMP%] {\n  background-color: #ffc107;\n}\n.cc-bar.estourado[_ngcontent-%COMP%] {\n  background-color: #f44336;\n}\n.cc-limite[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  width: 2px;\n  background: #555;\n}\n.cc-percentual[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #777;\n  text-align: right;\n  margin-top: 4px;\n}\n/*# sourceMappingURL=graficos.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(GraficosComponent, { className: "GraficosComponent", filePath: "src/app/pages/graficos/graficos.component.ts", lineNumber: 14 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fgraficos%2Fgraficos.component.ts%40GraficosComponent";
  function GraficosComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i08.\u0275\u0275replaceMetadata(GraficosComponent, m.default, [i08, gastos_mensais_service_exports, gastos_centro_custo_service_exports, detalhamento_gastos_centro_custo_service_exports, i4], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && GraficosComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && GraficosComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamentos/novo-lancamento/novo-lancamento.component.ts
var novo_lancamento_component_exports = {};
__export(novo_lancamento_component_exports, {
  NovoLancamentoComponent: () => NovoLancamentoComponent
});
import { Component as Component4 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i010 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/lancamento/lancamento.service.ts
var lancamento_service_exports = {};
__export(lancamento_service_exports, {
  LancamentoService: () => LancamentoService
});
import { Injectable as Injectable6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError5, throwError as throwError5 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i09 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i16 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var LancamentoService = class _LancamentoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getAllLancamentos() {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/lancamentos/usuario/${idUsuario}`).pipe(catchError5((error) => {
      return throwError5(error);
    }));
  }
  getLancamentoPorId(id) {
    return this.http.get(`${this.baseApiUrl}api/lancamentos/${id}`).pipe(catchError5((error) => {
      return throwError5(error);
    }));
  }
  getLancamentoDataDeAte(dataDe, dataAte, status, idCentroCusto) {
    const idUsuario = this.loginService.getIdUsuario();
    const url = `${this.baseApiUrl}api/lancamentos/dataDeAte?idUsuario=${idUsuario}&dataDe=${dataDe}&dataAte=${dataAte}&status=${status}&idCentroCusto=${idCentroCusto}`;
    console.log(url);
    return this.http.get(url).pipe(catchError5((error) => {
      return throwError5(error);
    }));
  }
  postLancamento(formData) {
    var dataLancamento = /* @__PURE__ */ new Date(formData.getAll("dataHora").toString() + "Z");
    var data = {
      dataHora: dataLancamento,
      valor: Number(formData.getAll("valor")),
      descricao: formData.getAll("descricao").toString().trim(),
      status: formData.getAll("status").toString(),
      idCCusto: Number(formData.getAll("idCCusto")),
      idUsuario: Number(formData.getAll("idUsuario"))
    };
    console.log(data);
    return this.http.post(`${this.baseApiUrl}api/lancamentos`, data).pipe(catchError5((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao criar lan\xE7amento: ${error.status}`, void 0);
      return throwError5(error);
    }));
  }
  excluirLancamento(id) {
    var data = {
      deletado: "*"
    };
    return this.http.put(`${this.baseApiUrl}api/lancamentos/del/${id}`, data).pipe(catchError5((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao excluir lan\xE7amento: ${error.status}`, void 0);
      return throwError5(error);
    }));
  }
  putLancamento(id, formData) {
    var dataLancamento = /* @__PURE__ */ new Date(formData.getAll("dataHora").toString() + "Z");
    console.log(Number(formData.getAll("valor")));
    var data = {
      dataHora: dataLancamento,
      valor: Number(formData.getAll("valor")),
      descricao: formData.getAll("descricao").toString().trim(),
      status: formData.getAll("status").toString(),
      idCCusto: Number(formData.getAll("idCCusto")),
      idUsuario: Number(formData.getAll("idUsuario"))
    };
    return this.http.put(`${this.baseApiUrl}api/lancamentos/${id}`, data).pipe(catchError5((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao atualizar lan\xE7amento: ${error.status}`, void 0);
      return throwError5(error);
    }));
  }
  getExisteCentroCusto(idUsuario, idCentroCusto) {
    return this.http.get(`${this.baseApiUrl}api/lancamentos/usuario/${idUsuario}/idcentrocusto/${idCentroCusto}`).pipe(catchError5((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao verificar centro de custo: ${error.status}`, void 0);
      return throwError5(error);
    }));
  }
  static {
    this.\u0275fac = function LancamentoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LancamentoService)(i09.\u0275\u0275inject(i16.HttpClient), i09.\u0275\u0275inject(LoginService), i09.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i09.\u0275\u0275defineInjectable({ token: _LancamentoService, factory: _LancamentoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/pages/lancamentos/novo-lancamento/novo-lancamento.component.ts
import * as i2 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
var NovoLancamentoComponent = class _NovoLancamentoComponent {
  constructor(lancamentoService, router, loginService) {
    this.lancamentoService = lancamentoService;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Registrar";
  }
  ngOnInit() {
  }
  createHandler(lancamento) {
    return __async(this, null, function* () {
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("dataHora", lancamento.dataHora.toString());
      formData.append("valor", lancamento.valor.toString());
      formData.append("descricao", lancamento.descricao);
      formData.append("status", lancamento.status);
      formData.append("idCCusto", lancamento.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      console.log(lancamento.dataHora);
      console.log(formData.getAll("dataHora"));
      console.log(formData.getAll("valor"));
      console.log(formData.getAll("descricao"));
      console.log(formData.getAll("status"));
      console.log(formData.getAll("idCCusto"));
      console.log(formData.getAll("idUsuario"));
      yield this.lancamentoService.postLancamento(formData).subscribe((result) => {
        this.router.navigate(["/"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function NovoLancamentoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NovoLancamentoComponent)(i010.\u0275\u0275directiveInject(LancamentoService), i010.\u0275\u0275directiveInject(i2.Router), i010.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i010.\u0275\u0275defineComponent({ type: _NovoLancamentoComponent, selectors: [["app-novo-lancamento"]], standalone: false, decls: 5, vars: 1, consts: [[3, "onSubmit", "btnText"]], template: function NovoLancamentoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i010.\u0275\u0275elementStart(0, "h2");
        i010.\u0275\u0275text(1, "Registre o seu ");
        i010.\u0275\u0275elementStart(2, "span");
        i010.\u0275\u0275text(3, "Lan\xE7amento");
        i010.\u0275\u0275elementEnd()();
        i010.\u0275\u0275elementStart(4, "app-lancamento-form", 0);
        i010.\u0275\u0275listener("onSubmit", function NovoLancamentoComponent_Template_app_lancamento_form_onSubmit_4_listener($event) {
          return ctx.createHandler($event);
        });
        i010.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        i010.\u0275\u0275advance(4);
        i010.\u0275\u0275property("btnText", ctx.btnText);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=novo-lancamento.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassDebugInfo(NovoLancamentoComponent, { className: "NovoLancamentoComponent", filePath: "src/app/pages/lancamentos/novo-lancamento/novo-lancamento.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamentos%2Fnovo-lancamento%2Fnovo-lancamento.component.ts%40NovoLancamentoComponent";
  function NovoLancamentoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i010.\u0275\u0275replaceMetadata(NovoLancamentoComponent, m.default, [i010, lancamento_service_exports, i2, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && NovoLancamentoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && NovoLancamentoComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/lancamento-form/lancamento-form.component.ts
var lancamento_form_component_exports = {};
__export(lancamento_form_component_exports, {
  LancamentoFormComponent: () => LancamentoFormComponent
});
import { Component as Component5, Input, Output, EventEmitter } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { FormControl, FormGroup, Validators as Validators2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i012 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/cetro-custo/centro-custo.service.ts
var centro_custo_service_exports = {};
__export(centro_custo_service_exports, {
  CentroCustoService: () => CentroCustoService
});
import { Injectable as Injectable7 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError6, throwError as throwError6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i011 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i17 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var CentroCustoService = class _CentroCustoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getAllCentroCustos() {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/centrocustos/usuario/${idUsuario}`).pipe(catchError6((error) => {
      return throwError6(error);
    }));
  }
  getIdCentroCustos(id) {
    return this.http.get(`${this.baseApiUrl}api/centrocustos/${id}`).pipe(catchError6((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao buscar centro de custo: ${error.status}`, void 0);
      return throwError6(error);
    }));
  }
  postCentroCusto(formData) {
    var data = {
      descriCCusto: formData.getAll("descriCCusto").toString().trim(),
      valorLimite: Number(formData.getAll("valorLimite")),
      idUsuario: Number(formData.getAll("idUsuario"))
    };
    console.log("Data: ");
    console.log(data);
    return this.http.post(`${this.baseApiUrl}api/centrocustos`, data).pipe(catchError6((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao criar centro de custo: ${error.status}`, void 0);
      return throwError6(error);
    }));
  }
  putCentroCustos(id, formData) {
    var data = {
      descriCCusto: formData.getAll("descriCCusto").toString().trim(),
      valorLimite: Number(formData.getAll("valorLimite"))
    };
    return this.http.put(`${this.baseApiUrl}api/centrocustos/${id}`, data).pipe(catchError6((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao atualizar centro de custo: ${error.status}`, void 0);
      return throwError6(error);
    }));
  }
  excluirCentroCusto(id) {
    var data = {
      deletado: "*"
    };
    return this.http.put(`${this.baseApiUrl}api/centrocustos/del/${id}`, data).pipe(catchError6((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao excluir centro de custo: ${error.status}`, void 0);
      return throwError6(error);
    }));
  }
  static {
    this.\u0275fac = function CentroCustoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _CentroCustoService)(i011.\u0275\u0275inject(i17.HttpClient), i011.\u0275\u0275inject(LoginService), i011.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i011.\u0275\u0275defineInjectable({ token: _CentroCustoService, factory: _CentroCustoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/components/lancamento-form/lancamento-form.component.ts
function LancamentoFormComponent_div_8_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "p");
    i012.\u0275\u0275text(1, "A data \xE9 obrigat\xF3ria.");
    i012.\u0275\u0275elementEnd();
  }
}
function LancamentoFormComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 20);
    i012.\u0275\u0275template(1, LancamentoFormComponent_div_8_p_1_Template, 2, 0, "p", 21);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance();
    i012.\u0275\u0275property("ngIf", ctx_r1.dataHora.errors == null ? null : ctx_r1.dataHora.errors["required"]);
  }
}
function LancamentoFormComponent_div_13_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "p");
    i012.\u0275\u0275text(1, "O valor \xE9 obrigat\xF3ria.");
    i012.\u0275\u0275elementEnd();
  }
}
function LancamentoFormComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 20);
    i012.\u0275\u0275template(1, LancamentoFormComponent_div_13_p_1_Template, 2, 0, "p", 21);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance();
    i012.\u0275\u0275property("ngIf", ctx_r1.valor.errors == null ? null : ctx_r1.valor.errors["required"]);
  }
}
function LancamentoFormComponent_div_18_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "p");
    i012.\u0275\u0275text(1, "A descri\xE7\xE3o \xE9 obrigat\xF3ria.");
    i012.\u0275\u0275elementEnd();
  }
}
function LancamentoFormComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 20);
    i012.\u0275\u0275template(1, LancamentoFormComponent_div_18_p_1_Template, 2, 0, "p", 21);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance();
    i012.\u0275\u0275property("ngIf", ctx_r1.descricao.errors == null ? null : ctx_r1.descricao.errors["required"]);
  }
}
function LancamentoFormComponent_option_35_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "option", 22);
    i012.\u0275\u0275text(1);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const centroCusto_r3 = ctx.$implicit;
    i012.\u0275\u0275propertyInterpolate("value", centroCusto_r3.id);
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate(centroCusto_r3.descriCCusto);
  }
}
function LancamentoFormComponent_div_36_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "p");
    i012.\u0275\u0275text(1, "O centro de custo \xE9 obrigat\xF3ria.");
    i012.\u0275\u0275elementEnd();
  }
}
function LancamentoFormComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 20);
    i012.\u0275\u0275template(1, LancamentoFormComponent_div_36_p_1_Template, 2, 0, "p", 21);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance();
    i012.\u0275\u0275property("ngIf", ctx_r1.idCCusto.errors == null ? null : ctx_r1.idCCusto.errors["required"]);
  }
}
var LancamentoFormComponent = class _LancamentoFormComponent {
  constructor(centroCustoService) {
    this.centroCustoService = centroCustoService;
    this.onSubmit = new EventEmitter();
    this.lancamentoData = null;
    this.centroCustos = [];
  }
  ngOnInit() {
    this.lancamentoForm = new FormGroup({
      id: new FormControl(this.lancamentoData ? this.lancamentoData.id : ""),
      dataHora: new FormControl(this.lancamentoData ? this.lancamentoData.dataHora : this.getDataHoraAtual(), [Validators2.required]),
      valor: new FormControl(this.lancamentoData ? this.formatValorInicial(this.lancamentoData.valor) : "", [Validators2.required]),
      descricao: new FormControl(this.lancamentoData ? this.lancamentoData.descricao : "", [Validators2.required]),
      status: new FormControl(this.lancamentoData ? this.lancamentoData.status : "", [Validators2.required]),
      idCCusto: new FormControl(this.lancamentoData ? this.lancamentoData.idCCusto : "", [Validators2.required])
    });
    this.centroCustoService.getAllCentroCustos().subscribe((centroCustos) => this.centroCustos = centroCustos);
  }
  // Formata o valor inicial quando carregado da API
  formatValorInicial(valor) {
    let valorStr = valor.toString().replace(".", ",");
    let partes = valorStr.split(",");
    let inteiro = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let decimal = partes[1] ? partes[1].padEnd(2, "0") : "00";
    return `${inteiro},${decimal}`;
  }
  formatValor() {
    let valor = this.valor.value.replace(/\D/g, "");
    if (valor.length === 0) {
      this.lancamentoForm.controls["valor"].setValue("", { emitEvent: false });
      return;
    }
    valor = valor.replace(/^0+(?!$)/, "");
    if (valor.length <= 2) {
      this.lancamentoForm.controls["valor"].setValue(`0,${valor.padStart(2, "0")}`, { emitEvent: false });
      return;
    }
    let inteiro = valor.slice(0, -2);
    let decimal = valor.slice(-2);
    inteiro = inteiro.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let valorFormatado = `${inteiro},${decimal}`;
    this.lancamentoForm.controls["valor"].setValue(valorFormatado, { emitEvent: false });
  }
  getDataHoraAtual() {
    const now = /* @__PURE__ */ new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  }
  get dataHora() {
    return this.lancamentoForm.get("dataHora");
  }
  get valor() {
    return this.lancamentoForm.get("valor");
  }
  get descricao() {
    return this.lancamentoForm.get("descricao");
  }
  get status() {
    return this.lancamentoForm.get("status");
  }
  get idCCusto() {
    return this.lancamentoForm.get("idCCusto");
  }
  get idUsuario() {
    return this.lancamentoForm.get("idUsuario");
  }
  submit() {
    if (this.lancamentoForm.invalid) {
      return;
    }
    let valorFormatado = String(this.valor.value).replace(/\./g, "").replace(",", ".");
    let lancamentoFormatado = __spreadProps(__spreadValues({}, this.lancamentoForm.value), {
      valor: valorFormatado
    });
    this.onSubmit.emit(lancamentoFormatado);
  }
  static {
    this.\u0275fac = function LancamentoFormComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LancamentoFormComponent)(i012.\u0275\u0275directiveInject(CentroCustoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i012.\u0275\u0275defineComponent({ type: _LancamentoFormComponent, selectors: [["app-lancamento-form"]], inputs: { btnText: "btnText", lancamentoData: "lancamentoData" }, outputs: { onSubmit: "onSubmit" }, standalone: false, decls: 38, vars: 7, consts: [["formDir", "ngForm"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["type", "hidden", "formControlName", "id"], ["for", "dataHora"], ["type", "datetime-local", "placeholder", "Coloque a data do Lan\xE7amento", "formControlName", "dataHora", "required", ""], ["class", "validation-error", 4, "ngIf"], ["for", "valor"], ["type", "text", "inputmode", "numeric", "placeholder", "Coloque o valor do Lan\xE7amento", "formControlName", "valor", "required", "", 3, "input"], ["for", "description"], ["placeholder", "Descri\xE7\xE3o do Lancamento", "formControlName", "descricao", "required", ""], ["for", "status"], ["formControlName", "status", "required", ""], ["value", "A Receber"], ["value", "A Pagar"], ["value", "Recebido"], ["value", "Pago"], ["formControlName", "idCCusto", "required", ""], [3, "value", 4, "ngFor", "ngForOf"], ["type", "submit", 3, "value"], [1, "validation-error"], [4, "ngIf"], [3, "value"]], template: function LancamentoFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i012.\u0275\u0275getCurrentView();
        i012.\u0275\u0275elementStart(0, "form", 1, 0);
        i012.\u0275\u0275listener("ngSubmit", function LancamentoFormComponent_Template_form_ngSubmit_0_listener() {
          i012.\u0275\u0275restoreView(_r1);
          return i012.\u0275\u0275resetView(ctx.submit());
        });
        i012.\u0275\u0275elementStart(2, "div", 2);
        i012.\u0275\u0275element(3, "input", 3);
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(4, "div", 2)(5, "label", 4);
        i012.\u0275\u0275text(6, "Data:");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275element(7, "input", 5);
        i012.\u0275\u0275template(8, LancamentoFormComponent_div_8_Template, 2, 1, "div", 6);
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(9, "div", 2)(10, "label", 7);
        i012.\u0275\u0275text(11, "Valor:");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(12, "input", 8);
        i012.\u0275\u0275listener("input", function LancamentoFormComponent_Template_input_input_12_listener() {
          i012.\u0275\u0275restoreView(_r1);
          return i012.\u0275\u0275resetView(ctx.formatValor());
        });
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275template(13, LancamentoFormComponent_div_13_Template, 2, 1, "div", 6);
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(14, "div", 2)(15, "label", 9);
        i012.\u0275\u0275text(16, "Descri\xE7\xE3o:");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275element(17, "textarea", 10);
        i012.\u0275\u0275template(18, LancamentoFormComponent_div_18_Template, 2, 1, "div", 6);
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(19, "div", 2)(20, "label", 11);
        i012.\u0275\u0275text(21, "Status:");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(22, "select", 12)(23, "option", 13);
        i012.\u0275\u0275text(24, "A Receber");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(25, "option", 14);
        i012.\u0275\u0275text(26, "A Pagar");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(27, "option", 15);
        i012.\u0275\u0275text(28, "Recebido");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(29, "option", 16);
        i012.\u0275\u0275text(30, "Pago");
        i012.\u0275\u0275elementEnd()()();
        i012.\u0275\u0275elementStart(31, "div", 2)(32, "label", 11);
        i012.\u0275\u0275text(33, "Centro Custo:");
        i012.\u0275\u0275elementEnd();
        i012.\u0275\u0275elementStart(34, "select", 17);
        i012.\u0275\u0275template(35, LancamentoFormComponent_option_35_Template, 2, 2, "option", 18);
        i012.\u0275\u0275elementEnd()();
        i012.\u0275\u0275template(36, LancamentoFormComponent_div_36_Template, 2, 1, "div", 6);
        i012.\u0275\u0275element(37, "input", 19);
        i012.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        const formDir_r4 = i012.\u0275\u0275reference(1);
        i012.\u0275\u0275property("formGroup", ctx.lancamentoForm);
        i012.\u0275\u0275advance(8);
        i012.\u0275\u0275property("ngIf", ctx.dataHora.invalid && formDir_r4.submitted);
        i012.\u0275\u0275advance(5);
        i012.\u0275\u0275property("ngIf", ctx.valor.invalid && formDir_r4.submitted);
        i012.\u0275\u0275advance(5);
        i012.\u0275\u0275property("ngIf", ctx.descricao.invalid && formDir_r4.submitted);
        i012.\u0275\u0275advance(17);
        i012.\u0275\u0275property("ngForOf", ctx.centroCustos);
        i012.\u0275\u0275advance();
        i012.\u0275\u0275property("ngIf", ctx.idCCusto.invalid && formDir_r4.submitted);
        i012.\u0275\u0275advance();
        i012.\u0275\u0275propertyInterpolate("value", ctx.btnText);
      }
    }, styles: ["\n\nform[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 500px;\n  margin: 0 auto;\n  padding: 15px;\n  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  background-color: #fff;\n}\n.form-group[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n}\nlabel[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-weight: bold;\n}\ninput[type=text][_ngcontent-%COMP%], \ninput[type=datetime-local][_ngcontent-%COMP%], \ntextarea[_ngcontent-%COMP%], \nselect[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  margin-top: 5px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  box-sizing: border-box;\n}\ninput[type=datetime-local][_ngcontent-%COMP%] {\n  -webkit-appearance: none;\n  appearance: none;\n  min-width: 0;\n}\ntextarea[_ngcontent-%COMP%] {\n  resize: vertical;\n}\n.validation-error[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 0.875em;\n  margin-top: 5px;\n}\ninput[type=submit][_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  background-color: #28a745;\n  color: #fff;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 1em;\n}\ninput[type=submit][_ngcontent-%COMP%]:hover {\n  background-color: #218838;\n}\n@media (max-width: 600px) {\n  form[_ngcontent-%COMP%] {\n    padding: 10px;\n  }\n  label[_ngcontent-%COMP%], \n   input[type=text][_ngcontent-%COMP%], \n   input[type=datetime-local][_ngcontent-%COMP%], \n   textarea[_ngcontent-%COMP%], \n   select[_ngcontent-%COMP%], \n   input[type=submit][_ngcontent-%COMP%] {\n    font-size: 1em;\n  }\n}\n/*# sourceMappingURL=lancamento-form.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(LancamentoFormComponent, { className: "LancamentoFormComponent", filePath: "src/app/components/lancamento-form/lancamento-form.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Flancamento-form%2Flancamento-form.component.ts%40LancamentoFormComponent";
  function LancamentoFormComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i012.\u0275\u0275replaceMetadata(LancamentoFormComponent, m.default, [i012, centro_custo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && LancamentoFormComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && LancamentoFormComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamentos/edit-lancamento/edit-lancamento.component.ts
var edit_lancamento_component_exports = {};
__export(edit_lancamento_component_exports, {
  EditLancamentoComponent: () => EditLancamentoComponent
});
import { Component as Component6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i013 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i22 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function EditLancamentoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i013.\u0275\u0275getCurrentView();
    i013.\u0275\u0275elementStart(0, "div")(1, "h2")(2, "span");
    i013.\u0275\u0275text(3, "Editar");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(4, " Lancamento ");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275elementStart(5, "app-lancamento-form", 1);
    i013.\u0275\u0275listener("onSubmit", function EditLancamentoComponent_div_0_Template_app_lancamento_form_onSubmit_5_listener($event) {
      i013.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i013.\u0275\u0275nextContext();
      return i013.\u0275\u0275resetView(ctx_r1.editHendler($event));
    });
    i013.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i013.\u0275\u0275nextContext();
    i013.\u0275\u0275advance(5);
    i013.\u0275\u0275property("lancamentoData", ctx_r1.lancamento)("btnText", ctx_r1.btnText);
  }
}
var EditLancamentoComponent = class _EditLancamentoComponent {
  constructor(lancamentoService, route, router, loginService) {
    this.lancamentoService = lancamentoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Confirmar";
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.lancamentoService.getLancamentoPorId(id).subscribe((item) => {
      this.lancamento = item;
      console.log(this.lancamento.dataHora);
    });
  }
  editHendler(lancamentoData) {
    return __async(this, null, function* () {
      const id = this.lancamento.id;
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("dataHora", lancamentoData.dataHora.toString());
      formData.append("valor", lancamentoData.valor.toString());
      formData.append("descricao", lancamentoData.descricao);
      formData.append("status", lancamentoData.status);
      formData.append("idCCusto", lancamentoData.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      yield this.lancamentoService.putLancamento(id, formData).subscribe((result) => {
        this.router.navigate(["/"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function EditLancamentoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _EditLancamentoComponent)(i013.\u0275\u0275directiveInject(LancamentoService), i013.\u0275\u0275directiveInject(i22.ActivatedRoute), i013.\u0275\u0275directiveInject(i22.Router), i013.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i013.\u0275\u0275defineComponent({ type: _EditLancamentoComponent, selectors: [["app-edit-lancamento"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "lancamentoData", "btnText"]], template: function EditLancamentoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i013.\u0275\u0275template(0, EditLancamentoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i013.\u0275\u0275property("ngIf", ctx.lancamento);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=edit-lancamento.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassDebugInfo(EditLancamentoComponent, { className: "EditLancamentoComponent", filePath: "src/app/pages/lancamentos/edit-lancamento/edit-lancamento.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamentos%2Fedit-lancamento%2Fedit-lancamento.component.ts%40EditLancamentoComponent";
  function EditLancamentoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i013.\u0275\u0275replaceMetadata(EditLancamentoComponent, m.default, [i013, lancamento_service_exports, i22, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && EditLancamentoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && EditLancamentoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamentos/excluir-lancamento/excluir-lancamento.component.ts
var excluir_lancamento_component_exports = {};
__export(excluir_lancamento_component_exports, {
  ExcluirLancamentoComponent: () => ExcluirLancamentoComponent
});
import { Component as Component7 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i014 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i23 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function ExcluirLancamentoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i014.\u0275\u0275getCurrentView();
    i014.\u0275\u0275elementStart(0, "div")(1, "h2");
    i014.\u0275\u0275text(2, " Excluir ");
    i014.\u0275\u0275elementStart(3, "span");
    i014.\u0275\u0275text(4, "Lancamento");
    i014.\u0275\u0275elementEnd()();
    i014.\u0275\u0275elementStart(5, "app-lancamento-form", 1);
    i014.\u0275\u0275listener("onSubmit", function ExcluirLancamentoComponent_div_0_Template_app_lancamento_form_onSubmit_5_listener($event) {
      i014.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i014.\u0275\u0275nextContext();
      return i014.\u0275\u0275resetView(ctx_r1.excluirHendler($event));
    });
    i014.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i014.\u0275\u0275nextContext();
    i014.\u0275\u0275advance(5);
    i014.\u0275\u0275property("lancamentoData", ctx_r1.lancamento)("btnText", ctx_r1.btnText);
  }
}
var ExcluirLancamentoComponent = class _ExcluirLancamentoComponent {
  constructor(lancamentoService, route, router, loginService) {
    this.lancamentoService = lancamentoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Remover";
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.lancamentoService.getLancamentoPorId(id).subscribe((item) => {
      this.lancamento = item;
      console.log(this.lancamento.dataHora);
    });
  }
  excluirHendler(lancamentoData) {
    return __async(this, null, function* () {
      const id = this.lancamento.id;
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("dataHora", lancamentoData.dataHora.toString());
      formData.append("valor", lancamentoData.valor.toString());
      formData.append("descricao", lancamentoData.descricao);
      formData.append("status", lancamentoData.status);
      formData.append("idCCusto", lancamentoData.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      yield this.lancamentoService.excluirLancamento(this.lancamento.id).subscribe((result) => {
        this.router.navigate(["/"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function ExcluirLancamentoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ExcluirLancamentoComponent)(i014.\u0275\u0275directiveInject(LancamentoService), i014.\u0275\u0275directiveInject(i23.ActivatedRoute), i014.\u0275\u0275directiveInject(i23.Router), i014.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i014.\u0275\u0275defineComponent({ type: _ExcluirLancamentoComponent, selectors: [["app-excluir-lancamento"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "lancamentoData", "btnText"]], template: function ExcluirLancamentoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i014.\u0275\u0275template(0, ExcluirLancamentoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i014.\u0275\u0275property("ngIf", ctx.lancamento);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=excluir-lancamento.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassDebugInfo(ExcluirLancamentoComponent, { className: "ExcluirLancamentoComponent", filePath: "src/app/pages/lancamentos/excluir-lancamento/excluir-lancamento.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamentos%2Fexcluir-lancamento%2Fexcluir-lancamento.component.ts%40ExcluirLancamentoComponent";
  function ExcluirLancamentoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i014.\u0275\u0275replaceMetadata(ExcluirLancamentoComponent, m.default, [i014, lancamento_service_exports, i23, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && ExcluirLancamentoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && ExcluirLancamentoComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/saldos/saldos.component.ts
var saldos_component_exports = {};
__export(saldos_component_exports, {
  SaldosComponent: () => SaldosComponent
});
import { Component as Component8, Input as Input2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i016 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/saldo/saldo.service.ts
var saldo_service_exports = {};
__export(saldo_service_exports, {
  SaldoService: () => SaldoService
});
import { Injectable as Injectable8 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { throwError as throwError7 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import { catchError as catchError7 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs_operators.js?v=6e2f77a0";
import * as i015 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i18 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var SaldoService = class _SaldoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getSaldos() {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/saldosinvestimentos/usuario/${idUsuario}`).pipe(catchError7((error) => {
      return throwError7(error);
    }));
  }
  static {
    this.\u0275fac = function SaldoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _SaldoService)(i015.\u0275\u0275inject(i18.HttpClient), i015.\u0275\u0275inject(LoginService), i015.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i015.\u0275\u0275defineInjectable({ token: _SaldoService, factory: _SaldoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/components/saldos/saldos.component.ts
var _c03 = () => [1, 2, 3];
var _c12 = () => [1, 2, 3, 4];
function SaldosComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i016.\u0275\u0275elementStart(0, "div", 9);
    i016.\u0275\u0275element(1, "div", 10)(2, "div", 11);
    i016.\u0275\u0275elementEnd();
  }
}
function SaldosComponent_div_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    i016.\u0275\u0275elementStart(0, "div", 12);
    i016.\u0275\u0275element(1, "div", 10)(2, "div", 11);
    i016.\u0275\u0275elementEnd();
  }
}
function SaldosComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    i016.\u0275\u0275elementStart(0, "div", 2)(1, "div", 3);
    i016.\u0275\u0275template(2, SaldosComponent_div_0_div_2_Template, 3, 0, "div", 4);
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(3, "div", 5);
    i016.\u0275\u0275template(4, SaldosComponent_div_0_div_4_Template, 3, 0, "div", 6);
    i016.\u0275\u0275elementStart(5, "div", 7);
    i016.\u0275\u0275element(6, "div", 8);
    i016.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    i016.\u0275\u0275advance(2);
    i016.\u0275\u0275property("ngForOf", i016.\u0275\u0275pureFunction0(2, _c03));
    i016.\u0275\u0275advance(2);
    i016.\u0275\u0275property("ngForOf", i016.\u0275\u0275pureFunction0(3, _c12));
  }
}
function SaldosComponent_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    i016.\u0275\u0275elementStart(0, "div", 2)(1, "div", 3)(2, "div", 13)(3, "p", 14);
    i016.\u0275\u0275text(4, "Saldo");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(5, "strong", 15);
    i016.\u0275\u0275text(6);
    i016.\u0275\u0275pipe(7, "formatValor");
    i016.\u0275\u0275elementEnd()();
    i016.\u0275\u0275elementStart(8, "div", 13)(9, "p", 14);
    i016.\u0275\u0275text(10, "Invest. Fixo");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(11, "strong", 15);
    i016.\u0275\u0275text(12);
    i016.\u0275\u0275pipe(13, "formatValor");
    i016.\u0275\u0275elementEnd()();
    i016.\u0275\u0275elementStart(14, "div", 13)(15, "p", 14);
    i016.\u0275\u0275text(16, "Invest. Vari\xE1vel");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(17, "strong", 15);
    i016.\u0275\u0275text(18);
    i016.\u0275\u0275pipe(19, "formatValor");
    i016.\u0275\u0275elementEnd()()();
    i016.\u0275\u0275elementStart(20, "div", 5)(21, "div", 16)(22, "div", 17)(23, "p", 18);
    i016.\u0275\u0275text(24, "A pagar");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(25, "strong", 19);
    i016.\u0275\u0275text(26);
    i016.\u0275\u0275pipe(27, "formatValor");
    i016.\u0275\u0275elementEnd()()();
    i016.\u0275\u0275elementStart(28, "div", 16)(29, "div", 17)(30, "p", 18);
    i016.\u0275\u0275text(31, "Pago");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(32, "strong", 19);
    i016.\u0275\u0275text(33);
    i016.\u0275\u0275pipe(34, "formatValor");
    i016.\u0275\u0275elementEnd()()();
    i016.\u0275\u0275elementStart(35, "div", 16)(36, "div", 17)(37, "p", 18);
    i016.\u0275\u0275text(38, "A receber");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(39, "strong", 19);
    i016.\u0275\u0275text(40);
    i016.\u0275\u0275pipe(41, "formatValor");
    i016.\u0275\u0275elementEnd()()();
    i016.\u0275\u0275elementStart(42, "div", 16)(43, "div", 17)(44, "p", 18);
    i016.\u0275\u0275text(45, "Recebido");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275elementStart(46, "strong", 19);
    i016.\u0275\u0275text(47);
    i016.\u0275\u0275pipe(48, "formatValor");
    i016.\u0275\u0275elementEnd()()();
    i016.\u0275\u0275element(49, "app-donut-chart", 20);
    i016.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i016.\u0275\u0275nextContext();
    i016.\u0275\u0275advance(6);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(7, 9, ctx_r0.saldo == null ? null : ctx_r0.saldo.saldo), "");
    i016.\u0275\u0275advance(6);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(13, 11, ctx_r0.saldo == null ? null : ctx_r0.saldo.investimentoFixo), "");
    i016.\u0275\u0275advance(6);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(19, 13, ctx_r0.saldo == null ? null : ctx_r0.saldo.investimentoVariavel), "");
    i016.\u0275\u0275advance(8);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(27, 15, ctx_r0.valorAPagar), "");
    i016.\u0275\u0275advance(7);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(34, 17, ctx_r0.valorPago), "");
    i016.\u0275\u0275advance(7);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(41, 19, ctx_r0.valorAReceber), "");
    i016.\u0275\u0275advance(7);
    i016.\u0275\u0275textInterpolate1("R$ ", i016.\u0275\u0275pipeBind1(48, 21, ctx_r0.valorRecebido), "");
    i016.\u0275\u0275advance(2);
    i016.\u0275\u0275property("despesasGraficoDonut", ctx_r0.despesasGraficoDonut)("receitasGraficoDonut", ctx_r0.receitasGraficoDonut);
  }
}
var SaldosComponent = class _SaldosComponent {
  constructor(saldoService) {
    this.saldoService = saldoService;
    this.valorAPagar = 0;
    this.valorPago = 0;
    this.valorAReceber = 0;
    this.valorRecebido = 0;
    this.isLoading = true;
  }
  ngOnInit() {
    this.saldoService.getSaldos().subscribe((item) => {
      this.saldo = item;
    });
  }
  static {
    this.\u0275fac = function SaldosComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _SaldosComponent)(i016.\u0275\u0275directiveInject(SaldoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i016.\u0275\u0275defineComponent({ type: _SaldosComponent, selectors: [["app-saldos"]], inputs: { valorAPagar: "valorAPagar", valorPago: "valorPago", valorAReceber: "valorAReceber", valorRecebido: "valorRecebido", despesasGraficoDonut: "despesasGraficoDonut", receitasGraficoDonut: "receitasGraficoDonut", isLoading: "isLoading" }, standalone: false, decls: 3, vars: 2, consts: [["saldosContent", ""], ["class", "container-saldos", 4, "ngIf", "ngIfElse"], [1, "container-saldos"], [1, "container-saldos-superior"], ["class", "quadrantes-saldos skeleton-card", 4, "ngFor", "ngForOf"], [1, "container-saldos-inferior"], ["class", "quadrante-saldos-saldo-filtro skeleton-card", 4, "ngFor", "ngForOf"], [1, "quadrante-saldos-grafico", "skeleton-chart"], [1, "skeleton-ring"], [1, "quadrantes-saldos", "skeleton-card"], [1, "skeleton-line", "skeleton-line-title"], [1, "skeleton-line", "skeleton-line-value"], [1, "quadrante-saldos-saldo-filtro", "skeleton-card"], [1, "quadrantes-saldos"], [1, "titulo-saldos"], [1, "resultado-saldos"], [1, "quadrante-saldos-saldo-filtro"], [1, "sessao-saldo-filtro"], [1, "filtro-titulo-saldos"], [1, "filtro-resultado-saldos"], [1, "quadrante-saldos-grafico", 3, "despesasGraficoDonut", "receitasGraficoDonut"]], template: function SaldosComponent_Template(rf, ctx) {
      if (rf & 1) {
        i016.\u0275\u0275template(0, SaldosComponent_div_0_Template, 7, 4, "div", 1)(1, SaldosComponent_ng_template_1_Template, 50, 23, "ng-template", null, 0, i016.\u0275\u0275templateRefExtractor);
      }
      if (rf & 2) {
        const saldosContent_r2 = i016.\u0275\u0275reference(2);
        i016.\u0275\u0275property("ngIf", ctx.isLoading)("ngIfElse", saldosContent_r2);
      }
    }, styles: ['\n\n.container-saldos[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 10px;\n  margin: 0;\n  padding: 0;\n  width: 100%;\n}\n.container-saldos-superior[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  gap: 12px;\n  width: 100%;\n}\n.container-saldos-inferior[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  gap: 12px;\n  width: 100%;\n}\n.quadrantes-saldos[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 100%;\n  border-radius: 8px;\n  background-color: #E6E7EB;\n  padding: 10px;\n}\n.quadrante-saldos-saldo-filtro[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 0;\n  min-height: 60px;\n  border-radius: 8px;\n  background-color: #E6E7EB;\n  padding: 10px;\n  flex: 1;\n}\n.sessao-saldo-filtro[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n  min-height: 100%;\n  text-align: center;\n}\n.quadrantes-saldos[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], \n.quadrantes-saldos[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], \n.quadrante-saldos-saldo-filtro[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], \n.quadrante-saldos-saldo-filtro[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], \n.sessao-saldo-filtro[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], \n.sessao-saldo-filtro[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  padding-top: 6px;\n  line-height: 1;\n}\n.titulo-saldos[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.filtro-titulo-saldos[_ngcontent-%COMP%] {\n  font-size: 11px;\n}\n.filtro-resultado-saldos[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n.resultado-saldos[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.quadrante-saldos-grafico[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background-color: rgba(215, 216, 220, 0.81);\n  border-radius: 8px;\n}\n.skeleton-card[_ngcontent-%COMP%], \n.skeleton-chart[_ngcontent-%COMP%] {\n  position: relative;\n  overflow: hidden;\n  background-color: #d9dbe2;\n}\n.skeleton-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  min-height: 74px;\n  min-width: 50px;\n  padding: 12px;\n}\n.skeleton-chart[_ngcontent-%COMP%] {\n  min-width: 40px;\n  min-height: 40px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.skeleton-line[_ngcontent-%COMP%] {\n  height: 10px;\n  border-radius: 999px;\n  background:\n    linear-gradient(\n      90deg,\n      #c8cad3,\n      #e3e5eb,\n      #c8cad3);\n  animation: _ngcontent-%COMP%_skeleton-shimmer 1.2s infinite;\n}\n.skeleton-line-title[_ngcontent-%COMP%] {\n  width: 65%;\n  height: 12px;\n}\n.skeleton-line-value[_ngcontent-%COMP%] {\n  width: 85%;\n  height: 12px;\n}\n.skeleton-ring[_ngcontent-%COMP%] {\n  width: 86px;\n  height: 86px;\n  border-radius: 50%;\n  border: 10px solid rgba(255, 255, 255, 0.45);\n  border-top-color: #ffffff;\n  animation: _ngcontent-%COMP%_skeleton-spin 1s linear infinite;\n}\n.skeleton-card[_ngcontent-%COMP%]::before, \n.skeleton-chart[_ngcontent-%COMP%]::before {\n  content: "";\n  position: absolute;\n  inset: 0;\n  background:\n    linear-gradient(\n      90deg,\n      transparent,\n      rgba(255, 255, 255, 0.6),\n      transparent);\n  transform: translateX(-100%);\n  animation: _ngcontent-%COMP%_skeleton-shimmer 1.2s infinite;\n}\n@keyframes _ngcontent-%COMP%_skeleton-shimmer {\n  100% {\n    transform: translateX(100%);\n  }\n}\n@keyframes _ngcontent-%COMP%_skeleton-spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n/*# sourceMappingURL=saldos.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i016.\u0275setClassDebugInfo(SaldosComponent, { className: "SaldosComponent", filePath: "src/app/components/saldos/saldos.component.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fsaldos%2Fsaldos.component.ts%40SaldosComponent";
  function SaldosComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i016.\u0275\u0275replaceMetadata(SaldosComponent, m.default, [i016, saldo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && SaldosComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && SaldosComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/login/login.component.ts
var login_component_exports = {};
__export(login_component_exports, {
  LoginComponent: () => LoginComponent
});
import { Component as Component9 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { Validators as Validators3 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i017 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i19 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i3 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function LoginComponent_small_7_Template(rf, ctx) {
  if (rf & 1) {
    i017.\u0275\u0275elementStart(0, "small");
    i017.\u0275\u0275text(1, " E-mail inv\xE1lido ");
    i017.\u0275\u0275elementEnd();
  }
}
function LoginComponent_small_12_Template(rf, ctx) {
  if (rf & 1) {
    i017.\u0275\u0275elementStart(0, "small");
    i017.\u0275\u0275text(1, " A senha deve ter pelo menos 6 caracteres ");
    i017.\u0275\u0275elementEnd();
  }
}
function LoginComponent_p_13_Template(rf, ctx) {
  if (rf & 1) {
    i017.\u0275\u0275elementStart(0, "p", 13);
    i017.\u0275\u0275text(1);
    i017.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i017.\u0275\u0275nextContext();
    i017.\u0275\u0275advance();
    i017.\u0275\u0275textInterpolate(ctx_r1.loginError);
  }
}
function LoginComponent_ng_container_15_Template(rf, ctx) {
  if (rf & 1) {
    i017.\u0275\u0275elementContainerStart(0);
    i017.\u0275\u0275text(1, " Entrar ");
    i017.\u0275\u0275elementContainerEnd();
  }
}
function LoginComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    i017.\u0275\u0275element(0, "span", 14);
    i017.\u0275\u0275text(1, " Entrando... ");
  }
}
var LoginComponent = class _LoginComponent {
  constructor(fb, loginService, router) {
    this.fb = fb;
    this.loginService = loginService;
    this.router = router;
    this.loginError = null;
    this.isLoading = false;
    this.loginForm = this.fb.group({
      email: ["", [Validators3.required, Validators3.email]],
      senha: ["", [Validators3.required, Validators3.minLength(6)]]
    });
  }
  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    this.loginError = null;
    this.isLoading = true;
    const loginData = this.loginForm.value;
    this.loginService.postLogin(loginData).subscribe((response) => {
      if (response && response.token && response.refreshToken) {
        this.loginService.storeTokens({
          token: response.token,
          refreshToken: response.refreshToken,
          idUsuario: response.idUsuario
        });
        this.isLoading = false;
        this.router.navigate(["/"]);
      } else {
        this.loginError = "E-mail ou senha inv\xE1lidos.";
        this.isLoading = false;
      }
    }, (error) => {
      this.loginError = "E-mail ou senha inv\xE1lidos.";
      this.isLoading = false;
    });
  }
  static {
    this.\u0275fac = function LoginComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LoginComponent)(i017.\u0275\u0275directiveInject(i19.FormBuilder), i017.\u0275\u0275directiveInject(LoginService), i017.\u0275\u0275directiveInject(i3.Router));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i017.\u0275\u0275defineComponent({ type: _LoginComponent, selectors: [["app-login"]], standalone: false, decls: 18, vars: 7, consts: [["loading", ""], [1, "container-principal"], [1, "container-login"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["for", "email"], ["id", "email", "formControlName", "email", "type", "email", "placeholder", "Digite seu e-mail"], [4, "ngIf"], ["for", "password"], ["id", "password", "formControlName", "senha", "type", "password", "placeholder", "Digite sua senha"], ["class", "error-message", 4, "ngIf"], [1, "btn", "btn-primary", "w-100", 3, "disabled"], [4, "ngIf", "ngIfElse"], [1, "error-message"], [1, "spinner"]], template: function LoginComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i017.\u0275\u0275getCurrentView();
        i017.\u0275\u0275elementStart(0, "div", 1)(1, "div", 2)(2, "form", 3);
        i017.\u0275\u0275listener("ngSubmit", function LoginComponent_Template_form_ngSubmit_2_listener() {
          i017.\u0275\u0275restoreView(_r1);
          return i017.\u0275\u0275resetView(ctx.onSubmit());
        });
        i017.\u0275\u0275elementStart(3, "div", 4)(4, "label", 5);
        i017.\u0275\u0275text(5, "E-mail");
        i017.\u0275\u0275elementEnd();
        i017.\u0275\u0275element(6, "input", 6);
        i017.\u0275\u0275template(7, LoginComponent_small_7_Template, 2, 0, "small", 7);
        i017.\u0275\u0275elementEnd();
        i017.\u0275\u0275elementStart(8, "div", 4)(9, "label", 8);
        i017.\u0275\u0275text(10, "Senha");
        i017.\u0275\u0275elementEnd();
        i017.\u0275\u0275element(11, "input", 9);
        i017.\u0275\u0275template(12, LoginComponent_small_12_Template, 2, 0, "small", 7);
        i017.\u0275\u0275elementEnd();
        i017.\u0275\u0275template(13, LoginComponent_p_13_Template, 2, 1, "p", 10);
        i017.\u0275\u0275elementStart(14, "button", 11);
        i017.\u0275\u0275template(15, LoginComponent_ng_container_15_Template, 2, 0, "ng-container", 12)(16, LoginComponent_ng_template_16_Template, 2, 0, "ng-template", null, 0, i017.\u0275\u0275templateRefExtractor);
        i017.\u0275\u0275elementEnd()()()();
      }
      if (rf & 2) {
        let tmp_2_0;
        let tmp_3_0;
        const loading_r3 = i017.\u0275\u0275reference(17);
        i017.\u0275\u0275advance(2);
        i017.\u0275\u0275property("formGroup", ctx.loginForm);
        i017.\u0275\u0275advance(5);
        i017.\u0275\u0275property("ngIf", ((tmp_2_0 = ctx.loginForm.get("email")) == null ? null : tmp_2_0.invalid) && ((tmp_2_0 = ctx.loginForm.get("email")) == null ? null : tmp_2_0.touched));
        i017.\u0275\u0275advance(5);
        i017.\u0275\u0275property("ngIf", ((tmp_3_0 = ctx.loginForm.get("password")) == null ? null : tmp_3_0.invalid) && ((tmp_3_0 = ctx.loginForm.get("password")) == null ? null : tmp_3_0.touched));
        i017.\u0275\u0275advance();
        i017.\u0275\u0275property("ngIf", ctx.loginError);
        i017.\u0275\u0275advance();
        i017.\u0275\u0275property("disabled", ctx.isLoading || ctx.loginForm.invalid);
        i017.\u0275\u0275advance();
        i017.\u0275\u0275property("ngIf", !ctx.isLoading)("ngIfElse", loading_r3);
      }
    }, styles: ["\n\n.container-principal[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 320px;\n}\n.container-login[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  min-width: 300px;\n  background-color: #faf9f9;\n  height: 320px;\n  border-width: 1px;\n  border-style: solid;\n  border-color: #969696;\n  border-radius: 8px;\n}\n.form-group[_ngcontent-%COMP%] {\n  display: flex;\n  margin-bottom: 15px;\n  text-align: left;\n  min-width: 270px;\n}\nlabel[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-weight: bold;\n  color: #555;\n}\ninput[type=email][_ngcontent-%COMP%], \ninput[type=password][_ngcontent-%COMP%] {\n  padding: 10px;\n  margin-top: 5px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  box-sizing: border-box;\n}\ninput[_ngcontent-%COMP%]:focus {\n  border-color: #007bff;\n  outline: none;\n}\nsmall[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 0.875em;\n  margin-top: 5px;\n  display: block;\n}\nbutton[_ngcontent-%COMP%] {\n  background-color: #28a745;\n  width: 100%;\n  color: white;\n  padding: 10px 70px;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  transition: background-color 0.3s ease-in-out;\n  margin-top: 20px;\n}\nbutton[_ngcontent-%COMP%]:hover {\n  background-color: #218838;\n}\nbutton[_ngcontent-%COMP%]:disabled {\n  background-color: #ccc;\n  cursor: not-allowed;\n}\n@media (max-width: 600px) {\n  .container-login[_ngcontent-%COMP%] {\n    padding: 15px;\n  }\n  label[_ngcontent-%COMP%], \n   input[_ngcontent-%COMP%], \n   button[_ngcontent-%COMP%] {\n    font-size: 1em;\n  }\n}\n.error-message[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 14px;\n  margin-top: 10px;\n}\n.spinner[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border: 3px solid #ccc;\n  border-top: 3px solid #fff;\n  border-radius: 50%;\n  display: inline-block;\n  animation: _ngcontent-%COMP%_spin 0.8s linear infinite;\n  vertical-align: middle;\n  margin-right: 8px;\n}\n@keyframes _ngcontent-%COMP%_spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n/*# sourceMappingURL=login.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i017.\u0275setClassDebugInfo(LoginComponent, { className: "LoginComponent", filePath: "src/app/pages/login/login.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flogin%2Flogin.component.ts%40LoginComponent";
  function LoginComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i017.\u0275\u0275replaceMetadata(LoginComponent, m.default, [i017, i19, login_service_exports, i3], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && LoginComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && LoginComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/centro-custo-form/centro-custo-form.component.ts
var centro_custo_form_component_exports = {};
__export(centro_custo_form_component_exports, {
  CentroCustoFormComponent: () => CentroCustoFormComponent
});
import { Component as Component10, EventEmitter as EventEmitter2, Input as Input3, Output as Output2 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { FormControl as FormControl2, FormGroup as FormGroup2, Validators as Validators4 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i018 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
function CentroCustoFormComponent_div_8_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275elementStart(0, "p");
    i018.\u0275\u0275text(1, "A descri\xE7\xE3o \xE9 obrigat\xF3ria.");
    i018.\u0275\u0275elementEnd();
  }
}
function CentroCustoFormComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275elementStart(0, "div", 10);
    i018.\u0275\u0275template(1, CentroCustoFormComponent_div_8_p_1_Template, 2, 0, "p", 11);
    i018.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i018.\u0275\u0275nextContext();
    i018.\u0275\u0275advance();
    i018.\u0275\u0275property("ngIf", ctx_r1.descriCCusto.errors == null ? null : ctx_r1.descriCCusto.errors["required"]);
  }
}
function CentroCustoFormComponent_div_13_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275elementStart(0, "p");
    i018.\u0275\u0275text(1, "O valor limite \xE9 obrigat\xF3rio.");
    i018.\u0275\u0275elementEnd();
  }
}
function CentroCustoFormComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275elementStart(0, "div", 10);
    i018.\u0275\u0275template(1, CentroCustoFormComponent_div_13_p_1_Template, 2, 0, "p", 11);
    i018.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i018.\u0275\u0275nextContext();
    i018.\u0275\u0275advance();
    i018.\u0275\u0275property("ngIf", ctx_r1.valorLimite.errors == null ? null : ctx_r1.valorLimite.errors["required"]);
  }
}
var CentroCustoFormComponent = class _CentroCustoFormComponent {
  constructor(centroCustoService) {
    this.centroCustoService = centroCustoService;
    this.onSubmit = new EventEmitter2();
    this.centroCustoData = null;
    this.centroCustos = [];
  }
  ngOnInit() {
    this.centroCustoForm = new FormGroup2({
      id: new FormControl2(this.centroCustoData ? this.centroCustoData.id : ""),
      descriCCusto: new FormControl2(this.centroCustoData ? this.centroCustoData.descriCCusto : "", [Validators4.required]),
      valorLimite: new FormControl2(this.centroCustoData ? this.formatValorInicial(this.centroCustoData.valorLimite) : "", [Validators4.required])
    });
  }
  get descriCCusto() {
    return this.centroCustoForm.get("descriCCusto");
  }
  get valorLimite() {
    return this.centroCustoForm.get("valorLimite");
  }
  submit() {
    if (this.centroCustoForm.invalid) {
      return;
    }
    let valorFormatado = String(this.valorLimite.value).replace(/\./g, "").replace(",", ".");
    let valorLimiteFormatado = __spreadProps(__spreadValues({}, this.centroCustoForm.value), {
      valorLimite: valorFormatado
    });
    this.onSubmit.emit(valorLimiteFormatado);
  }
  // Formata o valor inicial quando carregado da API
  formatValorInicial(valorLimite) {
    let valorStr = valorLimite.toString().replace(".", ",");
    let partes = valorStr.split(",");
    let inteiro = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let decimal = partes[1] ? partes[1].padEnd(2, "0") : "00";
    return `${inteiro},${decimal}`;
  }
  formatValor() {
    let valorLimite = this.valorLimite.value.replace(/\D/g, "");
    if (valorLimite.length === 0) {
      this.centroCustoForm.controls["valorLimite"].setValue("", { emitEvent: false });
      return;
    }
    valorLimite = valorLimite.replace(/^0+(?!$)/, "");
    if (valorLimite.length <= 2) {
      this.centroCustoForm.controls["valorLimite"].setValue(`0,${valorLimite.padStart(2, "0")}`, { emitEvent: false });
      return;
    }
    let inteiro = valorLimite.slice(0, -2);
    let decimal = valorLimite.slice(-2);
    inteiro = inteiro.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let valorFormatado = `${inteiro},${decimal}`;
    console.log(valorFormatado);
    this.centroCustoForm.controls["valorLimite"].setValue(valorFormatado, { emitEvent: false });
  }
  static {
    this.\u0275fac = function CentroCustoFormComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _CentroCustoFormComponent)(i018.\u0275\u0275directiveInject(CentroCustoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i018.\u0275\u0275defineComponent({ type: _CentroCustoFormComponent, selectors: [["app-centro-custo-form"]], inputs: { btnText: "btnText", centroCustoData: "centroCustoData" }, outputs: { onSubmit: "onSubmit" }, standalone: false, decls: 15, vars: 4, consts: [["formDir", "ngForm"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["type", "hidden", "formControlName", "id"], ["for", "description"], ["placeholder", "Descri\xE7\xE3o do Centro de Custo", "formControlName", "descriCCusto", "required", ""], ["class", "validation-error", 4, "ngIf"], ["for", "valor"], ["type", "text", "inputmode", "numeric", "placeholder", "Coloque o valor limite", "formControlName", "valorLimite", "required", "", 3, "input"], ["type", "submit", 3, "value"], [1, "validation-error"], [4, "ngIf"]], template: function CentroCustoFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i018.\u0275\u0275getCurrentView();
        i018.\u0275\u0275elementStart(0, "form", 1, 0);
        i018.\u0275\u0275listener("ngSubmit", function CentroCustoFormComponent_Template_form_ngSubmit_0_listener() {
          i018.\u0275\u0275restoreView(_r1);
          return i018.\u0275\u0275resetView(ctx.submit());
        });
        i018.\u0275\u0275elementStart(2, "div", 2);
        i018.\u0275\u0275element(3, "input", 3);
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275elementStart(4, "div", 2)(5, "label", 4);
        i018.\u0275\u0275text(6, "Descri\xE7\xE3o:");
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275element(7, "textarea", 5);
        i018.\u0275\u0275template(8, CentroCustoFormComponent_div_8_Template, 2, 1, "div", 6);
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275elementStart(9, "div", 2)(10, "label", 7);
        i018.\u0275\u0275text(11, "Valor Limite:");
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275elementStart(12, "input", 8);
        i018.\u0275\u0275listener("input", function CentroCustoFormComponent_Template_input_input_12_listener() {
          i018.\u0275\u0275restoreView(_r1);
          return i018.\u0275\u0275resetView(ctx.formatValor());
        });
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275template(13, CentroCustoFormComponent_div_13_Template, 2, 1, "div", 6);
        i018.\u0275\u0275elementEnd();
        i018.\u0275\u0275element(14, "input", 9);
        i018.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        const formDir_r3 = i018.\u0275\u0275reference(1);
        i018.\u0275\u0275property("formGroup", ctx.centroCustoForm);
        i018.\u0275\u0275advance(8);
        i018.\u0275\u0275property("ngIf", ctx.descriCCusto.invalid && formDir_r3.submitted);
        i018.\u0275\u0275advance(5);
        i018.\u0275\u0275property("ngIf", ctx.valorLimite.invalid && formDir_r3.submitted);
        i018.\u0275\u0275advance();
        i018.\u0275\u0275propertyInterpolate("value", ctx.btnText);
      }
    }, styles: ["\n\nform[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 500px;\n  margin: 0 auto;\n  padding: 15px;\n  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  background-color: #fff;\n}\n.form-group[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n}\nlabel[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-weight: bold;\n}\ntextarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  margin-top: 5px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  box-sizing: border-box;\n  resize: vertical;\n}\n.validation-error[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 0.875em;\n  margin-top: 5px;\n}\ninput[type=submit][_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  background-color: #28a745;\n  color: #fff;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 1em;\n}\ninput[type=submit][_ngcontent-%COMP%]:hover {\n  background-color: #218838;\n}\n@media (max-width: 600px) {\n  form[_ngcontent-%COMP%] {\n    padding: 10px;\n  }\n}\n/*# sourceMappingURL=centro-custo-form.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i018.\u0275setClassDebugInfo(CentroCustoFormComponent, { className: "CentroCustoFormComponent", filePath: "src/app/components/centro-custo-form/centro-custo-form.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fcentro-custo-form%2Fcentro-custo-form.component.ts%40CentroCustoFormComponent";
  function CentroCustoFormComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i018.\u0275\u0275replaceMetadata(CentroCustoFormComponent, m.default, [i018, centro_custo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && CentroCustoFormComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && CentroCustoFormComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/centro-custo/edit-centro-custo/edit-centro-custo.component.ts
var edit_centro_custo_component_exports = {};
__export(edit_centro_custo_component_exports, {
  EditCentroCustoComponent: () => EditCentroCustoComponent
});
import { Component as Component11 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i019 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i24 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function EditCentroCustoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i019.\u0275\u0275getCurrentView();
    i019.\u0275\u0275elementStart(0, "div")(1, "h2")(2, "span");
    i019.\u0275\u0275text(3, "Editar");
    i019.\u0275\u0275elementEnd();
    i019.\u0275\u0275text(4, " Centro de Custo ");
    i019.\u0275\u0275elementEnd();
    i019.\u0275\u0275elementStart(5, "app-centro-custo-form", 1);
    i019.\u0275\u0275listener("onSubmit", function EditCentroCustoComponent_div_0_Template_app_centro_custo_form_onSubmit_5_listener($event) {
      i019.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i019.\u0275\u0275nextContext();
      return i019.\u0275\u0275resetView(ctx_r1.editHendler($event));
    });
    i019.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i019.\u0275\u0275nextContext();
    i019.\u0275\u0275advance(5);
    i019.\u0275\u0275property("centroCustoData", ctx_r1.centroCusto)("btnText", ctx_r1.btnText);
  }
}
var EditCentroCustoComponent = class _EditCentroCustoComponent {
  constructor(centroCustoService, route, router, loginService) {
    this.centroCustoService = centroCustoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Confirmar";
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.centroCustoService.getIdCentroCustos(id).subscribe((item) => {
      this.centroCusto = item;
    });
  }
  editHendler(centroCustoData) {
    return __async(this, null, function* () {
      const id = this.centroCusto.id;
      const formData = new FormData();
      formData.append("descriCCusto", centroCustoData.descriCCusto ?? "");
      formData.append("valorLimite", centroCustoData.valorLimite.toString());
      yield this.centroCustoService.putCentroCustos(id, formData).subscribe((result) => {
        this.router.navigate(["/centro-custo"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function EditCentroCustoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _EditCentroCustoComponent)(i019.\u0275\u0275directiveInject(CentroCustoService), i019.\u0275\u0275directiveInject(i24.ActivatedRoute), i019.\u0275\u0275directiveInject(i24.Router), i019.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i019.\u0275\u0275defineComponent({ type: _EditCentroCustoComponent, selectors: [["app-edit-centro-custo"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "centroCustoData", "btnText"]], template: function EditCentroCustoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i019.\u0275\u0275template(0, EditCentroCustoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i019.\u0275\u0275property("ngIf", ctx.centroCusto);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=edit-centro-custo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i019.\u0275setClassDebugInfo(EditCentroCustoComponent, { className: "EditCentroCustoComponent", filePath: "src/app/pages/centro-custo/edit-centro-custo/edit-centro-custo.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fcentro-custo%2Fedit-centro-custo%2Fedit-centro-custo.component.ts%40EditCentroCustoComponent";
  function EditCentroCustoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i019.\u0275\u0275replaceMetadata(EditCentroCustoComponent, m.default, [i019, centro_custo_service_exports, i24, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && EditCentroCustoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && EditCentroCustoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/centro-custo/excluir-centro-custo/excluir-centro-custo.component.ts
var excluir_centro_custo_component_exports = {};
__export(excluir_centro_custo_component_exports, {
  ExcluirCentroCustoComponent: () => ExcluirCentroCustoComponent
});
import { Component as Component12 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { firstValueFrom } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i020 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i32 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function ExcluirCentroCustoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i020.\u0275\u0275getCurrentView();
    i020.\u0275\u0275elementStart(0, "div")(1, "h2");
    i020.\u0275\u0275text(2, " Excluir ");
    i020.\u0275\u0275elementStart(3, "span");
    i020.\u0275\u0275text(4, "Centro de Custo");
    i020.\u0275\u0275elementEnd()();
    i020.\u0275\u0275elementStart(5, "app-centro-custo-form", 1);
    i020.\u0275\u0275listener("onSubmit", function ExcluirCentroCustoComponent_div_0_Template_app_centro_custo_form_onSubmit_5_listener($event) {
      i020.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i020.\u0275\u0275nextContext();
      return i020.\u0275\u0275resetView(ctx_r1.excluirHendler($event));
    });
    i020.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i020.\u0275\u0275nextContext();
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275property("centroCustoData", ctx_r1.centroCusto)("btnText", ctx_r1.btnText);
  }
}
var ExcluirCentroCustoComponent = class _ExcluirCentroCustoComponent {
  constructor(centroCustoService, lancamentoService, route, router, loginService, mensagensService) {
    this.centroCustoService = centroCustoService;
    this.lancamentoService = lancamentoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.btnText = "Remover";
    this.quantidade = 0;
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.centroCustoService.getIdCentroCustos(id).subscribe((item) => {
      this.centroCusto = item;
    });
  }
  excluirHendler(centroCustoData) {
    return __async(this, null, function* () {
      const idCentroCusto = this.centroCusto.id;
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario()?.toString();
      formData.append("descriCCusto", centroCustoData.descriCCusto ?? "");
      formData.append("valorLimite", centroCustoData.valorLimite.toString());
      const item = yield firstValueFrom(this.lancamentoService.getExisteCentroCusto(idUsuario ?? "", idCentroCusto));
      this.quantidade = item.quantidade;
      if (this.quantidade.valueOf() == 0) {
        yield this.centroCustoService.excluirCentroCusto(idCentroCusto).subscribe((result) => {
          this.router.navigate(["/centro-custo"]);
        }, (error) => {
          console.log("Erro");
        });
      } else {
        this.mensagensService.mensagem("warning", "Aten\xE7\xE3o", `Esse centro de custo n\xE3o pode ser exclu\xEDdo, pois ${this.quantidade === 1 ? "existe " : "existem "} ${this.quantidade} ${this.quantidade === 1 ? "lan\xE7amento " : "lan\xE7amentos "} ${this.quantidade === 1 ? "atribu\xEDdo" : "atribu\xEDdos"} a ele.`, void 0);
      }
    });
  }
  static {
    this.\u0275fac = function ExcluirCentroCustoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ExcluirCentroCustoComponent)(i020.\u0275\u0275directiveInject(CentroCustoService), i020.\u0275\u0275directiveInject(LancamentoService), i020.\u0275\u0275directiveInject(i32.ActivatedRoute), i020.\u0275\u0275directiveInject(i32.Router), i020.\u0275\u0275directiveInject(LoginService), i020.\u0275\u0275directiveInject(MensagensService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i020.\u0275\u0275defineComponent({ type: _ExcluirCentroCustoComponent, selectors: [["app-excluir-centro-custo"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "centroCustoData", "btnText"]], template: function ExcluirCentroCustoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i020.\u0275\u0275template(0, ExcluirCentroCustoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i020.\u0275\u0275property("ngIf", ctx.centroCusto);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=excluir-centro-custo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i020.\u0275setClassDebugInfo(ExcluirCentroCustoComponent, { className: "ExcluirCentroCustoComponent", filePath: "src/app/pages/centro-custo/excluir-centro-custo/excluir-centro-custo.component.ts", lineNumber: 16 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fcentro-custo%2Fexcluir-centro-custo%2Fexcluir-centro-custo.component.ts%40ExcluirCentroCustoComponent";
  function ExcluirCentroCustoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i020.\u0275\u0275replaceMetadata(ExcluirCentroCustoComponent, m.default, [i020, centro_custo_service_exports, lancamento_service_exports, i32, login_service_exports, mensagens_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && ExcluirCentroCustoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && ExcluirCentroCustoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/centro-custo/novo-centro-custo/novo-centro-custo.component.ts
var novo_centro_custo_component_exports = {};
__export(novo_centro_custo_component_exports, {
  NovoCentroCustoComponent: () => NovoCentroCustoComponent
});
import { Component as Component13 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i021 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i25 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
var NovoCentroCustoComponent = class _NovoCentroCustoComponent {
  constructor(centroCustoService, router, loginService) {
    this.centroCustoService = centroCustoService;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Registrar";
  }
  ngOnInit() {
  }
  createHandler(centroCusto) {
    return __async(this, null, function* () {
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("descriCCusto", centroCusto.descriCCusto ?? "");
      formData.append("valorLimite", centroCusto.valorLimite.toString());
      formData.append("idUsuario", idUsuario ?? "");
      this.centroCustoService.postCentroCusto(formData).subscribe((result) => {
        this.router.navigate(["/centro-custo"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function NovoCentroCustoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NovoCentroCustoComponent)(i021.\u0275\u0275directiveInject(CentroCustoService), i021.\u0275\u0275directiveInject(i25.Router), i021.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i021.\u0275\u0275defineComponent({ type: _NovoCentroCustoComponent, selectors: [["app-novo-centro-custo"]], standalone: false, decls: 5, vars: 1, consts: [[3, "onSubmit", "btnText"]], template: function NovoCentroCustoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i021.\u0275\u0275elementStart(0, "h2");
        i021.\u0275\u0275text(1, "Registre o seu ");
        i021.\u0275\u0275elementStart(2, "span");
        i021.\u0275\u0275text(3, "Centro de Custo");
        i021.\u0275\u0275elementEnd()();
        i021.\u0275\u0275elementStart(4, "app-centro-custo-form", 0);
        i021.\u0275\u0275listener("onSubmit", function NovoCentroCustoComponent_Template_app_centro_custo_form_onSubmit_4_listener($event) {
          return ctx.createHandler($event);
        });
        i021.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        i021.\u0275\u0275advance(4);
        i021.\u0275\u0275property("btnText", ctx.btnText);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=novo-centro-custo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i021.\u0275setClassDebugInfo(NovoCentroCustoComponent, { className: "NovoCentroCustoComponent", filePath: "src/app/pages/centro-custo/novo-centro-custo/novo-centro-custo.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fcentro-custo%2Fnovo-centro-custo%2Fnovo-centro-custo.component.ts%40NovoCentroCustoComponent";
  function NovoCentroCustoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i021.\u0275\u0275replaceMetadata(NovoCentroCustoComponent, m.default, [i021, centro_custo_service_exports, i25, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && NovoCentroCustoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && NovoCentroCustoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/centro-custo/tabela-centro-custo/tabela-centro-custo.component.ts
var tabela_centro_custo_component_exports = {};
__export(tabela_centro_custo_component_exports, {
  TabelaCentroCustoComponent: () => TabelaCentroCustoComponent
});
import { Component as Component14 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i022 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var _c04 = () => ["/centro-custo/novo"];
var _c13 = (a0) => ["/centro-custo/edit", a0];
var _c22 = (a0) => ["/centro-custo/excluir", a0];
function TabelaCentroCustoComponent_div_5_tr_13_Template(rf, ctx) {
  if (rf & 1) {
    i022.\u0275\u0275elementStart(0, "tr")(1, "td");
    i022.\u0275\u0275text(2);
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(3, "td");
    i022.\u0275\u0275text(4);
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(5, "td");
    i022.\u0275\u0275text(6);
    i022.\u0275\u0275pipe(7, "formatValor");
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(8, "div", 8)(9, "button", 9);
    i022.\u0275\u0275element(10, "i", 10);
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(11, "button", 11);
    i022.\u0275\u0275element(12, "i", 12);
    i022.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const centroCusto_r1 = ctx.$implicit;
    i022.\u0275\u0275advance(2);
    i022.\u0275\u0275textInterpolate(centroCusto_r1.id);
    i022.\u0275\u0275advance(2);
    i022.\u0275\u0275textInterpolate(centroCusto_r1.descriCCusto);
    i022.\u0275\u0275advance(2);
    i022.\u0275\u0275textInterpolate(i022.\u0275\u0275pipeBind1(7, 5, centroCusto_r1.valorLimite));
    i022.\u0275\u0275advance(3);
    i022.\u0275\u0275property("routerLink", i022.\u0275\u0275pureFunction1(7, _c13, centroCusto_r1.id));
    i022.\u0275\u0275advance(2);
    i022.\u0275\u0275property("routerLink", i022.\u0275\u0275pureFunction1(9, _c22, centroCusto_r1.id));
  }
}
function TabelaCentroCustoComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    i022.\u0275\u0275elementStart(0, "div")(1, "table", 5)(2, "thead", 6)(3, "tr")(4, "th");
    i022.\u0275\u0275text(5, "Id");
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(6, "th");
    i022.\u0275\u0275text(7, "Descri\xE7\xE3o");
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(8, "th");
    i022.\u0275\u0275text(9, "Valor Limite");
    i022.\u0275\u0275elementEnd();
    i022.\u0275\u0275elementStart(10, "th", 2);
    i022.\u0275\u0275text(11, "A\xE7\xF5es");
    i022.\u0275\u0275elementEnd()()();
    i022.\u0275\u0275elementStart(12, "tbody");
    i022.\u0275\u0275template(13, TabelaCentroCustoComponent_div_5_tr_13_Template, 13, 11, "tr", 7);
    i022.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i022.\u0275\u0275nextContext();
    i022.\u0275\u0275advance(13);
    i022.\u0275\u0275property("ngForOf", ctx_r1.centroCustos);
  }
}
function TabelaCentroCustoComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    i022.\u0275\u0275elementStart(0, "h1", 2);
    i022.\u0275\u0275text(1, "N\xE3o existem registros cadastrados \u{1F622}");
    i022.\u0275\u0275elementEnd();
  }
}
var TabelaCentroCustoComponent = class _TabelaCentroCustoComponent {
  constructor(centroCustoService) {
    this.centroCustoService = centroCustoService;
    this.centroCustos = [];
  }
  ngOnInit() {
    this.centroCustoService.getAllCentroCustos().subscribe((centroCustos) => this.centroCustos = centroCustos);
  }
  removerCentroCusto(id) {
    this.centroCustoService.excluirCentroCusto(id).subscribe();
  }
  static {
    this.\u0275fac = function TabelaCentroCustoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TabelaCentroCustoComponent)(i022.\u0275\u0275directiveInject(CentroCustoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i022.\u0275\u0275defineComponent({ type: _TabelaCentroCustoComponent, selectors: [["app-tabela-centro-custo"]], standalone: false, decls: 11, vars: 4, consts: [["noCentroCustos", ""], [1, "container"], [1, "text-center"], [4, "ngIf", "ngIfElse"], ["mat-fab", "", "color", "primary", 1, "fab", 3, "routerLink"], [1, "table", "table-striped", "table-bordered", "align-middle", "shadow-sm"], [1, "table-dark"], [4, "ngFor", "ngForOf"], [1, "btn-group"], ["type", "button", 1, "btn", "btn-outline-primary", "btn-sm", "botao-editar", 3, "routerLink"], [1, "bi", "bi-pencil-square"], ["type", "button", 1, "btn", "btn-outline-danger", "btn-sm", "botao-remover", 3, "routerLink"], [1, "bi", "bi-trash"]], template: function TabelaCentroCustoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i022.\u0275\u0275elementStart(0, "div", 1)(1, "h2", 2);
        i022.\u0275\u0275text(2, "Centros de Custo");
        i022.\u0275\u0275elementEnd();
        i022.\u0275\u0275element(3, "br");
        i022.\u0275\u0275elementStart(4, "div");
        i022.\u0275\u0275template(5, TabelaCentroCustoComponent_div_5_Template, 14, 1, "div", 3)(6, TabelaCentroCustoComponent_ng_template_6_Template, 2, 0, "ng-template", null, 0, i022.\u0275\u0275templateRefExtractor);
        i022.\u0275\u0275elementStart(8, "button", 4)(9, "mat-icon");
        i022.\u0275\u0275text(10, "add");
        i022.\u0275\u0275elementEnd()()()();
      }
      if (rf & 2) {
        const noCentroCustos_r3 = i022.\u0275\u0275reference(7);
        i022.\u0275\u0275advance(5);
        i022.\u0275\u0275property("ngIf", ctx.centroCustos.length > 0)("ngIfElse", noCentroCustos_r3);
        i022.\u0275\u0275advance(3);
        i022.\u0275\u0275property("routerLink", i022.\u0275\u0275pureFunction0(3, _c04));
      }
    }, styles: ["\n\n.table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  background-color: #343a40;\n  color: white;\n  padding: 10px;\n  font-size: 16px;\n  font-family: Arial, sans-serif;\n}\n.table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 10px;\n  border-bottom: 1px solid #ddd;\n  font-size: 11px;\n  font-family: Arial, sans-serif;\n  color: #616161;\n}\n.table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  align-items: center;\n  justify-content: center;\n  border-radius: 50%;\n  border: none;\n  color: white;\n  font-size: 18px;\n  transition: background-color 0.3s ease;\n}\n.botao-editar[_ngcontent-%COMP%] {\n  background-color: #e7e7fd;\n}\n.botao-remover[_ngcontent-%COMP%] {\n  background-color: #fda6a6;\n}\nh2[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.fab[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 20px;\n  right: 20px;\n  z-index: 1000;\n  background-color: rgb(90, 165, 90);\n}\n@media (max-width: 599px) {\n  .table[_ngcontent-%COMP%] {\n    width: 100%;\n    font-size: 12px;\n  }\n}\n/*# sourceMappingURL=tabela-centro-custo.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i022.\u0275setClassDebugInfo(TabelaCentroCustoComponent, { className: "TabelaCentroCustoComponent", filePath: "src/app/pages/centro-custo/tabela-centro-custo/tabela-centro-custo.component.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fcentro-custo%2Ftabela-centro-custo%2Ftabela-centro-custo.component.ts%40TabelaCentroCustoComponent";
  function TabelaCentroCustoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i022.\u0275\u0275replaceMetadata(TabelaCentroCustoComponent, m.default, [i022, centro_custo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && TabelaCentroCustoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && TabelaCentroCustoComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/lancamento-fixo-form/lancamento-fixo-form.component.ts
var lancamento_fixo_form_component_exports = {};
__export(lancamento_fixo_form_component_exports, {
  LancamentoFixoFormComponent: () => LancamentoFixoFormComponent
});
import { Component as Component15, EventEmitter as EventEmitter3, Input as Input4, Output as Output3 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { FormControl as FormControl3, FormGroup as FormGroup3, Validators as Validators5 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i023 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
function LancamentoFixoFormComponent_option_10_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "option", 19);
    i023.\u0275\u0275text(1);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const dia_r2 = ctx.$implicit;
    i023.\u0275\u0275property("value", dia_r2);
    i023.\u0275\u0275advance();
    i023.\u0275\u0275textInterpolate(dia_r2);
  }
}
function LancamentoFixoFormComponent_div_11_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "p");
    i023.\u0275\u0275text(1, "O dia \xE9 obrigat\xF3rio.");
    i023.\u0275\u0275elementEnd();
  }
}
function LancamentoFixoFormComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "div", 20);
    i023.\u0275\u0275template(1, LancamentoFixoFormComponent_div_11_p_1_Template, 2, 0, "p", 21);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance();
    i023.\u0275\u0275property("ngIf", ctx_r2.diaMes.errors == null ? null : ctx_r2.diaMes.errors["required"]);
  }
}
function LancamentoFixoFormComponent_div_16_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "p");
    i023.\u0275\u0275text(1, "O valor \xE9 obrigat\xF3ria.");
    i023.\u0275\u0275elementEnd();
  }
}
function LancamentoFixoFormComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "div", 20);
    i023.\u0275\u0275template(1, LancamentoFixoFormComponent_div_16_p_1_Template, 2, 0, "p", 21);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance();
    i023.\u0275\u0275property("ngIf", ctx_r2.valor.errors == null ? null : ctx_r2.valor.errors["required"]);
  }
}
function LancamentoFixoFormComponent_div_21_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "p");
    i023.\u0275\u0275text(1, "A descri\xE7\xE3o \xE9 obrigat\xF3ria.");
    i023.\u0275\u0275elementEnd();
  }
}
function LancamentoFixoFormComponent_div_21_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "div", 20);
    i023.\u0275\u0275template(1, LancamentoFixoFormComponent_div_21_p_1_Template, 2, 0, "p", 21);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance();
    i023.\u0275\u0275property("ngIf", ctx_r2.descricao.errors == null ? null : ctx_r2.descricao.errors["required"]);
  }
}
function LancamentoFixoFormComponent_option_34_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "option", 19);
    i023.\u0275\u0275text(1);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const centroCusto_r4 = ctx.$implicit;
    i023.\u0275\u0275propertyInterpolate("value", centroCusto_r4.id);
    i023.\u0275\u0275advance();
    i023.\u0275\u0275textInterpolate(centroCusto_r4.descriCCusto);
  }
}
function LancamentoFixoFormComponent_div_35_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "p");
    i023.\u0275\u0275text(1, "O centro de custo \xE9 obrigat\xF3ria.");
    i023.\u0275\u0275elementEnd();
  }
}
function LancamentoFixoFormComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "div", 20);
    i023.\u0275\u0275template(1, LancamentoFixoFormComponent_div_35_p_1_Template, 2, 0, "p", 21);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance();
    i023.\u0275\u0275property("ngIf", ctx_r2.idCCusto.errors == null ? null : ctx_r2.idCCusto.errors["required"]);
  }
}
var LancamentoFixoFormComponent = class _LancamentoFixoFormComponent {
  constructor(centroCustoService) {
    this.centroCustoService = centroCustoService;
    this.onSubmit = new EventEmitter3();
    this.lancamentoFixoData = null;
    this.centroCustos = [];
    this.dias = Array.from({ length: 31 }, (_, i) => i + 1);
  }
  ngOnInit() {
    this.lancamentoFixoForm = new FormGroup3({
      id: new FormControl3(this.lancamentoFixoData ? this.lancamentoFixoData.id : ""),
      diaMes: new FormControl3(this.lancamentoFixoData?.diaMes, [Validators5.required]),
      valor: new FormControl3(this.lancamentoFixoData ? this.formatValorInicial(this.lancamentoFixoData.valor) : "", [Validators5.required]),
      descricao: new FormControl3(this.lancamentoFixoData ? this.lancamentoFixoData.descricao : "", [Validators5.required]),
      status: new FormControl3(this.lancamentoFixoData ? this.lancamentoFixoData.status : "", [Validators5.required]),
      idCCusto: new FormControl3(this.lancamentoFixoData ? this.lancamentoFixoData.idCCusto : "", [Validators5.required])
    });
    this.centroCustoService.getAllCentroCustos().subscribe((centroCustos) => this.centroCustos = centroCustos);
  }
  // Formata o valor inicial quando carregado da API
  formatValorInicial(valor) {
    let valorStr = valor.toString().replace(".", ",");
    let partes = valorStr.split(",");
    let inteiro = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let decimal = partes[1] ? partes[1].padEnd(2, "0") : "00";
    return `${inteiro},${decimal}`;
  }
  formatValor() {
    let valor = this.valor.value.replace(/\D/g, "");
    if (valor.length === 0) {
      this.lancamentoFixoForm.controls["valor"].setValue("", { emitEvent: false });
      return;
    }
    valor = valor.replace(/^0+(?!$)/, "");
    if (valor.length <= 2) {
      this.lancamentoFixoForm.controls["valor"].setValue(`0,${valor.padStart(2, "0")}`, { emitEvent: false });
      return;
    }
    let inteiro = valor.slice(0, -2);
    let decimal = valor.slice(-2);
    inteiro = inteiro.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    let valorFormatado = `${inteiro},${decimal}`;
    this.lancamentoFixoForm.controls["valor"].setValue(valorFormatado, { emitEvent: false });
  }
  get diaMes() {
    return this.lancamentoFixoForm.get("diaMes");
  }
  get valor() {
    return this.lancamentoFixoForm.get("valor");
  }
  get descricao() {
    return this.lancamentoFixoForm.get("descricao");
  }
  get status() {
    return this.lancamentoFixoForm.get("status");
  }
  get idCCusto() {
    return this.lancamentoFixoForm.get("idCCusto");
  }
  get idUsuario() {
    return this.lancamentoFixoForm.get("idUsuario");
  }
  submit() {
    if (this.lancamentoFixoForm.invalid) {
      return;
    }
    let valorFormatado = String(this.valor.value).replace(/\./g, "").replace(",", ".");
    let lancamentoFormatado = __spreadProps(__spreadValues({}, this.lancamentoFixoForm.value), {
      valor: valorFormatado
    });
    this.onSubmit.emit(lancamentoFormatado);
  }
  static {
    this.\u0275fac = function LancamentoFixoFormComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LancamentoFixoFormComponent)(i023.\u0275\u0275directiveInject(CentroCustoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i023.\u0275\u0275defineComponent({ type: _LancamentoFixoFormComponent, selectors: [["app-lancamento-fixo-form"]], inputs: { btnText: "btnText", lancamentoFixoData: "lancamentoFixoData" }, outputs: { onSubmit: "onSubmit" }, standalone: false, decls: 37, vars: 8, consts: [["formDir", "ngForm"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["type", "hidden", "formControlName", "id"], ["for", "dia"], ["id", "dia", "formControlName", "diaMes", "required", ""], ["value", "", "disabled", "", "selected", ""], [3, "value", 4, "ngFor", "ngForOf"], ["class", "validation-error", 4, "ngIf"], ["for", "valor"], ["type", "text", "inputmode", "numeric", "placeholder", "Coloque o valor do Lan\xE7amento", "formControlName", "valor", "required", "", 3, "input"], ["for", "description"], ["placeholder", "Descri\xE7\xE3o do Lancamento", "formControlName", "descricao", "required", ""], ["for", "status"], ["formControlName", "status", "required", ""], ["value", "A Receber"], ["value", "A Pagar"], ["formControlName", "idCCusto", "required", ""], ["type", "submit", 3, "value"], [3, "value"], [1, "validation-error"], [4, "ngIf"]], template: function LancamentoFixoFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i023.\u0275\u0275getCurrentView();
        i023.\u0275\u0275elementStart(0, "form", 1, 0);
        i023.\u0275\u0275listener("ngSubmit", function LancamentoFixoFormComponent_Template_form_ngSubmit_0_listener() {
          i023.\u0275\u0275restoreView(_r1);
          return i023.\u0275\u0275resetView(ctx.submit());
        });
        i023.\u0275\u0275elementStart(2, "div", 2);
        i023.\u0275\u0275element(3, "input", 3);
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(4, "div", 2)(5, "label", 4);
        i023.\u0275\u0275text(6, "Dia do M\xEAs:");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(7, "select", 5)(8, "option", 6);
        i023.\u0275\u0275text(9, "Selecione o dia");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275template(10, LancamentoFixoFormComponent_option_10_Template, 2, 2, "option", 7);
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275template(11, LancamentoFixoFormComponent_div_11_Template, 2, 1, "div", 8);
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(12, "div", 2)(13, "label", 9);
        i023.\u0275\u0275text(14, "Valor:");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(15, "input", 10);
        i023.\u0275\u0275listener("input", function LancamentoFixoFormComponent_Template_input_input_15_listener() {
          i023.\u0275\u0275restoreView(_r1);
          return i023.\u0275\u0275resetView(ctx.formatValor());
        });
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275template(16, LancamentoFixoFormComponent_div_16_Template, 2, 1, "div", 8);
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(17, "div", 2)(18, "label", 11);
        i023.\u0275\u0275text(19, "Descri\xE7\xE3o:");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275element(20, "textarea", 12);
        i023.\u0275\u0275template(21, LancamentoFixoFormComponent_div_21_Template, 2, 1, "div", 8);
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(22, "div", 2)(23, "label", 13);
        i023.\u0275\u0275text(24, "Status:");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(25, "select", 14)(26, "option", 15);
        i023.\u0275\u0275text(27, "A Receber");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(28, "option", 16);
        i023.\u0275\u0275text(29, "A Pagar");
        i023.\u0275\u0275elementEnd()()();
        i023.\u0275\u0275elementStart(30, "div", 2)(31, "label", 13);
        i023.\u0275\u0275text(32, "Centro Custo:");
        i023.\u0275\u0275elementEnd();
        i023.\u0275\u0275elementStart(33, "select", 17);
        i023.\u0275\u0275template(34, LancamentoFixoFormComponent_option_34_Template, 2, 2, "option", 7);
        i023.\u0275\u0275elementEnd()();
        i023.\u0275\u0275template(35, LancamentoFixoFormComponent_div_35_Template, 2, 1, "div", 8);
        i023.\u0275\u0275element(36, "input", 18);
        i023.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        const formDir_r5 = i023.\u0275\u0275reference(1);
        i023.\u0275\u0275property("formGroup", ctx.lancamentoFixoForm);
        i023.\u0275\u0275advance(10);
        i023.\u0275\u0275property("ngForOf", ctx.dias);
        i023.\u0275\u0275advance();
        i023.\u0275\u0275property("ngIf", ctx.diaMes.invalid && formDir_r5.submitted);
        i023.\u0275\u0275advance(5);
        i023.\u0275\u0275property("ngIf", ctx.valor.invalid && formDir_r5.submitted);
        i023.\u0275\u0275advance(5);
        i023.\u0275\u0275property("ngIf", ctx.descricao.invalid && formDir_r5.submitted);
        i023.\u0275\u0275advance(13);
        i023.\u0275\u0275property("ngForOf", ctx.centroCustos);
        i023.\u0275\u0275advance();
        i023.\u0275\u0275property("ngIf", ctx.idCCusto.invalid && formDir_r5.submitted);
        i023.\u0275\u0275advance();
        i023.\u0275\u0275propertyInterpolate("value", ctx.btnText);
      }
    }, styles: ["\n\nform[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 500px;\n  margin: 0 auto;\n  padding: 15px;\n  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  background-color: #fff;\n}\n.form-group[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n}\nlabel[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-weight: bold;\n}\ninput[type=text][_ngcontent-%COMP%], \ninput[type=datetime-local][_ngcontent-%COMP%], \ntextarea[_ngcontent-%COMP%], \nselect[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  margin-top: 5px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  box-sizing: border-box;\n}\ntextarea[_ngcontent-%COMP%] {\n  resize: vertical;\n}\n.validation-error[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 0.875em;\n  margin-top: 5px;\n}\ninput[type=submit][_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  background-color: #28a745;\n  color: #fff;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 1em;\n}\ninput[type=submit][_ngcontent-%COMP%]:hover {\n  background-color: #218838;\n}\n@media (max-width: 600px) {\n  form[_ngcontent-%COMP%] {\n    padding: 10px;\n  }\n  label[_ngcontent-%COMP%], \n   input[type=text][_ngcontent-%COMP%], \n   input[type=datetime-local][_ngcontent-%COMP%], \n   textarea[_ngcontent-%COMP%], \n   select[_ngcontent-%COMP%], \n   input[type=submit][_ngcontent-%COMP%] {\n    font-size: 1em;\n  }\n}\n/*# sourceMappingURL=lancamento-fixo-form.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i023.\u0275setClassDebugInfo(LancamentoFixoFormComponent, { className: "LancamentoFixoFormComponent", filePath: "src/app/components/lancamento-fixo-form/lancamento-fixo-form.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Flancamento-fixo-form%2Flancamento-fixo-form.component.ts%40LancamentoFixoFormComponent";
  function LancamentoFixoFormComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i023.\u0275\u0275replaceMetadata(LancamentoFixoFormComponent, m.default, [i023, centro_custo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && LancamentoFixoFormComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && LancamentoFixoFormComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamento-fixo/edit-lancamento-fixo/edit-lancamento-fixo.component.ts
var edit_lancamento_fixo_component_exports = {};
__export(edit_lancamento_fixo_component_exports, {
  EditLancamentoFixoComponent: () => EditLancamentoFixoComponent
});
import { Component as Component16 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i025 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/lancamento-fixo/lancamento-fixo.service.ts
var lancamento_fixo_service_exports = {};
__export(lancamento_fixo_service_exports, {
  LancamentoFixoService: () => LancamentoFixoService
});
import { Injectable as Injectable9 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError8, throwError as throwError8 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i024 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i110 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var LancamentoFixoService = class _LancamentoFixoService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getAllLancamentosFixos() {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/lancamentosfixos/usuario/${idUsuario}`).pipe(catchError8((error) => {
      return throwError8(error);
    }));
  }
  getLancamentoFixoPorId(id) {
    return this.http.get(`${this.baseApiUrl}api/lancamentosfixos/${id}`).pipe(catchError8((error) => {
      return throwError8(error);
    }));
  }
  postLancamentoFixo(formData) {
    var data = {
      diaMes: Number(formData.getAll("diaMes")),
      valor: Number(formData.getAll("valor")),
      descricao: formData.getAll("descricao").toString().trim(),
      status: formData.getAll("status").toString(),
      idCCusto: Number(formData.getAll("idCCusto")),
      idUsuario: Number(formData.getAll("idUsuario"))
    };
    console.log(data);
    return this.http.post(`${this.baseApiUrl}api/lancamentosfixos`, data).pipe(catchError8((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao criar lan\xE7amento fixo: ${error.status}`, void 0);
      return throwError8(error);
    }));
  }
  excluirLancamentoFixo(id) {
    var data = {
      deletado: "*"
    };
    return this.http.put(`${this.baseApiUrl}api/lancamentosfixos/del/${id}`, data).pipe(catchError8((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao excluir lan\xE7amento fixo: ${error.status}`, void 0);
      return throwError8(error);
    }));
  }
  putLancamentoFixo(id, formData) {
    var data = {
      diaMes: Number(formData.getAll("diaMes")),
      valor: Number(formData.getAll("valor")),
      descricao: formData.getAll("descricao").toString().trim(),
      status: formData.getAll("status").toString(),
      idCCusto: Number(formData.getAll("idCCusto")),
      idUsuario: Number(formData.getAll("idUsuario"))
    };
    return this.http.put(`${this.baseApiUrl}api/lancamentosfixos/${id}`, data).pipe(catchError8((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao atualizar lan\xE7amento fixo: ${error.status}`, void 0);
      return throwError8(error);
    }));
  }
  static {
    this.\u0275fac = function LancamentoFixoService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LancamentoFixoService)(i024.\u0275\u0275inject(i110.HttpClient), i024.\u0275\u0275inject(LoginService), i024.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i024.\u0275\u0275defineInjectable({ token: _LancamentoFixoService, factory: _LancamentoFixoService.\u0275fac, providedIn: "root" });
  }
};

// src/app/pages/lancamento-fixo/edit-lancamento-fixo/edit-lancamento-fixo.component.ts
import * as i26 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function EditLancamentoFixoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i025.\u0275\u0275getCurrentView();
    i025.\u0275\u0275elementStart(0, "div")(1, "h2")(2, "span");
    i025.\u0275\u0275text(3, "Editar");
    i025.\u0275\u0275elementEnd();
    i025.\u0275\u0275text(4, " Lan\xE7amento Fixo ");
    i025.\u0275\u0275elementEnd();
    i025.\u0275\u0275elementStart(5, "app-lancamento-fixo-form", 1);
    i025.\u0275\u0275listener("onSubmit", function EditLancamentoFixoComponent_div_0_Template_app_lancamento_fixo_form_onSubmit_5_listener($event) {
      i025.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i025.\u0275\u0275nextContext();
      return i025.\u0275\u0275resetView(ctx_r1.editHendler($event));
    });
    i025.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i025.\u0275\u0275nextContext();
    i025.\u0275\u0275advance(5);
    i025.\u0275\u0275property("lancamentoFixoData", ctx_r1.lancamentoFixo)("btnText", ctx_r1.btnText);
  }
}
var EditLancamentoFixoComponent = class _EditLancamentoFixoComponent {
  constructor(lancamentoFixoService, route, router, loginService) {
    this.lancamentoFixoService = lancamentoFixoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Confirmar";
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.lancamentoFixoService.getLancamentoFixoPorId(id).subscribe((item) => {
      this.lancamentoFixo = item;
      console.log(this.lancamentoFixo.diaMes);
    });
  }
  editHendler(lancamentoFixoData) {
    return __async(this, null, function* () {
      const id = this.lancamentoFixo.id;
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("diaMes", lancamentoFixoData.diaMes.toString());
      formData.append("valor", lancamentoFixoData.valor.toString());
      formData.append("descricao", lancamentoFixoData.descricao);
      formData.append("status", lancamentoFixoData.status);
      formData.append("idCCusto", lancamentoFixoData.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      yield this.lancamentoFixoService.putLancamentoFixo(id, formData).subscribe((result) => {
        this.router.navigate(["/lancamento-fixo"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function EditLancamentoFixoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _EditLancamentoFixoComponent)(i025.\u0275\u0275directiveInject(LancamentoFixoService), i025.\u0275\u0275directiveInject(i26.ActivatedRoute), i025.\u0275\u0275directiveInject(i26.Router), i025.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i025.\u0275\u0275defineComponent({ type: _EditLancamentoFixoComponent, selectors: [["app-edit-lancamento-fixo"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "lancamentoFixoData", "btnText"]], template: function EditLancamentoFixoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i025.\u0275\u0275template(0, EditLancamentoFixoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i025.\u0275\u0275property("ngIf", ctx.lancamentoFixo);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=edit-lancamento-fixo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i025.\u0275setClassDebugInfo(EditLancamentoFixoComponent, { className: "EditLancamentoFixoComponent", filePath: "src/app/pages/lancamento-fixo/edit-lancamento-fixo/edit-lancamento-fixo.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamento-fixo%2Fedit-lancamento-fixo%2Fedit-lancamento-fixo.component.ts%40EditLancamentoFixoComponent";
  function EditLancamentoFixoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i025.\u0275\u0275replaceMetadata(EditLancamentoFixoComponent, m.default, [i025, lancamento_fixo_service_exports, i26, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && EditLancamentoFixoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && EditLancamentoFixoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamento-fixo/excluir-lancamento-fixo/excluir-lancamento-fixo.component.ts
var excluir_lancamento_fixo_component_exports = {};
__export(excluir_lancamento_fixo_component_exports, {
  ExcluirLancamentoFixoComponent: () => ExcluirLancamentoFixoComponent
});
import { Component as Component17 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i026 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i27 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function ExcluirLancamentoFixoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i026.\u0275\u0275getCurrentView();
    i026.\u0275\u0275elementStart(0, "div")(1, "h2");
    i026.\u0275\u0275text(2, " Excluir ");
    i026.\u0275\u0275elementStart(3, "span");
    i026.\u0275\u0275text(4, "Lan\xE7amento Fixo");
    i026.\u0275\u0275elementEnd()();
    i026.\u0275\u0275elementStart(5, "app-lancamento-fixo-form", 1);
    i026.\u0275\u0275listener("onSubmit", function ExcluirLancamentoFixoComponent_div_0_Template_app_lancamento_fixo_form_onSubmit_5_listener($event) {
      i026.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i026.\u0275\u0275nextContext();
      return i026.\u0275\u0275resetView(ctx_r1.excluirHendler($event));
    });
    i026.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i026.\u0275\u0275nextContext();
    i026.\u0275\u0275advance(5);
    i026.\u0275\u0275property("lancamentoFixoData", ctx_r1.lancamentoFixo)("btnText", ctx_r1.btnText);
  }
}
var ExcluirLancamentoFixoComponent = class _ExcluirLancamentoFixoComponent {
  constructor(lancamentoFixoService, route, router, loginService) {
    this.lancamentoFixoService = lancamentoFixoService;
    this.route = route;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Remover";
  }
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.lancamentoFixoService.getLancamentoFixoPorId(id).subscribe((item) => {
      this.lancamentoFixo = item;
      console.log(this.lancamentoFixo.diaMes);
    });
  }
  excluirHendler(lancamentoFixoData) {
    return __async(this, null, function* () {
      const id = this.lancamentoFixo.id;
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("diaMes", lancamentoFixoData.diaMes.toString());
      formData.append("valor", lancamentoFixoData.valor.toString());
      formData.append("descricao", lancamentoFixoData.descricao);
      formData.append("status", lancamentoFixoData.status);
      formData.append("idCCusto", lancamentoFixoData.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      yield this.lancamentoFixoService.excluirLancamentoFixo(this.lancamentoFixo.id).subscribe((result) => {
        this.router.navigate(["/lancamento-fixo"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function ExcluirLancamentoFixoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ExcluirLancamentoFixoComponent)(i026.\u0275\u0275directiveInject(LancamentoFixoService), i026.\u0275\u0275directiveInject(i27.ActivatedRoute), i026.\u0275\u0275directiveInject(i27.Router), i026.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i026.\u0275\u0275defineComponent({ type: _ExcluirLancamentoFixoComponent, selectors: [["app-excluir-lancamento-fixo"]], standalone: false, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "onSubmit", "lancamentoFixoData", "btnText"]], template: function ExcluirLancamentoFixoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i026.\u0275\u0275template(0, ExcluirLancamentoFixoComponent_div_0_Template, 6, 2, "div", 0);
      }
      if (rf & 2) {
        i026.\u0275\u0275property("ngIf", ctx.lancamentoFixo);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=excluir-lancamento-fixo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i026.\u0275setClassDebugInfo(ExcluirLancamentoFixoComponent, { className: "ExcluirLancamentoFixoComponent", filePath: "src/app/pages/lancamento-fixo/excluir-lancamento-fixo/excluir-lancamento-fixo.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamento-fixo%2Fexcluir-lancamento-fixo%2Fexcluir-lancamento-fixo.component.ts%40ExcluirLancamentoFixoComponent";
  function ExcluirLancamentoFixoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i026.\u0275\u0275replaceMetadata(ExcluirLancamentoFixoComponent, m.default, [i026, lancamento_fixo_service_exports, i27, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && ExcluirLancamentoFixoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && ExcluirLancamentoFixoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamento-fixo/novo-lancamento-fixo/novo-lancamento-fixo.component.ts
var novo_lancamento_fixo_component_exports = {};
__export(novo_lancamento_fixo_component_exports, {
  NovoLancamentoFixoComponent: () => NovoLancamentoFixoComponent
});
import { Component as Component18 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i027 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i28 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
var NovoLancamentoFixoComponent = class _NovoLancamentoFixoComponent {
  constructor(lancamentoFixoService, router, loginService) {
    this.lancamentoFixoService = lancamentoFixoService;
    this.router = router;
    this.loginService = loginService;
    this.btnText = "Registrar";
  }
  ngOnInit() {
  }
  createHandler(lancamentoFixo) {
    return __async(this, null, function* () {
      const formData = new FormData();
      const idUsuario = this.loginService.getIdUsuario();
      formData.append("diaMes", lancamentoFixo.diaMes.toString());
      formData.append("valor", lancamentoFixo.valor.toString());
      formData.append("descricao", lancamentoFixo.descricao);
      formData.append("status", lancamentoFixo.status);
      formData.append("idCCusto", lancamentoFixo.idCCusto.toString());
      formData.append("idUsuario", idUsuario ?? "");
      console.log(lancamentoFixo.diaMes);
      console.log(formData.getAll("diaMes"));
      console.log(formData.getAll("valor"));
      console.log(formData.getAll("descricao"));
      console.log(formData.getAll("status"));
      console.log(formData.getAll("idCCusto"));
      console.log(formData.getAll("idUsuario"));
      yield this.lancamentoFixoService.postLancamentoFixo(formData).subscribe((result) => {
        this.router.navigate(["/lancamento-fixo"]);
      }, (error) => {
        console.log("Erro");
      });
    });
  }
  static {
    this.\u0275fac = function NovoLancamentoFixoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NovoLancamentoFixoComponent)(i027.\u0275\u0275directiveInject(LancamentoFixoService), i027.\u0275\u0275directiveInject(i28.Router), i027.\u0275\u0275directiveInject(LoginService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i027.\u0275\u0275defineComponent({ type: _NovoLancamentoFixoComponent, selectors: [["app-novo-lancamento-fixo"]], standalone: false, decls: 5, vars: 1, consts: [[3, "onSubmit", "btnText"]], template: function NovoLancamentoFixoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i027.\u0275\u0275elementStart(0, "h2");
        i027.\u0275\u0275text(1, "Registre o seu ");
        i027.\u0275\u0275elementStart(2, "span");
        i027.\u0275\u0275text(3, "Lan\xE7amento Fixo");
        i027.\u0275\u0275elementEnd()();
        i027.\u0275\u0275elementStart(4, "app-lancamento-fixo-form", 0);
        i027.\u0275\u0275listener("onSubmit", function NovoLancamentoFixoComponent_Template_app_lancamento_fixo_form_onSubmit_4_listener($event) {
          return ctx.createHandler($event);
        });
        i027.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        i027.\u0275\u0275advance(4);
        i027.\u0275\u0275property("btnText", ctx.btnText);
      }
    }, styles: ['\n\nh2[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 1em;\n  font-size: 25px;\n}\nh2[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: "#494949";\n}\n/*# sourceMappingURL=novo-lancamento-fixo.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i027.\u0275setClassDebugInfo(NovoLancamentoFixoComponent, { className: "NovoLancamentoFixoComponent", filePath: "src/app/pages/lancamento-fixo/novo-lancamento-fixo/novo-lancamento-fixo.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamento-fixo%2Fnovo-lancamento-fixo%2Fnovo-lancamento-fixo.component.ts%40NovoLancamentoFixoComponent";
  function NovoLancamentoFixoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i027.\u0275\u0275replaceMetadata(NovoLancamentoFixoComponent, m.default, [i027, lancamento_fixo_service_exports, i28, login_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && NovoLancamentoFixoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && NovoLancamentoFixoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/lancamento-fixo/tabela-lancamento-fixo/tabela-lancamento-fixo.component.ts
var tabela_lancamento_fixo_component_exports = {};
__export(tabela_lancamento_fixo_component_exports, {
  TabelaLancamentoFixoComponent: () => TabelaLancamentoFixoComponent
});
import { Component as Component19 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i028 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
function TabelaLancamentoFixoComponent_div_1_tr_15_Template(rf, ctx) {
  if (rf & 1) {
    i028.\u0275\u0275elementStart(0, "tr")(1, "td");
    i028.\u0275\u0275text(2);
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(3, "td");
    i028.\u0275\u0275text(4);
    i028.\u0275\u0275pipe(5, "formatValor");
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(6, "td");
    i028.\u0275\u0275text(7);
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(8, "td");
    i028.\u0275\u0275text(9);
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(10, "td")(11, "div", 6)(12, "button", 7);
    i028.\u0275\u0275element(13, "i", 8);
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(14, "button", 9);
    i028.\u0275\u0275element(15, "i", 10);
    i028.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const lancamentoFixo_r1 = ctx.$implicit;
    i028.\u0275\u0275advance(2);
    i028.\u0275\u0275textInterpolate(lancamentoFixo_r1.diaMes);
    i028.\u0275\u0275advance(2);
    i028.\u0275\u0275textInterpolate(i028.\u0275\u0275pipeBind1(5, 8, lancamentoFixo_r1.valor));
    i028.\u0275\u0275advance(3);
    i028.\u0275\u0275textInterpolate(lancamentoFixo_r1.descricao);
    i028.\u0275\u0275advance(2);
    i028.\u0275\u0275textInterpolate(lancamentoFixo_r1.status);
    i028.\u0275\u0275advance(3);
    i028.\u0275\u0275propertyInterpolate1("routerLink", "/lancamento-fixo/edit/", lancamentoFixo_r1.id, "");
    i028.\u0275\u0275advance(2);
    i028.\u0275\u0275propertyInterpolate1("routerLink", "/lancamento-fixo/excluir/", lancamentoFixo_r1.id, "");
  }
}
function TabelaLancamentoFixoComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i028.\u0275\u0275elementStart(0, "div")(1, "table", 3)(2, "thead", 4)(3, "tr")(4, "th");
    i028.\u0275\u0275text(5, "Dia do M\xEAs");
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(6, "th");
    i028.\u0275\u0275text(7, "Valor");
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(8, "th");
    i028.\u0275\u0275text(9, "Descri\xE7\xE3o");
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(10, "th");
    i028.\u0275\u0275text(11, "Status");
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275elementStart(12, "th");
    i028.\u0275\u0275text(13, "A\xE7\xF5es");
    i028.\u0275\u0275elementEnd()()();
    i028.\u0275\u0275elementStart(14, "tbody");
    i028.\u0275\u0275template(15, TabelaLancamentoFixoComponent_div_1_tr_15_Template, 16, 10, "tr", 5);
    i028.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i028.\u0275\u0275nextContext();
    i028.\u0275\u0275advance(15);
    i028.\u0275\u0275property("ngForOf", ctx_r1.lancamentosFixos);
  }
}
function TabelaLancamentoFixoComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i028.\u0275\u0275elementStart(0, "h1");
    i028.\u0275\u0275text(1, "N\xE3o exitem registros cadastrados :P");
    i028.\u0275\u0275elementEnd();
  }
}
var TabelaLancamentoFixoComponent = class _TabelaLancamentoFixoComponent {
  constructor(lancamentoFixoService, centroCustoService) {
    this.lancamentoFixoService = lancamentoFixoService;
    this.centroCustoService = centroCustoService;
    this.lancamentosFixos = [];
    this.centroCustos = [];
  }
  ngOnInit() {
    this.lancamentoFixoService.getAllLancamentosFixos().subscribe((lancamentos) => this.lancamentosFixos = lancamentos);
    this.centroCustoService.getAllCentroCustos().subscribe((centroCustos) => this.centroCustos = centroCustos);
  }
  removerLancamento(id) {
    this.lancamentoFixoService.excluirLancamentoFixo(id).subscribe();
  }
  static {
    this.\u0275fac = function TabelaLancamentoFixoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TabelaLancamentoFixoComponent)(i028.\u0275\u0275directiveInject(LancamentoFixoService), i028.\u0275\u0275directiveInject(CentroCustoService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i028.\u0275\u0275defineComponent({ type: _TabelaLancamentoFixoComponent, selectors: [["app-tabela-lancamento-fixo"]], standalone: false, decls: 7, vars: 2, consts: [["noLancamentos", ""], [4, "ngIf", "ngIfElse"], ["mat-fab", "", "color", "primary", "routerLink", "/lancamento-fixo/novo/", 1, "fab"], [1, "table", "table-striped", "table-bordered", "align-middle", "shadow-sm"], [1, "table-dark"], [4, "ngFor", "ngForOf"], [1, "btn-group"], ["type", "button", 1, "btn", "btn-outline-primary", "btn-sm", "botao-editar", 3, "routerLink"], [1, "bi", "bi-pencil-square"], ["type", "button", 1, "btn", "btn-outline-danger", "btn-sm", "botao-remover", 3, "routerLink"], [1, "bi", "bi-trash"]], template: function TabelaLancamentoFixoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i028.\u0275\u0275elementStart(0, "div");
        i028.\u0275\u0275template(1, TabelaLancamentoFixoComponent_div_1_Template, 16, 1, "div", 1)(2, TabelaLancamentoFixoComponent_ng_template_2_Template, 2, 0, "ng-template", null, 0, i028.\u0275\u0275templateRefExtractor);
        i028.\u0275\u0275elementStart(4, "button", 2)(5, "mat-icon");
        i028.\u0275\u0275text(6, "add");
        i028.\u0275\u0275elementEnd()()();
      }
      if (rf & 2) {
        const noLancamentos_r3 = i028.\u0275\u0275reference(3);
        i028.\u0275\u0275advance();
        i028.\u0275\u0275property("ngIf", ctx.lancamentosFixos.length > 0)("ngIfElse", noLancamentos_r3);
      }
    }, styles: ["\n\n.container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  align-items: flex-start;\n  padding: 10px;\n  margin: 0 auto;\n  max-width: 1200px;\n}\n.date-container[_ngcontent-%COMP%], \n.checkbox-columns[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  margin-bottom: 15px;\n}\n.date-picker[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.checkbox-columns[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.checkbox-column[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  margin-bottom: 10px;\n}\n.checkbox-item[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n#status[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px;\n  border: 1px solid #ced4da;\n  border-radius: 4px;\n  background-color: #fff;\n}\n@media (min-width: 600px) {\n  .container[_ngcontent-%COMP%] {\n    flex-wrap: nowrap;\n  }\n  .date-container[_ngcontent-%COMP%] {\n    width: 45%;\n    flex-direction: column;\n  }\n  .checkbox-columns[_ngcontent-%COMP%] {\n    width: 50%;\n    flex-direction: row;\n    justify-content: space-between;\n  }\n  .checkbox-column[_ngcontent-%COMP%] {\n    width: 45%;\n  }\n}\n@media (max-width: 599px) {\n  .date-container[_ngcontent-%COMP%], \n   .checkbox-columns[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n  .checkbox-column[_ngcontent-%COMP%], \n   .date-picker[_ngcontent-%COMP%] {\n    margin: 0 auto;\n    width: 90%;\n  }\n}\n.fab[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 20px;\n  right: 20px;\n  z-index: 1000;\n  background-color: rgb(90, 165, 90);\n}\nth[_ngcontent-%COMP%] {\n  font-size: 11px;\n  background-color: rgb(73, 73, 73);\n}\ntd[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: rgb(73, 73, 73);\n}\n.botao-editar[_ngcontent-%COMP%] {\n  background-color: #e7e7fd;\n}\n.botao-remover[_ngcontent-%COMP%] {\n  background-color: #fda6a6;\n}\n/*# sourceMappingURL=tabela-lancamento-fixo.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i028.\u0275setClassDebugInfo(TabelaLancamentoFixoComponent, { className: "TabelaLancamentoFixoComponent", filePath: "src/app/pages/lancamento-fixo/tabela-lancamento-fixo/tabela-lancamento-fixo.component.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Flancamento-fixo%2Ftabela-lancamento-fixo%2Ftabela-lancamento-fixo.component.ts%40TabelaLancamentoFixoComponent";
  function TabelaLancamentoFixoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i028.\u0275\u0275replaceMetadata(TabelaLancamentoFixoComponent, m.default, [i028, lancamento_fixo_service_exports, centro_custo_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && TabelaLancamentoFixoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && TabelaLancamentoFixoComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/tabela-lancamento/tabela-lancamento.component.ts
var tabela_lancamento_component_exports = {};
__export(tabela_lancamento_component_exports, {
  TabelaLancamentoComponent: () => TabelaLancamentoComponent
});
import { Component as Component20, Input as Input5 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { EMPTY, switchMap } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i030 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";

// src/app/services/configuracoes-ia/configuracoes-ia.service.ts
var configuracoes_ia_service_exports = {};
__export(configuracoes_ia_service_exports, {
  ConfiguracoesIaService: () => ConfiguracoesIaService
});
import { Injectable as Injectable10 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { catchError as catchError9, throwError as throwError9 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import * as i029 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i111 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common_http.js?v=6e2f77a0";
var ConfiguracoesIaService = class _ConfiguracoesIaService {
  constructor(http, loginService, mensagensService) {
    this.http = http;
    this.loginService = loginService;
    this.mensagensService = mensagensService;
    this.baseApiUrl = environment.baseApiUrl;
  }
  getConfiguracaoIA() {
    const idUsuario = this.loginService.getIdUsuario();
    return this.http.get(`${this.baseApiUrl}api/configuracoesia/usuario/${idUsuario}`).pipe(catchError9((error) => {
      return throwError9(error);
    }));
  }
  putConfiguracaoIA(payload, id) {
    return this.http.put(`${this.baseApiUrl}api/configuracoesia/${id}`, __spreadProps(__spreadValues({}, payload), {
      id
    })).pipe(catchError9((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao atualizar configura\xE7\xF5es IA: ${error.status}`, void 0);
      return throwError9(error);
    }));
  }
  postAnaliseFinanceiraIa(dataDe, dataAte, textoAuxiliar) {
    const body = {
      idUsuario: Number(this.loginService.getIdUsuario()),
      dataDe,
      dataAte,
      textoAuxiliar
    };
    return this.http.post(`${this.baseApiUrl}api/analisefinanceiraia`, body).pipe(catchError9((error) => {
      this.mensagensService.mensagem("error", "Erro", `Erro ao analisar finan\xE7as com IA: ${error.status}`, void 0);
      return throwError9(error);
    }));
  }
  static {
    this.\u0275fac = function ConfiguracoesIaService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ConfiguracoesIaService)(i029.\u0275\u0275inject(i111.HttpClient), i029.\u0275\u0275inject(LoginService), i029.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i029.\u0275\u0275defineInjectable({ token: _ConfiguracoesIaService, factory: _ConfiguracoesIaService.\u0275fac, providedIn: "root" });
  }
};

// src/app/components/tabela-lancamento/tabela-lancamento.component.ts
import * as i42 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_platform-browser.js?v=6e2f77a0";
var _c05 = (a0, a1) => ({ "status-verde": a0, "status-vermelho": a1 });
function TabelaLancamentoComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    i030.\u0275\u0275elementStart(0, "div", 30);
    i030.\u0275\u0275element(1, "div", 31);
    i030.\u0275\u0275elementStart(2, "p", 32);
    i030.\u0275\u0275text(3, "Gerando insight...");
    i030.\u0275\u0275elementEnd()();
  }
}
function TabelaLancamentoComponent_app_pop_up_ia_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i030.\u0275\u0275getCurrentView();
    i030.\u0275\u0275elementStart(0, "app-pop-up-ia", 33);
    i030.\u0275\u0275listener("fechar", function TabelaLancamentoComponent_app_pop_up_ia_11_Template_app_pop_up_ia_fechar_0_listener() {
      i030.\u0275\u0275restoreView(_r2);
      const ctx_r2 = i030.\u0275\u0275nextContext();
      return i030.\u0275\u0275resetView(ctx_r2.fecharPopup());
    });
    i030.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i030.\u0275\u0275nextContext();
    i030.\u0275\u0275property("htmlIa", ctx_r2.htmlIa);
  }
}
function TabelaLancamentoComponent_option_50_Template(rf, ctx) {
  if (rf & 1) {
    i030.\u0275\u0275elementStart(0, "option", 24);
    i030.\u0275\u0275text(1);
    i030.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const centroCusto_r4 = ctx.$implicit;
    i030.\u0275\u0275property("value", centroCusto_r4.id);
    i030.\u0275\u0275advance();
    i030.\u0275\u0275textInterpolate1(" ", centroCusto_r4.descriCCusto, " ");
  }
}
function TabelaLancamentoComponent_div_54_tr_15_Template(rf, ctx) {
  if (rf & 1) {
    i030.\u0275\u0275elementStart(0, "tr", 37)(1, "td");
    i030.\u0275\u0275text(2);
    i030.\u0275\u0275pipe(3, "date");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(4, "td");
    i030.\u0275\u0275text(5);
    i030.\u0275\u0275pipe(6, "formatValor");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(7, "td");
    i030.\u0275\u0275text(8);
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(9, "td");
    i030.\u0275\u0275text(10);
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(11, "td")(12, "div", 38)(13, "button", 39);
    i030.\u0275\u0275element(14, "i", 40);
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(15, "button", 41);
    i030.\u0275\u0275element(16, "i", 42);
    i030.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const lancamento_r5 = ctx.$implicit;
    i030.\u0275\u0275property("ngClass", i030.\u0275\u0275pureFunction2(14, _c05, lancamento_r5.status === "A Pagar" || lancamento_r5.status === "A Receber", lancamento_r5.descriCCusto === "Empr\xE9stimo"));
    i030.\u0275\u0275advance(2);
    i030.\u0275\u0275textInterpolate(i030.\u0275\u0275pipeBind2(3, 9, lancamento_r5.dataHora, "dd/MM/yyyy HH:mm"));
    i030.\u0275\u0275advance(3);
    i030.\u0275\u0275textInterpolate(i030.\u0275\u0275pipeBind1(6, 12, lancamento_r5.valor));
    i030.\u0275\u0275advance(3);
    i030.\u0275\u0275textInterpolate(lancamento_r5.descricao);
    i030.\u0275\u0275advance(2);
    i030.\u0275\u0275textInterpolate(lancamento_r5.status);
    i030.\u0275\u0275advance(3);
    i030.\u0275\u0275propertyInterpolate1("routerLink", "/lancamento/edit/", lancamento_r5.id, "");
    i030.\u0275\u0275advance(2);
    i030.\u0275\u0275propertyInterpolate1("routerLink", "/lancamento/excluir/", lancamento_r5.id, "");
  }
}
function TabelaLancamentoComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    i030.\u0275\u0275elementStart(0, "div")(1, "table", 34)(2, "thead", 35)(3, "tr")(4, "th");
    i030.\u0275\u0275text(5, "Data Hora");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(6, "th");
    i030.\u0275\u0275text(7, "Valor");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(8, "th");
    i030.\u0275\u0275text(9, "Descri\xE7\xE3o");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(10, "th");
    i030.\u0275\u0275text(11, "Status");
    i030.\u0275\u0275elementEnd();
    i030.\u0275\u0275elementStart(12, "th");
    i030.\u0275\u0275text(13, "A\xE7\xF5es");
    i030.\u0275\u0275elementEnd()()();
    i030.\u0275\u0275elementStart(14, "tbody");
    i030.\u0275\u0275template(15, TabelaLancamentoComponent_div_54_tr_15_Template, 17, 17, "tr", 36);
    i030.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = i030.\u0275\u0275nextContext();
    i030.\u0275\u0275advance(15);
    i030.\u0275\u0275property("ngForOf", ctx_r2.lancamentos);
  }
}
function TabelaLancamentoComponent_ng_template_55_Template(rf, ctx) {
  if (rf & 1) {
    i030.\u0275\u0275elementStart(0, "h1");
    i030.\u0275\u0275text(1, "N\xE3o exitem registros cadastrados :P");
    i030.\u0275\u0275elementEnd();
  }
}
function TabelaLancamentoComponent_app_copiar_lancamentos_63_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i030.\u0275\u0275getCurrentView();
    i030.\u0275\u0275elementStart(0, "app-copiar-lancamentos", 43);
    i030.\u0275\u0275listener("fechar", function TabelaLancamentoComponent_app_copiar_lancamentos_63_Template_app_copiar_lancamentos_fechar_0_listener() {
      i030.\u0275\u0275restoreView(_r6);
      const ctx_r2 = i030.\u0275\u0275nextContext();
      return i030.\u0275\u0275resetView(ctx_r2.fecharCopiarLancamentos());
    });
    i030.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = i030.\u0275\u0275nextContext();
    i030.\u0275\u0275property("lancamentos", ctx_r2.lancamentos);
  }
}
var TabelaLancamentoComponent = class _TabelaLancamentoComponent {
  constructor(lancamentoService, centroCustoService, configuracoesIAService, sanitizer) {
    this.lancamentoService = lancamentoService;
    this.centroCustoService = centroCustoService;
    this.configuracoesIAService = configuracoesIAService;
    this.sanitizer = sanitizer;
    this.centroCustos = [];
    this.dataDe = "";
    this.dataAte = this.getHoje();
    this.isAPagarChecked = true;
    this.isPagoChecked = true;
    this.isAReceberChecked = true;
    this.isRecebidoChecked = true;
    this.aPagar = "";
    this.pago = "";
    this.aReceber = "";
    this.recebido = "";
    this.filtroStatus = "";
    this.filtroCentroCusto = 0;
    this.valorAPagar = 0;
    this.valorPago = 0;
    this.valorAReceber = 0;
    this.valorRecebido = 0;
    this.despesasGraficoDonut = 0;
    this.receitasGraficoDonut = 0;
    this.lancamentos = [];
    this.isLoading = true;
    this.idsInvalidos = /* @__PURE__ */ new Set([19, 51]);
    this.isPopupAberto = false;
    this.isCopiaAberto = false;
    this.isLoadingInsight = false;
  }
  ngOnInit() {
    this.filtroStatus = this.agrupaStatus();
    this.lancamentoService.getAllLancamentos().subscribe((lancamentos) => {
      if (lancamentos != null && lancamentos.length > 0) {
        const data = new Date(lancamentos[lancamentos.length - 1].dataHora);
        this.dataDe = data.toISOString().split("T")[0];
        console.log("Data de in\xEDcio definida para: " + this.dataDe);
        for (let i = 0; i < lancamentos.length; i++) {
          this.lancamentos.push(lancamentos[i]);
          this.valorAPagar += lancamentos[i].status === "A Pagar" ? lancamentos[i].valor : 0;
          this.valorPago += lancamentos[i].status === "Pago" ? lancamentos[i].valor : 0;
          this.valorAReceber += lancamentos[i].status === "A Receber" ? lancamentos[i].valor : 0;
          this.valorRecebido += lancamentos[i].status === "Recebido" ? lancamentos[i].valor : 0;
          if (this.lancamentos[i].status === "Pago" && !this.idsInvalidos.has(this.lancamentos[i].idCCusto)) {
            this.despesasGraficoDonut += lancamentos[i].valor;
          }
          if (this.lancamentos[i].status === "Recebido") {
            this.receitasGraficoDonut += lancamentos[i].valor;
          }
        }
        this.isLoading = false;
      }
    });
    this.centroCustoService.getAllCentroCustos().subscribe((centroCustos) => this.centroCustos = centroCustos);
  }
  getHoje() {
    const hoje = /* @__PURE__ */ new Date();
    return hoje.toISOString().substring(0, 10);
  }
  getDataDiasAtras(dias) {
    const data = /* @__PURE__ */ new Date();
    data.setDate(data.getDate() - dias);
    return data.toISOString().substring(0, 10);
  }
  filtrarCentroCusto(event) {
    this.filtroCentroCusto = parseInt(event.target.value, 10);
    this.filtroData();
  }
  filtroData() {
    this.valorAPagar = 0;
    this.valorPago = 0;
    this.valorAReceber = 0;
    this.valorRecebido = 0;
    this.despesasGraficoDonut = 0;
    this.receitasGraficoDonut = 0;
    this.filtroStatus = this.agrupaStatus();
    if (this.dataDe != "" && this.dataAte != "") {
      this.lancamentoService.getLancamentoDataDeAte(this.dataDe, this.dataAte, this.filtroStatus, this.filtroCentroCusto).subscribe((item) => {
        this.lancamentos = [];
        this.lancamentos = item;
        if (this.lancamentos != null) {
          for (let i = 0; i < this.lancamentos.length; i++) {
            this.valorAPagar += this.lancamentos[i].status === "A Pagar" ? this.lancamentos[i].valor : 0;
            this.valorPago += this.lancamentos[i].status === "Pago" ? this.lancamentos[i].valor : 0;
            this.valorAReceber += this.lancamentos[i].status === "A Receber" ? this.lancamentos[i].valor : 0;
            this.valorRecebido += this.lancamentos[i].status === "Recebido" ? this.lancamentos[i].valor : 0;
            if (this.lancamentos[i].status === "Pago" && !this.idsInvalidos.has(this.lancamentos[i].idCCusto)) {
              this.despesasGraficoDonut += this.lancamentos[i].valor;
            }
            if (this.lancamentos[i].status === "Recebido") {
              this.receitasGraficoDonut += this.lancamentos[i].valor;
            }
          }
          this.isLoading = false;
        }
      });
    }
  }
  agrupaStatus() {
    this.filtroStatus = "";
    this.aPagar = this.isAPagarChecked ? "A Pagar" : "";
    this.pago = this.isPagoChecked ? "Pago" : "";
    this.aReceber = this.isAReceberChecked ? "A Receber" : "";
    this.recebido = this.isRecebidoChecked ? "Recebido" : "";
    return this.aPagar + this.pago + this.aReceber + this.recebido;
  }
  removerLancamento(id) {
    this.lancamentoService.excluirLancamento(id).subscribe();
  }
  abrirInsight(event) {
    event?.stopPropagation();
    if (this.isLoadingInsight)
      return;
    this.isLoadingInsight = true;
    this.htmlIa = void 0;
    this.configuracoesIAService.getConfiguracaoIA().pipe(switchMap((item) => {
      if (!item) {
        this.isLoadingInsight = false;
        return EMPTY;
      }
      return this.configuracoesIAService.postAnaliseFinanceiraIa(this.formatarData(item.filtroDataDe), this.formatarData(item.filtroDataAte), item.prompt);
    })).subscribe({
      next: (res) => {
        this.htmlIa = this.sanitizer.bypassSecurityTrustHtml(res.analiseIA);
        this.isPopupAberto = true;
        this.isLoadingInsight = false;
      },
      error: (error) => {
        this.isLoadingInsight = false;
        console.error("Erro ao gerar an\xE1lise IA", error);
      }
    });
    document.body.classList.add("no-scroll");
  }
  formatarData(data) {
    if (!data)
      return "";
    const d = new Date(data);
    return d.toISOString().split("T")[0];
  }
  fecharPopup() {
    this.isPopupAberto = false;
    document.body.classList.remove("no-scroll");
  }
  abrirCopiarLancamentos() {
    console.log("Abrindo popup de copiar lan\xE7amentos");
    this.isCopiaAberto = true;
    document.body.classList.add("no-scroll");
  }
  fecharCopiarLancamentos() {
    this.isCopiaAberto = false;
    document.body.classList.remove("no-scroll");
  }
  static {
    this.\u0275fac = function TabelaLancamentoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TabelaLancamentoComponent)(i030.\u0275\u0275directiveInject(LancamentoService), i030.\u0275\u0275directiveInject(CentroCustoService), i030.\u0275\u0275directiveInject(ConfiguracoesIaService), i030.\u0275\u0275directiveInject(i42.DomSanitizer));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i030.\u0275\u0275defineComponent({ type: _TabelaLancamentoComponent, selectors: [["app-tabela-lancamento"]], inputs: { valorAPagar: "valorAPagar", valorPago: "valorPago", valorAReceber: "valorAReceber", valorRecebido: "valorRecebido", despesasGraficoDonut: "despesasGraficoDonut", receitasGraficoDonut: "receitasGraficoDonut", lancamentos: "lancamentos", isLoading: "isLoading" }, standalone: false, decls: 64, vars: 22, consts: [["noLancamentos", ""], [3, "valorAPagar", "valorPago", "valorAReceber", "valorRecebido", "despesasGraficoDonut", "receitasGraficoDonut", "isLoading"], [1, "ai-insight-card", 3, "click"], [1, "ai-insight-content"], [1, "ai-text"], [1, "ai-title"], [1, "ai-subtitle"], [1, "ai-icon"], ["class", "ai-loading-overlay", 4, "ngIf"], [3, "htmlIa", "fechar", 4, "ngIf"], [1, "date-container"], [1, "date-picker"], ["for", "startDate"], ["id", "startDate", "type", "date", 3, "ngModelChange", "ngModel"], ["for", "endDate"], ["id", "endDate", "type", "date", 3, "ngModelChange", "ngModel"], [1, "checkbox-group"], [1, "checkbox-column"], [1, "custom-checkbox"], ["type", "checkbox", 3, "ngModelChange", "ngModel"], [1, "select-group"], ["for", "status"], ["id", "status", "required", "", 3, "change"], ["disabled", "", "selected", "", "hidden", ""], [3, "value"], [3, "value", 4, "ngFor", "ngForOf"], [4, "ngIf", "ngIfElse"], ["mat-fab", "", "color", "primary", "routerLink", "/lancamento/novo/", 1, "fab"], ["mat-fab", "", "color", "primary", 1, "btn-copiar", 3, "click"], [3, "lancamentos", "fechar", 4, "ngIf"], [1, "ai-loading-overlay"], [1, "spinner"], [1, "loading-text"], [3, "fechar", "htmlIa"], [1, "table", "table-striped", "table-bordered", "align-middle", "shadow-sm"], [1, "table-dark"], [3, "ngClass", 4, "ngFor", "ngForOf"], [3, "ngClass"], [1, "btn-group"], ["type", "button", 1, "btn", "btn-outline-primary", "btn-sm", "botao-editar", 3, "routerLink"], [1, "bi", "bi-pencil-square"], ["type", "button", 1, "btn", "btn-outline-danger", "btn-sm", "botao-remover", 3, "routerLink"], [1, "bi", "bi-trash"], [3, "fechar", "lancamentos"]], template: function TabelaLancamentoComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i030.\u0275\u0275getCurrentView();
        i030.\u0275\u0275element(0, "app-saldos", 1);
        i030.\u0275\u0275elementStart(1, "div", 2);
        i030.\u0275\u0275listener("click", function TabelaLancamentoComponent_Template_div_click_1_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.abrirInsight($event));
        });
        i030.\u0275\u0275elementStart(2, "div", 3)(3, "div", 4)(4, "div", 5);
        i030.\u0275\u0275text(5, "Obter Insight de IA");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(6, "div", 6);
        i030.\u0275\u0275text(7, " Clique para gerar um insight financeiro ");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275elementStart(8, "div", 7);
        i030.\u0275\u0275text(9, "\u{1F4A1}");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275template(10, TabelaLancamentoComponent_div_10_Template, 4, 0, "div", 8);
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275template(11, TabelaLancamentoComponent_app_pop_up_ia_11_Template, 1, 1, "app-pop-up-ia", 9);
        i030.\u0275\u0275element(12, "br");
        i030.\u0275\u0275elementStart(13, "div")(14, "div", 10)(15, "div", 11)(16, "label", 12);
        i030.\u0275\u0275text(17, "Data de:");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(18, "input", 13);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_18_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.dataDe, $event) || (ctx.dataDe = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_18_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275elementStart(19, "div", 11)(20, "label", 14);
        i030.\u0275\u0275text(21, "Data at\xE9:");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(22, "input", 15);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_22_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.dataAte, $event) || (ctx.dataAte = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_22_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd()()();
        i030.\u0275\u0275elementStart(23, "div", 16)(24, "div", 17)(25, "label", 18)(26, "input", 19);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_26_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.isAPagarChecked, $event) || (ctx.isAPagarChecked = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_26_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(27, "span");
        i030.\u0275\u0275text(28, "A Pagar");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275elementStart(29, "label", 18)(30, "input", 19);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_30_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.isPagoChecked, $event) || (ctx.isPagoChecked = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_30_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(31, "span");
        i030.\u0275\u0275text(32, "Pago");
        i030.\u0275\u0275elementEnd()()();
        i030.\u0275\u0275elementStart(33, "div", 17)(34, "label", 18)(35, "input", 19);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_35_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.isAReceberChecked, $event) || (ctx.isAReceberChecked = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_35_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(36, "span");
        i030.\u0275\u0275text(37, "A Receber");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275elementStart(38, "label", 18)(39, "input", 19);
        i030.\u0275\u0275twoWayListener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_39_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          i030.\u0275\u0275twoWayBindingSet(ctx.isRecebidoChecked, $event) || (ctx.isRecebidoChecked = $event);
          return i030.\u0275\u0275resetView($event);
        });
        i030.\u0275\u0275listener("ngModelChange", function TabelaLancamentoComponent_Template_input_ngModelChange_39_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtroData());
        });
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(40, "span");
        i030.\u0275\u0275text(41, "Recebido");
        i030.\u0275\u0275elementEnd()()()();
        i030.\u0275\u0275elementStart(42, "div", 20)(43, "label", 21);
        i030.\u0275\u0275text(44, "Centro de Custo:");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(45, "select", 22);
        i030.\u0275\u0275listener("change", function TabelaLancamentoComponent_Template_select_change_45_listener($event) {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.filtrarCentroCusto($event));
        });
        i030.\u0275\u0275elementStart(46, "option", 23);
        i030.\u0275\u0275text(47, "Todos");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275elementStart(48, "option", 24);
        i030.\u0275\u0275text(49, "Todos");
        i030.\u0275\u0275elementEnd();
        i030.\u0275\u0275template(50, TabelaLancamentoComponent_option_50_Template, 2, 2, "option", 25);
        i030.\u0275\u0275elementEnd()()();
        i030.\u0275\u0275element(51, "br");
        i030.\u0275\u0275elementStart(52, "div")(53, "div");
        i030.\u0275\u0275template(54, TabelaLancamentoComponent_div_54_Template, 16, 1, "div", 26)(55, TabelaLancamentoComponent_ng_template_55_Template, 2, 0, "ng-template", null, 0, i030.\u0275\u0275templateRefExtractor);
        i030.\u0275\u0275elementStart(57, "button", 27)(58, "mat-icon");
        i030.\u0275\u0275text(59, "add");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275elementStart(60, "button", 28);
        i030.\u0275\u0275listener("click", function TabelaLancamentoComponent_Template_button_click_60_listener() {
          i030.\u0275\u0275restoreView(_r1);
          return i030.\u0275\u0275resetView(ctx.abrirCopiarLancamentos());
        });
        i030.\u0275\u0275elementStart(61, "mat-icon");
        i030.\u0275\u0275text(62, "content_copy");
        i030.\u0275\u0275elementEnd()();
        i030.\u0275\u0275template(63, TabelaLancamentoComponent_app_copiar_lancamentos_63_Template, 1, 1, "app-copiar-lancamentos", 29);
        i030.\u0275\u0275elementEnd()();
      }
      if (rf & 2) {
        const noLancamentos_r7 = i030.\u0275\u0275reference(56);
        i030.\u0275\u0275property("valorAPagar", ctx.valorAPagar)("valorPago", ctx.valorPago)("valorAReceber", ctx.valorAReceber)("valorRecebido", ctx.valorRecebido)("despesasGraficoDonut", ctx.despesasGraficoDonut)("receitasGraficoDonut", ctx.receitasGraficoDonut)("isLoading", ctx.isLoading);
        i030.\u0275\u0275advance();
        i030.\u0275\u0275classProp("loading", ctx.isLoadingInsight);
        i030.\u0275\u0275advance(9);
        i030.\u0275\u0275property("ngIf", ctx.isLoadingInsight);
        i030.\u0275\u0275advance();
        i030.\u0275\u0275property("ngIf", ctx.isPopupAberto);
        i030.\u0275\u0275advance(7);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.dataDe);
        i030.\u0275\u0275advance(4);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.dataAte);
        i030.\u0275\u0275advance(4);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.isAPagarChecked);
        i030.\u0275\u0275advance(4);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.isPagoChecked);
        i030.\u0275\u0275advance(5);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.isAReceberChecked);
        i030.\u0275\u0275advance(4);
        i030.\u0275\u0275twoWayProperty("ngModel", ctx.isRecebidoChecked);
        i030.\u0275\u0275advance(9);
        i030.\u0275\u0275property("value", 0);
        i030.\u0275\u0275advance(2);
        i030.\u0275\u0275property("ngForOf", ctx.centroCustos);
        i030.\u0275\u0275advance(4);
        i030.\u0275\u0275property("ngIf", ctx.lancamentos.length > 0)("ngIfElse", noLancamentos_r7);
        i030.\u0275\u0275advance(9);
        i030.\u0275\u0275property("ngIf", ctx.isCopiaAberto);
      }
    }, styles: [`

.ai-insight-card[_ngcontent-%COMP%] {
  margin-top: 12px;
  border-radius: 14px;
  padding: 14px 16px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  background:
    linear-gradient(
      120deg,
      #1dd1a1,
      #54a0ff,
      #5f27cd,
      #00d2d3);
  background-size: 300% 300%;
  animation: gradientMove 6s ease infinite;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.18);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.ai-insight-card[_ngcontent-%COMP%]:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.25);
}
.ai-insight-content[_ngcontent-%COMP%] {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #fff;
}
.ai-text[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
}
.ai-title[_ngcontent-%COMP%] {
  font-size: 16px;
  font-weight: 600;
}
.ai-subtitle[_ngcontent-%COMP%] {
  font-size: 13px;
  opacity: 0.9;
}
.ai-icon[_ngcontent-%COMP%] {
  font-size: 34px;
  filter: drop-shadow(0 0 6px rgba(255, 255, 255, 0.8)) drop-shadow(0 0 12px rgba(255, 255, 255, 0.6));
  animation: pulse 2.5s ease-in-out infinite;
}
.spinner[_ngcontent-%COMP%] {
  display: block;
  width: 32px;
  height: 32px;
  box-sizing: border-box;
  border: 4px solid rgba(255, 255, 255, 0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: _ngcontent-%COMP%_spin 0.9s linear infinite;
}
.ai-loading-overlay[_ngcontent-%COMP%] {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.45);
  -webkit-backdrop-filter: blur(2px);
  backdrop-filter: blur(2px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  pointer-events: all;
}
.loading-text[_ngcontent-%COMP%] {
  color: white;
}
@keyframes _ngcontent-%COMP%_spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.date-container[_ngcontent-%COMP%] {
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  gap: 16px;
}
.date-picker[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
}
.date-picker[_ngcontent-%COMP%]   input[type=date][_ngcontent-%COMP%] {
  padding: 8px 10px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s ease-in-out;
}
.date-picker[_ngcontent-%COMP%]   input[type=date][_ngcontent-%COMP%]:focus {
  border-color: rgb(80, 80, 80);
  box-shadow: 0 0 0 2px rgba(80, 80, 80, 0.2);
}
.checkbox-group[_ngcontent-%COMP%] {
  display: flex;
  gap: 32px;
  margin: 16px 0;
}
.checkbox-column[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.custom-checkbox[_ngcontent-%COMP%] {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  color: #333;
}
.custom-checkbox[_ngcontent-%COMP%]   input[type=checkbox][_ngcontent-%COMP%] {
  width: 18px;
  height: 18px;
  accent-color: rgb(91, 91, 151);
  cursor: pointer;
}
.select-group[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 16px;
  width: 290px;
}
.select-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {
  padding: 8px 12px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 15px;
  background-color: #fff;
  color: #333;
  appearance: none;
  background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20fill%3D'%23333'%20height%3D'24'%20viewBox%3D'0%200%2024%2024'%20width%3D'24'%20xmlns%3D'http%3A//www.w3.org/2000/svg'%3E%3Cpath%20d%3D'M7%2010l5%205%205-5H7z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 10px center;
  background-size: 18px;
}
.select-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus {
  outline: none;
  border-color: #3f51b5;
  box-shadow: 0 0 0 2px rgba(63, 81, 181, 0.2);
}
th[_ngcontent-%COMP%] {
  font-size: 11px;
  background-color: rgb(73, 73, 73);
}
td[_ngcontent-%COMP%] {
  font-size: 11px;
  color: rgb(73, 73, 73);
}
.botao-editar[_ngcontent-%COMP%] {
  background-color: #e7e7fd;
}
.botao-remover[_ngcontent-%COMP%] {
  background-color: #fda6a6;
}
.fab[_ngcontent-%COMP%] {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 1000;
  background-color: rgb(90, 165, 90, 0.8);
}
.btn-copiar[_ngcontent-%COMP%] {
  position: fixed;
  left: 20px;
  bottom: 20px;
  z-index: 1000;
  background-color: rgb(166, 177, 194, 0.8);
}
tr.status-verde[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {
  background-color: #bbecc7 !important;
}
tr.status-vermelho[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {
  background-color: #fdcdcd !important;
}
mat-form-field[_ngcontent-%COMP%] {
  width: 200px;
}
/*# sourceMappingURL=tabela-lancamento.component.css.map */`] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i030.\u0275setClassDebugInfo(TabelaLancamentoComponent, { className: "TabelaLancamentoComponent", filePath: "src/app/components/tabela-lancamento/tabela-lancamento.component.ts", lineNumber: 15 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Ftabela-lancamento%2Ftabela-lancamento.component.ts%40TabelaLancamentoComponent";
  function TabelaLancamentoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i030.\u0275\u0275replaceMetadata(TabelaLancamentoComponent, m.default, [i030, lancamento_service_exports, centro_custo_service_exports, configuracoes_ia_service_exports, i42], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && TabelaLancamentoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && TabelaLancamentoComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/donut-chart/donut-chart.component.ts
var donut_chart_component_exports = {};
__export(donut_chart_component_exports, {
  DonutChartComponent: () => DonutChartComponent
});
import { Component as Component21, Input as Input6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i031 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var DonutChartComponent = class _DonutChartComponent {
  constructor(mensagensService) {
    this.mensagensService = mensagensService;
    this._despesasGraficoDonut = 0;
    this._receitasGraficoDonut = 0;
    this.donutChartOptions = {
      responsive: true,
      cutout: "70%",
      plugins: { legend: { display: false } }
    };
    this.donutChartData = {
      labels: ["Receita", "Gastos"],
      datasets: [
        {
          data: [0, 0],
          backgroundColor: ["#28a745", "#dc3545"],
          hoverBackgroundColor: ["#218838", "#c82333"]
        }
      ]
    };
  }
  set despesasGraficoDonut(value) {
    this._despesasGraficoDonut = value || 0;
    this.updateChartData();
  }
  set receitasGraficoDonut(value) {
    this._receitasGraficoDonut = value || 0;
    this.updateChartData();
  }
  updateChartData() {
    let backgroundColors;
    let hoverColors;
    if (this._despesasGraficoDonut > 0 && this._receitasGraficoDonut === 0) {
      backgroundColors = ["#dc3545", "#dc3545"];
      hoverColors = ["#c82333", "#c82333"];
    } else if (this._receitasGraficoDonut > 0 && this._despesasGraficoDonut === 0) {
      backgroundColors = ["#28a745", "#28a745"];
      hoverColors = ["#218838", "#218838"];
    } else {
      backgroundColors = ["#28a745", "#dc3545"];
      hoverColors = ["#218838", "#c82333"];
    }
    this.donutChartData = __spreadProps(__spreadValues({}, this.donutChartData), {
      datasets: [
        __spreadProps(__spreadValues({}, this.donutChartData.datasets[0]), {
          data: [this._receitasGraficoDonut, this._despesasGraficoDonut],
          backgroundColor: backgroundColors,
          hoverBackgroundColor: hoverColors
        })
      ]
    });
  }
  onChartClick(event) {
    if (this._despesasGraficoDonut === 0 && this._receitasGraficoDonut === 0)
      return;
    this.mensagensService.mensagem(void 0, "Detalhes", void 0, `
    <p><strong>Receita:</strong> R$ ${this._receitasGraficoDonut.toFixed(2)}</p>
    <p><strong>Gastos:</strong> R$ ${this._despesasGraficoDonut.toFixed(2)}</p>
    <p><strong>Saldo:</strong> R$ ${(this._receitasGraficoDonut - this._despesasGraficoDonut).toFixed(2)}</p>
  `);
  }
  static {
    this.\u0275fac = function DonutChartComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _DonutChartComponent)(i031.\u0275\u0275directiveInject(MensagensService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i031.\u0275\u0275defineComponent({ type: _DonutChartComponent, selectors: [["app-donut-chart"]], inputs: { despesasGraficoDonut: "despesasGraficoDonut", receitasGraficoDonut: "receitasGraficoDonut" }, standalone: false, decls: 1, vars: 3, consts: [["baseChart", "", 3, "chartClick", "data", "options", "type"]], template: function DonutChartComponent_Template(rf, ctx) {
      if (rf & 1) {
        i031.\u0275\u0275elementStart(0, "canvas", 0);
        i031.\u0275\u0275listener("chartClick", function DonutChartComponent_Template_canvas_chartClick_0_listener($event) {
          return ctx.onChartClick($event);
        });
        i031.\u0275\u0275elementEnd();
      }
      if (rf & 2) {
        i031.\u0275\u0275property("data", ctx.donutChartData)("options", ctx.donutChartOptions)("type", "doughnut");
      }
    }, styles: ["\n\ncanvas[_ngcontent-%COMP%] {\n  width: 60px !important;\n  height: 60px !important;\n}\n/*# sourceMappingURL=donut-chart.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i031.\u0275setClassDebugInfo(DonutChartComponent, { className: "DonutChartComponent", filePath: "src/app/components/donut-chart/donut-chart.component.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fdonut-chart%2Fdonut-chart.component.ts%40DonutChartComponent";
  function DonutChartComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i031.\u0275\u0275replaceMetadata(DonutChartComponent, m.default, [i031, mensagens_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && DonutChartComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && DonutChartComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/pop-up-centro-custo/pop-up-centro-custo.component.ts
var pop_up_centro_custo_component_exports = {};
__export(pop_up_centro_custo_component_exports, {
  PopUpCentroCustoComponent: () => PopUpCentroCustoComponent
});
import { Component as Component22, EventEmitter as EventEmitter4, Input as Input7, Output as Output4 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i032 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i112 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
function PopUpCentroCustoComponent_div_0_div_8_tr_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i032.\u0275\u0275getCurrentView();
    i032.\u0275\u0275elementStart(0, "tr")(1, "td");
    i032.\u0275\u0275text(2);
    i032.\u0275\u0275pipe(3, "date");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(4, "td");
    i032.\u0275\u0275text(5);
    i032.\u0275\u0275pipe(6, "formatValor");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(7, "td");
    i032.\u0275\u0275text(8);
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(9, "td")(10, "div", 12)(11, "button", 13);
    i032.\u0275\u0275listener("click", function PopUpCentroCustoComponent_div_0_div_8_tr_13_Template_button_click_11_listener() {
      const item_r4 = i032.\u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = i032.\u0275\u0275nextContext(3);
      return i032.\u0275\u0275resetView(ctx_r1.abrirEdicao(item_r4.id));
    });
    i032.\u0275\u0275element(12, "i", 14);
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(13, "button", 15);
    i032.\u0275\u0275listener("click", function PopUpCentroCustoComponent_div_0_div_8_tr_13_Template_button_click_13_listener() {
      const item_r4 = i032.\u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = i032.\u0275\u0275nextContext(3);
      return i032.\u0275\u0275resetView(ctx_r1.abrirExclusao(item_r4.id));
    });
    i032.\u0275\u0275element(14, "i", 16);
    i032.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i032.\u0275\u0275advance(2);
    i032.\u0275\u0275textInterpolate(i032.\u0275\u0275pipeBind2(3, 3, item_r4.dataHora, "dd/MM/yyyy HH:mm"));
    i032.\u0275\u0275advance(3);
    i032.\u0275\u0275textInterpolate(i032.\u0275\u0275pipeBind1(6, 6, item_r4.valor));
    i032.\u0275\u0275advance(3);
    i032.\u0275\u0275textInterpolate(item_r4.descricaoLancamento);
  }
}
function PopUpCentroCustoComponent_div_0_div_8_Template(rf, ctx) {
  if (rf & 1) {
    i032.\u0275\u0275elementStart(0, "div")(1, "table", 9)(2, "thead", 10)(3, "tr")(4, "th");
    i032.\u0275\u0275text(5, "Data Hora");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(6, "th");
    i032.\u0275\u0275text(7, "Valor");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(8, "th");
    i032.\u0275\u0275text(9, "Descri\xE7\xE3o");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(10, "th");
    i032.\u0275\u0275text(11, "A\xE7\xF5es");
    i032.\u0275\u0275elementEnd()()();
    i032.\u0275\u0275elementStart(12, "tbody");
    i032.\u0275\u0275template(13, PopUpCentroCustoComponent_div_0_div_8_tr_13_Template, 15, 8, "tr", 11);
    i032.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i032.\u0275\u0275nextContext(2);
    i032.\u0275\u0275advance(13);
    i032.\u0275\u0275property("ngForOf", ctx_r1.detalhamentoGastosCC);
  }
}
function PopUpCentroCustoComponent_div_0_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i032.\u0275\u0275elementStart(0, "p", 17);
    i032.\u0275\u0275text(1, " N\xE3o existem registros para este centro de custo. ");
    i032.\u0275\u0275elementEnd();
  }
}
function PopUpCentroCustoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i032.\u0275\u0275getCurrentView();
    i032.\u0275\u0275elementStart(0, "div", 2)(1, "div", 3)(2, "div", 4)(3, "h3", 5);
    i032.\u0275\u0275text(4, "Detalhamento por Centro de Custo");
    i032.\u0275\u0275elementEnd();
    i032.\u0275\u0275elementStart(5, "button", 6);
    i032.\u0275\u0275listener("click", function PopUpCentroCustoComponent_div_0_Template_button_click_5_listener() {
      i032.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i032.\u0275\u0275nextContext();
      return i032.\u0275\u0275resetView(ctx_r1.fecharPopup());
    });
    i032.\u0275\u0275text(6, "\xD7");
    i032.\u0275\u0275elementEnd()();
    i032.\u0275\u0275elementStart(7, "div", 7);
    i032.\u0275\u0275template(8, PopUpCentroCustoComponent_div_0_div_8_Template, 14, 1, "div", 8)(9, PopUpCentroCustoComponent_div_0_ng_template_9_Template, 2, 0, "ng-template", null, 0, i032.\u0275\u0275templateRefExtractor);
    i032.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const noRegistros_r5 = i032.\u0275\u0275reference(10);
    const ctx_r1 = i032.\u0275\u0275nextContext();
    i032.\u0275\u0275advance(8);
    i032.\u0275\u0275property("ngIf", ctx_r1.detalhamentoGastosCC.length > 0)("ngIfElse", noRegistros_r5);
  }
}
var PopUpCentroCustoComponent = class _PopUpCentroCustoComponent {
  constructor(router) {
    this.router = router;
    this.aberto = false;
    this.detalhamentoGastosCC = [];
    this.fechar = new EventEmitter4();
  }
  abrirEdicao(id) {
    document.body.classList.remove("no-scroll");
    this.router.navigate(["/lancamento/edit", id]);
  }
  abrirExclusao(id) {
    document.body.classList.remove("no-scroll");
    this.router.navigate(["/lancamento/excluir", id]);
  }
  fecharPopup() {
    this.fechar.emit();
    document.body.classList.remove("no-scroll");
  }
  static {
    this.\u0275fac = function PopUpCentroCustoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _PopUpCentroCustoComponent)(i032.\u0275\u0275directiveInject(i112.Router));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i032.\u0275\u0275defineComponent({ type: _PopUpCentroCustoComponent, selectors: [["app-pop-up-centro-custo"]], inputs: { aberto: "aberto", detalhamentoGastosCC: "detalhamentoGastosCC" }, outputs: { fechar: "fechar" }, standalone: false, decls: 1, vars: 1, consts: [["noRegistros", ""], ["class", "overlay", 4, "ngIf"], [1, "overlay"], [1, "popup"], [1, "popup-header"], [1, "titulo-h3"], [1, "btn-fechar", 3, "click"], [1, "popup-body"], [4, "ngIf", "ngIfElse"], [1, "table", "table-striped", "table-bordered", "align-middle", "shadow-sm"], [1, "table-dark"], [4, "ngFor", "ngForOf"], [1, "btn-group"], ["type", "button", 1, "btn", "btn-outline-primary", "btn-sm", "botao-editar", 3, "click"], [1, "bi", "bi-pencil-square"], ["type", "button", 1, "btn", "btn-outline-danger", "btn-sm", "botao-remover", 3, "click"], [1, "bi", "bi-trash"], [1, "text-center", "mt-3"]], template: function PopUpCentroCustoComponent_Template(rf, ctx) {
      if (rf & 1) {
        i032.\u0275\u0275template(0, PopUpCentroCustoComponent_div_0_Template, 11, 2, "div", 1);
      }
      if (rf & 2) {
        i032.\u0275\u0275property("ngIf", ctx.aberto);
      }
    }, styles: ["\n\n.titulo-h3[_ngcontent-%COMP%] {\n  padding-top: 5px;\n  font-size: 16px;\n  text-align: center;\n}\n.overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0;\n  background: rgba(0, 0, 0, 0.6);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  z-index: 1050;\n}\n.popup[_ngcontent-%COMP%] {\n  background: #fff;\n  width: 90%;\n  max-width: 900px;\n  border-radius: 8px;\n  overflow: hidden;\n}\n.popup-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 16px;\n  background: #494949;\n  color: #fff;\n}\n.popup-body[_ngcontent-%COMP%] {\n  padding: 16px;\n  max-height: 70vh;\n  overflow-y: auto;\n}\n.popup-footer[_ngcontent-%COMP%] {\n  padding: 12px 16px;\n  text-align: right;\n}\n.btn-fechar[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  font-size: 22px;\n  color: #fff;\n  cursor: pointer;\n}\nth[_ngcontent-%COMP%] {\n  font-size: 11px;\n  background-color: rgb(73, 73, 73);\n}\ntd[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: rgb(73, 73, 73);\n}\n/*# sourceMappingURL=pop-up-centro-custo.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i032.\u0275setClassDebugInfo(PopUpCentroCustoComponent, { className: "PopUpCentroCustoComponent", filePath: "src/app/components/pop-up-centro-custo/pop-up-centro-custo.component.ts", lineNumber: 10 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fpop-up-centro-custo%2Fpop-up-centro-custo.component.ts%40PopUpCentroCustoComponent";
  function PopUpCentroCustoComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i032.\u0275\u0275replaceMetadata(PopUpCentroCustoComponent, m.default, [i032, i112], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && PopUpCentroCustoComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && PopUpCentroCustoComponent_HmrLoad(d.timestamp)));
})();

// src/app/pages/configuracoes-ia/configuracoes-ia.component.ts
var configuracoes_ia_component_exports = {};
__export(configuracoes_ia_component_exports, {
  ConfiguracoesIaComponent: () => ConfiguracoesIaComponent
});
import { Component as Component23, EventEmitter as EventEmitter5, Output as Output5 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { FormControl as FormControl4, FormGroup as FormGroup4, Validators as Validators6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i033 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
function ConfiguracoesIaComponent_div_7_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "p");
    i033.\u0275\u0275text(1, "A data \xE9 obrigat\xF3ria.");
    i033.\u0275\u0275elementEnd();
  }
}
function ConfiguracoesIaComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "div", 11);
    i033.\u0275\u0275template(1, ConfiguracoesIaComponent_div_7_p_1_Template, 2, 0, "p", 12);
    i033.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i033.\u0275\u0275nextContext();
    i033.\u0275\u0275advance();
    i033.\u0275\u0275property("ngIf", ctx_r0.filtroDataDe.errors == null ? null : ctx_r0.filtroDataDe.errors["required"]);
  }
}
function ConfiguracoesIaComponent_div_12_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "p");
    i033.\u0275\u0275text(1, "A data \xE9 obrigat\xF3ria.");
    i033.\u0275\u0275elementEnd();
  }
}
function ConfiguracoesIaComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "div", 11);
    i033.\u0275\u0275template(1, ConfiguracoesIaComponent_div_12_p_1_Template, 2, 0, "p", 12);
    i033.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i033.\u0275\u0275nextContext();
    i033.\u0275\u0275advance();
    i033.\u0275\u0275property("ngIf", ctx_r0.filtroDataAte.errors == null ? null : ctx_r0.filtroDataAte.errors["required"]);
  }
}
function ConfiguracoesIaComponent_div_17_p_1_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "p");
    i033.\u0275\u0275text(1, "A descri\xE7\xE3o \xE9 obrigat\xF3ria.");
    i033.\u0275\u0275elementEnd();
  }
}
function ConfiguracoesIaComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    i033.\u0275\u0275elementStart(0, "div", 11);
    i033.\u0275\u0275template(1, ConfiguracoesIaComponent_div_17_p_1_Template, 2, 0, "p", 12);
    i033.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i033.\u0275\u0275nextContext();
    i033.\u0275\u0275advance();
    i033.\u0275\u0275property("ngIf", ctx_r0.prompt.errors == null ? null : ctx_r0.prompt.errors["required"]);
  }
}
var ConfiguracoesIaComponent = class _ConfiguracoesIaComponent {
  constructor(configuracoesIAService, mensagensService) {
    this.configuracoesIAService = configuracoesIAService;
    this.mensagensService = mensagensService;
    this.listaConfiguracoesIA = [];
    this.onSubmit = new EventEmitter5();
  }
  ngOnInit() {
    this.buscarConfiguracaoIA();
    this.configuracoesIAForm = new FormGroup4({
      id: new FormControl4(""),
      filtroDataDe: new FormControl4("", Validators6.required),
      filtroDataAte: new FormControl4("", Validators6.required),
      prompt: new FormControl4("", Validators6.required),
      idUsuario: new FormControl4("")
    });
  }
  buscarConfiguracaoIA() {
    this.configuracoesIAService.getConfiguracaoIA().subscribe((item) => {
      if (!item) {
        return;
      }
      this.configuracoesIAForm.patchValue(__spreadProps(__spreadValues({}, item), {
        filtroDataDe: this.formatarData(item.filtroDataDe),
        filtroDataAte: this.formatarData(item.filtroDataAte)
      }));
      console.log(this.configuracoesIAForm);
    });
  }
  formatarData(data) {
    if (!data)
      return "";
    const d = new Date(data);
    return d.toISOString().split("T")[0];
  }
  get id() {
    return this.configuracoesIAForm.get("id");
  }
  get filtroDataDe() {
    return this.configuracoesIAForm.get("filtroDataDe");
  }
  get filtroDataAte() {
    return this.configuracoesIAForm.get("filtroDataAte");
  }
  get prompt() {
    return this.configuracoesIAForm.get("prompt");
  }
  get idUsuario() {
    return this.configuracoesIAForm.get("idUsuario");
  }
  submit() {
    if (this.configuracoesIAForm.invalid) {
      this.configuracoesIAForm.markAllAsTouched();
      return;
    }
    const payload = __spreadValues({}, this.configuracoesIAForm.value);
    const idRegistro = this.id.value;
    this.configuracoesIAService.putConfiguracaoIA(payload, idRegistro).subscribe({
      next: () => {
        this.mensagensService.mensagem("success", void 0, "Configura\xE7\xF5es de IA atualizadas com sucesso!", void 0);
      },
      error: (error) => {
        this.mensagensService.mensagem("error", void 0, "O seguinte erro foi apresentado: ${error}", void 0);
      }
    });
  }
  static {
    this.\u0275fac = function ConfiguracoesIaComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ConfiguracoesIaComponent)(i033.\u0275\u0275directiveInject(ConfiguracoesIaService), i033.\u0275\u0275directiveInject(MensagensService));
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i033.\u0275\u0275defineComponent({ type: _ConfiguracoesIaComponent, selectors: [["app-configuracoes-ia"]], outputs: { onSubmit: "onSubmit" }, standalone: false, decls: 20, vars: 5, consts: [[3, "ngSubmit", "formGroup"], [1, "h1"], [1, "form-group"], ["for", "filtroDataDe"], ["type", "date", "placeholder", "", "formControlName", "filtroDataDe"], ["class", "validation-error", 4, "ngIf"], ["for", "filtroDataAte"], ["type", "date", "placeholder", "", "formControlName", "filtroDataAte"], ["for", "prompt"], ["placeholder", "Descri\xE7\xE3o do Prompt", "formControlName", "prompt", 1, "textarea"], ["type", "submit", 1, "btn-salvar", 3, "disabled"], [1, "validation-error"], [4, "ngIf"]], template: function ConfiguracoesIaComponent_Template(rf, ctx) {
      if (rf & 1) {
        i033.\u0275\u0275elementStart(0, "form", 0);
        i033.\u0275\u0275listener("ngSubmit", function ConfiguracoesIaComponent_Template_form_ngSubmit_0_listener() {
          return ctx.submit();
        });
        i033.\u0275\u0275elementStart(1, "h1", 1);
        i033.\u0275\u0275text(2, "Configura\xE7\xF5es IA");
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275elementStart(3, "div", 2)(4, "label", 3);
        i033.\u0275\u0275text(5, "Data De:");
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275element(6, "input", 4);
        i033.\u0275\u0275template(7, ConfiguracoesIaComponent_div_7_Template, 2, 1, "div", 5);
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275elementStart(8, "div", 2)(9, "label", 6);
        i033.\u0275\u0275text(10, "Data At\xE9:");
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275element(11, "input", 7);
        i033.\u0275\u0275template(12, ConfiguracoesIaComponent_div_12_Template, 2, 1, "div", 5);
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275elementStart(13, "div", 2)(14, "label", 8);
        i033.\u0275\u0275text(15, "Prompt:");
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275element(16, "textarea", 9);
        i033.\u0275\u0275template(17, ConfiguracoesIaComponent_div_17_Template, 2, 1, "div", 5);
        i033.\u0275\u0275elementEnd();
        i033.\u0275\u0275elementStart(18, "button", 10);
        i033.\u0275\u0275text(19, " Salvar ");
        i033.\u0275\u0275elementEnd()();
      }
      if (rf & 2) {
        i033.\u0275\u0275property("formGroup", ctx.configuracoesIAForm);
        i033.\u0275\u0275advance(7);
        i033.\u0275\u0275property("ngIf", ctx.filtroDataDe.invalid && ctx.configuracoesIAForm.touched);
        i033.\u0275\u0275advance(5);
        i033.\u0275\u0275property("ngIf", ctx.filtroDataAte.invalid && ctx.configuracoesIAForm.touched);
        i033.\u0275\u0275advance(5);
        i033.\u0275\u0275property("ngIf", ctx.prompt.invalid && ctx.configuracoesIAForm.touched);
        i033.\u0275\u0275advance();
        i033.\u0275\u0275property("disabled", ctx.configuracoesIAForm.invalid);
      }
    }, styles: ['\n\n.form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  margin-bottom: 18px;\n}\n.form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  font-weight: 600;\n  color: #444;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], \n.form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n  font-size: 0.95rem;\n  border-radius: 8px;\n  border: 1px solid #d1d5db;\n  outline: none;\n  transition: border-color 0.2s ease, box-shadow 0.2s ease;\n  background-color: #fff;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus, \n.form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus {\n  border-color: #6366f1;\n  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.15);\n}\n.h1[_ngcontent-%COMP%] {\n  font-size: 1.8rem;\n  font-weight: 800;\n  margin-bottom: 28px;\n  text-align: center;\n  background:\n    linear-gradient(\n      90deg,\n      #6366f1,\n      #22d3ee);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\nh1[_ngcontent-%COMP%]::after {\n  content: "";\n  position: absolute;\n  left: 0;\n  bottom: -8px;\n  width: 48px;\n  height: 3px;\n  background-color: #6366f1;\n  border-radius: 2px;\n}\n.textarea[_ngcontent-%COMP%] {\n  min-height: 220px;\n  resize: vertical;\n  line-height: 1.5;\n}\n.validation-error[_ngcontent-%COMP%] {\n  margin-top: 4px;\n}\n.validation-error[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 0.75rem;\n  color: #dc2626;\n  margin: 0;\n}\n.form-group[_ngcontent-%COMP%]   input.ng-invalid.ng-touched[_ngcontent-%COMP%], \n.form-group[_ngcontent-%COMP%]   textarea.ng-invalid.ng-touched[_ngcontent-%COMP%] {\n  border-color: #dc2626;\n}\n.form-group[_ngcontent-%COMP%]   input.ng-invalid.ng-touched[_ngcontent-%COMP%]:focus, \n.form-group[_ngcontent-%COMP%]   textarea.ng-invalid.ng-touched[_ngcontent-%COMP%]:focus {\n  box-shadow: 0 0 0 2px rgba(220, 38, 38, 0.15);\n}\n.form-actions[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  margin-top: 28px;\n}\n.btn-salvar[_ngcontent-%COMP%] {\n  padding: 12px 36px;\n  font-size: 0.95rem;\n  font-weight: 600;\n  border: none;\n  border-radius: 10px;\n  cursor: pointer;\n  color: #fff;\n  background:\n    linear-gradient(\n      90deg,\n      #6366f1,\n      #22d3ee);\n  transition:\n    transform 0.2s ease,\n    box-shadow 0.2s ease,\n    opacity 0.2s ease;\n}\n.btn-salvar[_ngcontent-%COMP%]:hover {\n  transform: translateY(-1px);\n  box-shadow: 0 10px 20px rgba(99, 102, 241, 0.25);\n}\n.btn-salvar[_ngcontent-%COMP%]:active {\n  transform: translateY(0);\n  box-shadow: 0 6px 12px rgba(99, 102, 241, 0.2);\n}\n.btn-salvar[_ngcontent-%COMP%]:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n  box-shadow: none;\n  transform: none;\n}\n@media (max-width: 480px) {\n  .textarea[_ngcontent-%COMP%] {\n    min-height: 180px;\n  }\n  .form-actions[_ngcontent-%COMP%] {\n    justify-content: stretch;\n  }\n  .btn-salvar[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=configuracoes-ia.component.css.map */'] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i033.\u0275setClassDebugInfo(ConfiguracoesIaComponent, { className: "ConfiguracoesIaComponent", filePath: "src/app/pages/configuracoes-ia/configuracoes-ia.component.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fconfiguracoes-ia%2Fconfiguracoes-ia.component.ts%40ConfiguracoesIaComponent";
  function ConfiguracoesIaComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i033.\u0275\u0275replaceMetadata(ConfiguracoesIaComponent, m.default, [i033, configuracoes_ia_service_exports, mensagens_service_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && ConfiguracoesIaComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && ConfiguracoesIaComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/pop-up-ia/pop-up-ia.component.ts
var pop_up_ia_component_exports = {};
__export(pop_up_ia_component_exports, {
  PopUpIaComponent: () => PopUpIaComponent
});
import { Component as Component24, EventEmitter as EventEmitter6, Input as Input8, Output as Output6 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i034 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var PopUpIaComponent = class _PopUpIaComponent {
  constructor() {
    this.fechar = new EventEmitter6();
  }
  static {
    this.\u0275fac = function PopUpIaComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _PopUpIaComponent)();
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i034.\u0275\u0275defineComponent({ type: _PopUpIaComponent, selectors: [["app-pop-up-ia"]], inputs: { htmlIa: "htmlIa" }, outputs: { fechar: "fechar" }, standalone: false, decls: 8, vars: 1, consts: [[1, "overlay", 3, "click"], [1, "popup", 3, "click"], [1, "popup-header"], [1, "close-btn", 3, "click"], [1, "popup-content", 3, "innerHTML"]], template: function PopUpIaComponent_Template(rf, ctx) {
      if (rf & 1) {
        i034.\u0275\u0275elementStart(0, "div", 0);
        i034.\u0275\u0275listener("click", function PopUpIaComponent_Template_div_click_0_listener() {
          return ctx.fechar.emit();
        });
        i034.\u0275\u0275elementStart(1, "div", 1);
        i034.\u0275\u0275listener("click", function PopUpIaComponent_Template_div_click_1_listener($event) {
          return $event.stopPropagation();
        });
        i034.\u0275\u0275elementStart(2, "div", 2)(3, "span");
        i034.\u0275\u0275text(4, "\u{1F4A1} Insight da IA");
        i034.\u0275\u0275elementEnd();
        i034.\u0275\u0275elementStart(5, "button", 3);
        i034.\u0275\u0275listener("click", function PopUpIaComponent_Template_button_click_5_listener() {
          return ctx.fechar.emit();
        });
        i034.\u0275\u0275text(6, "\u2715");
        i034.\u0275\u0275elementEnd()();
        i034.\u0275\u0275element(7, "div", 4);
        i034.\u0275\u0275elementEnd()();
      }
      if (rf & 2) {
        i034.\u0275\u0275advance(7);
        i034.\u0275\u0275property("innerHTML", ctx.htmlIa, i034.\u0275\u0275sanitizeHtml);
      }
    }, styles: ["\n\n.overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0;\n  background: rgba(0, 0, 0, 0.55);\n  z-index: 1000;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.popup[_ngcontent-%COMP%] {\n  background: #ffffff;\n  width: 90%;\n  max-width: 720px;\n  max-height: 80vh;\n  border-radius: 16px;\n  overflow: hidden;\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35);\n  animation: _ngcontent-%COMP%_popupFadeIn 0.25s ease-out;\n}\n.popup-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 14px 18px;\n  background:\n    linear-gradient(\n      135deg,\n      #5f27cd,\n      #54a0ff);\n  color: #fff;\n  font-weight: 600;\n}\n.close-btn[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  color: #fff;\n  font-size: 18px;\n  cursor: pointer;\n}\n.popup-content[_ngcontent-%COMP%] {\n  padding: 18px;\n  overflow-y: auto;\n  max-height: calc(80vh - 56px);\n}\n@keyframes _ngcontent-%COMP%_popupFadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(12px) scale(0.97);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0) scale(1);\n  }\n}\n/*# sourceMappingURL=pop-up-ia.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i034.\u0275setClassDebugInfo(PopUpIaComponent, { className: "PopUpIaComponent", filePath: "src/app/components/pop-up-ia/pop-up-ia.component.ts", lineNumber: 10 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fpop-up-ia%2Fpop-up-ia.component.ts%40PopUpIaComponent";
  function PopUpIaComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i034.\u0275\u0275replaceMetadata(PopUpIaComponent, m.default, [i034], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && PopUpIaComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && PopUpIaComponent_HmrLoad(d.timestamp)));
})();

// src/app/components/copiar-lancamentos/copiar-lancamentos.component.ts
var copiar_lancamentos_component_exports = {};
__export(copiar_lancamentos_component_exports, {
  CopiarLancamentosComponent: () => CopiarLancamentosComponent
});
import { Component as Component25, Input as Input9, Output as Output7, EventEmitter as EventEmitter7 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i035 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
function CopiarLancamentosComponent_div_9_tr_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i035.\u0275\u0275getCurrentView();
    i035.\u0275\u0275elementStart(0, "tr")(1, "td")(2, "input", 13);
    i035.\u0275\u0275listener("change", function CopiarLancamentosComponent_div_9_tr_15_Template_input_change_2_listener() {
      const lancamento_r5 = i035.\u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = i035.\u0275\u0275nextContext(2);
      return i035.\u0275\u0275resetView(ctx_r2.toggleSelecao(lancamento_r5.id));
    });
    i035.\u0275\u0275elementEnd()();
    i035.\u0275\u0275elementStart(3, "td");
    i035.\u0275\u0275text(4);
    i035.\u0275\u0275pipe(5, "date");
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(6, "td");
    i035.\u0275\u0275text(7);
    i035.\u0275\u0275pipe(8, "formatValor");
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(9, "td");
    i035.\u0275\u0275text(10);
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(11, "td");
    i035.\u0275\u0275text(12);
    i035.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const lancamento_r5 = ctx.$implicit;
    const ctx_r2 = i035.\u0275\u0275nextContext(2);
    i035.\u0275\u0275advance(2);
    i035.\u0275\u0275property("checked", ctx_r2.isSelecionado(lancamento_r5.id));
    i035.\u0275\u0275advance(2);
    i035.\u0275\u0275textInterpolate(i035.\u0275\u0275pipeBind2(5, 5, lancamento_r5.dataHora, "dd/MM/yyyy HH:mm"));
    i035.\u0275\u0275advance(3);
    i035.\u0275\u0275textInterpolate(i035.\u0275\u0275pipeBind1(8, 8, lancamento_r5.valor));
    i035.\u0275\u0275advance(3);
    i035.\u0275\u0275textInterpolate(lancamento_r5.descricao);
    i035.\u0275\u0275advance(2);
    i035.\u0275\u0275textInterpolate(lancamento_r5.status);
  }
}
function CopiarLancamentosComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i035.\u0275\u0275getCurrentView();
    i035.\u0275\u0275elementStart(0, "div")(1, "table", 9)(2, "thead", 10)(3, "tr")(4, "th")(5, "input", 11);
    i035.\u0275\u0275listener("change", function CopiarLancamentosComponent_div_9_Template_input_change_5_listener($event) {
      i035.\u0275\u0275restoreView(_r2);
      const ctx_r2 = i035.\u0275\u0275nextContext();
      return i035.\u0275\u0275resetView(ctx_r2.selecionarTodos($event));
    });
    i035.\u0275\u0275elementEnd()();
    i035.\u0275\u0275elementStart(6, "th");
    i035.\u0275\u0275text(7, "Data Hora");
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(8, "th");
    i035.\u0275\u0275text(9, "Valor");
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(10, "th");
    i035.\u0275\u0275text(11, "Descri\xE7\xE3o");
    i035.\u0275\u0275elementEnd();
    i035.\u0275\u0275elementStart(12, "th");
    i035.\u0275\u0275text(13, "Status");
    i035.\u0275\u0275elementEnd()()();
    i035.\u0275\u0275elementStart(14, "tbody");
    i035.\u0275\u0275template(15, CopiarLancamentosComponent_div_9_tr_15_Template, 13, 10, "tr", 12);
    i035.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = i035.\u0275\u0275nextContext();
    i035.\u0275\u0275advance(15);
    i035.\u0275\u0275property("ngForOf", ctx_r2.lancamentos);
  }
}
function CopiarLancamentosComponent_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    i035.\u0275\u0275elementStart(0, "div", 14)(1, "p");
    i035.\u0275\u0275text(2, "Nenhum lan\xE7amento encontrado");
    i035.\u0275\u0275elementEnd()();
  }
}
var CopiarLancamentosComponent = class _CopiarLancamentosComponent {
  constructor() {
    this.lancamentos = [];
    this.fechar = new EventEmitter7();
    this.selectedLancamentos = [];
  }
  toggleSelecao(id) {
    const index = this.selectedLancamentos.indexOf(id);
    if (index > -1) {
      this.selectedLancamentos.splice(index, 1);
    } else {
      this.selectedLancamentos.push(id);
    }
  }
  isSelecionado(id) {
    return this.selectedLancamentos.includes(id);
  }
  selecionarTodos(event) {
    if (event.target.checked) {
      this.selectedLancamentos = this.lancamentos.map((l) => l.id).filter((id) => id !== void 0);
    } else {
      this.selectedLancamentos = [];
    }
  }
  copiarSelecionados() {
    if (this.selectedLancamentos.length === 0) {
      return;
    }
    const lancamentosSelecionados = this.lancamentos.filter((l) => this.selectedLancamentos.includes(l.id));
    const lancamentosPorData = /* @__PURE__ */ new Map();
    lancamentosSelecionados.forEach((lancamento) => {
      const data = new Date(lancamento.dataHora).toLocaleDateString("pt-BR");
      if (!lancamentosPorData.has(data)) {
        lancamentosPorData.set(data, []);
      }
      lancamentosPorData.get(data).push(lancamento);
    });
    const total = lancamentosSelecionados.reduce((sum, lancamento) => sum + lancamento.valor, 0);
    let textoParaCopiar = "";
    const datasOrdenadas = Array.from(lancamentosPorData.keys()).sort((a, b) => {
      const [diaA, mesA, anoA] = a.split("/").map(Number);
      const [diaB, mesB, anoB] = b.split("/").map(Number);
      return new Date(anoA, mesA - 1, diaA).getTime() - new Date(anoB, mesB - 1, diaB).getTime();
    });
    datasOrdenadas.forEach((data) => {
      textoParaCopiar += `${data}
`;
      const lancamentosData = lancamentosPorData.get(data);
      lancamentosData.forEach((lancamento) => {
        const valor = lancamento.valor.toLocaleString("pt-BR", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        textoParaCopiar += `R$ ${valor} - ${lancamento.descricao}
`;
      });
      textoParaCopiar += "\n";
    });
    textoParaCopiar += `Valor Total: R$ ${total.toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
    this.copiarParaClipboard(textoParaCopiar).then(() => {
      this.fecharPopup();
    }).catch((err) => {
      console.error("Erro ao copiar para \xE1rea de transfer\xEAncia:", err);
      this.mostrarTextoParaCopiar(textoParaCopiar);
    });
  }
  copiarParaClipboard(texto) {
    return __async(this, null, function* () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        yield navigator.clipboard.writeText(texto);
        return;
      }
      const textArea = document.createElement("textarea");
      textArea.value = texto;
      textArea.style.position = "fixed";
      textArea.style.left = "-999999px";
      textArea.style.top = "-999999px";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        const successful = document.execCommand("copy");
        if (!successful) {
          throw new Error("Falha no execCommand");
        }
      } finally {
        document.body.removeChild(textArea);
      }
    });
  }
  mostrarTextoParaCopiar(texto) {
    const modal = document.createElement("div");
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    `;
    const content = document.createElement("div");
    content.style.cssText = `
      background: white;
      padding: 20px;
      border-radius: 8px;
      max-width: 500px;
      width: 90%;
      max-height: 70vh;
      overflow-y: auto;
    `;
    content.innerHTML = `
      <h3>Copie o texto abaixo:</h3>
      <textarea style="width: 100%; height: 200px; margin: 10px 0; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace;" readonly>${texto}</textarea>
      <div style="text-align: right;">
        <button id="fechar-modal" style="padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">Fechar</button>
      </div>
    `;
    modal.appendChild(content);
    document.body.appendChild(modal);
    const textarea = content.querySelector("textarea");
    textarea.focus();
    textarea.select();
    const fecharModal = () => {
      if (document.body.contains(modal)) {
        document.body.removeChild(modal);
      }
      this.fecharPopup();
    };
    const fecharBtn = content.querySelector("#fechar-modal");
    fecharBtn.onclick = fecharModal;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        fecharModal();
        document.removeEventListener("keydown", handleKeyDown);
      }
    };
    document.addEventListener("keydown", handleKeyDown);
  }
  fecharPopup() {
    this.lancamentos = [];
    this.selectedLancamentos = [];
    this.fechar.emit();
  }
  static {
    this.\u0275fac = function CopiarLancamentosComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _CopiarLancamentosComponent)();
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i035.\u0275\u0275defineComponent({ type: _CopiarLancamentosComponent, selectors: [["app-copiar-lancamentos"]], inputs: { lancamentos: "lancamentos" }, outputs: { fechar: "fechar" }, standalone: false, decls: 15, vars: 4, consts: [["noLancamentos", ""], [1, "overlay", 3, "click"], [1, "modal-content", 3, "click"], [1, "modal-header"], ["aria-label", "Fechar", 1, "btn-close", 3, "click"], [1, "modal-body"], [4, "ngIf", "ngIfElse"], [1, "modal-footer"], [1, "btn", "btn-primary", 3, "click", "disabled"], [1, "table", "table-striped", "table-bordered", "align-middle", "shadow-sm"], [1, "table-dark"], ["type", "checkbox", 3, "change"], [4, "ngFor", "ngForOf"], ["type", "checkbox", 3, "change", "checked"], [1, "no-data"]], template: function CopiarLancamentosComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = i035.\u0275\u0275getCurrentView();
        i035.\u0275\u0275elementStart(0, "div", 1);
        i035.\u0275\u0275listener("click", function CopiarLancamentosComponent_Template_div_click_0_listener() {
          i035.\u0275\u0275restoreView(_r1);
          return i035.\u0275\u0275resetView(ctx.fecharPopup());
        });
        i035.\u0275\u0275elementStart(1, "div", 2);
        i035.\u0275\u0275listener("click", function CopiarLancamentosComponent_Template_div_click_1_listener($event) {
          i035.\u0275\u0275restoreView(_r1);
          return i035.\u0275\u0275resetView($event.stopPropagation());
        });
        i035.\u0275\u0275elementStart(2, "div", 3)(3, "h2");
        i035.\u0275\u0275text(4, "Copiar Lan\xE7amentos");
        i035.\u0275\u0275elementEnd();
        i035.\u0275\u0275elementStart(5, "button", 4);
        i035.\u0275\u0275listener("click", function CopiarLancamentosComponent_Template_button_click_5_listener() {
          i035.\u0275\u0275restoreView(_r1);
          return i035.\u0275\u0275resetView(ctx.fecharPopup());
        });
        i035.\u0275\u0275elementStart(6, "span");
        i035.\u0275\u0275text(7, "\xD7");
        i035.\u0275\u0275elementEnd()()();
        i035.\u0275\u0275elementStart(8, "div", 5);
        i035.\u0275\u0275template(9, CopiarLancamentosComponent_div_9_Template, 16, 1, "div", 6)(10, CopiarLancamentosComponent_ng_template_10_Template, 3, 0, "ng-template", null, 0, i035.\u0275\u0275templateRefExtractor);
        i035.\u0275\u0275elementEnd();
        i035.\u0275\u0275elementStart(12, "div", 7)(13, "button", 8);
        i035.\u0275\u0275listener("click", function CopiarLancamentosComponent_Template_button_click_13_listener() {
          i035.\u0275\u0275restoreView(_r1);
          return i035.\u0275\u0275resetView(ctx.copiarSelecionados());
        });
        i035.\u0275\u0275text(14);
        i035.\u0275\u0275elementEnd()()()();
      }
      if (rf & 2) {
        const noLancamentos_r6 = i035.\u0275\u0275reference(11);
        i035.\u0275\u0275advance(9);
        i035.\u0275\u0275property("ngIf", ctx.lancamentos.length > 0)("ngIfElse", noLancamentos_r6);
        i035.\u0275\u0275advance(4);
        i035.\u0275\u0275property("disabled", ctx.selectedLancamentos.length === 0);
        i035.\u0275\u0275advance();
        i035.\u0275\u0275textInterpolate1(" Copiar Selecionados (", ctx.selectedLancamentos.length, ") ");
      }
    }, styles: ["\n\n.overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0;\n  background: rgba(0, 0, 0, 0.6);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  z-index: 1050;\n  margin-top: 70px;\n}\n.modal-content[_ngcontent-%COMP%] {\n  background: white;\n  border-radius: 8px;\n  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);\n  max-width: 900px;\n  width: 90%;\n  max-height: 80vh;\n  display: flex;\n  flex-direction: column;\n  animation: _ngcontent-%COMP%_slideIn 0.3s ease-out;\n}\nth[_ngcontent-%COMP%] {\n  font-size: 11px;\n  background-color: rgb(73, 73, 73);\n}\ntd[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: rgb(73, 73, 73);\n}\n@keyframes _ngcontent-%COMP%_slideIn {\n  from {\n    transform: translateY(-50px);\n    opacity: 0;\n  }\n  to {\n    transform: translateY(0);\n    opacity: 1;\n  }\n}\n.modal-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 20px;\n  border-bottom: 1px solid #e0e0e0;\n}\n.modal-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 24px;\n  font-weight: 600;\n  color: #333;\n}\n.btn-close[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  font-size: 28px;\n  cursor: pointer;\n  color: #666;\n  padding: 0;\n  width: 30px;\n  height: 30px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  transition: color 0.2s;\n}\n.btn-close[_ngcontent-%COMP%]:hover {\n  color: #333;\n}\n.modal-body[_ngcontent-%COMP%] {\n  padding: 20px;\n  overflow-y: auto;\n  flex: 1;\n}\n.modal-body[_ngcontent-%COMP%]   .table[_ngcontent-%COMP%] {\n  margin-bottom: 0;\n}\n.modal-body[_ngcontent-%COMP%]   .table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  top: 0;\n  background-color: #212529;\n  color: white;\n}\n.no-data[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 40px 20px;\n  color: #999;\n  font-size: 16px;\n}\n.modal-footer[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  gap: 10px;\n  padding: 20px;\n  border-top: 1px solid #e0e0e0;\n  background-color: #f9f9f9;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  padding: 8px 16px;\n  border-radius: 4px;\n  border: none;\n  cursor: pointer;\n  font-size: 14px;\n  font-weight: 500;\n  transition: all 0.2s;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn-secondary[_ngcontent-%COMP%] {\n  background-color: #6c757d;\n  color: white;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn-secondary[_ngcontent-%COMP%]:hover {\n  background-color: #5a6268;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  background-color: #007bff;\n  color: white;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background-color: #0056b3;\n}\n.modal-footer[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%]:disabled {\n  background-color: #ccc;\n  cursor: not-allowed;\n}\n@media (max-width: 600px) {\n  .modal-content[_ngcontent-%COMP%] {\n    width: 95%;\n    max-height: 90vh;\n  }\n  .modal-header[_ngcontent-%COMP%] {\n    padding: 15px;\n  }\n  .modal-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 20px;\n  }\n  .modal-body[_ngcontent-%COMP%] {\n    padding: 15px;\n  }\n  .modal-footer[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n  .modal-footer[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=copiar-lancamentos.component.css.map */"] });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i035.\u0275setClassDebugInfo(CopiarLancamentosComponent, { className: "CopiarLancamentosComponent", filePath: "src/app/components/copiar-lancamentos/copiar-lancamentos.component.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fcopiar-lancamentos%2Fcopiar-lancamentos.component.ts%40CopiarLancamentosComponent";
  function CopiarLancamentosComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i035.\u0275\u0275replaceMetadata(CopiarLancamentosComponent, m.default, [i035], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && CopiarLancamentosComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && CopiarLancamentosComponent_HmrLoad(d.timestamp)));
})();

// src/app/pipes/format-valor.pipe.ts
var format_valor_pipe_exports = {};
__export(format_valor_pipe_exports, {
  FormatValorPipe: () => FormatValorPipe
});
import { Pipe } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i036 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var FormatValorPipe = class _FormatValorPipe {
  transform(valor) {
    if (valor == null || isNaN(valor)) {
      return "0,00";
    }
    let numero = parseFloat(valor);
    return numero.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  static {
    this.\u0275fac = function FormatValorPipe_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormatValorPipe)();
    };
  }
  static {
    this.\u0275pipe = /* @__PURE__ */ i036.\u0275\u0275definePipe({ name: "formatValor", type: _FormatValorPipe, pure: true, standalone: false });
  }
};

// src/app/pages/home/home.component.ts
var HomeComponent = class _HomeComponent {
  static {
    this.\u0275fac = function HomeComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _HomeComponent)();
    };
  }
  static {
    this.\u0275cmp = /* @__PURE__ */ i037.\u0275\u0275defineComponent({ type: _HomeComponent, selectors: [["app-home"]], standalone: false, decls: 1, vars: 0, template: function HomeComponent_Template(rf, ctx) {
      if (rf & 1) {
        i037.\u0275\u0275element(0, "app-tabela-lancamento");
      }
    }, dependencies: [i113.RouterOutlet, i113.RouterLink, i113.RouterLinkActive, i113.\u0275EmptyOutletComponent, i29.\u0275NgNoValidate, i29.NgSelectOption, i29.\u0275NgSelectMultipleOption, i29.DefaultValueAccessor, i29.NumberValueAccessor, i29.RangeValueAccessor, i29.CheckboxControlValueAccessor, i29.SelectControlValueAccessor, i29.SelectMultipleControlValueAccessor, i29.RadioControlValueAccessor, i29.NgControlStatus, i29.NgControlStatusGroup, i29.RequiredValidator, i29.MinLengthValidator, i29.MaxLengthValidator, i29.PatternValidator, i29.CheckboxRequiredValidator, i29.EmailValidator, i29.MinValidator, i29.MaxValidator, i29.NgModel, i29.NgModelGroup, i29.NgForm, i29.FormControlDirective, i29.FormGroupDirective, i29.FormControlName, i29.FormGroupName, i29.FormArrayName, i33.NgClass, i33.NgComponentOutlet, i33.NgForOf, i33.NgIf, i33.NgTemplateOutlet, i33.NgStyle, i33.NgSwitch, i33.NgSwitchCase, i33.NgSwitchDefault, i33.NgPlural, i33.NgPluralCase, i43.MatCard, i43.MatCardActions, i43.MatCardAvatar, i43.MatCardContent, i43.MatCardFooter, i43.MatCardHeader, i43.MatCardImage, i43.MatCardLgImage, i43.MatCardMdImage, i43.MatCardSmImage, i43.MatCardSubtitle, i43.MatCardTitle, i43.MatCardTitleGroup, i43.MatCardXlImage, i5.Dir, i6.CdkScrollable, i7.MatDrawer, i7.MatDrawerContainer, i7.MatDrawerContent, i7.MatSidenav, i7.MatSidenavContainer, i7.MatSidenavContent, i8.MatList, i8.MatActionList, i8.MatNavList, i8.MatSelectionList, i8.MatListItem, i8.MatListOption, i8.MatListItemAvatar, i8.MatListItemIcon, i8.MatListSubheaderCssMatStyler, i9.MatDivider, i8.MatListItemLine, i8.MatListItemTitle, i8.MatListItemMeta, i10.MatIcon, i11.MatToolbar, i11.MatToolbarRow, i122.MatAnchor, i122.MatButton, i122.MatIconAnchor, i122.MatIconButton, i122.MatMiniFabAnchor, i122.MatMiniFabButton, i122.MatFabAnchor, i122.MatFabButton, i132.MatCalendar, i132.MatCalendarBody, i132.MatDatepicker, i132.MatDatepickerContent, i132.MatDatepickerInput, i132.MatDatepickerToggle, i132.MatDatepickerToggleIcon, i132.MatMonthView, i132.MatYearView, i132.MatMultiYearView, i132.MatCalendarHeader, i132.MatDateRangeInput, i132.MatStartDate, i132.MatEndDate, i132.MatDateRangePicker, i132.MatDatepickerActions, i132.MatDatepickerCancel, i132.MatDatepickerApply, i142.MatFormField, i142.MatLabel, i142.MatHint, i142.MatError, i142.MatPrefix, i142.MatSuffix, i152.MatInput, i162.CdkAutofill, i162.CdkTextareaAutosize, i172.BaseChartDirective, i182.NgxSkeletonLoaderComponent, AppComponent, FooterComponent, GraficosComponent, NovoLancamentoComponent, LancamentoFormComponent, EditLancamentoComponent, ExcluirLancamentoComponent, SaldosComponent, LoginComponent, CentroCustoFormComponent, EditCentroCustoComponent, ExcluirCentroCustoComponent, NovoCentroCustoComponent, TabelaCentroCustoComponent, LancamentoFixoFormComponent, EditLancamentoFixoComponent, ExcluirLancamentoFixoComponent, NovoLancamentoFixoComponent, TabelaLancamentoFixoComponent, TabelaLancamentoComponent, DonutChartComponent, PopUpCentroCustoComponent, ConfiguracoesIaComponent, PopUpIaComponent, CopiarLancamentosComponent, i33.AsyncPipe, i33.UpperCasePipe, i33.LowerCasePipe, i33.JsonPipe, i33.SlicePipe, i33.DecimalPipe, i33.PercentPipe, i33.TitleCasePipe, i33.CurrencyPipe, i33.DatePipe, i33.I18nPluralPipe, i33.I18nSelectPipe, i33.KeyValuePipe, FormatValorPipe], encapsulation: 2 });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i037.\u0275setClassDebugInfo(HomeComponent, { className: "HomeComponent", filePath: "src/app/pages/home/home.component.ts", lineNumber: 9 });
})();
(() => {
  const id = "src%2Fapp%2Fpages%2Fhome%2Fhome.component.ts%40HomeComponent";
  function HomeComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(new URL("./@ng/component?c=" + id + "&t=" + encodeURIComponent(t), import.meta.url).href, 'import')
    ).then((m) => m.default && i037.\u0275\u0275replaceMetadata(HomeComponent, m.default, [i037, i113, i29, i33, i43, i5, i6, i7, i8, i9, i10, i11, i122, i132, i142, i152, i162, i172, i182, app_component_exports, footer_component_exports, graficos_component_exports, novo_lancamento_component_exports, lancamento_form_component_exports, edit_lancamento_component_exports, excluir_lancamento_component_exports, saldos_component_exports, login_component_exports, centro_custo_form_component_exports, edit_centro_custo_component_exports, excluir_centro_custo_component_exports, novo_centro_custo_component_exports, tabela_centro_custo_component_exports, lancamento_fixo_form_component_exports, edit_lancamento_fixo_component_exports, excluir_lancamento_fixo_component_exports, novo_lancamento_fixo_component_exports, tabela_lancamento_fixo_component_exports, tabela_lancamento_component_exports, donut_chart_component_exports, pop_up_centro_custo_component_exports, configuracoes_ia_component_exports, pop_up_ia_component_exports, copiar_lancamentos_component_exports, format_valor_pipe_exports], [], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && HomeComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && HomeComponent_HmrLoad(d.timestamp)));
})();

// src/app/app-routing.module.ts
import * as i038 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
var routes = [
  { path: "login", component: LoginComponent },
  { path: "", component: HomeComponent },
  { path: "graficos", component: GraficosComponent },
  { path: "lancamento/edit/:id", component: EditLancamentoComponent },
  { path: "lancamento/excluir/:id", component: ExcluirLancamentoComponent },
  { path: "lancamento/novo", component: NovoLancamentoComponent },
  { path: "lancamento-fixo", component: TabelaLancamentoFixoComponent },
  { path: "lancamento-fixo/edit/:id", component: EditLancamentoFixoComponent },
  { path: "lancamento-fixo/excluir/:id", component: ExcluirLancamentoFixoComponent },
  { path: "lancamento-fixo/novo", component: NovoLancamentoFixoComponent },
  { path: "centro-custo", component: TabelaCentroCustoComponent },
  { path: "centro-custo/edit/:id", component: EditCentroCustoComponent },
  { path: "centro-custo/excluir/:id", component: ExcluirCentroCustoComponent },
  { path: "centro-custo/novo", component: NovoCentroCustoComponent },
  { path: "configuracoes-ia", component: ConfiguracoesIaComponent }
];
var AppRoutingModule = class _AppRoutingModule {
  static {
    this.\u0275fac = function AppRoutingModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _AppRoutingModule)();
    };
  }
  static {
    this.\u0275mod = /* @__PURE__ */ i038.\u0275\u0275defineNgModule({ type: _AppRoutingModule });
  }
  static {
    this.\u0275inj = /* @__PURE__ */ i038.\u0275\u0275defineInjector({ imports: [RouterModule.forRoot(routes), RouterModule] });
  }
};

// src/app/app.module.ts
import { MatSidenavModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_sidenav.js?v=6e2f77a0";
import { MatListModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_list.js?v=6e2f77a0";
import { MatIconModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_icon.js?v=6e2f77a0";
import { MatToolbarModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_toolbar.js?v=6e2f77a0";
import { MatButtonModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_button.js?v=6e2f77a0";
import { MatDatepickerModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_datepicker.js?v=6e2f77a0";
import { MatFormFieldModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_form-field.js?v=6e2f77a0";
import { MatNativeDateModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_core.js?v=6e2f77a0";
import { MatInputModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_input.js?v=6e2f77a0";
import { MatCardModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_card.js?v=6e2f77a0";
import { BrowserAnimationsModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_platform-browser_animations.js?v=6e2f77a0";

// src/app/services/interceptor/interceptor.service.ts
import { Injectable as Injectable11 } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import { throwError as throwError10, BehaviorSubject } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs.js?v=6e2f77a0";
import { catchError as catchError10, switchMap as switchMap2, filter, take } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/rxjs_operators.js?v=6e2f77a0";
import * as i039 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i210 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
var AuthInterceptor = class _AuthInterceptor {
  constructor(loginService, router, mensagensService) {
    this.loginService = loginService;
    this.router = router;
    this.mensagensService = mensagensService;
    this.isRefreshing = false;
    this.refreshTokenSubject = new BehaviorSubject(null);
  }
  intercept(req, next) {
    const authToken = this.loginService.getAuthToken();
    if (authToken) {
      req = this.addToken(req, authToken);
    }
    return next.handle(req).pipe(catchError10((error) => {
      if (error.status === 401 && !req.url.includes("auth/login") && !req.url.includes("auth/refresh")) {
        return this.handle401Error(req, next);
      } else if (error.status !== 401) {
        this.mensagensService.mensagem("error", "Erro", `Erro na requisi\xE7\xE3o: ${error.status}`, void 0);
      }
      return throwError10(() => error);
    }));
  }
  handle401Error(request, next) {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
      const refreshToken = this.loginService.getRefreshToken();
      console.log("Refresh Token:", refreshToken);
      if (!refreshToken) {
        this.isRefreshing = false;
        this.router.navigate(["/login"]);
        return throwError10(() => new Error("401"));
      }
      return this.loginService.refreshToken().pipe(switchMap2((tokens) => {
        this.isRefreshing = false;
        this.refreshTokenSubject.next(tokens.token);
        this.loginService.storeTokens(tokens);
        return next.handle(this.addToken(request, tokens.token));
      }), catchError10((err) => {
        this.isRefreshing = false;
        this.loginService.clearTokens();
        this.loginService.logout();
        return throwError10(() => err);
      }));
    } else {
      return this.refreshTokenSubject.pipe(filter((token) => token !== null), take(1), switchMap2((token) => next.handle(this.addToken(request, token))));
    }
  }
  addToken(request, token) {
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }
  static {
    this.\u0275fac = function AuthInterceptor_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _AuthInterceptor)(i039.\u0275\u0275inject(LoginService), i039.\u0275\u0275inject(i210.Router), i039.\u0275\u0275inject(MensagensService));
    };
  }
  static {
    this.\u0275prov = /* @__PURE__ */ i039.\u0275\u0275defineInjectable({ token: _AuthInterceptor, factory: _AuthInterceptor.\u0275fac });
  }
};

// src/app/app.module.ts
import { NgChartsModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ng2-charts.js?v=6e2f77a0";
import { NgxSkeletonLoaderModule } from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ngx-skeleton-loader.js?v=6e2f77a0";
import * as i040 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_core.js?v=6e2f77a0";
import * as i114 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_router.js?v=6e2f77a0";
import * as i211 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_forms.js?v=6e2f77a0";
import * as i34 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_common.js?v=6e2f77a0";
import * as i44 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_card.js?v=6e2f77a0";
import * as i52 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_bidi.js?v=6e2f77a0";
import * as i62 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_scrolling.js?v=6e2f77a0";
import * as i72 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_sidenav.js?v=6e2f77a0";
import * as i82 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_list.js?v=6e2f77a0";
import * as i92 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_divider.js?v=6e2f77a0";
import * as i102 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_icon.js?v=6e2f77a0";
import * as i115 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_toolbar.js?v=6e2f77a0";
import * as i123 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_button.js?v=6e2f77a0";
import * as i133 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_datepicker.js?v=6e2f77a0";
import * as i143 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_form-field.js?v=6e2f77a0";
import * as i153 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_material_input.js?v=6e2f77a0";
import * as i163 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/@angular_cdk_text-field.js?v=6e2f77a0";
import * as i173 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ng2-charts.js?v=6e2f77a0";
import * as i183 from "/@fs/C:/Users/adeni/Desenvolvimento/Angular/gestaoFinanceira/.angular/cache/19.2.0/gestaoFinanceira/vite/deps/ngx-skeleton-loader.js?v=6e2f77a0";
var AppModule = class _AppModule {
  static {
    this.\u0275fac = function AppModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _AppModule)();
    };
  }
  static {
    this.\u0275mod = /* @__PURE__ */ i040.\u0275\u0275defineNgModule({ type: _AppModule, bootstrap: [AppComponent] });
  }
  static {
    this.\u0275inj = /* @__PURE__ */ i040.\u0275\u0275defineInjector({ providers: [
      { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
      provideHttpClient(withInterceptorsFromDi())
    ], imports: [
      AppRoutingModule,
      FormsModule,
      ReactiveFormsModule,
      BrowserModule,
      BrowserAnimationsModule,
      MatCardModule,
      MatSidenavModule,
      MatListModule,
      MatIconModule,
      MatToolbarModule,
      MatButtonModule,
      MatDatepickerModule,
      MatFormFieldModule,
      MatNativeDateModule,
      MatInputModule,
      NgChartsModule,
      NgxSkeletonLoaderModule
    ] });
  }
};
i040.\u0275\u0275setComponentScope(AppComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(FooterComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(GraficosComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(NovoLancamentoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(LancamentoFormComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(EditLancamentoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(ExcluirLancamentoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(SaldosComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(LoginComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(CentroCustoFormComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(EditCentroCustoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(ExcluirCentroCustoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(NovoCentroCustoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(TabelaCentroCustoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(LancamentoFixoFormComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(EditLancamentoFixoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(ExcluirLancamentoFixoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(NovoLancamentoFixoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(TabelaLancamentoFixoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(TabelaLancamentoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(DonutChartComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(PopUpCentroCustoComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(ConfiguracoesIaComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  PopUpIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(PopUpIaComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  CopiarLancamentosComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);
i040.\u0275\u0275setComponentScope(CopiarLancamentosComponent, [
  i114.RouterOutlet,
  i114.RouterLink,
  i114.RouterLinkActive,
  i114.\u0275EmptyOutletComponent,
  i211.\u0275NgNoValidate,
  i211.NgSelectOption,
  i211.\u0275NgSelectMultipleOption,
  i211.DefaultValueAccessor,
  i211.NumberValueAccessor,
  i211.RangeValueAccessor,
  i211.CheckboxControlValueAccessor,
  i211.SelectControlValueAccessor,
  i211.SelectMultipleControlValueAccessor,
  i211.RadioControlValueAccessor,
  i211.NgControlStatus,
  i211.NgControlStatusGroup,
  i211.RequiredValidator,
  i211.MinLengthValidator,
  i211.MaxLengthValidator,
  i211.PatternValidator,
  i211.CheckboxRequiredValidator,
  i211.EmailValidator,
  i211.MinValidator,
  i211.MaxValidator,
  i211.NgModel,
  i211.NgModelGroup,
  i211.NgForm,
  i211.FormControlDirective,
  i211.FormGroupDirective,
  i211.FormControlName,
  i211.FormGroupName,
  i211.FormArrayName,
  i34.NgClass,
  i34.NgComponentOutlet,
  i34.NgForOf,
  i34.NgIf,
  i34.NgTemplateOutlet,
  i34.NgStyle,
  i34.NgSwitch,
  i34.NgSwitchCase,
  i34.NgSwitchDefault,
  i34.NgPlural,
  i34.NgPluralCase,
  i44.MatCard,
  i44.MatCardActions,
  i44.MatCardAvatar,
  i44.MatCardContent,
  i44.MatCardFooter,
  i44.MatCardHeader,
  i44.MatCardImage,
  i44.MatCardLgImage,
  i44.MatCardMdImage,
  i44.MatCardSmImage,
  i44.MatCardSubtitle,
  i44.MatCardTitle,
  i44.MatCardTitleGroup,
  i44.MatCardXlImage,
  i52.Dir,
  i62.CdkScrollable,
  i72.MatDrawer,
  i72.MatDrawerContainer,
  i72.MatDrawerContent,
  i72.MatSidenav,
  i72.MatSidenavContainer,
  i72.MatSidenavContent,
  i82.MatList,
  i82.MatActionList,
  i82.MatNavList,
  i82.MatSelectionList,
  i82.MatListItem,
  i82.MatListOption,
  i82.MatListItemAvatar,
  i82.MatListItemIcon,
  i82.MatListSubheaderCssMatStyler,
  i92.MatDivider,
  i82.MatListItemLine,
  i82.MatListItemTitle,
  i82.MatListItemMeta,
  i102.MatIcon,
  i115.MatToolbar,
  i115.MatToolbarRow,
  i123.MatAnchor,
  i123.MatButton,
  i123.MatIconAnchor,
  i123.MatIconButton,
  i123.MatMiniFabAnchor,
  i123.MatMiniFabButton,
  i123.MatFabAnchor,
  i123.MatFabButton,
  i133.MatCalendar,
  i133.MatCalendarBody,
  i133.MatDatepicker,
  i133.MatDatepickerContent,
  i133.MatDatepickerInput,
  i133.MatDatepickerToggle,
  i133.MatDatepickerToggleIcon,
  i133.MatMonthView,
  i133.MatYearView,
  i133.MatMultiYearView,
  i133.MatCalendarHeader,
  i133.MatDateRangeInput,
  i133.MatStartDate,
  i133.MatEndDate,
  i133.MatDateRangePicker,
  i133.MatDatepickerActions,
  i133.MatDatepickerCancel,
  i133.MatDatepickerApply,
  i143.MatFormField,
  i143.MatLabel,
  i143.MatHint,
  i143.MatError,
  i143.MatPrefix,
  i143.MatSuffix,
  i153.MatInput,
  i163.CdkAutofill,
  i163.CdkTextareaAutosize,
  i173.BaseChartDirective,
  i183.NgxSkeletonLoaderComponent,
  AppComponent,
  FooterComponent,
  HomeComponent,
  GraficosComponent,
  NovoLancamentoComponent,
  LancamentoFormComponent,
  EditLancamentoComponent,
  ExcluirLancamentoComponent,
  SaldosComponent,
  LoginComponent,
  CentroCustoFormComponent,
  EditCentroCustoComponent,
  ExcluirCentroCustoComponent,
  NovoCentroCustoComponent,
  TabelaCentroCustoComponent,
  LancamentoFixoFormComponent,
  EditLancamentoFixoComponent,
  ExcluirLancamentoFixoComponent,
  NovoLancamentoFixoComponent,
  TabelaLancamentoFixoComponent,
  TabelaLancamentoComponent,
  DonutChartComponent,
  PopUpCentroCustoComponent,
  ConfiguracoesIaComponent,
  PopUpIaComponent
], [i34.AsyncPipe, i34.UpperCasePipe, i34.LowerCasePipe, i34.JsonPipe, i34.SlicePipe, i34.DecimalPipe, i34.PercentPipe, i34.TitleCasePipe, i34.CurrencyPipe, i34.DatePipe, i34.I18nPluralPipe, i34.I18nSelectPipe, i34.KeyValuePipe, FormatValorPipe]);

// src/main.ts
__NgCli_bootstrap_1.platformBrowser().bootstrapModule(AppModule).catch((err) => console.error(err));


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLm1vZHVsZS50cyIsInNyYy9hcHAvYXBwLXJvdXRpbmcubW9kdWxlLnRzIiwic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50LnRzIiwic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQudHMiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZS50cyIsInNyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQudHMiLCJzcmMvYXBwL3NlcnZpY2VzL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZS50cyIsInNyYy9hcHAvY29tcG9uZW50cy9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC50cyIsInNyYy9hcHAvY29tcG9uZW50cy9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9wYWdlcy9ncmFmaWNvcy9ncmFmaWNvcy5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2dyYWZpY29zL2dyYWZpY29zLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC91dGlscy9jb2xvcnMudHMiLCJzcmMvYXBwL3NlcnZpY2VzL2dhc3Rvcy1tZW5zYWlzL2dhc3Rvcy1tZW5zYWlzLnNlcnZpY2UudHMiLCJzcmMvYXBwL3NlcnZpY2VzL2dhc3Rvcy1jZW50cm8tY3VzdG8vZ2FzdG9zLWNlbnRyby1jdXN0by5zZXJ2aWNlLnRzIiwic3JjL2FwcC9zZXJ2aWNlcy9kZXRhbGhhbWVudG8tZ2FzdG9zLWN1c3RvL2RldGFsaGFtZW50by1nYXN0b3MtY2VudHJvLWN1c3RvLnNlcnZpY2UudHMiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG9zL25vdm8tbGFuY2FtZW50by9ub3ZvLWxhbmNhbWVudG8uY29tcG9uZW50LnRzIiwic3JjL2FwcC9wYWdlcy9sYW5jYW1lbnRvcy9ub3ZvLWxhbmNhbWVudG8vbm92by1sYW5jYW1lbnRvLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9zZXJ2aWNlcy9sYW5jYW1lbnRvL2xhbmNhbWVudG8uc2VydmljZS50cyIsInNyYy9hcHAvY29tcG9uZW50cy9sYW5jYW1lbnRvLWZvcm0vbGFuY2FtZW50by1mb3JtLmNvbXBvbmVudC50cyIsInNyYy9hcHAvY29tcG9uZW50cy9sYW5jYW1lbnRvLWZvcm0vbGFuY2FtZW50by1mb3JtLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9zZXJ2aWNlcy9jZXRyby1jdXN0by9jZW50cm8tY3VzdG8uc2VydmljZS50cyIsInNyYy9hcHAvcGFnZXMvbGFuY2FtZW50b3MvZWRpdC1sYW5jYW1lbnRvL2VkaXQtbGFuY2FtZW50by5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG9zL2VkaXQtbGFuY2FtZW50by9lZGl0LWxhbmNhbWVudG8uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG9zL2V4Y2x1aXItbGFuY2FtZW50by9leGNsdWlyLWxhbmNhbWVudG8uY29tcG9uZW50LnRzIiwic3JjL2FwcC9wYWdlcy9sYW5jYW1lbnRvcy9leGNsdWlyLWxhbmNhbWVudG8vZXhjbHVpci1sYW5jYW1lbnRvLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9jb21wb25lbnRzL3NhbGRvcy9zYWxkb3MuY29tcG9uZW50LnRzIiwic3JjL2FwcC9jb21wb25lbnRzL3NhbGRvcy9zYWxkb3MuY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3NlcnZpY2VzL3NhbGRvL3NhbGRvLnNlcnZpY2UudHMiLCJzcmMvYXBwL3BhZ2VzL2xvZ2luL2xvZ2luLmNvbXBvbmVudC50cyIsInNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvY2VudHJvLWN1c3RvLWZvcm0vY2VudHJvLWN1c3RvLWZvcm0uY29tcG9uZW50LnRzIiwic3JjL2FwcC9jb21wb25lbnRzL2NlbnRyby1jdXN0by1mb3JtL2NlbnRyby1jdXN0by1mb3JtLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9wYWdlcy9jZW50cm8tY3VzdG8vZWRpdC1jZW50cm8tY3VzdG8vZWRpdC1jZW50cm8tY3VzdG8uY29tcG9uZW50LnRzIiwic3JjL2FwcC9wYWdlcy9jZW50cm8tY3VzdG8vZWRpdC1jZW50cm8tY3VzdG8vZWRpdC1jZW50cm8tY3VzdG8uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BhZ2VzL2NlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2NlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvcGFnZXMvY2VudHJvLWN1c3RvL25vdm8tY2VudHJvLWN1c3RvL25vdm8tY2VudHJvLWN1c3RvLmNvbXBvbmVudC50cyIsInNyYy9hcHAvcGFnZXMvY2VudHJvLWN1c3RvL25vdm8tY2VudHJvLWN1c3RvL25vdm8tY2VudHJvLWN1c3RvLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9wYWdlcy9jZW50cm8tY3VzdG8vdGFiZWxhLWNlbnRyby1jdXN0by90YWJlbGEtY2VudHJvLWN1c3RvLmNvbXBvbmVudC50cyIsInNyYy9hcHAvcGFnZXMvY2VudHJvLWN1c3RvL3RhYmVsYS1jZW50cm8tY3VzdG8vdGFiZWxhLWNlbnRyby1jdXN0by5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvY29tcG9uZW50cy9sYW5jYW1lbnRvLWZpeG8tZm9ybS9sYW5jYW1lbnRvLWZpeG8tZm9ybS5jb21wb25lbnQudHMiLCJzcmMvYXBwL2NvbXBvbmVudHMvbGFuY2FtZW50by1maXhvLWZvcm0vbGFuY2FtZW50by1maXhvLWZvcm0uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvc2VydmljZXMvbGFuY2FtZW50by1maXhvL2xhbmNhbWVudG8tZml4by5zZXJ2aWNlLnRzIiwic3JjL2FwcC9wYWdlcy9sYW5jYW1lbnRvLWZpeG8vZXhjbHVpci1sYW5jYW1lbnRvLWZpeG8vZXhjbHVpci1sYW5jYW1lbnRvLWZpeG8uY29tcG9uZW50LnRzIiwic3JjL2FwcC9wYWdlcy9sYW5jYW1lbnRvLWZpeG8vZXhjbHVpci1sYW5jYW1lbnRvLWZpeG8vZXhjbHVpci1sYW5jYW1lbnRvLWZpeG8uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvcGFnZXMvbGFuY2FtZW50by1maXhvL3RhYmVsYS1sYW5jYW1lbnRvLWZpeG8vdGFiZWxhLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8tZml4by90YWJlbGEtbGFuY2FtZW50by1maXhvL3RhYmVsYS1sYW5jYW1lbnRvLWZpeG8uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvdGFiZWxhLWxhbmNhbWVudG8vdGFiZWxhLWxhbmNhbWVudG8uY29tcG9uZW50LnRzIiwic3JjL2FwcC9jb21wb25lbnRzL3RhYmVsYS1sYW5jYW1lbnRvL3RhYmVsYS1sYW5jYW1lbnRvLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9zZXJ2aWNlcy9jb25maWd1cmFjb2VzLWlhL2NvbmZpZ3VyYWNvZXMtaWEuc2VydmljZS50cyIsInNyYy9hcHAvY29tcG9uZW50cy9kb251dC1jaGFydC9kb251dC1jaGFydC5jb21wb25lbnQudHMiLCJzcmMvYXBwL2NvbXBvbmVudHMvZG9udXQtY2hhcnQvZG9udXQtY2hhcnQuY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvcG9wLXVwLWNlbnRyby1jdXN0by9wb3AtdXAtY2VudHJvLWN1c3RvLmNvbXBvbmVudC50cyIsInNyYy9hcHAvY29tcG9uZW50cy9wb3AtdXAtY2VudHJvLWN1c3RvL3BvcC11cC1jZW50cm8tY3VzdG8uY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BhZ2VzL2NvbmZpZ3VyYWNvZXMtaWEvY29uZmlndXJhY29lcy1pYS5jb21wb25lbnQudHMiLCJzcmMvYXBwL3BhZ2VzL2NvbmZpZ3VyYWNvZXMtaWEvY29uZmlndXJhY29lcy1pYS5jb21wb25lbnQuaHRtbCIsInNyYy9hcHAvY29tcG9uZW50cy9wb3AtdXAtaWEvcG9wLXVwLWlhLmNvbXBvbmVudC50cyIsInNyYy9hcHAvY29tcG9uZW50cy9wb3AtdXAtaWEvcG9wLXVwLWlhLmNvbXBvbmVudC5odG1sIiwic3JjL2FwcC9jb21wb25lbnRzL2NvcGlhci1sYW5jYW1lbnRvcy9jb3BpYXItbGFuY2FtZW50b3MuY29tcG9uZW50LnRzIiwic3JjL2FwcC9jb21wb25lbnRzL2NvcGlhci1sYW5jYW1lbnRvcy9jb3BpYXItbGFuY2FtZW50b3MuY29tcG9uZW50Lmh0bWwiLCJzcmMvYXBwL3BpcGVzL2Zvcm1hdC12YWxvci5waXBlLnRzIiwic3JjL2FwcC9zZXJ2aWNlcy9pbnRlcmNlcHRvci9pbnRlcmNlcHRvci5zZXJ2aWNlLnRzIiwic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQnJvd3Nlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5pbXBvcnQgeyBIVFRQX0lOVEVSQ0VQVE9SUywgcHJvdmlkZUh0dHBDbGllbnQsIHdpdGhJbnRlcmNlcHRvcnNGcm9tRGkgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEZvcm1zTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuaW1wb3J0IHsgQXBwUm91dGluZ01vZHVsZSB9IGZyb20gJy4vYXBwLXJvdXRpbmcubW9kdWxlJztcclxuaW1wb3J0IHsgQXBwQ29tcG9uZW50IH0gZnJvbSAnLi9hcHAuY29tcG9uZW50JztcclxuaW1wb3J0IHsgRm9vdGVyQ29tcG9uZW50IH0gZnJvbSAnLi9jb21wb25lbnRzL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50JztcclxuaW1wb3J0IHsgSG9tZUNvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvaG9tZS9ob21lLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEdyYWZpY29zQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9ncmFmaWNvcy9ncmFmaWNvcy5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOb3ZvTGFuY2FtZW50b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50b3Mvbm92by1sYW5jYW1lbnRvL25vdm8tbGFuY2FtZW50by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvRm9ybUNvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy9sYW5jYW1lbnRvLWZvcm0vbGFuY2FtZW50by1mb3JtLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvRm9ybUNvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy9jZW50cm8tY3VzdG8tZm9ybS9jZW50cm8tY3VzdG8tZm9ybS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFZGl0TGFuY2FtZW50b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50b3MvZWRpdC1sYW5jYW1lbnRvL2VkaXQtbGFuY2FtZW50by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFZGl0Q2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9lZGl0LWNlbnRyby1jdXN0by9lZGl0LWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFeGNsdWlyTGFuY2FtZW50b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50b3MvZXhjbHVpci1sYW5jYW1lbnRvL2V4Y2x1aXItbGFuY2FtZW50by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFeGNsdWlyQ2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBUYWJlbGFDZW50cm9DdXN0b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvY2VudHJvLWN1c3RvL3RhYmVsYS1jZW50cm8tY3VzdG8vdGFiZWxhLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOb3ZvQ2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9ub3ZvLWNlbnRyby1jdXN0by9ub3ZvLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvRml4b0Zvcm1Db21wb25lbnQgfSBmcm9tICcuL2NvbXBvbmVudHMvbGFuY2FtZW50by1maXhvLWZvcm0vbGFuY2FtZW50by1maXhvLWZvcm0uY29tcG9uZW50JztcclxuaW1wb3J0IHsgU2FsZG9zQ29tcG9uZW50IH0gZnJvbSAnLi9jb21wb25lbnRzL3NhbGRvcy9zYWxkb3MuY29tcG9uZW50JztcclxuaW1wb3J0IHsgTG9naW5Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2xvZ2luL2xvZ2luLmNvbXBvbmVudCc7XHJcblxyXG4vLyBJbXBvcnRhw6fDtWVzIHBhcmEgbyBBbmd1bGFyIE1hdGVyaWFsXHJcbmltcG9ydCB7IE1hdFNpZGVuYXZNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9zaWRlbmF2JztcclxuaW1wb3J0IHsgTWF0TGlzdE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2xpc3QnO1xyXG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XHJcbmltcG9ydCB7IE1hdFRvb2xiYXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sYmFyJztcclxuaW1wb3J0IHsgTWF0QnV0dG9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvYnV0dG9uJztcclxuaW1wb3J0IHsgTWF0RGF0ZXBpY2tlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2RhdGVwaWNrZXInO1xyXG5pbXBvcnQgeyBNYXRGb3JtRmllbGRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9mb3JtLWZpZWxkJztcclxuaW1wb3J0IHsgTWF0TmF0aXZlRGF0ZU1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NvcmUnO1xyXG5pbXBvcnQgeyBNYXRJbnB1dE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2lucHV0JztcclxuXHJcbmltcG9ydCB7IE1hdENhcmRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jYXJkJztcclxuaW1wb3J0IHsgQnJvd3NlckFuaW1hdGlvbnNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyL2FuaW1hdGlvbnMnO1xyXG5cclxuaW1wb3J0IHsgRm9ybWF0VmFsb3JQaXBlIH0gZnJvbSAnLi9waXBlcy9mb3JtYXQtdmFsb3IucGlwZSc7XHJcbmltcG9ydCB7IEVkaXRMYW5jYW1lbnRvRml4b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50by1maXhvL2VkaXQtbGFuY2FtZW50by1maXhvL2VkaXQtbGFuY2FtZW50by1maXhvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEV4Y2x1aXJMYW5jYW1lbnRvRml4b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50by1maXhvL2V4Y2x1aXItbGFuY2FtZW50by1maXhvL2V4Y2x1aXItbGFuY2FtZW50by1maXhvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IE5vdm9MYW5jYW1lbnRvRml4b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50by1maXhvL25vdm8tbGFuY2FtZW50by1maXhvL25vdm8tbGFuY2FtZW50by1maXhvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFRhYmVsYUxhbmNhbWVudG9GaXhvQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9sYW5jYW1lbnRvLWZpeG8vdGFiZWxhLWxhbmNhbWVudG8tZml4by90YWJlbGEtbGFuY2FtZW50by1maXhvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEF1dGhJbnRlcmNlcHRvciB9IGZyb20gJy4vc2VydmljZXMvaW50ZXJjZXB0b3IvaW50ZXJjZXB0b3Iuc2VydmljZSc7XHJcbmltcG9ydCB7IFRhYmVsYUxhbmNhbWVudG9Db21wb25lbnQgfSBmcm9tICcuL2NvbXBvbmVudHMvdGFiZWxhLWxhbmNhbWVudG8vdGFiZWxhLWxhbmNhbWVudG8uY29tcG9uZW50JztcclxuaW1wb3J0IHsgTmdDaGFydHNNb2R1bGUgfSBmcm9tICduZzItY2hhcnRzJztcclxuaW1wb3J0IHsgRG9udXRDaGFydENvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy9kb251dC1jaGFydC9kb251dC1jaGFydC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOZ3hTa2VsZXRvbkxvYWRlck1vZHVsZSB9IGZyb20gJ25neC1za2VsZXRvbi1sb2FkZXInO1xyXG5pbXBvcnQgeyBQb3BVcENlbnRyb0N1c3RvQ29tcG9uZW50IH0gZnJvbSBcInNyYy9hcHAvY29tcG9uZW50cy9wb3AtdXAtY2VudHJvLWN1c3RvL3BvcC11cC1jZW50cm8tY3VzdG8uY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IENvbmZpZ3VyYWNvZXNJYUNvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvY29uZmlndXJhY29lcy1pYS9jb25maWd1cmFjb2VzLWlhLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFBvcFVwSWFDb21wb25lbnQgfSBmcm9tICcuL2NvbXBvbmVudHMvcG9wLXVwLWlhL3BvcC11cC1pYS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBDb3BpYXJMYW5jYW1lbnRvc0NvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy9jb3BpYXItbGFuY2FtZW50b3MvY29waWFyLWxhbmNhbWVudG9zLmNvbXBvbmVudCc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gICAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICAgICAgQXBwQ29tcG9uZW50LFxyXG4gICAgICAgIEZvb3RlckNvbXBvbmVudCxcclxuICAgICAgICBIb21lQ29tcG9uZW50LFxyXG4gICAgICAgIEdyYWZpY29zQ29tcG9uZW50LFxyXG4gICAgICAgIE5vdm9MYW5jYW1lbnRvQ29tcG9uZW50LFxyXG4gICAgICAgIExhbmNhbWVudG9Gb3JtQ29tcG9uZW50LFxyXG4gICAgICAgIEVkaXRMYW5jYW1lbnRvQ29tcG9uZW50LFxyXG4gICAgICAgIEV4Y2x1aXJMYW5jYW1lbnRvQ29tcG9uZW50LFxyXG4gICAgICAgIFNhbGRvc0NvbXBvbmVudCxcclxuICAgICAgICBMb2dpbkNvbXBvbmVudCxcclxuICAgICAgICBDZW50cm9DdXN0b0Zvcm1Db21wb25lbnQsXHJcbiAgICAgICAgRWRpdENlbnRyb0N1c3RvQ29tcG9uZW50LFxyXG4gICAgICAgIEV4Y2x1aXJDZW50cm9DdXN0b0NvbXBvbmVudCxcclxuICAgICAgICBOb3ZvQ2VudHJvQ3VzdG9Db21wb25lbnQsXHJcbiAgICAgICAgVGFiZWxhQ2VudHJvQ3VzdG9Db21wb25lbnQsXHJcbiAgICAgICAgRm9ybWF0VmFsb3JQaXBlLFxyXG4gICAgICAgIExhbmNhbWVudG9GaXhvRm9ybUNvbXBvbmVudCxcclxuICAgICAgICBFZGl0TGFuY2FtZW50b0ZpeG9Db21wb25lbnQsXHJcbiAgICAgICAgRXhjbHVpckxhbmNhbWVudG9GaXhvQ29tcG9uZW50LFxyXG4gICAgICAgIE5vdm9MYW5jYW1lbnRvRml4b0NvbXBvbmVudCxcclxuICAgICAgICBUYWJlbGFMYW5jYW1lbnRvRml4b0NvbXBvbmVudCxcclxuICAgICAgICBUYWJlbGFMYW5jYW1lbnRvQ29tcG9uZW50LFxyXG4gICAgICAgIERvbnV0Q2hhcnRDb21wb25lbnQsXHJcbiAgICAgICAgUG9wVXBDZW50cm9DdXN0b0NvbXBvbmVudCxcclxuICAgICAgICBDb25maWd1cmFjb2VzSWFDb21wb25lbnQsXHJcbiAgICAgICAgUG9wVXBJYUNvbXBvbmVudCxcclxuICAgICAgICBDb3BpYXJMYW5jYW1lbnRvc0NvbXBvbmVudFxyXG4gICAgXSxcclxuICAgIGJvb3RzdHJhcDogW0FwcENvbXBvbmVudF0sIGltcG9ydHM6IFtcclxuICAgIEFwcFJvdXRpbmdNb2R1bGUsXHJcbiAgICBGb3Jtc01vZHVsZSxcclxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXHJcbiAgICBCcm93c2VyTW9kdWxlLFxyXG4gICAgQnJvd3NlckFuaW1hdGlvbnNNb2R1bGUsXHJcbiAgICBNYXRDYXJkTW9kdWxlLFxyXG4gICAgTWF0U2lkZW5hdk1vZHVsZSxcclxuICAgIE1hdExpc3RNb2R1bGUsXHJcbiAgICBNYXRJY29uTW9kdWxlLFxyXG4gICAgTWF0VG9vbGJhck1vZHVsZSxcclxuICAgIE1hdEJ1dHRvbk1vZHVsZSxcclxuICAgIE1hdERhdGVwaWNrZXJNb2R1bGUsXHJcbiAgICBNYXRGb3JtRmllbGRNb2R1bGUsXHJcbiAgICBNYXROYXRpdmVEYXRlTW9kdWxlLFxyXG4gICAgTWF0SW5wdXRNb2R1bGUsXHJcbiAgICBOZ0NoYXJ0c01vZHVsZSxcclxuICAgIE5neFNrZWxldG9uTG9hZGVyTW9kdWxlICAgIFxyXG5dLCBwcm92aWRlcnM6IFtcclxuICAgICAgICAgICAgeyBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SUywgdXNlQ2xhc3M6IEF1dGhJbnRlcmNlcHRvciwgbXVsdGk6IHRydWUgfSxcclxuICAgICAgICAgICAgcHJvdmlkZUh0dHBDbGllbnQod2l0aEludGVyY2VwdG9yc0Zyb21EaSgpKVxyXG4gICAgICAgIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcE1vZHVsZSB7IH1cclxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyTW9kdWxlLCBSb3V0ZXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBIb21lQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50JztcclxuaW1wb3J0IHsgR3JhZmljb3NDb21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2dyYWZpY29zL2dyYWZpY29zLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IE5vdm9MYW5jYW1lbnRvQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9sYW5jYW1lbnRvcy9ub3ZvLWxhbmNhbWVudG8vbm92by1sYW5jYW1lbnRvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEVkaXRMYW5jYW1lbnRvQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9sYW5jYW1lbnRvcy9lZGl0LWxhbmNhbWVudG8vZWRpdC1sYW5jYW1lbnRvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEV4Y2x1aXJMYW5jYW1lbnRvQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9sYW5jYW1lbnRvcy9leGNsdWlyLWxhbmNhbWVudG8vZXhjbHVpci1sYW5jYW1lbnRvLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IExvZ2luQ29tcG9uZW50IH0gZnJvbSAnLi9wYWdlcy9sb2dpbi9sb2dpbi5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFZGl0Q2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9lZGl0LWNlbnRyby1jdXN0by9lZGl0LWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFeGNsdWlyQ2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by9leGNsdWlyLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOb3ZvQ2VudHJvQ3VzdG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NlbnRyby1jdXN0by9ub3ZvLWNlbnRyby1jdXN0by9ub3ZvLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBUYWJlbGFDZW50cm9DdXN0b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvY2VudHJvLWN1c3RvL3RhYmVsYS1jZW50cm8tY3VzdG8vdGFiZWxhLWNlbnRyby1jdXN0by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBUYWJlbGFMYW5jYW1lbnRvRml4b0NvbXBvbmVudCB9IGZyb20gJy4vcGFnZXMvbGFuY2FtZW50by1maXhvL3RhYmVsYS1sYW5jYW1lbnRvLWZpeG8vdGFiZWxhLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFZGl0TGFuY2FtZW50b0ZpeG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2xhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by9lZGl0LWxhbmNhbWVudG8tZml4by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFeGNsdWlyTGFuY2FtZW50b0ZpeG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2xhbmNhbWVudG8tZml4by9leGNsdWlyLWxhbmNhbWVudG8tZml4by9leGNsdWlyLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOb3ZvTGFuY2FtZW50b0ZpeG9Db21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2xhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by9ub3ZvLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBDb25maWd1cmFjb2VzSWFDb21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2NvbmZpZ3VyYWNvZXMtaWEvY29uZmlndXJhY29lcy1pYS5jb21wb25lbnQnO1xyXG5cclxuY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXHJcbiAge3BhdGg6ICdsb2dpbicsIGNvbXBvbmVudDogTG9naW5Db21wb25lbnR9LFxyXG4gIHtwYXRoOiAnJywgY29tcG9uZW50OiBIb21lQ29tcG9uZW50fSxcclxuICB7cGF0aDogJ2dyYWZpY29zJywgY29tcG9uZW50OiBHcmFmaWNvc0NvbXBvbmVudH0sXHJcbiAge3BhdGg6ICdsYW5jYW1lbnRvL2VkaXQvOmlkJywgY29tcG9uZW50OiBFZGl0TGFuY2FtZW50b0NvbXBvbmVudH0sXHJcbiAge3BhdGg6ICdsYW5jYW1lbnRvL2V4Y2x1aXIvOmlkJywgY29tcG9uZW50OiBFeGNsdWlyTGFuY2FtZW50b0NvbXBvbmVudH0sXHJcbiAge3BhdGg6ICdsYW5jYW1lbnRvL25vdm8nLCBjb21wb25lbnQ6IE5vdm9MYW5jYW1lbnRvQ29tcG9uZW50fSxcclxuICB7cGF0aDogJ2xhbmNhbWVudG8tZml4bycsIGNvbXBvbmVudDogVGFiZWxhTGFuY2FtZW50b0ZpeG9Db21wb25lbnR9LFxyXG4gIHtwYXRoOiAnbGFuY2FtZW50by1maXhvL2VkaXQvOmlkJywgY29tcG9uZW50OiBFZGl0TGFuY2FtZW50b0ZpeG9Db21wb25lbnR9LFxyXG4gIHtwYXRoOiAnbGFuY2FtZW50by1maXhvL2V4Y2x1aXIvOmlkJywgY29tcG9uZW50OiBFeGNsdWlyTGFuY2FtZW50b0ZpeG9Db21wb25lbnR9LFxyXG4gIHtwYXRoOiAnbGFuY2FtZW50by1maXhvL25vdm8nLCBjb21wb25lbnQ6IE5vdm9MYW5jYW1lbnRvRml4b0NvbXBvbmVudH0sXHJcbiAge3BhdGg6ICdjZW50cm8tY3VzdG8nLCBjb21wb25lbnQ6IFRhYmVsYUNlbnRyb0N1c3RvQ29tcG9uZW50fSxcclxuICB7cGF0aDogJ2NlbnRyby1jdXN0by9lZGl0LzppZCcsIGNvbXBvbmVudDogRWRpdENlbnRyb0N1c3RvQ29tcG9uZW50fSxcclxuICB7cGF0aDogJ2NlbnRyby1jdXN0by9leGNsdWlyLzppZCcsIGNvbXBvbmVudDogRXhjbHVpckNlbnRyb0N1c3RvQ29tcG9uZW50fSxcclxuICB7cGF0aDogJ2NlbnRyby1jdXN0by9ub3ZvJywgY29tcG9uZW50OiBOb3ZvQ2VudHJvQ3VzdG9Db21wb25lbnR9LFxyXG4gIHtwYXRoOiAnY29uZmlndXJhY29lcy1pYScsIGNvbXBvbmVudDogQ29uZmlndXJhY29lc0lhQ29tcG9uZW50fVxyXG5dO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbUm91dGVyTW9kdWxlLmZvclJvb3Qocm91dGVzKV0sXHJcbiAgZXhwb3J0czogW1JvdXRlck1vZHVsZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcFJvdXRpbmdNb2R1bGUgeyB9XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2FwcC1ob21lJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9ob21lLmNvbXBvbmVudC5odG1sJyxcclxuICAgIHN0eWxlVXJsczogWycuL2hvbWUuY29tcG9uZW50LmNzcyddLFxyXG4gICAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQge1xyXG5cclxufSIsIjxhcHAtdGFiZWxhLWxhbmNhbWVudG8+PC9hcHAtdGFiZWxhLWxhbmNhbWVudG8+IiwiaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTWF0U2lkZW5hdiB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3NpZGVuYXYnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcm9vdCcsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2FwcC5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vYXBwLmNvbXBvbmVudC5jc3MnXSxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50IHtcclxuXHJcbiAgQFZpZXdDaGlsZCgnc2lkZW5hdicpIHNpZGVuYXYhOiBNYXRTaWRlbmF2OyAgLy8gQWNlc3NvIGFvIG1hdC1zaWRlbmF2XHJcblxyXG4gIC8vIE3DqXRvZG8gcGFyYSBhbHRlcm5hciBvIGVzdGFkbyBkYSBzaWRlYmFyXHJcbiAgdG9nZ2xlU2lkZWJhcigpIHtcclxuICAgIHRoaXMuc2lkZW5hdi50b2dnbGUoKTtcclxuICB9XHJcblxyXG4gIC8vIE3DqXRvZG8gY2hhbWFkbyBhbyBzZWxlY2lvbmFyIHVtYSBvcMOnw6NvIG5vIG1lbnVcclxuICBzZWxlY3RPcHRpb24oKSB7XHJcbiAgICB0aGlzLnNpZGVuYXYuY2xvc2UoKTsgIC8vIEZlY2hhIGEgc2lkZWJhciBhbyBzZWxlY2lvbmFyIHVtYSBvcMOnw6NvXHJcbiAgfVxyXG5cclxuICB0aXRsZSA9ICdnZXN0YW9GaW5hbmNlaXJhJztcclxuICBzaG93SGVhZGVyRm9vdGVyID0gdHJ1ZTsgLy8gRGVmaW5lIHNlIG8gaGVhZGVyIGUgZm9vdGVyIGRldmVtIHNlciBleGliaWRvc1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKSB7XHJcbiAgICB0aGlzLnJvdXRlci5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgIHRoaXMuc2hvd0hlYWRlckZvb3RlciA9IGV2ZW50LnVybCAhPT0gJy9sb2dpbic7IC8vIEF0dWFsaXphIGNvbSBiYXNlIG5hIFVSTFxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGlzTG9naW5QYWdlKCk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIHRoaXMucm91dGVyLnVybCA9PT0gJy9sb2dpbic7XHJcbiAgfVxyXG5cclxuICBzZWxlY3RTYWlyKCk6IHZvaWQge1xyXG4gICAgdGhpcy5sb2dpblNlcnZpY2UubG9nb3V0KCk7XHJcbiAgfVxyXG59XHJcbiIsIjxtYXQtdG9vbGJhciAqbmdJZj1cInNob3dIZWFkZXJGb290ZXJcIiBtYXQtaWNvbi1idXR0b24gKGNsaWNrKT1cInNpZGVuYXYudG9nZ2xlKClcIiBjb2xvcj1cInByaW1hcnlcIj5cclxuICA8YnV0dG9uPlxyXG4gICAgPG1hdC1pY29uPm1lbnU8L21hdC1pY29uPlxyXG4gIDwvYnV0dG9uPlxyXG4gIDxzcGFuPkdlc3TDo28gRmluYW5jZWlyYTwvc3Bhbj5cclxuPC9tYXQtdG9vbGJhcj5cclxuXHJcbjxtYXQtc2lkZW5hdi1jb250YWluZXI+XHJcbiAgPCEtLSBNZW51IExhdGVyYWwgLS0+XHJcbiAgPG1hdC1zaWRlbmF2ICNzaWRlbmF2IG1vZGU9XCJvdmVyXCIgKGNsaWNrKT1cInNpZGVuYXYuY2xvc2UoKVwiPlxyXG4gICAgPG1hdC1uYXYtbGlzdD5cclxuICAgICAgPGE+XHJcbiAgICAgICAgPG1hdC1pY29uPmxpc3Q8L21hdC1pY29uPiAgICAgICAgXHJcbiAgICAgIDwvYT5cclxuICAgICAgPGEgbWF0LWxpc3QtaXRlbSByb3V0ZXJMaW5rPVwiL1wiIHJvdXRlckxpbmtBY3RpdmU9XCJzZWxlY3RlZFwiIChjbGljayk9XCJzZWxlY3RPcHRpb24oKVwiPlxyXG4gICAgICAgIDxtYXQtaWNvbj5saXN0PC9tYXQtaWNvbj5cclxuICAgICAgICBMYW7Dp2FtZW50b3NcclxuICAgICAgPC9hPlxyXG4gICAgICA8YSBtYXQtbGlzdC1pdGVtIHJvdXRlckxpbms9XCIvZ3JhZmljb3NcIiByb3V0ZXJMaW5rQWN0aXZlPVwic2VsZWN0ZWRcIiAoY2xpY2spPVwic2VsZWN0T3B0aW9uKClcIj5cclxuICAgICAgICA8bWF0LWljb24+YmFyX2NoYXJ0PC9tYXQtaWNvbj5cclxuICAgICAgICBHcsOhZmljb3NcclxuICAgICAgPC9hPlxyXG4gICAgICA8YSBtYXQtbGlzdC1pdGVtIHJvdXRlckxpbms9XCIvY2VudHJvLWN1c3RvXCIgcm91dGVyTGlua0FjdGl2ZT1cInNlbGVjdGVkXCIgKGNsaWNrKT1cInNlbGVjdE9wdGlvbigpXCI+XHJcbiAgICAgICAgPG1hdC1pY29uPmNhdGVnb3J5PC9tYXQtaWNvbj5cclxuICAgICAgICBDZW50cm9zIGRlIEN1c3RvXHJcbiAgICAgIDwvYT5cclxuICAgICAgPGEgbWF0LWxpc3QtaXRlbSByb3V0ZXJMaW5rPVwiL2xhbmNhbWVudG8tZml4b1wiIHJvdXRlckxpbmtBY3RpdmU9XCJzZWxlY3RlZFwiIChjbGljayk9XCJzZWxlY3RPcHRpb24oKVwiPlxyXG4gICAgICAgIDxtYXQtaWNvbj5ldmVudDwvbWF0LWljb24+XHJcbiAgICAgICAgTGFuw6dhbWVudG9zIEZpeG9zXHJcbiAgICAgIDwvYT5cclxuICAgICAgPGEgbWF0LWxpc3QtaXRlbSByb3V0ZXJMaW5rPVwiL2NvbmZpZ3VyYWNvZXMtaWFcIiByb3V0ZXJMaW5rQWN0aXZlPVwic2VsZWN0ZWRcIiAoY2xpY2spPVwic2VsZWN0T3B0aW9uKClcIj5cclxuICAgICAgICA8bWF0LWljb24+YXV0b19hd2Vzb21lPC9tYXQtaWNvbj5cclxuICAgICAgICBDb25maWd1cmHDp8O1ZXMgSUFcclxuICAgICAgPC9hPlxyXG4gICAgICA8YSBtYXQtbGlzdC1pdGVtIHJvdXRlckxpbms9XCIvbG9naW5cIiByb3V0ZXJMaW5rQWN0aXZlPVwic2VsZWN0ZWRcIiAoY2xpY2spPVwic2VsZWN0U2FpcigpXCI+XHJcbiAgICAgICAgPG1hdC1pY29uPmxvZ291dDwvbWF0LWljb24+XHJcbiAgICAgICAgU2FpclxyXG4gICAgICA8L2E+XHJcbiAgICA8L21hdC1uYXYtbGlzdD5cclxuICA8L21hdC1zaWRlbmF2PlxyXG4gIDwhLS0gQ29udGXDumRvIGRhIFDDoWdpbmEgLS0+XHJcbiAgPG1hdC1zaWRlbmF2LWNvbnRlbnQ+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY29udGVudC1jb250YWluZXJcIj5cclxuICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxyXG4gICAgPC9kaXY+XHJcbiAgPC9tYXQtc2lkZW5hdi1jb250ZW50PlxyXG48L21hdC1zaWRlbmF2LWNvbnRhaW5lcj5cclxuXHJcbjxhcHAtZm9vdGVyPjwvYXBwLWZvb3Rlcj5cclxuIiwiaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0YXAsIGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICdzcmMvZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJy4uL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBMb2dpblNlcnZpY2Uge1xyXG4gIHByaXZhdGUgYmFzZUFwaVVybCA9IGVudmlyb25tZW50LmJhc2VBcGlVcmw7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCwgcHJpdmF0ZSBtZW5zYWdlbnNTZXJ2aWNlOiBNZW5zYWdlbnNTZXJ2aWNlKSB7IH1cclxuXHJcbiAgcG9zdExvZ2luKGxvZ2luRGF0YTogeyBlbWFpbDogc3RyaW5nLCBzZW5oYTogc3RyaW5nIH0pOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgY29uc29sZS5sb2cobG9naW5EYXRhKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2F1dGgvbG9naW5gLCBsb2dpbkRhdGEpLnBpcGUoXHJcbiAgICAgIHRhcChyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgdGhpcy5zdG9yZVRva2VucyhyZXNwb25zZSk7XHJcbiAgICAgIH0pLFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBubyBsb2dpbjogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gTcOpdG9kbyBwYXJhIGFybWF6ZW5hciBvcyB0b2tlbnNcclxuICBzdG9yZVRva2Vucyh0b2tlbnM6IHsgdG9rZW46IHN0cmluZywgcmVmcmVzaFRva2VuOiBzdHJpbmcsIGlkVXN1YXJpbzogTnVtYmVyIH0pIHtcclxuICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ2F1dGhUb2tlbicsIHRva2Vucy50b2tlbik7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncmVmcmVzaFRva2VuJywgdG9rZW5zLnJlZnJlc2hUb2tlbik7IC8vIEFybWF6ZW5hbmRvIG5vIGxvY2FsU3RvcmFnZVxyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2lkVXN1YXJpbycsIHRva2Vucy5pZFVzdWFyaW8udG9TdHJpbmcoKSk7XHJcbiAgfVxyXG5cclxuICBnZXRBdXRoVG9rZW4oKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICByZXR1cm4gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgnYXV0aFRva2VuJyk7XHJcbiAgfVxyXG5cclxuICBnZXRJZFVzdWFyaW8oKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2lkVXN1YXJpbycpO1xyXG4gIH1cclxuXHJcbiAgLy8gTcOpdG9kbyBwYXJhIG9idGVyIG8gcmVmcmVzaFRva2VuIGRvIGxvY2FsU3RvcmFnZVxyXG4gIGdldFJlZnJlc2hUb2tlbigpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgncmVmcmVzaFRva2VuJyk7XHJcbiAgfVxyXG5cclxuICAvLyBNw6l0b2RvIHBhcmEgcmVub3ZhciBvIHRva2VuXHJcbiAgcmVmcmVzaFRva2VuKCk6IE9ic2VydmFibGU8eyB0b2tlbjogc3RyaW5nOyByZWZyZXNoVG9rZW46IHN0cmluZzsgaWRVc3VhcmlvOiBOdW1iZXIgfT4ge1xyXG4gICAgY29uc3QgcmVmcmVzaFRva2VuID0gdGhpcy5nZXRSZWZyZXNoVG9rZW4oKTsgLy8gUmVjdXBlcmFuZG8gbyByZWZyZXNoVG9rZW4gZG8gbG9jYWxTdG9yYWdlXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8eyB0b2tlbjogc3RyaW5nOyByZWZyZXNoVG9rZW46IHN0cmluZzsgaWRVc3VhcmlvOiBOdW1iZXIgfT4oXHJcbiAgICAgIGAke3RoaXMuYmFzZUFwaVVybH1hcGkvYXV0aC9yZWZyZXNoYCxcclxuICAgICAgeyByZWZyZXNoVG9rZW4gfSxcclxuICAgICAgeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSAvLyBQZXJtaXRlIGVudmlhciBvcyBjb29raWVzIGF1dG9tYXRpY2FtZW50ZSwgc2UgbmVjZXNzw6FyaW9cclxuICAgICkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gcmVub3ZhciB0b2tlbjogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY2xlYXJUb2tlbnMoKSB7XHJcbiAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKCdhdXRoVG9rZW4nKTtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdpZFVzdWFyaW8nKTtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdyZWZyZXNoVG9rZW4nKTsgLy8gTGltcGEgbyByZWZyZXNoVG9rZW4gdGFtYsOpbVxyXG4gIH1cclxuXHJcbiAgbG9nb3V0KCkge1xyXG4gICAgdGhpcy5jbGVhclRva2VucygpO1xyXG4gICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAnL2xvZ2luJzsgLy8gUmVkaXJlY2lvbmEgcGFyYSBsb2dpblxyXG4gIH1cclxuXHJcbn1cclxuIiwiZXhwb3J0IGNvbnN0IGVudmlyb25tZW50ID0ge1xyXG4gICAgcHJvZHVjdGlvbjogZmFsc2UsXHJcbiAgICAvL2Jhc2VBcGlVcmw6IFwiXCIsXHJcbiAgICBiYXNlQXBpVXJsOiBcImh0dHA6Ly8xOTIuMTY4LjEuMTEwL1wiXHJcbn0iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCBTd2FsLCB7IFN3ZWV0QWxlcnRJY29uIH0gZnJvbSAnc3dlZXRhbGVydDInO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgTWVuc2FnZW5zU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG1lbnNhZ2VtKGljb24/OiBTd2VldEFsZXJ0SWNvbiwgdGl0bGU/OiBzdHJpbmcsIHRleHQ/OiBzdHJpbmcsIGh0bWw/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgIGljb24sXHJcbiAgICAgIHRpdGxlLFxyXG4gICAgICB0ZXh0LFxyXG4gICAgICBodG1sXHJcbiAgICB9KTtcclxuICB9XHJcbn0iLCJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdhcHAtZm9vdGVyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9mb290ZXIuY29tcG9uZW50Lmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4vZm9vdGVyLmNvbXBvbmVudC5jc3MnXSxcclxuICAgIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBGb290ZXJDb21wb25lbnQge1xyXG5cclxufVxyXG4iLCI8Zm9vdGVyPlxyXG4gICAgPGgzPkNvbnRyb2xlIHNldXMgZ2FzdG9zIDpEPC9oMz5cclxuICAgIDxwPjxzcGFuPkdlc3TDo28gRmluYW5jZWlyYTwvc3Bhbj4gJmNvcHk7IDIwMjM8L3A+XHJcbjwvZm9vdGVyPiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IERldGFsaGFtZW50b0dhc3Rvc0NlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvZGV0YWxoYW1lbnRvLWdhc3Rvcy1jdXN0by9kZXRhbGhhbWVudG8tZ2FzdG9zLWNlbnRyby1jdXN0by5zZXJ2aWNlJztcclxuaW1wb3J0IHsgR2FzdG9zQ2VudHJvQ3VzdG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9nYXN0b3MtY2VudHJvLWN1c3RvL2dhc3Rvcy1jZW50cm8tY3VzdG8uc2VydmljZSc7XHJcbmltcG9ydCB7IEdhc3Rvc01lbnNhaXNTZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9nYXN0b3MtbWVuc2Fpcy9nYXN0b3MtbWVuc2Fpcy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgZ2V0Q29sb3JGb3JTb2JyYSB9IGZyb20gJy4uLy4uL3V0aWxzL2NvbG9ycyc7XHJcbmltcG9ydCB7IEZvcm1CdWlsZGVyLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1ncmFmaWNvcycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2dyYWZpY29zLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9ncmFmaWNvcy5jb21wb25lbnQuY3NzJ10sXHJcbiAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIEdyYWZpY29zQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBbeDogc3RyaW5nXTogYW55O1xyXG5cclxuICAvL1ZhcmnDoXZlaXMgZ3JhZmljbyBHYXN0b3MgTWVuc2Fpc1xyXG4gIHB1YmxpYyBnR01MYWJlbE1lczogYW55W10gPSBbXTtcclxuICBwdWJsaWMgZ0dNTWVzQW5vOiBhbnlbXSA9IFtdO1xyXG4gIHB1YmxpYyBnR01EYXRhVmFsb3I6IGFueVtdID0gW107XHJcbiAgcHVibGljIGdHTURhdGFTb2JyYU1lczogYW55W10gPSBbXTtcclxuICBwdWJsaWMgZ0dNQ29yZG9RdWFkcmFudGU6IGFueVtdID0gW107XHJcbiAgcHVibGljIGdHTURhdGFWYWxvclJlY2ViaWRvTWVzOiBhbnlbXSA9IFtdO1xyXG5cclxuICAvL1ZhcmnDoXZlaXMgZ3LDoWZpY28gR2FzdG9zIHBvciBDZW50cm8gZGUgQ3VzdG9cclxuICBwcml2YXRlIGNoYXJ0SW5mb0NDOiBhbnk7XHJcbiAgcHJpdmF0ZSBnR0NDVmFsb3I6IGFueVtdID0gW107XHJcbiAgcHJpdmF0ZSBnR0NDVmFsb3JMaW1pdGU6IGFueVtdID0gW107XHJcbiAgcHJpdmF0ZSBnR0NDRGVzY3JpY2FvOiBhbnlbXSA9IFtdO1xyXG4gIHByaXZhdGUgZ0dDQ21lc0Fub0F0dWFsOiBhbnlbXSA9IFtdO1xyXG5cclxuICAvL0RldGFsaGFtZW50byBHYXN0b3NDZW50cm9DdXN0b1xyXG4gIHBvcHVwQWJlcnRvID0gZmFsc2U7XHJcbiAgZGV0YWxoYW1lbnRvR2FzdG9zQ0M6IGFueVtdID0gW107XHJcblxyXG4gIGZvcm0hOiBGb3JtR3JvdXA7XHJcbiAgYW5vczogbnVtYmVyW10gPSBbXTtcclxuXHJcbiAgbG9hZGluZ0dhc3Rvc01lbnNhaXMgPSB0cnVlO1xyXG4gIGxvYWRpbmdDZW50cm9zQ3VzdG8gPSB0cnVlO1xyXG4gIG1lc0Fub1NlbGVjaW9uYWRvOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBzYWxkb1NlcnZpY2U6IEdhc3Rvc01lbnNhaXNTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBnYXN0b3NDZW50cm9DdXN0b1NlcnZpY2U6IEdhc3Rvc0NlbnRyb0N1c3RvU2VydmljZSxcclxuICAgIHByaXZhdGUgZGV0YWxoYW1lbnRvR2FzdG9zQ2VudHJvQ3VzdG86IERldGFsaGFtZW50b0dhc3Rvc0NlbnRyb0N1c3RvU2VydmljZSxcclxuICAgIHByaXZhdGUgZmI6IEZvcm1CdWlsZGVyKSB7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIC8vQ3JpYSBvIGZvcm11bMOhcmlvXHJcbiAgICB0aGlzLmZvcm0gPSB0aGlzLmZiLmdyb3VwKHtcclxuICAgICAgYW5vOiBbbnVsbCwgVmFsaWRhdG9ycy5yZXF1aXJlZF1cclxuICAgIH0pO1xyXG5cclxuICAgIC8vdGhpcy5nR01NZXNBbm9BdXhpbGlhciA9IHRoaXMudHJhdGFNZXNBbm9BdHVhbCgpO1xyXG4gICAgdGhpcy5idXNjYXJJbmZvcm1hY29lc0dhc3Rvc01lbnNhaXMoXCJcIiwgXCJcIik7XHJcblxyXG4gIH1cclxuXHJcbiAgZ2V0IGFubygpIHtcclxuICAgIHJldHVybiB0aGlzLmZvcm0uZ2V0KCdhbm8nKSE7XHJcbiAgfVxyXG5cclxuICBhbm9TZWxlY2lvbmFkbyhkYXRhOiBEYXRlLCBkYXRlcGlja2VyOiBhbnkpIHtcclxuICAgIGNvbnN0IGFubyA9IGRhdGEuZ2V0RnVsbFllYXIoKTtcclxuICAgIHRoaXMuZm9ybS5nZXQoJ2FubycpPy5zZXRWYWx1ZShuZXcgRGF0ZShhbm8sIDAsIDEpKTtcclxuICAgIGRhdGVwaWNrZXIuY2xvc2UoKTtcclxuXHJcbiAgICBjb25zdCBkYXRhRGUgPSBgJHthbm99LTAxLTAxYDtcclxuICAgIGNvbnN0IGRhdGFBdGUgPSBgJHthbm99LTEyLTMxYDtcclxuXHJcbiAgICAvLyBsaW1wYXIgZ3LDoWZpY29zXHJcbiAgICB0aGlzLmdHTUxhYmVsTWVzID0gW107XHJcbiAgICB0aGlzLmdHTU1lc0FubyA9IFtdO1xyXG4gICAgdGhpcy5nR01EYXRhVmFsb3IgPSBbXTtcclxuICAgIHRoaXMuZ0dNRGF0YVNvYnJhTWVzID0gW107XHJcbiAgICB0aGlzLmdHTUNvcmRvUXVhZHJhbnRlID0gW107XHJcbiAgICB0aGlzLmdHTURhdGFWYWxvclJlY2ViaWRvTWVzID0gW107XHJcbiAgICB0aGlzLmNlbnRyb3NDdXN0b1Zpc3VhbCA9IFtdO1xyXG4gICAgdGhpcy5tZXNBbm9TZWxlY2lvbmFkbyA9IG51bGw7XHJcblxyXG4gICAgLy8gY2hhbWFyIEFQSSBmaWx0cmFkYVxyXG4gICAgdGhpcy5idXNjYXJJbmZvcm1hY29lc0dhc3Rvc01lbnNhaXMoZGF0YURlLCBkYXRhQXRlKTtcclxuXHJcbiAgfVxyXG5cclxuICB0ZW1SZWdpc3RybyhpbmRleDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gISF0aGlzLmdHTUNvcmRvUXVhZHJhbnRlW2luZGV4XTtcclxuICB9XHJcblxyXG4gIHNlbGVjaW9uYXJNZXMobWVzQW5vOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIHRoaXMubWVzQW5vU2VsZWNpb25hZG8gPSBtZXNBbm87XHJcbiAgICB0aGlzLmJ1c2NhckluZm9ybWFjb2VzQ2VudHJvQ3VzdG8obWVzQW5vKTtcclxuICB9XHJcblxyXG4gIGJ1c2NhckluZm9ybWFjb2VzR2FzdG9zTWVuc2FpcyhkYXRhRGU6IHN0cmluZywgZGF0YUF0ZTogc3RyaW5nKSB7XHJcbiAgICB0aGlzLmxvYWRpbmdHYXN0b3NNZW5zYWlzID0gdHJ1ZTtcclxuICAgIHRoaXMuc2FsZG9TZXJ2aWNlLmdldEdhc3Rvc01lbnNhaXMoZGF0YURlLCBkYXRhQXRlKS5zdWJzY3JpYmUoaXRlbSA9PiB7XHJcbiAgICAgIGlmICghaXRlbSB8fCBpdGVtLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIHRoaXMubG9hZGluZ0dhc3Rvc01lbnNhaXMgPSBmYWxzZTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgdGhpcy5nR01MYWJlbE1lcy5wdXNoKGl0ZW1baV0ubWVzKTtcclxuICAgICAgICB0aGlzLmdHTU1lc0Fuby5wdXNoKGl0ZW1baV0ubWVzICsgXCIgLSBcIiArIGl0ZW1baV0uYW5vKTtcclxuICAgICAgICB0aGlzLmdHTURhdGFWYWxvci5wdXNoKGl0ZW1baV0udmFsb3IpO1xyXG4gICAgICAgIHRoaXMuZ0dNRGF0YVNvYnJhTWVzLnB1c2goaXRlbVtpXS5zb2JyYU1lcyk7XHJcbiAgICAgICAgdGhpcy5nR01Db3Jkb1F1YWRyYW50ZS5wdXNoKHRoaXMuZ2V0Q29sb3IoaXRlbVtpXS5zb2JyYU1lcykpO1xyXG4gICAgICAgIHRoaXMuZ0dNRGF0YVZhbG9yUmVjZWJpZG9NZXMucHVzaChpdGVtW2ldLnZhbG9yUmVjZWJpZG9NZXMpO1xyXG4gICAgICB9XHJcbiAgICAgIHRoaXMubG9hZGluZ0dhc3Rvc01lbnNhaXMgPSBmYWxzZTtcclxuICAgICAgY29uc3QgdWx0aW1vTWVzID0gdGhpcy5nR01NZXNBbm9bdGhpcy5nR01NZXNBbm8ubGVuZ3RoIC0gMV07XHJcbiAgICAgIHRoaXMubWVzQW5vU2VsZWNpb25hZG8gPSB1bHRpbW9NZXM7XHJcbiAgICAgIHRoaXMuYnVzY2FySW5mb3JtYWNvZXNDZW50cm9DdXN0byh1bHRpbW9NZXMpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjZW50cm9zQ3VzdG9WaXN1YWw6IHtcclxuICAgIGdhc3RvOiBudW1iZXI7XHJcbiAgICBsaW1pdGU6IG51bWJlcjtcclxuICAgIG1lc0VBbm86IHN0cmluZztcclxuICAgIGRlc2NyaWNhb0NlbnRyb0N1c3RvOiBzdHJpbmdcclxuICB9W10gPSBbXTtcclxuXHJcbiAgYnVzY2FySW5mb3JtYWNvZXNDZW50cm9DdXN0byhtZXNBbm8/OiBzdHJpbmcpIHtcclxuICAgIHRoaXMubG9hZGluZ0NlbnRyb3NDdXN0byA9IHRydWU7XHJcblxyXG4gICAgdGhpcy5nYXN0b3NDZW50cm9DdXN0b1NlcnZpY2UuZ2V0QWxsR2FzdG9zQ2VudHJvTWVzQW5vKG1lc0Fubykuc3Vic2NyaWJlKGl0ZW0gPT4ge1xyXG4gICAgICB0aGlzLmNoYXJ0SW5mb0NDID0gaXRlbTtcclxuICAgICAgdGhpcy5nR0NDVmFsb3IgPSBbXTtcclxuICAgICAgdGhpcy5nR0NDVmFsb3JMaW1pdGUgPSBbXTtcclxuICAgICAgdGhpcy5nR0NDRGVzY3JpY2FvID0gW107XHJcbiAgICAgIHRoaXMuZ0dDQ21lc0Fub0F0dWFsID0gW107XHJcblxyXG4gICAgICAvL05PVk86IGxpbXBhIGEgbGlzdGEgdmlzdWFsXHJcbiAgICAgIHRoaXMuY2VudHJvc0N1c3RvVmlzdWFsID0gW107XHJcbiAgICAgIGlmICh0aGlzLmNoYXJ0SW5mb0NDICE9IG51bGwpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY2hhcnRJbmZvQ0MubGVuZ3RoOyBpKyspIHtcclxuXHJcbiAgICAgICAgICBjb25zdCByZWdpc3RybyA9IHRoaXMuY2hhcnRJbmZvQ0NbaV07XHJcblxyXG4gICAgICAgICAgdGhpcy5nR0NDVmFsb3IucHVzaCh0aGlzLmNoYXJ0SW5mb0NDW2ldLnZhbG9yKTtcclxuICAgICAgICAgIHRoaXMuZ0dDQ1ZhbG9yTGltaXRlLnB1c2godGhpcy5jaGFydEluZm9DQ1tpXS52YWxvckxpbWl0ZSk7XHJcbiAgICAgICAgICB0aGlzLmdHQ0NEZXNjcmljYW8ucHVzaCh0aGlzLmNoYXJ0SW5mb0NDW2ldLmRlc2NyaWNhbyk7XHJcbiAgICAgICAgICB0aGlzLmdHQ0NtZXNBbm9BdHVhbC5wdXNoKHRoaXMuY2hhcnRJbmZvQ0NbaV0ubWVzQW5vKTtcclxuXHJcbiAgICAgICAgICB0aGlzLmNlbnRyb3NDdXN0b1Zpc3VhbC5wdXNoKHtcclxuICAgICAgICAgICAgZ2FzdG86IHJlZ2lzdHJvLnZhbG9yLFxyXG4gICAgICAgICAgICBsaW1pdGU6IHJlZ2lzdHJvLnZhbG9yTGltaXRlLFxyXG4gICAgICAgICAgICBtZXNFQW5vOiByZWdpc3Ryby5tZXNBbm8sXHJcbiAgICAgICAgICAgIGRlc2NyaWNhb0NlbnRyb0N1c3RvOiByZWdpc3Ryby5kZXNjcmljYW9cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuY2VudHJvc0N1c3RvVmlzdWFsKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5sb2FkaW5nQ2VudHJvc0N1c3RvID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICB9XHJcblxyXG4gIGdldFBlcmNlbnR1YWwoaXRlbTogYW55KTogbnVtYmVyIHtcclxuICAgIGlmICghaXRlbS5saW1pdGUpIHJldHVybiAwO1xyXG4gICAgcmV0dXJuIE1hdGgubWluKChpdGVtLmdhc3RvIC8gaXRlbS5saW1pdGUpICogMTAwKTtcclxuICB9XHJcblxyXG4gIGdldENsYXNzZShpdGVtOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgcGVyY2VudHVhbCA9IHRoaXMuZ2V0UGVyY2VudHVhbChpdGVtKTtcclxuXHJcbiAgICBpZiAocGVyY2VudHVhbCA+IDEwMCkgcmV0dXJuICdlc3RvdXJhZG8nO1xyXG4gICAgaWYgKHBlcmNlbnR1YWwgPj0gODApIHJldHVybiAnYWxlcnRhJztcclxuICAgIHJldHVybiAnb2snO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBmb3JtYXRhckRhdGEoZGF0YTogc3RyaW5nIHwgRGF0ZSk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBkID0gbmV3IERhdGUoZGF0YSk7XHJcbiAgICByZXR1cm4gZC50b0xvY2FsZURhdGVTdHJpbmcoJ3B0LUJSJykgKyAnICcgK1xyXG4gICAgICBkLnRvTG9jYWxlVGltZVN0cmluZygncHQtQlInLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSk7XHJcbiAgfVxyXG5cclxuICAvKlxyXG4gICAgdHJhdGFNZXNBbm9BdHVhbCgpIHtcclxuICAgICAgbGV0IGRhdGFBdHVhbCA9IG5ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdwdC1CUicpO1xyXG4gICAgICBsZXQgbWVzOiBzdHJpbmcgPSBkYXRhQXR1YWwudG9TdHJpbmcoKS5zdWJzdHJpbmcoMywgNSk7XHJcbiAgICAgIGxldCBhbm86IHN0cmluZyA9IGRhdGFBdHVhbC50b1N0cmluZygpLnN1YnN0cmluZyg2LCAxMCk7XHJcbiAgXHJcbiAgICAgIHN3aXRjaCAobWVzKSB7XHJcbiAgICAgICAgY2FzZSBcIjAxXCI6IHtcclxuICAgICAgICAgIG1lcyA9IFwiSmFuZWlyb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIwMlwiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIkZldmVyZWlyb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIwM1wiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIk1hcsOnb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIwNFwiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIkFicmlsXCI7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBcIjA1XCI6IHtcclxuICAgICAgICAgIG1lcyA9IFwiTWFpb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIwNlwiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIkp1bmhvXCI7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBcIjA3XCI6IHtcclxuICAgICAgICAgIG1lcyA9IFwiSnVsaG9cIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFwiMDhcIjoge1xyXG4gICAgICAgICAgbWVzID0gXCJBZ29zdG9cIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFwiMDlcIjoge1xyXG4gICAgICAgICAgbWVzID0gXCJTZXRlbWJyb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIxMFwiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIk91dHVicm9cIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFwiMTFcIjoge1xyXG4gICAgICAgICAgbWVzID0gXCJOb3ZlbWJyb1wiO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgXCIxMlwiOiB7XHJcbiAgICAgICAgICBtZXMgPSBcIkRlemVtYnJvXCI7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgIH1cclxuICAgICAgbGV0IG1lc0Fubzogc3RyaW5nID0gbWVzICsgXCIgLSBcIiArIGFubztcclxuICAgICAgcmV0dXJuIG1lc0FubztcclxuICBcclxuICAgIH0qL1xyXG5cclxuICBidXNjYXJEZXRhbGhhbWVudG9HYXN0b3NDZW50cm9DdXN0byhtZXNBbm8/OiBzdHJpbmcsIGRlc0NDPzogc3RyaW5nKSB7XHJcbiAgICB0aGlzLmRldGFsaGFtZW50b0dhc3Rvc0NlbnRyb0N1c3RvLmdldEFsbERldGFsaGFtZW50b0dhc3Rvc0NlbnRyb01lc0FubyhtZXNBbm8sIGRlc0NDKS5zdWJzY3JpYmUoaXRlbSA9PiB7XHJcbiAgICAgIHRoaXMuZGV0YWxoYW1lbnRvR2FzdG9zQ0MgPSBbXTtcclxuICAgICAgaWYgKGl0ZW0gJiYgaXRlbS5sZW5ndGggPiAwKSB7ICAgICAgICBcclxuICAgICAgICB0aGlzLmRldGFsaGFtZW50b0dhc3Rvc0NDID0gaXRlbTtcclxuICAgICAgICB0aGlzLnBvcHVwQWJlcnRvID0gdHJ1ZTsgLy9hYnJlIG8gcG9wLXVwXHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKCduby1zY3JvbGwnKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBnZXRDb2xvcih2YWxvcjogbnVtYmVyKSB7XHJcbiAgICByZXR1cm4gZ2V0Q29sb3JGb3JTb2JyYSh2YWxvcik7XHJcbiAgfVxyXG5cclxufVxyXG4iLCI8Zm9ybSBbZm9ybUdyb3VwXT1cImZvcm1cIj5cclxuICAgIDxtYXQtZm9ybS1maWVsZCBhcHBlYXJhbmNlPVwib3V0bGluZVwiIGNsYXNzPVwiY2FtcG8tYW5vXCI+XHJcbiAgICAgICAgPG1hdC1sYWJlbD5Bbm88L21hdC1sYWJlbD5cclxuXHJcbiAgICAgICAgPGlucHV0IG1hdElucHV0IFttYXREYXRlcGlja2VyXT1cInBpY2tlclwiIGZvcm1Db250cm9sTmFtZT1cImFub1wiIHJlYWRvbmx5PlxyXG5cclxuICAgICAgICA8bWF0LWRhdGVwaWNrZXItdG9nZ2xlIG1hdFN1ZmZpeCBbZm9yXT1cInBpY2tlclwiPjwvbWF0LWRhdGVwaWNrZXItdG9nZ2xlPlxyXG5cclxuICAgICAgICA8bWF0LWRhdGVwaWNrZXIgI3BpY2tlciBzdGFydFZpZXc9XCJtdWx0aS15ZWFyXCIgKHllYXJTZWxlY3RlZCk9XCJhbm9TZWxlY2lvbmFkbygkZXZlbnQsIHBpY2tlcilcIj5cclxuICAgICAgICA8L21hdC1kYXRlcGlja2VyPlxyXG5cclxuICAgICAgICA8bWF0LWVycm9yICpuZ0lmPVwiYW5vLmludmFsaWRcIj5cclxuICAgICAgICAgICAgQW5vIMOpIG9icmlnYXTDs3Jpb1xyXG4gICAgICAgIDwvbWF0LWVycm9yPlxyXG4gICAgPC9tYXQtZm9ybS1maWVsZD5cclxuPC9mb3JtPlxyXG5cclxuPCEtLSBTS0VMRVRPTiAtLT5cclxuPGRpdiBjbGFzcz1cImdyYWZpY28tY2FsZW5kYXJpb1wiICpuZ0lmPVwibG9hZGluZ0dhc3Rvc01lbnNhaXNcIj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiY2FsZW5kYXJpby1saW5oYVwiICpuZ0Zvcj1cImxldCBsaW5oYSBvZiBbMCwxLDJdXCI+XHJcblxyXG4gICAgICAgIDxuZy1jb250YWluZXIgKm5nRm9yPVwibGV0IGNvbCBvZiBbMCwxLDIsM11cIj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJxdWFkcmFudGVcIj5cclxuICAgICAgICAgICAgICAgIDxuZ3gtc2tlbGV0b24tbG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgY291bnQ9XCI0XCJcclxuICAgICAgICAgICAgICAgICAgICBhcHBlYXJhbmNlPVwibGluZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW3RoZW1lXT1cIntcclxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzE0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ21hcmdpbi1ib3R0b20nOiAnNnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICdib3JkZXItcmFkaXVzJzogJzRweCdcclxuICAgICAgICAgICAgICAgICAgICB9XCI+XHJcbiAgICAgICAgICAgICAgICA8L25neC1za2VsZXRvbi1sb2FkZXI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8L25nLWNvbnRhaW5lcj5cclxuICAgIDwvZGl2PlxyXG5cclxuPC9kaXY+XHJcblxyXG48IS0tQ09OVEXDmkRPIC0tPlxyXG48bmctY29udGFpbmVyICpuZ0lmPVwiIWxvYWRpbmdHYXN0b3NNZW5zYWlzXCI+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJncmFmaWNvLWNhbGVuZGFyaW9cIiAqbmdJZj1cImdHTU1lc0Fuby5sZW5ndGggPiAwOyBlbHNlIHJlZ2lzdHJvc05hb0VuY29udHJhZG9zXCI+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwiY2FsZW5kYXJpby1saW5oYVwiICpuZ0Zvcj1cImxldCBsaW5oYSBvZiBbMCwxLDJdOyBsZXQgbCA9IGluZGV4XCI+XHJcblxyXG4gICAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdGb3I9XCJsZXQgY29sIG9mIFswLDEsMiwzXTsgbGV0IGMgPSBpbmRleFwiPlxyXG5cclxuICAgICAgICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwidGVtUmVnaXN0cm8obCAqIDQgKyBjKTsgZWxzZSBzZW1SZWdpc3Ryb1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInF1YWRyYW50ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnF1YWRyYW50ZS1zZWxlY2lvbmFkb109XCJnR01NZXNBbm9bbCAqIDQgKyBjXSA9PT0gbWVzQW5vU2VsZWNpb25hZG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgIFtzdHlsZS5iYWNrZ3JvdW5kQ29sb3JdPVwiZ0dNQ29yZG9RdWFkcmFudGVbbCAqIDQgKyBjXVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInNlbGVjaW9uYXJNZXMoZ0dNTWVzQW5vW2wgKiA0ICsgY10pXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzcz1cIm5vbWUtbWVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3sgZ0dNTGFiZWxNZXNbbCAqIDQgKyBjXSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ2YWxvcmVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKyBSJCB7eyBnR01EYXRhVmFsb3JSZWNlYmlkb01lc1tsICogNCArIGNdIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ2YWxvcmVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLSBSJCB7eyBnR01EYXRhVmFsb3JbbCAqIDQgKyBjXSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidmFsb3Jlc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID0gUiQge3sgZ0dNRGF0YVNvYnJhTWVzW2wgKiA0ICsgY10gfX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvbmctY29udGFpbmVyPlxyXG5cclxuICAgICAgICAgIDwvbmctY29udGFpbmVyPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAjc2VtUmVnaXN0cm8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicXVhZHJhbnRlIHF1YWRyYW50ZS12YXppb1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2VtLWRhZG9zXCI+4pyVPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcblxyXG4gIDwvZGl2PlxyXG5cclxuICA8IS0tU0VNIFJFR0lTVFJPUyAtLT5cclxuICA8bmctdGVtcGxhdGUgI3JlZ2lzdHJvc05hb0VuY29udHJhZG9zPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwicXVhZHJhbnRlIHF1YWRyYW50ZS12YXppb1wiPlxyXG4gICAgICAgICAgPHNwYW4+UmVnaXN0cm9zIG7Do28gZW5jb250cmFkb3MhPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICA8L25nLXRlbXBsYXRlPlxyXG5cclxuPC9uZy1jb250YWluZXI+XHJcblxyXG5cclxuXHJcbjxiciAvPlxyXG5cclxuPCEtLSBTS0VMRVRPTiBDRU5UUk9TIERFIENVU1RPIC0tPlxyXG48bmctY29udGFpbmVyICpuZ0lmPVwibG9hZGluZ0NlbnRyb3NDdXN0b1wiPlxyXG4gIDxkaXYgY2xhc3M9XCJjYy1jYXJkXCIgKm5nRm9yPVwibGV0IGkgb2YgWzAsMSwyLDMsNF1cIj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiY2MtaGVhZGVyXCI+XHJcbiAgICAgIDxuZ3gtc2tlbGV0b24tbG9hZGVyXHJcbiAgICAgICAgYXBwZWFyYW5jZT1cImxpbmVcIlxyXG4gICAgICAgIFt0aGVtZV09XCJ7XHJcbiAgICAgICAgICB3aWR0aDogJzYwJScsXHJcbiAgICAgICAgICBoZWlnaHQ6ICcxNnB4JyxcclxuICAgICAgICAgICdib3JkZXItcmFkaXVzJzogJzRweCdcclxuICAgICAgICB9XCI+XHJcbiAgICAgIDwvbmd4LXNrZWxldG9uLWxvYWRlcj5cclxuXHJcbiAgICAgIDxuZ3gtc2tlbGV0b24tbG9hZGVyXHJcbiAgICAgICAgYXBwZWFyYW5jZT1cImxpbmVcIlxyXG4gICAgICAgIFt0aGVtZV09XCJ7XHJcbiAgICAgICAgICB3aWR0aDogJzMwJScsXHJcbiAgICAgICAgICBoZWlnaHQ6ICcxNnB4JyxcclxuICAgICAgICAgICdib3JkZXItcmFkaXVzJzogJzRweCdcclxuICAgICAgICB9XCI+XHJcbiAgICAgIDwvbmd4LXNrZWxldG9uLWxvYWRlcj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJjYy1iYXItY29udGFpbmVyXCI+XHJcbiAgICAgIDxuZ3gtc2tlbGV0b24tbG9hZGVyXHJcbiAgICAgICAgYXBwZWFyYW5jZT1cImxpbmVcIlxyXG4gICAgICAgIFt0aGVtZV09XCJ7XHJcbiAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgaGVpZ2h0OiAnOHB4JyxcclxuICAgICAgICAgICdib3JkZXItcmFkaXVzJzogJzRweCdcclxuICAgICAgICB9XCI+XHJcbiAgICAgIDwvbmd4LXNrZWxldG9uLWxvYWRlcj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJjYy1wZXJjZW50dWFsXCI+XHJcbiAgICAgIDxuZ3gtc2tlbGV0b24tbG9hZGVyXHJcbiAgICAgICAgYXBwZWFyYW5jZT1cImxpbmVcIlxyXG4gICAgICAgIFt0aGVtZV09XCJ7XHJcbiAgICAgICAgICB3aWR0aDogJzQwJScsXHJcbiAgICAgICAgICBoZWlnaHQ6ICcxNHB4JyxcclxuICAgICAgICAgICdib3JkZXItcmFkaXVzJzogJzRweCdcclxuICAgICAgICB9XCI+XHJcbiAgICAgIDwvbmd4LXNrZWxldG9uLWxvYWRlcj5cclxuICAgIDwvZGl2PlxyXG5cclxuICA8L2Rpdj5cclxuPC9uZy1jb250YWluZXI+XHJcblxyXG5cclxuXHJcbjxkaXYgY2xhc3M9XCJjYy1jYXJkXCIgKm5nRm9yPVwibGV0IGl0ZW0gb2YgY2VudHJvc0N1c3RvVmlzdWFsXCI+XHJcbiAgPGRpdiBjbGFzcz1cImNjLWhlYWRlclwiIChjbGljayk9XCJidXNjYXJEZXRhbGhhbWVudG9HYXN0b3NDZW50cm9DdXN0byhpdGVtLm1lc0VBbm8sIGl0ZW0uZGVzY3JpY2FvQ2VudHJvQ3VzdG8pXCI+XHJcbiAgICA8c3BhbiBjbGFzcz1cImNjLW5vbWVcIj57eyBpdGVtLmRlc2NyaWNhb0NlbnRyb0N1c3RvIH19PC9zcGFuPlxyXG4gICAgPHNwYW4gY2xhc3M9XCJjYy12YWxvclwiPlxyXG4gICAgICBSJCB7eyBpdGVtLmdhc3RvIHwgbnVtYmVyOicxLjItMicgfX1cclxuICAgICAgL1xyXG4gICAgICB7eyBpdGVtLmxpbWl0ZSB8IG51bWJlcjonMS4yLTInIH19XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJjYy1iYXItY29udGFpbmVyXCI+XHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzPVwiY2MtYmFyXCJcclxuICAgICAgW25nQ2xhc3NdPVwiZ2V0Q2xhc3NlKGl0ZW0pXCJcclxuICAgICAgW3N0eWxlLndpZHRoLiVdPVwiZ2V0UGVyY2VudHVhbChpdGVtKVwiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzcz1cImNjLWxpbWl0ZVwiXHJcbiAgICAgIFtzdHlsZS5sZWZ0LiVdPVwiMTAwXCI+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzcz1cImNjLXBlcmNlbnR1YWxcIj5cclxuICAgIHt7IGdldFBlcmNlbnR1YWwoaXRlbSkgfCBudW1iZXI6JzEuMC0wJyB9fSVcclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcblxyXG48YXBwLXBvcC11cC1jZW50cm8tY3VzdG9cclxuICBbYWJlcnRvXT1cInBvcHVwQWJlcnRvXCJcclxuICBbZGV0YWxoYW1lbnRvR2FzdG9zQ0NdPVwiZGV0YWxoYW1lbnRvR2FzdG9zQ0NcIlxyXG4gIChmZWNoYXIpPVwicG9wdXBBYmVydG8gPSBmYWxzZVwiPlxyXG48L2FwcC1wb3AtdXAtY2VudHJvLWN1c3RvPlxyXG5cclxuIiwiZnVuY3Rpb24gaGV4VG9SZ2IoaGV4OiBzdHJpbmcpIHtcclxuICBjb25zdCBoID0gaGV4LnJlcGxhY2UoJyMnLCcnKTtcclxuICBjb25zdCBiaWdpbnQgPSBwYXJzZUludChoLmxlbmd0aCA9PT0gMyA/IGguc3BsaXQoJycpLm1hcChjPT5jK2MpLmpvaW4oJycpIDogaCwgMTYpO1xyXG4gIHJldHVybiB7IHI6IChiaWdpbnQgPj4gMTYpICYgMjU1LCBnOiAoYmlnaW50ID4+IDgpICYgMjU1LCBiOiBiaWdpbnQgJiAyNTUgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmdiVG9IZXgocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcikge1xyXG4gIGNvbnN0IHRvSGV4ID0gKG46IG51bWJlcikgPT4ge1xyXG4gICAgY29uc3QgaCA9IE1hdGgucm91bmQoTWF0aC5tYXgoMCwgTWF0aC5taW4oMjU1LCBuKSkpLnRvU3RyaW5nKDE2KTtcclxuICAgIHJldHVybiBoLmxlbmd0aCA9PT0gMSA/ICcwJyArIGggOiBoO1xyXG4gIH07XHJcbiAgcmV0dXJuIGAjJHt0b0hleChyKX0ke3RvSGV4KGcpfSR7dG9IZXgoYil9YC50b1VwcGVyQ2FzZSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBsZXJwKGE6IG51bWJlciwgYjogbnVtYmVyLCB0OiBudW1iZXIpIHtcclxuICByZXR1cm4gYSArIChiIC0gYSkgKiB0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBpbnRlcnBvbGF0ZUhleChoZXgxOiBzdHJpbmcsIGhleDI6IHN0cmluZywgdDogbnVtYmVyKSB7XHJcbiAgY29uc3QgYzEgPSBoZXhUb1JnYihoZXgxKTtcclxuICBjb25zdCBjMiA9IGhleFRvUmdiKGhleDIpO1xyXG4gIGNvbnN0IHIgPSBsZXJwKGMxLnIsIGMyLnIsIHQpO1xyXG4gIGNvbnN0IGcgPSBsZXJwKGMxLmcsIGMyLmcsIHQpO1xyXG4gIGNvbnN0IGIgPSBsZXJwKGMxLmIsIGMyLmIsIHQpO1xyXG4gIHJldHVybiByZ2JUb0hleChyLCBnLCBiKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbG9yRm9yU29icmEoc29icmE6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgY29uc3QgR1JFRU4gPSAnIzAwQTg1OSc7ICAvLyB2ZXJkZVxyXG4gIGNvbnN0IFlFTExPVyA9ICcjRkZEMTAwJzsgLy8gYW1hcmVsb1xyXG4gIGNvbnN0IFJFRCA9ICcjRkYwMDAwJzsgICAgLy8gdmVybWVsaG9cclxuXHJcbiAgaWYgKHNvYnJhID49IDIwMDApIHtcclxuICAgIHJldHVybiBHUkVFTjtcclxuICB9XHJcblxyXG4gIGlmIChzb2JyYSA8IDApIHtcclxuICAgIHJldHVybiBSRUQ7XHJcbiAgfVxyXG5cclxuICBjb25zdCB0ID0gMSAtIChzb2JyYSAvIDIwMDApOyAgXHJcbiAgcmV0dXJuIGludGVycG9sYXRlSGV4KEdSRUVOLCBZRUxMT1csIHQpO1xyXG59XHJcbiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgY2F0Y2hFcnJvciwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJ3NyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICcuLi9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgR2FzdG9zTWVuc2FpcyB9IGZyb20gJ3NyYy90eXBlcyc7XHJcbmltcG9ydCB7IE1lbnNhZ2Vuc1NlcnZpY2UgfSBmcm9tICcuLi9tZW5zYWdlbnMvbWVuc2FnZW5zLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgR2FzdG9zTWVuc2Fpc1NlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGJhc2VBcGlVcmwgPSBlbnZpcm9ubWVudC5iYXNlQXBpVXJsO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsIHByaXZhdGUgbWVuc2FnZW5zU2VydmljZTogTWVuc2FnZW5zU2VydmljZSkgeyB9XHJcblxyXG4gIGdldEdhc3Rvc01lbnNhaXMoZGF0YURlOiBzdHJpbmcsIGRhdGFBdGU6IHN0cmluZyk6IE9ic2VydmFibGU8R2FzdG9zTWVuc2Fpc1tdPiB7XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKTtcclxuICAgIGlmIChkYXRhRGUgJiYgZGF0YUF0ZSkge1xyXG4gICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxHYXN0b3NNZW5zYWlzW10+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvZ2FzdG9zbWVuc2Fpcz9pZFVzdWFyaW89JHtpZFVzdWFyaW99JmRhdGFEZT0ke2RhdGFEZX0mZGF0YUF0ZT0ke2RhdGFBdGV9YCkucGlwZShcclxuICAgICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICAgIC8vdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYnVzY2FyIGdhc3RvcyBtZW5zYWlzOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxHYXN0b3NNZW5zYWlzW10+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvZ2FzdG9zbWVuc2Fpcz9pZFVzdWFyaW89JHtpZFVzdWFyaW99YCkucGlwZShcclxuICAgICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICAgIC8vdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYnVzY2FyIGdhc3RvcyBtZW5zYWlzOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnc3JjL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnLi4vbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IEdhc3Rvc0NlbnRyb0N1c3RvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJy4uL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBHYXN0b3NDZW50cm9DdXN0b1NlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGJhc2VBcGlVcmwgPSBlbnZpcm9ubWVudC5iYXNlQXBpVXJsO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCwgcHJpdmF0ZSBsb2dpblNlcnZpY2U6IExvZ2luU2VydmljZSwgcHJpdmF0ZSBtZW5zYWdlbnNTZXJ2aWNlOiBNZW5zYWdlbnNTZXJ2aWNlICApIHsgfVxyXG5cclxuICBnZXRBbGxHYXN0b3NDZW50cm9NZXNBbm8obWVzQW5vPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXN0b3NDZW50cm9DdXN0b1tdPntcclxuICAgIGNvbnN0IGlkVXN1YXJpbyA9IHRoaXMubG9naW5TZXJ2aWNlLmdldElkVXN1YXJpbygpO1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8R2FzdG9zQ2VudHJvQ3VzdG9bXT4oYCR7dGhpcy5iYXNlQXBpVXJsfWFwaS9nYXN0b3NjZW50cm9jdXN0b3MvdXN1YXJpby8ke2lkVXN1YXJpb30vbWVzYW5vLyR7bWVzQW5vfWApLnBpcGUoXHJcbiAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgIC8vdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYnVzY2FyIGdhc3RvcyBwb3IgY2VudHJvIGRlIGN1c3RvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICdzcmMvZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgY2F0Y2hFcnJvciwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICcuLi9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgRGV0YWxoYW1lbnRvR2FzdG9zQ2VudHJvQ3VzdG8gfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5pbXBvcnQgeyBNZW5zYWdlbnNTZXJ2aWNlIH0gZnJvbSAnLi4vbWVuc2FnZW5zL21lbnNhZ2Vucy5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIERldGFsaGFtZW50b0dhc3Rvc0NlbnRyb0N1c3RvU2VydmljZSB7XHJcblxyXG4gIHByaXZhdGUgYmFzZUFwaVVybCA9IGVudmlyb25tZW50LmJhc2VBcGlVcmw7XHJcbiAgXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlLCBwcml2YXRlIG1lbnNhZ2Vuc1NlcnZpY2U6IE1lbnNhZ2Vuc1NlcnZpY2UpIHsgfVxyXG5cclxuICBnZXRBbGxEZXRhbGhhbWVudG9HYXN0b3NDZW50cm9NZXNBbm8obWVzQW5vPzogc3RyaW5nLCBkZXNjQ0M/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERldGFsaGFtZW50b0dhc3Rvc0NlbnRyb0N1c3RvW10+e1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxEZXRhbGhhbWVudG9HYXN0b3NDZW50cm9DdXN0b1tdPihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2RldGFsaGFtZW50b2dhc3Rvc2NlbnRyb2N1c3Rvcy9kZXNjcmljYW9DQz9pZFVzdWFyaW89JHtpZFVzdWFyaW99Jm1lc0Fubz0ke21lc0Fub30mZGVzY0NDPSR7ZGVzY0NDfWApLnBpcGUoXHJcbiAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgIC8vdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYnVzY2FyIGRldGFsaGFtZW50byBkZSBnYXN0b3M6ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgTGFuY2FtZW50byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9sYW5jYW1lbnRvL2xhbmNhbWVudG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnYXBwLW5vdm8tbGFuY2FtZW50bycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vbm92by1sYW5jYW1lbnRvLmNvbXBvbmVudC5odG1sJyxcclxuICAgIHN0eWxlVXJsczogWycuL25vdm8tbGFuY2FtZW50by5jb21wb25lbnQuY3NzJ10sXHJcbiAgICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTm92b0xhbmNhbWVudG9Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XHJcbiAgYnRuVGV4dDogc3RyaW5nID0gXCJSZWdpc3RyYXJcIjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBsYW5jYW1lbnRvU2VydmljZTogTGFuY2FtZW50b1NlcnZpY2UsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2Upe31cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICBcclxuICB9XHJcblxyXG4gIGFzeW5jIGNyZWF0ZUhhbmRsZXIobGFuY2FtZW50bzogTGFuY2FtZW50byl7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcblxyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkYXRhSG9yYScsIGxhbmNhbWVudG8uZGF0YUhvcmEudG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZhbG9yJywgbGFuY2FtZW50by52YWxvci50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnZGVzY3JpY2FvJywgbGFuY2FtZW50by5kZXNjcmljYW8pO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdzdGF0dXMnLCBsYW5jYW1lbnRvLnN0YXR1cyk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkQ0N1c3RvJywgbGFuY2FtZW50by5pZENDdXN0by50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnaWRVc3VhcmlvJywgaWRVc3VhcmlvID8/ICcnKTtcclxuXHJcbiAgICAgLy9Ub2RvXHJcbiAgICBjb25zb2xlLmxvZyhsYW5jYW1lbnRvLmRhdGFIb3JhKTtcclxuICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLmdldEFsbChcImRhdGFIb3JhXCIpKTtcclxuICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLmdldEFsbChcInZhbG9yXCIpKTtcclxuICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLmdldEFsbChcImRlc2NyaWNhb1wiKSk7XHJcbiAgICBjb25zb2xlLmxvZyhmb3JtRGF0YS5nZXRBbGwoXCJzdGF0dXNcIikpO1xyXG4gICAgY29uc29sZS5sb2coZm9ybURhdGEuZ2V0QWxsKFwiaWRDQ3VzdG9cIikpO1xyXG4gICAgY29uc29sZS5sb2coZm9ybURhdGEuZ2V0QWxsKFwiaWRVc3VhcmlvXCIpKTtcclxuICAgIGF3YWl0IHRoaXMubGFuY2FtZW50b1NlcnZpY2UucG9zdExhbmNhbWVudG8oZm9ybURhdGEpLnN1YnNjcmliZSgocmVzdWx0OiBhbnkpID0+IHtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvJ10pO1xyXG4gICAgfSxcclxuICAgICAgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvXCIpO1xyXG4gICAgICB9KVxyXG5cclxuICAgIFxyXG5cclxuICAvL0V4aWJpciBtc2dcclxuXHJcbiAgLy9SZWRpcmVjdFxyXG4gIH1cclxuIFxyXG5cclxufVxyXG4iLCI8aDI+UmVnaXN0cmUgbyBzZXUgPHNwYW4+TGFuw6dhbWVudG88L3NwYW4+PC9oMj5cclxuPGFwcC1sYW5jYW1lbnRvLWZvcm0gW2J0blRleHRdPVwiYnRuVGV4dFwiIChvblN1Ym1pdCk9XCJjcmVhdGVIYW5kbGVyKCRldmVudClcIj48L2FwcC1sYW5jYW1lbnRvLWZvcm0+IiwiaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBjYXRjaEVycm9yLCBPYnNlcnZhYmxlLCB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnc3JjL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJy4uL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJy4uL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBMYW5jYW1lbnRvU2VydmljZSB7XHJcbiAgcHJpdmF0ZSBiYXNlQXBpVXJsID0gZW52aXJvbm1lbnQuYmFzZUFwaVVybDtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlLCBwcml2YXRlIG1lbnNhZ2Vuc1NlcnZpY2U6IE1lbnNhZ2Vuc1NlcnZpY2UpIHsgfVxyXG5cclxuICBnZXRBbGxMYW5jYW1lbnRvcygpOiBPYnNlcnZhYmxlPExhbmNhbWVudG9bXT4ge1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxMYW5jYW1lbnRvW10+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvbGFuY2FtZW50b3MvdXN1YXJpby8ke2lkVXN1YXJpb31gKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICAvL3RoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnZXJyb3InLCAnRXJybycsIGBFcnJvIGFvIGJ1c2NhciBMYW7Dp2FtZW50b3M6ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGdldExhbmNhbWVudG9Qb3JJZChpZDogTnVtYmVyKTogT2JzZXJ2YWJsZTxMYW5jYW1lbnRvPiB7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxMYW5jYW1lbnRvPihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zLyR7aWR9YCkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgbGFuw6dhbWVudG86ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGdldExhbmNhbWVudG9EYXRhRGVBdGUoZGF0YURlOiBzdHJpbmcsIGRhdGFBdGU6IHN0cmluZywgc3RhdHVzOiBzdHJpbmcsIGlkQ2VudHJvQ3VzdG86IE51bWJlcik6IE9ic2VydmFibGU8TGFuY2FtZW50b1tdPiB7XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKTtcclxuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuYmFzZUFwaVVybH1hcGkvbGFuY2FtZW50b3MvZGF0YURlQXRlP2lkVXN1YXJpbz0ke2lkVXN1YXJpb30mZGF0YURlPSR7ZGF0YURlfSZkYXRhQXRlPSR7ZGF0YUF0ZX0mc3RhdHVzPSR7c3RhdHVzfSZpZENlbnRyb0N1c3RvPSR7aWRDZW50cm9DdXN0b31gO1xyXG4gICAgY29uc29sZS5sb2codXJsKTtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PExhbmNhbWVudG9bXT4odXJsKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICAvL3RoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnZXJyb3InLCAnRXJybycsIGBFcnJvIGFvIGJ1c2NhciBMYW7Dp2FtZW50b3M6ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHBvc3RMYW5jYW1lbnRvKGZvcm1EYXRhOiBGb3JtRGF0YSk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICB2YXIgZGF0YUxhbmNhbWVudG8gPSBuZXcgRGF0ZShmb3JtRGF0YS5nZXRBbGwoXCJkYXRhSG9yYVwiKS50b1N0cmluZygpICsgXCJaXCIpO1xyXG4gICAgdmFyIGRhdGEgPSB7XHJcbiAgICAgIGRhdGFIb3JhOiBkYXRhTGFuY2FtZW50byxcclxuICAgICAgdmFsb3I6IE51bWJlcihmb3JtRGF0YS5nZXRBbGwoXCJ2YWxvclwiKSksXHJcbiAgICAgIGRlc2NyaWNhbzogZm9ybURhdGEuZ2V0QWxsKFwiZGVzY3JpY2FvXCIpLnRvU3RyaW5nKCkudHJpbSgpLFxyXG4gICAgICBzdGF0dXM6IGZvcm1EYXRhLmdldEFsbChcInN0YXR1c1wiKS50b1N0cmluZygpLFxyXG4gICAgICBpZENDdXN0bzogTnVtYmVyKGZvcm1EYXRhLmdldEFsbChcImlkQ0N1c3RvXCIpKSxcclxuICAgICAgaWRVc3VhcmlvOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwiaWRVc3VhcmlvXCIpKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zYCwgZGF0YSkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gY3JpYXIgbGFuw6dhbWVudG86ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGV4Y2x1aXJMYW5jYW1lbnRvKGlkOiBOdW1iZXIpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgdmFyIGRhdGEgPSB7XHJcbiAgICAgIGRlbGV0YWRvOiAnKidcclxuICAgIH07XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnB1dChgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zL2RlbC8ke2lkfWAsIGRhdGEpLnBpcGUoXHJcbiAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgIHRoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnZXJyb3InLCAnRXJybycsIGBFcnJvIGFvIGV4Y2x1aXIgbGFuw6dhbWVudG86ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHB1dExhbmNhbWVudG8oaWQ6IE51bWJlciwgZm9ybURhdGE6IEZvcm1EYXRhKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHZhciBkYXRhTGFuY2FtZW50byA9IG5ldyBEYXRlKGZvcm1EYXRhLmdldEFsbChcImRhdGFIb3JhXCIpLnRvU3RyaW5nKCkgKyBcIlpcIik7XHJcbiAgICBjb25zb2xlLmxvZyhOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwidmFsb3JcIikpKTtcclxuICAgIHZhciBkYXRhID0ge1xyXG4gICAgICBkYXRhSG9yYTogZGF0YUxhbmNhbWVudG8sXHJcbiAgICAgIHZhbG9yOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwidmFsb3JcIikpLFxyXG4gICAgICBkZXNjcmljYW86IGZvcm1EYXRhLmdldEFsbChcImRlc2NyaWNhb1wiKS50b1N0cmluZygpLnRyaW0oKSxcclxuICAgICAgc3RhdHVzOiBmb3JtRGF0YS5nZXRBbGwoXCJzdGF0dXNcIikudG9TdHJpbmcoKSxcclxuICAgICAgaWRDQ3VzdG86IE51bWJlcihmb3JtRGF0YS5nZXRBbGwoXCJpZENDdXN0b1wiKSksXHJcbiAgICAgIGlkVXN1YXJpbzogTnVtYmVyKGZvcm1EYXRhLmdldEFsbChcImlkVXN1YXJpb1wiKSlcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8YW55PihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zLyR7aWR9YCwgZGF0YSkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYXR1YWxpemFyIGxhbsOnYW1lbnRvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBnZXRFeGlzdGVDZW50cm9DdXN0byhpZFVzdWFyaW86IHN0cmluZywgaWRDZW50cm9DdXN0bzogTnVtYmVyKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PGFueT4oYCR7dGhpcy5iYXNlQXBpVXJsfWFwaS9sYW5jYW1lbnRvcy91c3VhcmlvLyR7aWRVc3VhcmlvfS9pZGNlbnRyb2N1c3RvLyR7aWRDZW50cm9DdXN0b31gKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyB2ZXJpZmljYXIgY2VudHJvIGRlIGN1c3RvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbnB1dCwgT3V0cHV0LCBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUNvbnRyb2wsIEZvcm1Hcm91cCwgVmFsaWRhdG9ycyB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgQ2VudHJvQ3VzdG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9jZXRyby1jdXN0by9jZW50cm8tY3VzdG8uc2VydmljZSc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvLCBMYW5jYW1lbnRvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWxhbmNhbWVudG8tZm9ybScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2xhbmNhbWVudG8tZm9ybS5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vbGFuY2FtZW50by1mb3JtLmNvbXBvbmVudC5jc3MnXSxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTGFuY2FtZW50b0Zvcm1Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIEBPdXRwdXQoKSBvblN1Ym1pdCA9IG5ldyBFdmVudEVtaXR0ZXI8TGFuY2FtZW50bz4oKTtcclxuICBASW5wdXQoKSBidG5UZXh0ITogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIGxhbmNhbWVudG9EYXRhOiBMYW5jYW1lbnRvIHwgbnVsbCA9IG51bGw7XHJcbiAgbGFuY2FtZW50b0Zvcm0hOiBGb3JtR3JvdXA7XHJcbiAgY2VudHJvQ3VzdG9zOiBDZW50cm9DdXN0b1tdID0gW107XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UpIHsgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIHRoaXMubGFuY2FtZW50b0Zvcm0gPSBuZXcgRm9ybUdyb3VwKHtcclxuICAgICAgaWQ6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9EYXRhID8gdGhpcy5sYW5jYW1lbnRvRGF0YS5pZCA6ICcnKSxcclxuICAgICAgZGF0YUhvcmE6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9EYXRhID8gdGhpcy5sYW5jYW1lbnRvRGF0YS5kYXRhSG9yYSA6IHRoaXMuZ2V0RGF0YUhvcmFBdHVhbCgpLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICB2YWxvcjogbmV3IEZvcm1Db250cm9sKHRoaXMubGFuY2FtZW50b0RhdGEgPyB0aGlzLmZvcm1hdFZhbG9ySW5pY2lhbCh0aGlzLmxhbmNhbWVudG9EYXRhLnZhbG9yKSA6ICcnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICBkZXNjcmljYW86IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9EYXRhID8gdGhpcy5sYW5jYW1lbnRvRGF0YS5kZXNjcmljYW8gOiAnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdKSxcclxuICAgICAgc3RhdHVzOiBuZXcgRm9ybUNvbnRyb2wodGhpcy5sYW5jYW1lbnRvRGF0YSA/IHRoaXMubGFuY2FtZW50b0RhdGEuc3RhdHVzIDogJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXSksXHJcbiAgICAgIGlkQ0N1c3RvOiBuZXcgRm9ybUNvbnRyb2wodGhpcy5sYW5jYW1lbnRvRGF0YSA/IHRoaXMubGFuY2FtZW50b0RhdGEuaWRDQ3VzdG8gOiAnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdKSxcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmdldEFsbENlbnRyb0N1c3RvcygpLnN1YnNjcmliZSgoY2VudHJvQ3VzdG9zKSA9PiAodGhpcy5jZW50cm9DdXN0b3MgPSBjZW50cm9DdXN0b3MpKTtcclxuICB9XHJcblxyXG4gIC8vIEZvcm1hdGEgbyB2YWxvciBpbmljaWFsIHF1YW5kbyBjYXJyZWdhZG8gZGEgQVBJXHJcbiAgZm9ybWF0VmFsb3JJbmljaWFsKHZhbG9yOiBudW1iZXIgfCBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgbGV0IHZhbG9yU3RyID0gdmFsb3IudG9TdHJpbmcoKS5yZXBsYWNlKCcuJywgJywnKTsgLy8gVHJvY2EgcG9udG8gcG9yIHbDrXJndWxhXHJcbiAgICBsZXQgcGFydGVzID0gdmFsb3JTdHIuc3BsaXQoJywnKTtcclxuICAgIGxldCBpbnRlaXJvID0gcGFydGVzWzBdLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcuJyk7IC8vIEFkaWNpb25hIHNlcGFyYWRvciBkZSBtaWxoYXJcclxuICAgIGxldCBkZWNpbWFsID0gcGFydGVzWzFdID8gcGFydGVzWzFdLnBhZEVuZCgyLCAnMCcpIDogJzAwJzsgLy8gR2FyYW50ZSBkb2lzIGTDrWdpdG9zIG5vcyBjZW50YXZvc1xyXG4gICAgcmV0dXJuIGAke2ludGVpcm99LCR7ZGVjaW1hbH1gO1xyXG4gIH1cclxuXHJcbiAgZm9ybWF0VmFsb3IoKTogdm9pZCB7XHJcbiAgICBsZXQgdmFsb3IgPSB0aGlzLnZhbG9yLnZhbHVlLnJlcGxhY2UoL1xcRC9nLCAnJyk7IC8vIFJlbW92ZSB0dWRvIHF1ZSBuw6NvIGZvciBuw7ptZXJvXHJcbiAgXHJcbiAgICBpZiAodmFsb3IubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHRoaXMubGFuY2FtZW50b0Zvcm0uY29udHJvbHNbJ3ZhbG9yJ10uc2V0VmFsdWUoJycsIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLy8gUmVtb3ZlIHplcm9zIMOgIGVzcXVlcmRhXHJcbiAgICB2YWxvciA9IHZhbG9yLnJlcGxhY2UoL14wKyg/ISQpLywgJycpO1xyXG4gIFxyXG4gICAgLy8gU2UgdGl2ZXIgbWVub3MgZGUgMyBkw61naXRvcywgYXBlbmFzIGFkaWNpb25hIGEgdsOtcmd1bGEgY29ycmV0YW1lbnRlXHJcbiAgICBpZiAodmFsb3IubGVuZ3RoIDw9IDIpIHtcclxuICAgICAgdGhpcy5sYW5jYW1lbnRvRm9ybS5jb250cm9sc1sndmFsb3InXS5zZXRWYWx1ZShgMCwke3ZhbG9yLnBhZFN0YXJ0KDIsICcwJyl9YCwgeyBlbWl0RXZlbnQ6IGZhbHNlIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgXHJcbiAgICAvLyBTZXBhcmEgb3MgY2VudGF2b3MgKMO6bHRpbW9zIDIgZMOtZ2l0b3MpXHJcbiAgICBsZXQgaW50ZWlybyA9IHZhbG9yLnNsaWNlKDAsIC0yKTtcclxuICAgIGxldCBkZWNpbWFsID0gdmFsb3Iuc2xpY2UoLTIpO1xyXG4gIFxyXG4gICAgLy8gQXBsaWNhIHNlcGFyYWRvcmVzIGRlIG1pbGhhclxyXG4gICAgaW50ZWlybyA9IGludGVpcm8ucmVwbGFjZSgvXFxCKD89KFxcZHszfSkrKD8hXFxkKSkvZywgJy4nKTtcclxuICBcclxuICAgIC8vIE1vbnRhIG8gdmFsb3IgZmluYWxcclxuICAgIGxldCB2YWxvckZvcm1hdGFkbyA9IGAke2ludGVpcm99LCR7ZGVjaW1hbH1gO1xyXG4gIFxyXG4gICAgLy8gQXR1YWxpemEgbyBjYW1wbyBzZW0gZGlzcGFyYXIgZXZlbnRvcyBpbmZpbml0b3NcclxuICAgIHRoaXMubGFuY2FtZW50b0Zvcm0uY29udHJvbHNbJ3ZhbG9yJ10uc2V0VmFsdWUodmFsb3JGb3JtYXRhZG8sIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcclxuICB9XHJcblxyXG4gIGdldERhdGFIb3JhQXR1YWwoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgICBub3cuc2V0TWludXRlcyhub3cuZ2V0TWludXRlcygpIC0gbm93LmdldFRpbWV6b25lT2Zmc2V0KCkpO1xyXG4gICAgcmV0dXJuIG5vdy50b0lTT1N0cmluZygpLnNsaWNlKDAsIDE2KTtcclxuICB9XHJcblxyXG4gIGdldCBkYXRhSG9yYSgpIHtcclxuICAgIHJldHVybiB0aGlzLmxhbmNhbWVudG9Gb3JtLmdldCgnZGF0YUhvcmEnKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgdmFsb3IoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5sYW5jYW1lbnRvRm9ybS5nZXQoJ3ZhbG9yJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGRlc2NyaWNhbygpIHtcclxuICAgIHJldHVybiB0aGlzLmxhbmNhbWVudG9Gb3JtLmdldCgnZGVzY3JpY2FvJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IHN0YXR1cygpIHtcclxuICAgIHJldHVybiB0aGlzLmxhbmNhbWVudG9Gb3JtLmdldCgnc3RhdHVzJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGlkQ0N1c3RvKCkge1xyXG4gICAgcmV0dXJuIHRoaXMubGFuY2FtZW50b0Zvcm0uZ2V0KCdpZENDdXN0bycpITtcclxuICB9XHJcblxyXG4gIGdldCBpZFVzdWFyaW8oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5sYW5jYW1lbnRvRm9ybS5nZXQoJ2lkVXN1YXJpbycpITtcclxuICB9XHJcblxyXG4gIHN1Ym1pdCgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLmxhbmNhbWVudG9Gb3JtLmludmFsaWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgbGV0IHZhbG9yRm9ybWF0YWRvID0gU3RyaW5nKHRoaXMudmFsb3IudmFsdWUpXHJcbiAgICAgIC5yZXBsYWNlKC9cXC4vZywgJycpIC8vIFJlbW92ZSBwb250b3MgZG9zIG1pbGhhcmVzXHJcbiAgICAgIC5yZXBsYWNlKCcsJywgJy4nKTsgLy8gVHJvY2EgdsOtcmd1bGEgcG9yIHBvbnRvIHBhcmEgZGVjaW1hbFxyXG4gIFxyXG4gICAgbGV0IGxhbmNhbWVudG9Gb3JtYXRhZG8gPSB7XHJcbiAgICAgIC4uLnRoaXMubGFuY2FtZW50b0Zvcm0udmFsdWUsXHJcbiAgICAgIHZhbG9yOiB2YWxvckZvcm1hdGFkb1xyXG4gICAgfTtcclxuICBcclxuICAgIHRoaXMub25TdWJtaXQuZW1pdChsYW5jYW1lbnRvRm9ybWF0YWRvKTtcclxuICB9XHJcbiAgXHJcbn1cclxuIiwiPGZvcm0gKG5nU3VibWl0KT1cInN1Ym1pdCgpXCIgW2Zvcm1Hcm91cF09XCJsYW5jYW1lbnRvRm9ybVwiICNmb3JtRGlyPVwibmdGb3JtXCI+XHJcbiAgICBcclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJoaWRkZW5cIiBmb3JtQ29udHJvbE5hbWU9XCJpZFwiIC8+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cImRhdGFIb3JhXCI+RGF0YTo8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIiBwbGFjZWhvbGRlcj1cIkNvbG9xdWUgYSBkYXRhIGRvIExhbsOnYW1lbnRvXCIgZm9ybUNvbnRyb2xOYW1lPSBcImRhdGFIb3JhXCIgcmVxdWlyZWQ+XHJcbiAgICAgICAgPGRpdiAqbmdJZj1cImRhdGFIb3JhLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJkYXRhSG9yYS5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPkEgZGF0YSDDqSBvYnJpZ2F0w7NyaWEuPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxvclwiPlZhbG9yOjwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaW5wdXRtb2RlPVwibnVtZXJpY1wiIHBsYWNlaG9sZGVyPVwiQ29sb3F1ZSBvIHZhbG9yIGRvIExhbsOnYW1lbnRvXCIgZm9ybUNvbnRyb2xOYW1lPVwidmFsb3JcIiByZXF1aXJlZCAoaW5wdXQpPVwiZm9ybWF0VmFsb3IoKVwiPlxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJ2YWxvci5pbnZhbGlkICYmIGZvcm1EaXIuc3VibWl0dGVkXCIgY2xhc3M9XCJ2YWxpZGF0aW9uLWVycm9yXCI+XHJcbiAgICAgICAgICAgIDxwICpuZ0lmPVwidmFsb3IuZXJyb3JzPy5bJ3JlcXVpcmVkJ11cIj5PIHZhbG9yIMOpIG9icmlnYXTDs3JpYS48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cImRlc2NyaXB0aW9uXCI+RGVzY3Jpw6fDo286PC9sYWJlbD5cclxuICAgICAgICA8dGV4dGFyZWEgcGxhY2Vob2xkZXI9XCJEZXNjcmnDp8OjbyBkbyBMYW5jYW1lbnRvXCIgZm9ybUNvbnRyb2xOYW1lPVwiZGVzY3JpY2FvXCIgcmVxdWlyZWQ+PC90ZXh0YXJlYT5cclxuICAgICAgICA8ZGl2ICpuZ0lmPVwiZGVzY3JpY2FvLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJkZXNjcmljYW8uZXJyb3JzPy5bJ3JlcXVpcmVkJ11cIj5BIGRlc2NyacOnw6NvIMOpIG9icmlnYXTDs3JpYS48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj4gICBcclxuICAgIFxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwic3RhdHVzXCI+U3RhdHVzOjwvbGFiZWw+XHJcbiAgICAgICAgPHNlbGVjdCBmb3JtQ29udHJvbE5hbWU9XCJzdGF0dXNcIiByZXF1aXJlZD5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkEgUmVjZWJlclwiPkEgUmVjZWJlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQSBQYWdhclwiPkEgUGFnYXI8L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJlY2ViaWRvXCI+UmVjZWJpZG88L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBhZ29cIj5QYWdvPC9vcHRpb24+XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJzdGF0dXNcIj5DZW50cm8gQ3VzdG86PC9sYWJlbD5cclxuICAgICAgICA8c2VsZWN0IGZvcm1Db250cm9sTmFtZT1cImlkQ0N1c3RvXCIgcmVxdWlyZWQ+XHJcbiAgICAgICAgICAgIDxvcHRpb24gKm5nRm9yPVwibGV0IGNlbnRyb0N1c3RvIG9mIGNlbnRyb0N1c3Rvc1wiIHZhbHVlPXt7Y2VudHJvQ3VzdG8uaWR9fT57e2NlbnRyb0N1c3RvLmRlc2NyaUNDdXN0b319PC9vcHRpb24+XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICA8L2Rpdj5cclxuICAgIFxyXG4gICAgPGRpdiAqbmdJZj1cImlkQ0N1c3RvLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICA8cCAqbmdJZj1cImlkQ0N1c3RvLmVycm9ycz8uWydyZXF1aXJlZCddXCI+TyBjZW50cm8gZGUgY3VzdG8gw6kgb2JyaWdhdMOzcmlhLjwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgXHJcblxyXG4gICAgPGlucHV0IHR5cGU9XCJzdWJtaXRcIiB2YWx1ZT1cInt7YnRuVGV4dH19XCI+ICAgIFxyXG48L2Zvcm0+IiwiaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBjYXRjaEVycm9yLCB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnc3JjL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJy4uL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDZW50cm9DdXN0byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcbmltcG9ydCB7IE1lbnNhZ2Vuc1NlcnZpY2UgfSBmcm9tICcuLi9tZW5zYWdlbnMvbWVuc2FnZW5zLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQ2VudHJvQ3VzdG9TZXJ2aWNlIHtcclxuXHJcbiAgcHJpdmF0ZSBiYXNlQXBpVXJsID0gZW52aXJvbm1lbnQuYmFzZUFwaVVybDtcclxuICBcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsIHByaXZhdGUgbWVuc2FnZW5zU2VydmljZTogTWVuc2FnZW5zU2VydmljZSkgeyB9XHJcbiAgXHJcbiAgZ2V0QWxsQ2VudHJvQ3VzdG9zKCk6IE9ic2VydmFibGU8Q2VudHJvQ3VzdG9bXT57XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKTtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PENlbnRyb0N1c3RvW10+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvY2VudHJvY3VzdG9zL3VzdWFyaW8vJHtpZFVzdWFyaW99YCkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgY2VudHJvcyBkZSBjdXN0bzogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgZ2V0SWRDZW50cm9DdXN0b3MoaWQ6IE51bWJlcik6IE9ic2VydmFibGU8Q2VudHJvQ3VzdG8+e1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8Q2VudHJvQ3VzdG8+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvY2VudHJvY3VzdG9zLyR7aWR9YCkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYnVzY2FyIGNlbnRybyBkZSBjdXN0bzogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcG9zdENlbnRyb0N1c3RvKGZvcm1EYXRhOiBGb3JtRGF0YSk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICB2YXIgZGF0YSA9IHsgXHJcbiAgICAgIGRlc2NyaUNDdXN0bzogZm9ybURhdGEuZ2V0QWxsKFwiZGVzY3JpQ0N1c3RvXCIpLnRvU3RyaW5nKCkudHJpbSgpLFxyXG4gICAgICB2YWxvckxpbWl0ZTogTnVtYmVyKGZvcm1EYXRhLmdldEFsbChcInZhbG9yTGltaXRlXCIpKSxcclxuICAgICAgaWRVc3VhcmlvOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwiaWRVc3VhcmlvXCIpKVxyXG4gICAgfTsgXHJcbiAgICBjb25zb2xlLmxvZyhcIkRhdGE6IFwiKTsgXHJcbiAgICBjb25zb2xlLmxvZyhkYXRhKTsgICBcclxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvY2VudHJvY3VzdG9zYCwgZGF0YSkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gY3JpYXIgY2VudHJvIGRlIGN1c3RvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBwdXRDZW50cm9DdXN0b3MoaWQ6IE51bWJlciwgZm9ybURhdGE6IEZvcm1EYXRhKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHZhciBkYXRhID0geyBcclxuICAgICAgZGVzY3JpQ0N1c3RvOiBmb3JtRGF0YS5nZXRBbGwoXCJkZXNjcmlDQ3VzdG9cIikudG9TdHJpbmcoKS50cmltKCksXHJcbiAgICAgIHZhbG9yTGltaXRlOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwidmFsb3JMaW1pdGVcIikpXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiB0aGlzLmh0dHAucHV0PGFueT4oYCR7dGhpcy5iYXNlQXBpVXJsfWFwaS9jZW50cm9jdXN0b3MvJHtpZH1gLCBkYXRhKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBhdHVhbGl6YXIgY2VudHJvIGRlIGN1c3RvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBleGNsdWlyQ2VudHJvQ3VzdG8oaWQ6IE51bWJlcik6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICB2YXIgZGF0YSA9IHsgXHJcbiAgICAgIGRlbGV0YWRvOiAnKidcclxuICAgIH07XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnB1dChgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2NlbnRyb2N1c3Rvcy9kZWwvJHtpZH1gLCBkYXRhKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcclxuICAgICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBleGNsdWlyIGNlbnRybyBkZSBjdXN0bzogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH0gXHJcblxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuaW1wb3J0IHsgTGFuY2FtZW50b1NlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2xhbmNhbWVudG8vbGFuY2FtZW50by5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdhcHAtZWRpdC1sYW5jYW1lbnRvJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9lZGl0LWxhbmNhbWVudG8uY29tcG9uZW50Lmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4vZWRpdC1sYW5jYW1lbnRvLmNvbXBvbmVudC5jc3MnXSxcclxuICAgIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBFZGl0TGFuY2FtZW50b0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuXHJcbiAgbGFuY2FtZW50byE6IExhbmNhbWVudG87XHJcbiAgYnRuVGV4dDogc3RyaW5nID0gJ0NvbmZpcm1hcic7XHJcbiAgXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBsYW5jYW1lbnRvU2VydmljZTogTGFuY2FtZW50b1NlcnZpY2UsIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkID0gTnVtYmVyKHRoaXMucm91dGUuc25hcHNob3QucGFyYW1NYXAuZ2V0KFwiaWRcIikpO1xyXG5cclxuICAgIHRoaXMubGFuY2FtZW50b1NlcnZpY2UuZ2V0TGFuY2FtZW50b1BvcklkKGlkKS5zdWJzY3JpYmUoKGl0ZW0pID0+IHtcclxuICAgICAgdGhpcy5sYW5jYW1lbnRvID0gaXRlbTtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5sYW5jYW1lbnRvLmRhdGFIb3JhKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGFzeW5jIGVkaXRIZW5kbGVyKGxhbmNhbWVudG9EYXRhOiBMYW5jYW1lbnRvKXsgICAgXHJcbiAgICBjb25zdCBpZCA9IHRoaXMubGFuY2FtZW50by5pZDtcclxuICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKTtcclxuXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2RhdGFIb3JhJywgbGFuY2FtZW50b0RhdGEuZGF0YUhvcmEudG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZhbG9yJywgbGFuY2FtZW50b0RhdGEudmFsb3IudG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2Rlc2NyaWNhbycsIGxhbmNhbWVudG9EYXRhLmRlc2NyaWNhbyk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3N0YXR1cycsIGxhbmNhbWVudG9EYXRhLnN0YXR1cyk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkQ0N1c3RvJywgbGFuY2FtZW50b0RhdGEuaWRDQ3VzdG8udG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkVXN1YXJpbycsIGlkVXN1YXJpbyA/PyAnJyk7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5sYW5jYW1lbnRvU2VydmljZS5wdXRMYW5jYW1lbnRvKGlkISwgZm9ybURhdGEpLnN1YnNjcmliZSgocmVzdWx0OiBhbnkpID0+IHtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvJ10pO1xyXG4gICAgfSxcclxuICAgICAgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvXCIpO1xyXG4gICAgICB9KVxyXG4gIH1cclxuICBcclxufVxyXG4iLCI8ZGl2ICpuZ0lmPVwibGFuY2FtZW50b1wiPlxyXG4gICAgPGgyPlxyXG4gICAgICAgIDxzcGFuPkVkaXRhcjwvc3Bhbj4gTGFuY2FtZW50b1xyXG4gICAgPC9oMj5cclxuICAgIDxhcHAtbGFuY2FtZW50by1mb3JtIChvblN1Ym1pdCk9XCJlZGl0SGVuZGxlcigkZXZlbnQpXCIgW2xhbmNhbWVudG9EYXRhXT1cImxhbmNhbWVudG9cIiBbYnRuVGV4dF09XCJidG5UZXh0XCI+PC9hcHAtbGFuY2FtZW50by1mb3JtPlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgTGFuY2FtZW50byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9sYW5jYW1lbnRvL2xhbmNhbWVudG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnYXBwLWV4Y2x1aXItbGFuY2FtZW50bycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vZXhjbHVpci1sYW5jYW1lbnRvLmNvbXBvbmVudC5odG1sJyxcclxuICAgIHN0eWxlVXJsczogWycuL2V4Y2x1aXItbGFuY2FtZW50by5jb21wb25lbnQuY3NzJ10sXHJcbiAgICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRXhjbHVpckxhbmNhbWVudG9Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XHJcblxyXG4gIGxhbmNhbWVudG8hOiBMYW5jYW1lbnRvO1xyXG4gIGJ0blRleHQ6IHN0cmluZyA9ICdSZW1vdmVyJztcclxuICBcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGxhbmNhbWVudG9TZXJ2aWNlOiBMYW5jYW1lbnRvU2VydmljZSwgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIgLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkID0gTnVtYmVyKHRoaXMucm91dGUuc25hcHNob3QucGFyYW1NYXAuZ2V0KFwiaWRcIikpO1xyXG5cclxuICAgIHRoaXMubGFuY2FtZW50b1NlcnZpY2UuZ2V0TGFuY2FtZW50b1BvcklkKGlkKS5zdWJzY3JpYmUoKGl0ZW0pID0+IHtcclxuICAgICAgdGhpcy5sYW5jYW1lbnRvID0gaXRlbTtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5sYW5jYW1lbnRvLmRhdGFIb3JhKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG5cclxuICBhc3luYyBleGNsdWlySGVuZGxlcihsYW5jYW1lbnRvRGF0YTogTGFuY2FtZW50byl7ICAgIFxyXG4gICAgY29uc3QgaWQgPSB0aGlzLmxhbmNhbWVudG8uaWQ7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcblxyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkYXRhSG9yYScsIGxhbmNhbWVudG9EYXRhLmRhdGFIb3JhLnRvU3RyaW5nKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCd2YWxvcicsIGxhbmNhbWVudG9EYXRhLnZhbG9yLnRvU3RyaW5nKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkZXNjcmljYW8nLCBsYW5jYW1lbnRvRGF0YS5kZXNjcmljYW8pO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdzdGF0dXMnLCBsYW5jYW1lbnRvRGF0YS5zdGF0dXMpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdpZENDdXN0bycsIGxhbmNhbWVudG9EYXRhLmlkQ0N1c3RvLnRvU3RyaW5nKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdpZFVzdWFyaW8nLCBpZFVzdWFyaW8gPz8gJycpO1xyXG5cclxuICAgIGF3YWl0IHRoaXMubGFuY2FtZW50b1NlcnZpY2UuZXhjbHVpckxhbmNhbWVudG8odGhpcy5sYW5jYW1lbnRvLmlkISkuc3Vic2NyaWJlKChyZXN1bHQ6IGFueSkgPT4ge1xyXG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy8nXSk7XHJcbiAgICB9LFxyXG4gICAgICAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9cIik7XHJcbiAgICAgIH0pXHJcbiAgfVxyXG5cclxufVxyXG4iLCI8ZGl2ICpuZ0lmPVwibGFuY2FtZW50b1wiPlxyXG4gICAgPGgyPlxyXG4gICAgICAgIEV4Y2x1aXIgPHNwYW4+TGFuY2FtZW50bzwvc3Bhbj5cclxuICAgIDwvaDI+XHJcbiAgICA8YXBwLWxhbmNhbWVudG8tZm9ybSAob25TdWJtaXQpPVwiZXhjbHVpckhlbmRsZXIoJGV2ZW50KVwiIFtsYW5jYW1lbnRvRGF0YV09XCJsYW5jYW1lbnRvXCIgW2J0blRleHRdPVwiYnRuVGV4dFwiPjwvYXBwLWxhbmNhbWVudG8tZm9ybT5cclxuPC9kaXY+IiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTYWxkb1NlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL3NhbGRvL3NhbGRvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTYWxkbyB9IGZyb20gJ3NyYy90eXBlcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnYXBwLXNhbGRvcycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vc2FsZG9zLmNvbXBvbmVudC5odG1sJyxcclxuICAgIHN0eWxlVXJsczogWycuL3NhbGRvcy5jb21wb25lbnQuY3NzJ10sXHJcbiAgICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgU2FsZG9zQ29tcG9uZW50IHtcclxuICBASW5wdXQoKSB2YWxvckFQYWdhcjogbnVtYmVyID0gMDtcclxuICBASW5wdXQoKSB2YWxvclBhZ286IG51bWJlciA9IDA7XHJcbiAgQElucHV0KCkgdmFsb3JBUmVjZWJlcjogbnVtYmVyID0gMDtcclxuICBASW5wdXQoKSB2YWxvclJlY2ViaWRvOiBudW1iZXIgPSAwO1xyXG4gIEBJbnB1dCgpIGRlc3Blc2FzR3JhZmljb0RvbnV0ITogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHJlY2VpdGFzR3JhZmljb0RvbnV0ITogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIGlzTG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcbiAgc2FsZG86IFNhbGRvIHwgdW5kZWZpbmVkO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNhbGRvU2VydmljZTogU2FsZG9TZXJ2aWNlKSB7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIHRoaXMuc2FsZG9TZXJ2aWNlLmdldFNhbGRvcygpLnN1YnNjcmliZSgoaXRlbSkgPT4ge1xyXG4gICAgICB0aGlzLnNhbGRvID0gaXRlbTtcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG4iLCI8ZGl2IGNsYXNzPVwiY29udGFpbmVyLXNhbGRvc1wiICpuZ0lmPVwiaXNMb2FkaW5nOyBlbHNlIHNhbGRvc0NvbnRlbnRcIj5cclxuICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyLXNhbGRvcy1zdXBlcmlvclwiPlxyXG4gICAgPGRpdiBjbGFzcz1cInF1YWRyYW50ZXMtc2FsZG9zIHNrZWxldG9uLWNhcmRcIiAqbmdGb3I9XCJsZXQgaXRlbSBvZiBbMSwgMiwgM11cIj5cclxuICAgICAgPGRpdiBjbGFzcz1cInNrZWxldG9uLWxpbmUgc2tlbGV0b24tbGluZS10aXRsZVwiPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzPVwic2tlbGV0b24tbGluZSBza2VsZXRvbi1saW5lLXZhbHVlXCI+PC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzcz1cImNvbnRhaW5lci1zYWxkb3MtaW5mZXJpb3JcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJxdWFkcmFudGUtc2FsZG9zLXNhbGRvLWZpbHRybyBza2VsZXRvbi1jYXJkXCIgKm5nRm9yPVwibGV0IGl0ZW0gb2YgWzEsIDIsIDMsIDRdXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJza2VsZXRvbi1saW5lIHNrZWxldG9uLWxpbmUtdGl0bGVcIj48L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzcz1cInNrZWxldG9uLWxpbmUgc2tlbGV0b24tbGluZS12YWx1ZVwiPjwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwicXVhZHJhbnRlLXNhbGRvcy1ncmFmaWNvIHNrZWxldG9uLWNoYXJ0XCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJza2VsZXRvbi1yaW5nXCI+PC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcblxyXG48bmctdGVtcGxhdGUgI3NhbGRvc0NvbnRlbnQ+XHJcbiAgPGRpdiBjbGFzcz1cImNvbnRhaW5lci1zYWxkb3NcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJjb250YWluZXItc2FsZG9zLXN1cGVyaW9yXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJxdWFkcmFudGVzLXNhbGRvc1wiPlxyXG4gICAgICAgIDxwIGNsYXNzPVwidGl0dWxvLXNhbGRvc1wiPlNhbGRvPC9wPlxyXG4gICAgICAgIDxzdHJvbmcgY2xhc3M9XCJyZXN1bHRhZG8tc2FsZG9zXCI+UiQge3sgc2FsZG8/LnNhbGRvIHwgZm9ybWF0VmFsb3IgfX08L3N0cm9uZz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwicXVhZHJhbnRlcy1zYWxkb3NcIj5cclxuICAgICAgICA8cCBjbGFzcz1cInRpdHVsby1zYWxkb3NcIj5JbnZlc3QuIEZpeG88L3A+XHJcbiAgICAgICAgPHN0cm9uZyBjbGFzcz1cInJlc3VsdGFkby1zYWxkb3NcIj5SJCB7eyBzYWxkbz8uaW52ZXN0aW1lbnRvRml4byB8IGZvcm1hdFZhbG9yIH19PC9zdHJvbmc+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cInF1YWRyYW50ZXMtc2FsZG9zXCI+XHJcbiAgICAgICAgPHAgY2xhc3M9XCJ0aXR1bG8tc2FsZG9zXCI+SW52ZXN0LiBWYXJpw6F2ZWw8L3A+XHJcbiAgICAgICAgPHN0cm9uZyBjbGFzcz1cInJlc3VsdGFkby1zYWxkb3NcIj5SJCB7eyBzYWxkbz8uaW52ZXN0aW1lbnRvVmFyaWF2ZWwgfCBmb3JtYXRWYWxvciB9fTwvc3Ryb25nPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJjb250YWluZXItc2FsZG9zLWluZmVyaW9yXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJxdWFkcmFudGUtc2FsZG9zLXNhbGRvLWZpbHRyb1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzZXNzYW8tc2FsZG8tZmlsdHJvXCI+XHJcbiAgICAgICAgICA8cCBjbGFzcz1cImZpbHRyby10aXR1bG8tc2FsZG9zXCI+QSBwYWdhcjwvcD5cclxuICAgICAgICAgIDxzdHJvbmcgY2xhc3M9XCJmaWx0cm8tcmVzdWx0YWRvLXNhbGRvc1wiPlIkIHt7IHZhbG9yQVBhZ2FyIHwgZm9ybWF0VmFsb3IgfX08L3N0cm9uZz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwicXVhZHJhbnRlLXNhbGRvcy1zYWxkby1maWx0cm9cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwic2Vzc2FvLXNhbGRvLWZpbHRyb1wiPlxyXG4gICAgICAgICAgPHAgY2xhc3M9XCJmaWx0cm8tdGl0dWxvLXNhbGRvc1wiPlBhZ288L3A+XHJcbiAgICAgICAgICA8c3Ryb25nIGNsYXNzPVwiZmlsdHJvLXJlc3VsdGFkby1zYWxkb3NcIj5SJCB7eyB2YWxvclBhZ28gfCBmb3JtYXRWYWxvciB9fTwvc3Ryb25nPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJxdWFkcmFudGUtc2FsZG9zLXNhbGRvLWZpbHRyb1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzZXNzYW8tc2FsZG8tZmlsdHJvXCI+XHJcbiAgICAgICAgICA8cCBjbGFzcz1cImZpbHRyby10aXR1bG8tc2FsZG9zXCI+QSByZWNlYmVyPC9wPlxyXG4gICAgICAgICAgPHN0cm9uZyBjbGFzcz1cImZpbHRyby1yZXN1bHRhZG8tc2FsZG9zXCI+UiQge3sgdmFsb3JBUmVjZWJlciB8IGZvcm1hdFZhbG9yIH19PC9zdHJvbmc+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cInF1YWRyYW50ZS1zYWxkb3Mtc2FsZG8tZmlsdHJvXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNlc3Nhby1zYWxkby1maWx0cm9cIj5cclxuICAgICAgICAgIDxwIGNsYXNzPVwiZmlsdHJvLXRpdHVsby1zYWxkb3NcIj5SZWNlYmlkbzwvcD5cclxuICAgICAgICAgIDxzdHJvbmcgY2xhc3M9XCJmaWx0cm8tcmVzdWx0YWRvLXNhbGRvc1wiPlIkIHt7IHZhbG9yUmVjZWJpZG8gfCBmb3JtYXRWYWxvciB9fTwvc3Ryb25nPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxhcHAtZG9udXQtY2hhcnQgY2xhc3M9XCJxdWFkcmFudGUtc2FsZG9zLWdyYWZpY29cIiBbZGVzcGVzYXNHcmFmaWNvRG9udXRdPVwiZGVzcGVzYXNHcmFmaWNvRG9udXRcIlxyXG4gICAgICAgIFtyZWNlaXRhc0dyYWZpY29Eb251dF09XCJyZWNlaXRhc0dyYWZpY29Eb251dFwiPlxyXG4gICAgICA8L2FwcC1kb251dC1jaGFydD5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L25nLXRlbXBsYXRlPiIsImltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBIZWFkZXJzIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnc3JjL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgY2F0Y2hFcnJvciB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnLi4vbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IFNhbGRvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJy4uL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTYWxkb1NlcnZpY2Uge1xyXG4gIHByaXZhdGUgYmFzZUFwaVVybCA9IGVudmlyb25tZW50LmJhc2VBcGlVcmw7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCwgcHJpdmF0ZSBsb2dpblNlcnZpY2U6IExvZ2luU2VydmljZSwgcHJpdmF0ZSBtZW5zYWdlbnNTZXJ2aWNlOiBNZW5zYWdlbnNTZXJ2aWNlKSB7IH1cclxuXHJcbiAgZ2V0U2FsZG9zKCk6IE9ic2VydmFibGU8U2FsZG8+e1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxTYWxkbz4oYCR7dGhpcy5iYXNlQXBpVXJsfWFwaS9zYWxkb3NpbnZlc3RpbWVudG9zL3VzdWFyaW8vJHtpZFVzdWFyaW99YCkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgc2FsZG9zOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBGb3JtQnVpbGRlciwgRm9ybUdyb3VwLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInOyAvLyBJbXBvcnRhbmRvIG8gUm91dGVyXHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7IC8vIEltcG9ydGFuZG8gbyBzZXJ2acOnbyBkZSBsb2dpblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2FwcC1sb2dpbicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vbG9naW4uY29tcG9uZW50Lmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4vbG9naW4uY29tcG9uZW50LmNzcyddLFxyXG4gICAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIExvZ2luQ29tcG9uZW50IHtcclxuICBsb2dpbkZvcm06IEZvcm1Hcm91cDtcclxuICBsb2dpbkVycm9yOiBzdHJpbmcgfCBudWxsID0gbnVsbDsgLy8gVmFyacOhdmVsIHBhcmEgYXJtYXplbmFyIGEgbWVuc2FnZW0gZGUgZXJyb1xyXG5cclxuICBpc0xvYWRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIGZiOiBGb3JtQnVpbGRlcixcclxuICAgIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsXHJcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyXHJcbiAgKSB7XHJcbiAgICB0aGlzLmxvZ2luRm9ybSA9IHRoaXMuZmIuZ3JvdXAoe1xyXG4gICAgICBlbWFpbDogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdG9ycy5lbWFpbF1dLFxyXG4gICAgICBzZW5oYTogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdG9ycy5taW5MZW5ndGgoNildXVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBvblN1Ym1pdCgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLmxvZ2luRm9ybS5pbnZhbGlkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmxvZ2luRXJyb3IgPSBudWxsOyAvLyBMaW1wYSBhIG1lbnNhZ2VtIGRlIGVycm8gYW50ZXMgZGUgdGVudGFyIG8gbG9naW5cclxuICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcclxuICAgIGNvbnN0IGxvZ2luRGF0YSA9IHRoaXMubG9naW5Gb3JtLnZhbHVlO1xyXG5cclxuICAgIHRoaXMubG9naW5TZXJ2aWNlLnBvc3RMb2dpbihsb2dpbkRhdGEpLnN1YnNjcmliZShcclxuICAgICAgKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLnRva2VuICYmIHJlc3BvbnNlLnJlZnJlc2hUb2tlbikge1xyXG4gICAgICAgICAgdGhpcy5sb2dpblNlcnZpY2Uuc3RvcmVUb2tlbnMoe1xyXG4gICAgICAgICAgICB0b2tlbjogcmVzcG9uc2UudG9rZW4sXHJcbiAgICAgICAgICAgIHJlZnJlc2hUb2tlbjogcmVzcG9uc2UucmVmcmVzaFRva2VuLFxyXG4gICAgICAgICAgICBpZFVzdWFyaW86IHJlc3BvbnNlLmlkVXN1YXJpb1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnLyddKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5sb2dpbkVycm9yID0gJ0UtbWFpbCBvdSBzZW5oYSBpbnbDoWxpZG9zLic7IC8vIE1lbnNhZ2VtIHBhcmEgZXJybyBpbmVzcGVyYWRvXHJcbiAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgdGhpcy5sb2dpbkVycm9yID0gJ0UtbWFpbCBvdSBzZW5oYSBpbnbDoWxpZG9zLic7IC8vIE1lbnNhZ2VtIGRlIGVycm8gZ2Vuw6lyaWNhXHJcbiAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIiwiPGRpdiBjbGFzcz1cImNvbnRhaW5lci1wcmluY2lwYWxcIj5cclxuICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWxvZ2luXCI+XHJcblxyXG5cclxuXHJcblxyXG4gICAgPGZvcm0gW2Zvcm1Hcm91cF09XCJsb2dpbkZvcm1cIiAobmdTdWJtaXQpPVwib25TdWJtaXQoKVwiPlxyXG4gICAgICBcclxuICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwiZW1haWxcIj5FLW1haWw8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dCBpZD1cImVtYWlsXCIgZm9ybUNvbnRyb2xOYW1lPVwiZW1haWxcIiB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIkRpZ2l0ZSBzZXUgZS1tYWlsXCIgLz5cclxuICAgICAgICA8c21hbGwgKm5nSWY9XCJsb2dpbkZvcm0uZ2V0KCdlbWFpbCcpPy5pbnZhbGlkICYmIGxvZ2luRm9ybS5nZXQoJ2VtYWlsJyk/LnRvdWNoZWRcIj5cclxuICAgICAgICAgIEUtbWFpbCBpbnbDoWxpZG9cclxuICAgICAgICA8L3NtYWxsPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cInBhc3N3b3JkXCI+U2VuaGE8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dCBpZD1cInBhc3N3b3JkXCIgZm9ybUNvbnRyb2xOYW1lPVwic2VuaGFcIiB0eXBlPVwicGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIkRpZ2l0ZSBzdWEgc2VuaGFcIiAvPlxyXG4gICAgICAgIDxzbWFsbCAqbmdJZj1cImxvZ2luRm9ybS5nZXQoJ3Bhc3N3b3JkJyk/LmludmFsaWQgJiYgbG9naW5Gb3JtLmdldCgncGFzc3dvcmQnKT8udG91Y2hlZFwiPlxyXG4gICAgICAgICAgQSBzZW5oYSBkZXZlIHRlciBwZWxvIG1lbm9zIDYgY2FyYWN0ZXJlc1xyXG4gICAgICAgIDwvc21hbGw+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHAgKm5nSWY9XCJsb2dpbkVycm9yXCIgY2xhc3M9XCJlcnJvci1tZXNzYWdlXCI+e3sgbG9naW5FcnJvciB9fTwvcD5cclxuXHJcbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgdy0xMDBcIiBbZGlzYWJsZWRdPVwiaXNMb2FkaW5nIHx8IGxvZ2luRm9ybS5pbnZhbGlkXCI+XHJcblxyXG4gICAgICAgIDxuZy1jb250YWluZXIgKm5nSWY9XCIhaXNMb2FkaW5nOyBlbHNlIGxvYWRpbmdcIj5cclxuICAgICAgICAgIEVudHJhclxyXG4gICAgICAgIDwvbmctY29udGFpbmVyPlxyXG5cclxuICAgICAgICA8bmctdGVtcGxhdGUgI2xvYWRpbmc+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzcz1cInNwaW5uZXJcIj48L3NwYW4+XHJcbiAgICAgICAgICBFbnRyYW5kby4uLlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDwvYnV0dG9uPlxyXG5cclxuXHJcblxyXG4gICAgPC9mb3JtPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvY2V0cm8tY3VzdG8vY2VudHJvLWN1c3RvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDZW50cm9DdXN0byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1jZW50cm8tY3VzdG8tZm9ybScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2NlbnRyby1jdXN0by1mb3JtLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vY2VudHJvLWN1c3RvLWZvcm0uY29tcG9uZW50LmNzcycsXHJcbiAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIENlbnRyb0N1c3RvRm9ybUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuICBAT3V0cHV0KCkgb25TdWJtaXQgPSBuZXcgRXZlbnRFbWl0dGVyPENlbnRyb0N1c3RvPigpO1xyXG4gIEBJbnB1dCgpIGJ0blRleHQhOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgY2VudHJvQ3VzdG9EYXRhOiBDZW50cm9DdXN0byB8IG51bGwgPSBudWxsO1xyXG4gIGNlbnRyb0N1c3RvRm9ybSE6IEZvcm1Hcm91cDtcclxuICBjZW50cm9DdXN0b3M6IENlbnRyb0N1c3RvW10gPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjZW50cm9DdXN0b1NlcnZpY2U6IENlbnRyb0N1c3RvU2VydmljZSApe31cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgIHRoaXMuY2VudHJvQ3VzdG9Gb3JtID0gbmV3IEZvcm1Hcm91cCh7XHJcbiAgICAgICAgaWQ6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmNlbnRyb0N1c3RvRGF0YSA/IHRoaXMuY2VudHJvQ3VzdG9EYXRhLmlkIDogJycpLFxyXG4gICAgICAgIGRlc2NyaUNDdXN0bzogbmV3IEZvcm1Db250cm9sKHRoaXMuY2VudHJvQ3VzdG9EYXRhID8gdGhpcy5jZW50cm9DdXN0b0RhdGEuZGVzY3JpQ0N1c3RvIDogJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXSksXHJcbiAgICAgICAgdmFsb3JMaW1pdGU6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmNlbnRyb0N1c3RvRGF0YSA/IHRoaXMuZm9ybWF0VmFsb3JJbmljaWFsKHRoaXMuY2VudHJvQ3VzdG9EYXRhLnZhbG9yTGltaXRlKSA6ICcnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICB9KTtcclxuICB9XHJcblxyXG4gIGdldCBkZXNjcmlDQ3VzdG8oKXtcclxuICAgIHJldHVybiB0aGlzLmNlbnRyb0N1c3RvRm9ybS5nZXQoJ2Rlc2NyaUNDdXN0bycpITtcclxuICB9XHJcblxyXG4gICBnZXQgdmFsb3JMaW1pdGUoKXtcclxuICAgIHJldHVybiB0aGlzLmNlbnRyb0N1c3RvRm9ybS5nZXQoJ3ZhbG9yTGltaXRlJykhO1xyXG4gIH1cclxuXHJcbiAgc3VibWl0KCl7XHJcbiAgICBpZih0aGlzLmNlbnRyb0N1c3RvRm9ybS5pbnZhbGlkKXtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCB2YWxvckZvcm1hdGFkbyA9IFN0cmluZyh0aGlzLnZhbG9yTGltaXRlLnZhbHVlKVxyXG4gICAgICAucmVwbGFjZSgvXFwuL2csICcnKSAvLyBSZW1vdmUgcG9udG9zIGRvcyBtaWxoYXJlc1xyXG4gICAgICAucmVwbGFjZSgnLCcsICcuJyk7IC8vIFRyb2NhIHbDrXJndWxhIHBvciBwb250byBwYXJhIGRlY2ltYWxcclxuICBcclxuICAgIGxldCB2YWxvckxpbWl0ZUZvcm1hdGFkbyA9IHtcclxuICAgICAgLi4udGhpcy5jZW50cm9DdXN0b0Zvcm0udmFsdWUsXHJcbiAgICAgIHZhbG9yTGltaXRlOiB2YWxvckZvcm1hdGFkb1xyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLm9uU3VibWl0LmVtaXQodmFsb3JMaW1pdGVGb3JtYXRhZG8pO1xyXG4gIH1cclxuXHJcbiAgLy8gRm9ybWF0YSBvIHZhbG9yIGluaWNpYWwgcXVhbmRvIGNhcnJlZ2FkbyBkYSBBUElcclxuICBmb3JtYXRWYWxvckluaWNpYWwodmFsb3JMaW1pdGU6IG51bWJlciB8IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICBsZXQgdmFsb3JTdHIgPSB2YWxvckxpbWl0ZS50b1N0cmluZygpLnJlcGxhY2UoJy4nLCAnLCcpOyAvLyBUcm9jYSBwb250byBwb3IgdsOtcmd1bGFcclxuICAgIGxldCBwYXJ0ZXMgPSB2YWxvclN0ci5zcGxpdCgnLCcpO1xyXG4gICAgbGV0IGludGVpcm8gPSBwYXJ0ZXNbMF0ucmVwbGFjZSgvXFxCKD89KFxcZHszfSkrKD8hXFxkKSkvZywgJy4nKTsgLy8gQWRpY2lvbmEgc2VwYXJhZG9yIGRlIG1pbGhhclxyXG4gICAgbGV0IGRlY2ltYWwgPSBwYXJ0ZXNbMV0gPyBwYXJ0ZXNbMV0ucGFkRW5kKDIsICcwJykgOiAnMDAnOyAvLyBHYXJhbnRlIGRvaXMgZMOtZ2l0b3Mgbm9zIGNlbnRhdm9zXHJcbiAgICByZXR1cm4gYCR7aW50ZWlyb30sJHtkZWNpbWFsfWA7XHJcbiAgfVxyXG5cclxuICBmb3JtYXRWYWxvcigpOiB2b2lkIHtcclxuICAgIGxldCB2YWxvckxpbWl0ZSA9IHRoaXMudmFsb3JMaW1pdGUudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKTsgLy8gUmVtb3ZlIHR1ZG8gcXVlIG7Do28gZm9yIG7Dum1lcm9cclxuICBcclxuICAgIGlmICh2YWxvckxpbWl0ZS5sZW5ndGggPT09IDApIHtcclxuICAgICAgdGhpcy5jZW50cm9DdXN0b0Zvcm0uY29udHJvbHNbJ3ZhbG9yTGltaXRlJ10uc2V0VmFsdWUoJycsIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLy8gUmVtb3ZlIHplcm9zIMOgIGVzcXVlcmRhXHJcbiAgICB2YWxvckxpbWl0ZSA9IHZhbG9yTGltaXRlLnJlcGxhY2UoL14wKyg/ISQpLywgJycpO1xyXG4gIFxyXG4gICAgLy8gU2UgdGl2ZXIgbWVub3MgZGUgMyBkw61naXRvcywgYXBlbmFzIGFkaWNpb25hIGEgdsOtcmd1bGEgY29ycmV0YW1lbnRlXHJcbiAgICBpZiAodmFsb3JMaW1pdGUubGVuZ3RoIDw9IDIpIHtcclxuICAgICAgdGhpcy5jZW50cm9DdXN0b0Zvcm0uY29udHJvbHNbJ3ZhbG9yTGltaXRlJ10uc2V0VmFsdWUoYDAsJHt2YWxvckxpbWl0ZS5wYWRTdGFydCgyLCAnMCcpfWAsIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLy8gU2VwYXJhIG9zIGNlbnRhdm9zICjDumx0aW1vcyAyIGTDrWdpdG9zKVxyXG4gICAgbGV0IGludGVpcm8gPSB2YWxvckxpbWl0ZS5zbGljZSgwLCAtMik7XHJcbiAgICBsZXQgZGVjaW1hbCA9IHZhbG9yTGltaXRlLnNsaWNlKC0yKTtcclxuICBcclxuICAgIC8vIEFwbGljYSBzZXBhcmFkb3JlcyBkZSBtaWxoYXJcclxuICAgIGludGVpcm8gPSBpbnRlaXJvLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcuJyk7XHJcbiAgXHJcbiAgICAvLyBNb250YSBvIHZhbG9yIGZpbmFsXHJcbiAgICBsZXQgdmFsb3JGb3JtYXRhZG8gPSBgJHtpbnRlaXJvfSwke2RlY2ltYWx9YDtcclxuICAgIGNvbnNvbGUubG9nKHZhbG9yRm9ybWF0YWRvKVxyXG4gICAgLy8gQXR1YWxpemEgbyBjYW1wbyBzZW0gZGlzcGFyYXIgZXZlbnRvcyBpbmZpbml0b3NcclxuICAgIHRoaXMuY2VudHJvQ3VzdG9Gb3JtLmNvbnRyb2xzWyd2YWxvckxpbWl0ZSddLnNldFZhbHVlKHZhbG9yRm9ybWF0YWRvLCB7IGVtaXRFdmVudDogZmFsc2UgfSk7XHJcbiAgfVxyXG59XHJcbiIsIjxmb3JtIChuZ1N1Ym1pdCk9XCJzdWJtaXQoKVwiIFtmb3JtR3JvdXBdPVwiY2VudHJvQ3VzdG9Gb3JtXCIgI2Zvcm1EaXI9XCJuZ0Zvcm1cIj5cclxuICAgIFxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cImhpZGRlblwiIGZvcm1Db250cm9sTmFtZT1cImlkXCIgLz5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cImRlc2NyaXB0aW9uXCI+RGVzY3Jpw6fDo286PC9sYWJlbD5cclxuICAgICAgICA8dGV4dGFyZWEgcGxhY2Vob2xkZXI9XCJEZXNjcmnDp8OjbyBkbyBDZW50cm8gZGUgQ3VzdG9cIiBmb3JtQ29udHJvbE5hbWU9XCJkZXNjcmlDQ3VzdG9cIiByZXF1aXJlZD48L3RleHRhcmVhPlxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJkZXNjcmlDQ3VzdG8uaW52YWxpZCAmJiBmb3JtRGlyLnN1Ym1pdHRlZFwiIGNsYXNzPVwidmFsaWRhdGlvbi1lcnJvclwiPlxyXG4gICAgICAgICAgICA8cCAqbmdJZj1cImRlc2NyaUNDdXN0by5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPkEgZGVzY3Jpw6fDo28gw6kgb2JyaWdhdMOzcmlhLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgXHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxvclwiPlZhbG9yIExpbWl0ZTo8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlucHV0bW9kZT1cIm51bWVyaWNcIiBwbGFjZWhvbGRlcj1cIkNvbG9xdWUgbyB2YWxvciBsaW1pdGVcIiBmb3JtQ29udHJvbE5hbWU9XCJ2YWxvckxpbWl0ZVwiIHJlcXVpcmVkIChpbnB1dCk9XCJmb3JtYXRWYWxvcigpXCI+XHJcbiAgICAgICAgPGRpdiAqbmdJZj1cInZhbG9yTGltaXRlLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJ2YWxvckxpbWl0ZS5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPk8gdmFsb3IgbGltaXRlIMOpIG9icmlnYXTDs3Jpby48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIHZhbHVlPVwie3tidG5UZXh0fX1cIj4gICAgXHJcbjwvZm9ybT4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgQ2VudHJvQ3VzdG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9jZXRyby1jdXN0by9jZW50cm8tY3VzdG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWVkaXQtY2VudHJvLWN1c3RvJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZWRpdC1jZW50cm8tY3VzdG8uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9lZGl0LWNlbnRyby1jdXN0by5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRWRpdENlbnRyb0N1c3RvQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xyXG5cclxuICBjZW50cm9DdXN0byE6IENlbnRyb0N1c3RvO1xyXG4gIGJ0blRleHQ6IHN0cmluZyA9ICdDb25maXJtYXInO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UsIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkID0gTnVtYmVyKHRoaXMucm91dGUuc25hcHNob3QucGFyYW1NYXAuZ2V0KFwiaWRcIikpO1xyXG5cclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmdldElkQ2VudHJvQ3VzdG9zKGlkKS5zdWJzY3JpYmUoKGl0ZW0pID0+IHtcclxuICAgICAgdGhpcy5jZW50cm9DdXN0byA9IGl0ZW07XHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZWRpdEhlbmRsZXIoY2VudHJvQ3VzdG9EYXRhOiBDZW50cm9DdXN0byl7ICAgIFxyXG4gICAgY29uc3QgaWQgPSB0aGlzLmNlbnRyb0N1c3RvLmlkO1xyXG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2Rlc2NyaUNDdXN0bycsIGNlbnRyb0N1c3RvRGF0YS5kZXNjcmlDQ3VzdG8gPz8gJycpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCd2YWxvckxpbWl0ZScsIGNlbnRyb0N1c3RvRGF0YS52YWxvckxpbWl0ZS50b1N0cmluZygpKTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLmNlbnRyb0N1c3RvU2VydmljZS5wdXRDZW50cm9DdXN0b3MoaWQhLCBmb3JtRGF0YSkuc3Vic2NyaWJlKChyZXN1bHQ6IGFueSkgPT4ge1xyXG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9jZW50cm8tY3VzdG8nXSk7XHJcbiAgICB9LFxyXG4gICAgICAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9cIik7XHJcbiAgICAgIH0pXHJcbiAgfVxyXG59IiwiPGRpdiAqbmdJZj1cImNlbnRyb0N1c3RvXCI+XHJcbiAgICA8aDI+XHJcbiAgICAgICAgPHNwYW4+RWRpdGFyPC9zcGFuPiBDZW50cm8gZGUgQ3VzdG9cclxuICAgIDwvaDI+XHJcbiAgICA8YXBwLWNlbnRyby1jdXN0by1mb3JtIChvblN1Ym1pdCk9XCJlZGl0SGVuZGxlcigkZXZlbnQpXCIgW2NlbnRyb0N1c3RvRGF0YV09XCJjZW50cm9DdXN0b1wiIFtidG5UZXh0XT1cImJ0blRleHRcIj48L2FwcC1jZW50cm8tY3VzdG8tZm9ybT5cclxuPC9kaXY+IiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IGZpcnN0VmFsdWVGcm9tIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvY2V0cm8tY3VzdG8vY2VudHJvLWN1c3RvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbGFuY2FtZW50by9sYW5jYW1lbnRvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBNZW5zYWdlbnNTZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9tZW5zYWdlbnMvbWVuc2FnZW5zLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDZW50cm9DdXN0byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1leGNsdWlyLWNlbnRyby1jdXN0bycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2V4Y2x1aXItY2VudHJvLWN1c3RvLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vZXhjbHVpci1jZW50cm8tY3VzdG8uY29tcG9uZW50LmNzcycsXHJcbiAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIEV4Y2x1aXJDZW50cm9DdXN0b0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNlbnRyb0N1c3RvITogQ2VudHJvQ3VzdG87XHJcbiAgYnRuVGV4dDogc3RyaW5nID0gJ1JlbW92ZXInO1xyXG4gIHF1YW50aWRhZGU6IE51bWJlciA9IDA7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UsXHJcbiAgICBwcml2YXRlIGxhbmNhbWVudG9TZXJ2aWNlOiBMYW5jYW1lbnRvU2VydmljZSxcclxuICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxyXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcclxuICAgIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsXHJcbiAgICBwcml2YXRlIG1lbnNhZ2Vuc1NlcnZpY2U6IE1lbnNhZ2Vuc1NlcnZpY2UpIHtcclxuXHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkID0gTnVtYmVyKHRoaXMucm91dGUuc25hcHNob3QucGFyYW1NYXAuZ2V0KFwiaWRcIikpO1xyXG5cclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmdldElkQ2VudHJvQ3VzdG9zKGlkKS5zdWJzY3JpYmUoKGl0ZW0pID0+IHtcclxuICAgICAgdGhpcy5jZW50cm9DdXN0byA9IGl0ZW07XHJcbiAgICB9KVxyXG4gIH1cclxuXHJcblxyXG4gIGFzeW5jIGV4Y2x1aXJIZW5kbGVyKGNlbnRyb0N1c3RvRGF0YTogQ2VudHJvQ3VzdG8pIHtcclxuICAgIGNvbnN0IGlkQ2VudHJvQ3VzdG8gPSB0aGlzLmNlbnRyb0N1c3RvLmlkITtcclxuICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKT8udG9TdHJpbmcoKTtcclxuXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2Rlc2NyaUNDdXN0bycsIGNlbnRyb0N1c3RvRGF0YS5kZXNjcmlDQ3VzdG8gPz8gJycpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCd2YWxvckxpbWl0ZScsIGNlbnRyb0N1c3RvRGF0YS52YWxvckxpbWl0ZS50b1N0cmluZygpKTtcclxuXHJcbiAgICBjb25zdCBpdGVtID0gYXdhaXQgZmlyc3RWYWx1ZUZyb20odGhpcy5sYW5jYW1lbnRvU2VydmljZS5nZXRFeGlzdGVDZW50cm9DdXN0byhpZFVzdWFyaW8gPz8gJycsIGlkQ2VudHJvQ3VzdG8pKTtcclxuICAgIHRoaXMucXVhbnRpZGFkZSA9IGl0ZW0ucXVhbnRpZGFkZTtcclxuXHJcbiAgICBpZiAodGhpcy5xdWFudGlkYWRlLnZhbHVlT2YoKSA9PSAwKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmV4Y2x1aXJDZW50cm9DdXN0byhpZENlbnRyb0N1c3RvKS5zdWJzY3JpYmUoKHJlc3VsdDogYW55KSA9PiB7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvY2VudHJvLWN1c3RvJ10pO1xyXG4gICAgICB9LFxyXG4gICAgICAgIChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvXCIpO1xyXG4gICAgICAgIH0pXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ3dhcm5pbmcnLFxyXG4gICAgICAgICdBdGVuw6fDo28nLFxyXG4gICAgICAgIGBFc3NlIGNlbnRybyBkZSBjdXN0byBuw6NvIHBvZGUgc2VyIGV4Y2x1w61kbywgcG9pcyAke3RoaXMucXVhbnRpZGFkZSA9PT0gMSA/ICdleGlzdGUgJyA6ICdleGlzdGVtICd9ICR7dGhpcy5xdWFudGlkYWRlfSAke3RoaXMucXVhbnRpZGFkZSA9PT0gMSA/ICdsYW7Dp2FtZW50byAnIDogJ2xhbsOnYW1lbnRvcyAnfSAke3RoaXMucXVhbnRpZGFkZSA9PT0gMSA/ICdhdHJpYnXDrWRvJyA6ICdhdHJpYnXDrWRvcyd9IGEgZWxlLmAsXHJcbiAgICAgICAgdW5kZWZpbmVkKTtcclxuICAgIH1cclxuICB9XHJcblxyXG59IiwiPGRpdiAqbmdJZj1cImNlbnRyb0N1c3RvXCI+XHJcbiAgICA8aDI+XHJcbiAgICAgICAgRXhjbHVpciA8c3Bhbj5DZW50cm8gZGUgQ3VzdG88L3NwYW4+XHJcbiAgICA8L2gyPlxyXG4gICAgPGFwcC1jZW50cm8tY3VzdG8tZm9ybSAob25TdWJtaXQpPVwiZXhjbHVpckhlbmRsZXIoJGV2ZW50KVwiIFtjZW50cm9DdXN0b0RhdGFdPVwiY2VudHJvQ3VzdG9cIiBbYnRuVGV4dF09XCJidG5UZXh0XCI+PC9hcHAtY2VudHJvLWN1c3RvLWZvcm0+XHJcbjwvZGl2PiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvY2V0cm8tY3VzdG8vY2VudHJvLWN1c3RvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDZW50cm9DdXN0byB9IGZyb20gJ3NyYy90eXBlcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1ub3ZvLWNlbnRyby1jdXN0bycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL25vdm8tY2VudHJvLWN1c3RvLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vbm92by1jZW50cm8tY3VzdG8uY29tcG9uZW50LmNzcycsXHJcbiAgc3RhbmRhbG9uZTogZmFsc2VcclxufSlcclxuZXhwb3J0IGNsYXNzIE5vdm9DZW50cm9DdXN0b0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHtcclxuICBidG5UZXh0OiBzdHJpbmcgPSBcIlJlZ2lzdHJhclwiO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNlbnRyb0N1c3RvU2VydmljZTogQ2VudHJvQ3VzdG9TZXJ2aWNlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKXt9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgXHJcbiAgfVxyXG5cclxuICBhc3luYyBjcmVhdGVIYW5kbGVyKGNlbnRyb0N1c3RvOiBDZW50cm9DdXN0byl7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcblxyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkZXNjcmlDQ3VzdG8nLCBjZW50cm9DdXN0by5kZXNjcmlDQ3VzdG8gPz8gJycpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCd2YWxvckxpbWl0ZScsIGNlbnRyb0N1c3RvLnZhbG9yTGltaXRlLnRvU3RyaW5nKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdpZFVzdWFyaW8nLCBpZFVzdWFyaW8gPz8gJycpO1xyXG4gICAgXHJcbiAgICB0aGlzLmNlbnRyb0N1c3RvU2VydmljZS5wb3N0Q2VudHJvQ3VzdG8oZm9ybURhdGEpLnN1YnNjcmliZSgocmVzdWx0OiBhbnkpID0+IHtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvY2VudHJvLWN1c3RvJ10pO1xyXG4gICAgfSxcclxuICAgICAgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvXCIpO1xyXG4gICAgICB9KVxyXG4gIH1cclxufVxyXG4iLCI8aDI+UmVnaXN0cmUgbyBzZXUgPHNwYW4+Q2VudHJvIGRlIEN1c3RvPC9zcGFuPjwvaDI+XHJcbjxhcHAtY2VudHJvLWN1c3RvLWZvcm0gW2J0blRleHRdPVwiYnRuVGV4dFwiIChvblN1Ym1pdCk9XCJjcmVhdGVIYW5kbGVyKCRldmVudClcIj48L2FwcC1jZW50cm8tY3VzdG8tZm9ybT4iLCJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2VudHJvQ3VzdG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9jZXRyby1jdXN0by9jZW50cm8tY3VzdG8uc2VydmljZSc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLXRhYmVsYS1jZW50cm8tY3VzdG8nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi90YWJlbGEtY2VudHJvLWN1c3RvLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vdGFiZWxhLWNlbnRyby1jdXN0by5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgVGFiZWxhQ2VudHJvQ3VzdG9Db21wb25lbnQge1xyXG4gIGNlbnRyb0N1c3RvczogQ2VudHJvQ3VzdG9bXSA9IFtdO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UpIHtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgdGhpcy5jZW50cm9DdXN0b1NlcnZpY2UuZ2V0QWxsQ2VudHJvQ3VzdG9zKCkuc3Vic2NyaWJlKChjZW50cm9DdXN0b3MpID0+ICh0aGlzLmNlbnRyb0N1c3RvcyA9IGNlbnRyb0N1c3RvcykpO1xyXG4gIH1cclxuXHJcbiAgcmVtb3ZlckNlbnRyb0N1c3RvKGlkOiBOdW1iZXIpOiB2b2lkIHtcclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmV4Y2x1aXJDZW50cm9DdXN0byhpZCkuc3Vic2NyaWJlKCk7XHJcbiAgfVxyXG59XHJcbiIsIjxkaXYgY2xhc3M9XCJjb250YWluZXJcIj5cclxuICAgIDxoMiBjbGFzcz1cInRleHQtY2VudGVyXCI+Q2VudHJvcyBkZSBDdXN0bzwvaDI+XHJcbiAgICA8YnIgLz5cclxuXHJcbiAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJjZW50cm9DdXN0b3MubGVuZ3RoID4gMDsgZWxzZSBub0NlbnRyb0N1c3Rvc1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsZSB0YWJsZS1zdHJpcGVkIHRhYmxlLWJvcmRlcmVkIGFsaWduLW1pZGRsZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzcz1cInRhYmxlLWRhcmtcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5JZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5EZXNjcmnDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5WYWxvciBMaW1pdGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPkHDp8O1ZXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ciAqbmdGb3I9XCJsZXQgY2VudHJvQ3VzdG8gb2YgY2VudHJvQ3VzdG9zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBjZW50cm9DdXN0by5pZCB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBjZW50cm9DdXN0by5kZXNjcmlDQ3VzdG8gfX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3sgY2VudHJvQ3VzdG8udmFsb3JMaW1pdGUgfCBmb3JtYXRWYWxvciB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG4tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gW3JvdXRlckxpbmtdPVwiWycvY2VudHJvLWN1c3RvL2VkaXQnLCBjZW50cm9DdXN0by5pZF1cIiB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5IGJ0bi1zbSBib3Rhby1lZGl0YXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImJpIGJpLXBlbmNpbC1zcXVhcmVcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gW3JvdXRlckxpbmtdPVwiWycvY2VudHJvLWN1c3RvL2V4Y2x1aXInLCBjZW50cm9DdXN0by5pZF1cIiB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1kYW5nZXIgYnRuLXNtIGJvdGFvLXJlbW92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImJpIGJpLXRyYXNoXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8bmctdGVtcGxhdGUgI25vQ2VudHJvQ3VzdG9zPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPk7Do28gZXhpc3RlbSByZWdpc3Ryb3MgY2FkYXN0cmFkb3Mg8J+YojwvaDE+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuXHJcbiAgICAgICAgPGJ1dHRvbiBtYXQtZmFiIGNvbG9yPVwicHJpbWFyeVwiIGNsYXNzPVwiZmFiXCIgW3JvdXRlckxpbmtdPVwiWycvY2VudHJvLWN1c3RvL25vdm8nXVwiPlxyXG4gICAgICAgICAgICA8bWF0LWljb24+YWRkPC9tYXQtaWNvbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvY2V0cm8tY3VzdG8vY2VudHJvLWN1c3RvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvRml4bywgQ2VudHJvQ3VzdG8gfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtbGFuY2FtZW50by1maXhvLWZvcm0nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9sYW5jYW1lbnRvLWZpeG8tZm9ybS5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL2xhbmNhbWVudG8tZml4by1mb3JtLmNvbXBvbmVudC5jc3MnLFxyXG4gIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBMYW5jYW1lbnRvRml4b0Zvcm1Db21wb25lbnQgIGltcGxlbWVudHMgT25Jbml0IHtcclxuICBAT3V0cHV0KCkgb25TdWJtaXQgPSBuZXcgRXZlbnRFbWl0dGVyPExhbmNhbWVudG9GaXhvPigpO1xyXG4gIEBJbnB1dCgpIGJ0blRleHQhOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgbGFuY2FtZW50b0ZpeG9EYXRhOiBMYW5jYW1lbnRvRml4byB8IG51bGwgPSBudWxsO1xyXG4gIGxhbmNhbWVudG9GaXhvRm9ybSE6IEZvcm1Hcm91cDtcclxuICBjZW50cm9DdXN0b3M6IENlbnRyb0N1c3RvW10gPSBbXTtcclxuICBkaWFzOiBudW1iZXJbXSA9IEFycmF5LmZyb20oeyBsZW5ndGg6IDMxIH0sIChfLCBpKSA9PiBpICsgMSk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UpIHsgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtID0gbmV3IEZvcm1Hcm91cCh7XHJcbiAgICAgIGlkOiBuZXcgRm9ybUNvbnRyb2wodGhpcy5sYW5jYW1lbnRvRml4b0RhdGEgPyB0aGlzLmxhbmNhbWVudG9GaXhvRGF0YS5pZCA6ICcnKSxcclxuICAgICAgZGlhTWVzOiBuZXcgRm9ybUNvbnRyb2wodGhpcy5sYW5jYW1lbnRvRml4b0RhdGE/LmRpYU1lcywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdKSxcclxuICAgICAgdmFsb3I6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9GaXhvRGF0YSA/IHRoaXMuZm9ybWF0VmFsb3JJbmljaWFsKHRoaXMubGFuY2FtZW50b0ZpeG9EYXRhLnZhbG9yKSA6ICcnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICBkZXNjcmljYW86IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9GaXhvRGF0YSA/IHRoaXMubGFuY2FtZW50b0ZpeG9EYXRhLmRlc2NyaWNhbyA6ICcnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICBzdGF0dXM6IG5ldyBGb3JtQ29udHJvbCh0aGlzLmxhbmNhbWVudG9GaXhvRGF0YSA/IHRoaXMubGFuY2FtZW50b0ZpeG9EYXRhLnN0YXR1cyA6ICcnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF0pLFxyXG4gICAgICBpZENDdXN0bzogbmV3IEZvcm1Db250cm9sKHRoaXMubGFuY2FtZW50b0ZpeG9EYXRhID8gdGhpcy5sYW5jYW1lbnRvRml4b0RhdGEuaWRDQ3VzdG8gOiAnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdKSxcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmdldEFsbENlbnRyb0N1c3RvcygpLnN1YnNjcmliZSgoY2VudHJvQ3VzdG9zKSA9PiAodGhpcy5jZW50cm9DdXN0b3MgPSBjZW50cm9DdXN0b3MpKTtcclxuICB9XHJcblxyXG4gIC8vIEZvcm1hdGEgbyB2YWxvciBpbmljaWFsIHF1YW5kbyBjYXJyZWdhZG8gZGEgQVBJXHJcbiAgZm9ybWF0VmFsb3JJbmljaWFsKHZhbG9yOiBudW1iZXIgfCBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgbGV0IHZhbG9yU3RyID0gdmFsb3IudG9TdHJpbmcoKS5yZXBsYWNlKCcuJywgJywnKTsgLy8gVHJvY2EgcG9udG8gcG9yIHbDrXJndWxhXHJcbiAgICBsZXQgcGFydGVzID0gdmFsb3JTdHIuc3BsaXQoJywnKTtcclxuICAgIGxldCBpbnRlaXJvID0gcGFydGVzWzBdLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcuJyk7IC8vIEFkaWNpb25hIHNlcGFyYWRvciBkZSBtaWxoYXJcclxuICAgIGxldCBkZWNpbWFsID0gcGFydGVzWzFdID8gcGFydGVzWzFdLnBhZEVuZCgyLCAnMCcpIDogJzAwJzsgLy8gR2FyYW50ZSBkb2lzIGTDrWdpdG9zIG5vcyBjZW50YXZvc1xyXG4gICAgcmV0dXJuIGAke2ludGVpcm99LCR7ZGVjaW1hbH1gO1xyXG4gIH1cclxuXHJcbiAgZm9ybWF0VmFsb3IoKTogdm9pZCB7XHJcbiAgICBsZXQgdmFsb3IgPSB0aGlzLnZhbG9yLnZhbHVlLnJlcGxhY2UoL1xcRC9nLCAnJyk7IC8vIFJlbW92ZSB0dWRvIHF1ZSBuw6NvIGZvciBuw7ptZXJvXHJcbiAgXHJcbiAgICBpZiAodmFsb3IubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmNvbnRyb2xzWyd2YWxvciddLnNldFZhbHVlKCcnLCB7IGVtaXRFdmVudDogZmFsc2UgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICBcclxuICAgIC8vIFJlbW92ZSB6ZXJvcyDDoCBlc3F1ZXJkYVxyXG4gICAgdmFsb3IgPSB2YWxvci5yZXBsYWNlKC9eMCsoPyEkKS8sICcnKTtcclxuICBcclxuICAgIC8vIFNlIHRpdmVyIG1lbm9zIGRlIDMgZMOtZ2l0b3MsIGFwZW5hcyBhZGljaW9uYSBhIHbDrXJndWxhIGNvcnJldGFtZW50ZVxyXG4gICAgaWYgKHZhbG9yLmxlbmd0aCA8PSAyKSB7XHJcbiAgICAgIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmNvbnRyb2xzWyd2YWxvciddLnNldFZhbHVlKGAwLCR7dmFsb3IucGFkU3RhcnQoMiwgJzAnKX1gLCB7IGVtaXRFdmVudDogZmFsc2UgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICBcclxuICAgIC8vIFNlcGFyYSBvcyBjZW50YXZvcyAow7psdGltb3MgMiBkw61naXRvcylcclxuICAgIGxldCBpbnRlaXJvID0gdmFsb3Iuc2xpY2UoMCwgLTIpO1xyXG4gICAgbGV0IGRlY2ltYWwgPSB2YWxvci5zbGljZSgtMik7XHJcbiAgXHJcbiAgICAvLyBBcGxpY2Egc2VwYXJhZG9yZXMgZGUgbWlsaGFyXHJcbiAgICBpbnRlaXJvID0gaW50ZWlyby5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCAnLicpO1xyXG4gIFxyXG4gICAgLy8gTW9udGEgbyB2YWxvciBmaW5hbFxyXG4gICAgbGV0IHZhbG9yRm9ybWF0YWRvID0gYCR7aW50ZWlyb30sJHtkZWNpbWFsfWA7XHJcbiAgXHJcbiAgICAvLyBBdHVhbGl6YSBvIGNhbXBvIHNlbSBkaXNwYXJhciBldmVudG9zIGluZmluaXRvc1xyXG4gICAgdGhpcy5sYW5jYW1lbnRvRml4b0Zvcm0uY29udHJvbHNbJ3ZhbG9yJ10uc2V0VmFsdWUodmFsb3JGb3JtYXRhZG8sIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcclxuICB9XHJcblxyXG4gIGdldCBkaWFNZXMoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5sYW5jYW1lbnRvRml4b0Zvcm0uZ2V0KCdkaWFNZXMnKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgdmFsb3IoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5sYW5jYW1lbnRvRml4b0Zvcm0uZ2V0KCd2YWxvcicpITtcclxuICB9XHJcblxyXG4gIGdldCBkZXNjcmljYW8oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5sYW5jYW1lbnRvRml4b0Zvcm0uZ2V0KCdkZXNjcmljYW8nKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgc3RhdHVzKCkge1xyXG4gICAgcmV0dXJuIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmdldCgnc3RhdHVzJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGlkQ0N1c3RvKCkge1xyXG4gICAgcmV0dXJuIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmdldCgnaWRDQ3VzdG8nKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgaWRVc3VhcmlvKCkge1xyXG4gICAgcmV0dXJuIHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmdldCgnaWRVc3VhcmlvJykhO1xyXG4gIH1cclxuXHJcbiAgc3VibWl0KCk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLmludmFsaWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgbGV0IHZhbG9yRm9ybWF0YWRvID0gU3RyaW5nKHRoaXMudmFsb3IudmFsdWUpXHJcbiAgICAgIC5yZXBsYWNlKC9cXC4vZywgJycpIC8vIFJlbW92ZSBwb250b3MgZG9zIG1pbGhhcmVzXHJcbiAgICAgIC5yZXBsYWNlKCcsJywgJy4nKTsgLy8gVHJvY2EgdsOtcmd1bGEgcG9yIHBvbnRvIHBhcmEgZGVjaW1hbFxyXG4gIFxyXG4gICAgbGV0IGxhbmNhbWVudG9Gb3JtYXRhZG8gPSB7XHJcbiAgICAgIC4uLnRoaXMubGFuY2FtZW50b0ZpeG9Gb3JtLnZhbHVlLFxyXG4gICAgICB2YWxvcjogdmFsb3JGb3JtYXRhZG9cclxuICAgIH07XHJcbiAgXHJcbiAgICB0aGlzLm9uU3VibWl0LmVtaXQobGFuY2FtZW50b0Zvcm1hdGFkbyk7XHJcbiAgfVxyXG4gIFxyXG59IiwiPGZvcm0gKG5nU3VibWl0KT1cInN1Ym1pdCgpXCIgW2Zvcm1Hcm91cF09XCJsYW5jYW1lbnRvRml4b0Zvcm1cIiAjZm9ybURpcj1cIm5nRm9ybVwiPlxyXG4gICAgXHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgZm9ybUNvbnRyb2xOYW1lPVwiaWRcIiAvPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJkaWFcIj5EaWEgZG8gTcOqczo8L2xhYmVsPlxyXG4gICAgICAgIDxzZWxlY3QgaWQ9XCJkaWFcIiBmb3JtQ29udHJvbE5hbWU9XCJkaWFNZXNcIiByZXF1aXJlZD5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkIHNlbGVjdGVkPlNlbGVjaW9uZSBvIGRpYTwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8b3B0aW9uICpuZ0Zvcj1cImxldCBkaWEgb2YgZGlhc1wiIFt2YWx1ZV09XCJkaWFcIj57eyBkaWEgfX08L29wdGlvbj5cclxuICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICA8ZGl2ICpuZ0lmPVwiZGlhTWVzLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJkaWFNZXMuZXJyb3JzPy5bJ3JlcXVpcmVkJ11cIj5PIGRpYSDDqSBvYnJpZ2F0w7NyaW8uPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICBcclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cInZhbG9yXCI+VmFsb3I6PC9sYWJlbD5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpbnB1dG1vZGU9XCJudW1lcmljXCIgcGxhY2Vob2xkZXI9XCJDb2xvcXVlIG8gdmFsb3IgZG8gTGFuw6dhbWVudG9cIiBmb3JtQ29udHJvbE5hbWU9XCJ2YWxvclwiIHJlcXVpcmVkIChpbnB1dCk9XCJmb3JtYXRWYWxvcigpXCI+XHJcbiAgICAgICAgPGRpdiAqbmdJZj1cInZhbG9yLmludmFsaWQgJiYgZm9ybURpci5zdWJtaXR0ZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJ2YWxvci5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPk8gdmFsb3Igw6kgb2JyaWdhdMOzcmlhLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwiZGVzY3JpcHRpb25cIj5EZXNjcmnDp8Ojbzo8L2xhYmVsPlxyXG4gICAgICAgIDx0ZXh0YXJlYSBwbGFjZWhvbGRlcj1cIkRlc2NyacOnw6NvIGRvIExhbmNhbWVudG9cIiBmb3JtQ29udHJvbE5hbWU9XCJkZXNjcmljYW9cIiByZXF1aXJlZD48L3RleHRhcmVhPlxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJkZXNjcmljYW8uaW52YWxpZCAmJiBmb3JtRGlyLnN1Ym1pdHRlZFwiIGNsYXNzPVwidmFsaWRhdGlvbi1lcnJvclwiPlxyXG4gICAgICAgICAgICA8cCAqbmdJZj1cImRlc2NyaWNhby5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPkEgZGVzY3Jpw6fDo28gw6kgb2JyaWdhdMOzcmlhLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PiAgIFxyXG4gICAgXHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJzdGF0dXNcIj5TdGF0dXM6PC9sYWJlbD5cclxuICAgICAgICA8c2VsZWN0IGZvcm1Db250cm9sTmFtZT1cInN0YXR1c1wiIHJlcXVpcmVkPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQSBSZWNlYmVyXCI+QSBSZWNlYmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBIFBhZ2FyXCI+QSBQYWdhcjwvb3B0aW9uPlxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwic3RhdHVzXCI+Q2VudHJvIEN1c3RvOjwvbGFiZWw+XHJcbiAgICAgICAgPHNlbGVjdCBmb3JtQ29udHJvbE5hbWU9XCJpZENDdXN0b1wiIHJlcXVpcmVkPlxyXG4gICAgICAgICAgICA8b3B0aW9uICpuZ0Zvcj1cImxldCBjZW50cm9DdXN0byBvZiBjZW50cm9DdXN0b3NcIiB2YWx1ZT17e2NlbnRyb0N1c3RvLmlkfX0+e3tjZW50cm9DdXN0by5kZXNjcmlDQ3VzdG99fTwvb3B0aW9uPlxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgPC9kaXY+XHJcbiAgICBcclxuICAgIDxkaXYgKm5nSWY9XCJpZENDdXN0by5pbnZhbGlkICYmIGZvcm1EaXIuc3VibWl0dGVkXCIgY2xhc3M9XCJ2YWxpZGF0aW9uLWVycm9yXCI+XHJcbiAgICAgICAgPHAgKm5nSWY9XCJpZENDdXN0by5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPk8gY2VudHJvIGRlIGN1c3RvIMOpIG9icmlnYXTDs3JpYS48L3A+XHJcbiAgICA8L2Rpdj5cclxuICAgIFxyXG5cclxuICAgIDxpbnB1dCB0eXBlPVwic3VibWl0XCIgdmFsdWU9XCJ7e2J0blRleHR9fVwiPiAgICBcclxuPC9mb3JtPiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvRml4b1NlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2xhbmNhbWVudG8tZml4by9sYW5jYW1lbnRvLWZpeG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9GaXhvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWVkaXQtbGFuY2FtZW50by1maXhvJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZWRpdC1sYW5jYW1lbnRvLWZpeG8uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9lZGl0LWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRWRpdExhbmNhbWVudG9GaXhvQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xyXG5cclxuICBsYW5jYW1lbnRvRml4byE6IExhbmNhbWVudG9GaXhvO1xyXG4gIGJ0blRleHQ6IHN0cmluZyA9ICdDb25maXJtYXInO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbGFuY2FtZW50b0ZpeG9TZXJ2aWNlOiBMYW5jYW1lbnRvRml4b1NlcnZpY2UsIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlKSB7XHJcbiAgICAgICAgXHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkID0gTnVtYmVyKHRoaXMucm91dGUuc25hcHNob3QucGFyYW1NYXAuZ2V0KFwiaWRcIikpO1xyXG5cclxuICAgIHRoaXMubGFuY2FtZW50b0ZpeG9TZXJ2aWNlLmdldExhbmNhbWVudG9GaXhvUG9ySWQoaWQpLnN1YnNjcmliZSgoaXRlbSkgPT4ge1xyXG4gICAgICB0aGlzLmxhbmNhbWVudG9GaXhvID0gaXRlbTtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5sYW5jYW1lbnRvRml4by5kaWFNZXMpXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZWRpdEhlbmRsZXIobGFuY2FtZW50b0ZpeG9EYXRhOiBMYW5jYW1lbnRvRml4byl7ICAgIFxyXG4gICAgY29uc3QgaWQgPSB0aGlzLmxhbmNhbWVudG9GaXhvLmlkO1xyXG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGNvbnN0IGlkVXN1YXJpbyA9IHRoaXMubG9naW5TZXJ2aWNlLmdldElkVXN1YXJpbygpO1xyXG5cclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnZGlhTWVzJywgbGFuY2FtZW50b0ZpeG9EYXRhLmRpYU1lcy50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgndmFsb3InLCBsYW5jYW1lbnRvRml4b0RhdGEudmFsb3IudG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2Rlc2NyaWNhbycsIGxhbmNhbWVudG9GaXhvRGF0YS5kZXNjcmljYW8pO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdzdGF0dXMnLCBsYW5jYW1lbnRvRml4b0RhdGEuc3RhdHVzKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnaWRDQ3VzdG8nLCBsYW5jYW1lbnRvRml4b0RhdGEuaWRDQ3VzdG8udG9TdHJpbmcoKSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkVXN1YXJpbycsIGlkVXN1YXJpbyA/PyAnJyk7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5sYW5jYW1lbnRvRml4b1NlcnZpY2UucHV0TGFuY2FtZW50b0ZpeG8oaWQhLCBmb3JtRGF0YSkuc3Vic2NyaWJlKChyZXN1bHQ6IGFueSkgPT4ge1xyXG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9sYW5jYW1lbnRvLWZpeG8nXSk7XHJcbiAgICB9LFxyXG4gICAgICAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9cIik7XHJcbiAgICAgIH0pXHJcbiAgfVxyXG4gIFxyXG59IiwiPGRpdiAqbmdJZj1cImxhbmNhbWVudG9GaXhvXCI+XHJcbiAgICA8aDI+XHJcbiAgICAgICAgPHNwYW4+RWRpdGFyPC9zcGFuPiBMYW7Dp2FtZW50byBGaXhvXHJcbiAgICA8L2gyPlxyXG4gICAgPGFwcC1sYW5jYW1lbnRvLWZpeG8tZm9ybSAob25TdWJtaXQpPVwiZWRpdEhlbmRsZXIoJGV2ZW50KVwiIFtsYW5jYW1lbnRvRml4b0RhdGFdPVwibGFuY2FtZW50b0ZpeG9cIiBbYnRuVGV4dF09XCJidG5UZXh0XCI+PC9hcHAtbGFuY2FtZW50by1maXhvLWZvcm0+XHJcbjwvZGl2PiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnLi4vbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICdzcmMvZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuaW1wb3J0IHsgTGFuY2FtZW50b0ZpeG8gfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5pbXBvcnQgeyBNZW5zYWdlbnNTZXJ2aWNlIH0gZnJvbSAnLi4vbWVuc2FnZW5zL21lbnNhZ2Vucy5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIExhbmNhbWVudG9GaXhvU2VydmljZSB7XHJcbiAgXHJcbiAgcHJpdmF0ZSBiYXNlQXBpVXJsID0gZW52aXJvbm1lbnQuYmFzZUFwaVVybDtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsIHByaXZhdGUgbWVuc2FnZW5zU2VydmljZTogTWVuc2FnZW5zU2VydmljZSkgeyB9XHJcblxyXG4gIGdldEFsbExhbmNhbWVudG9zRml4b3MoKTogT2JzZXJ2YWJsZTxMYW5jYW1lbnRvRml4b1tdPiB7XHJcbiAgICAgIGNvbnN0IGlkVXN1YXJpbyA9IHRoaXMubG9naW5TZXJ2aWNlLmdldElkVXN1YXJpbygpO1xyXG4gICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxMYW5jYW1lbnRvRml4b1tdPihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zZml4b3MvdXN1YXJpby8ke2lkVXN1YXJpb31gKS5waXBlKFxyXG4gICAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgbGFuw6dhbWVudG9zIGZpeG9zOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICBnZXRMYW5jYW1lbnRvRml4b1BvcklkKGlkOiBOdW1iZXIpOiBPYnNlcnZhYmxlPExhbmNhbWVudG9GaXhvPiB7XHJcbiAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PExhbmNhbWVudG9GaXhvPihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zZml4b3MvJHtpZH1gKS5waXBlKFxyXG4gICAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgbGFuw6dhbWVudG8gZml4bzogJHtlcnJvci5zdGF0dXN9YCwgdW5kZWZpbmVkKTtcclxuICAgICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgICB9KVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgcG9zdExhbmNhbWVudG9GaXhvKGZvcm1EYXRhOiBGb3JtRGF0YSk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgIHZhciBkYXRhID0geyBcclxuICAgICAgICBkaWFNZXM6IE51bWJlcihmb3JtRGF0YS5nZXRBbGwoXCJkaWFNZXNcIikpLFxyXG4gICAgICAgIHZhbG9yOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwidmFsb3JcIikpLFxyXG4gICAgICAgIGRlc2NyaWNhbzogZm9ybURhdGEuZ2V0QWxsKFwiZGVzY3JpY2FvXCIpLnRvU3RyaW5nKCkudHJpbSgpLFxyXG4gICAgICAgIHN0YXR1czogZm9ybURhdGEuZ2V0QWxsKFwic3RhdHVzXCIpLnRvU3RyaW5nKCksXHJcbiAgICAgICAgaWRDQ3VzdG86IE51bWJlcihmb3JtRGF0YS5nZXRBbGwoXCJpZENDdXN0b1wiKSksXHJcbiAgICAgICAgaWRVc3VhcmlvOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwiaWRVc3VhcmlvXCIpKVxyXG4gICAgICB9O1xyXG4gIFxyXG4gICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgXHJcbiAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvbGFuY2FtZW50b3NmaXhvc2AsIGRhdGEpLnBpcGUoXHJcbiAgICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBjcmlhciBsYW7Dp2FtZW50byBmaXhvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICBleGNsdWlyTGFuY2FtZW50b0ZpeG8oaWQ6IE51bWJlcik6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgIHZhciBkYXRhID0geyBcclxuICAgICAgICBkZWxldGFkbzogJyonXHJcbiAgICAgIH07XHJcbiAgICAgIHJldHVybiB0aGlzLmh0dHAucHV0KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvbGFuY2FtZW50b3NmaXhvcy9kZWwvJHtpZH1gLCBkYXRhKS5waXBlKFxyXG4gICAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gZXhjbHVpciBsYW7Dp2FtZW50byBmaXhvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICBwdXRMYW5jYW1lbnRvRml4byhpZDogTnVtYmVyLCBmb3JtRGF0YTogRm9ybURhdGEpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICB2YXIgZGF0YSA9IHsgXHJcbiAgICAgICAgZGlhTWVzOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwiZGlhTWVzXCIpKSxcclxuICAgICAgICB2YWxvcjogTnVtYmVyKGZvcm1EYXRhLmdldEFsbChcInZhbG9yXCIpKSxcclxuICAgICAgICBkZXNjcmljYW86IGZvcm1EYXRhLmdldEFsbChcImRlc2NyaWNhb1wiKS50b1N0cmluZygpLnRyaW0oKSxcclxuICAgICAgICBzdGF0dXM6IGZvcm1EYXRhLmdldEFsbChcInN0YXR1c1wiKS50b1N0cmluZygpLFxyXG4gICAgICAgIGlkQ0N1c3RvOiBOdW1iZXIoZm9ybURhdGEuZ2V0QWxsKFwiaWRDQ3VzdG9cIikpLFxyXG4gICAgICAgIGlkVXN1YXJpbzogTnVtYmVyKGZvcm1EYXRhLmdldEFsbChcImlkVXN1YXJpb1wiKSlcclxuICAgICAgfTtcclxuICBcclxuICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8YW55PihgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2xhbmNhbWVudG9zZml4b3MvJHtpZH1gLCBkYXRhKS5waXBlKFxyXG4gICAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gYW8gYXR1YWxpemFyIGxhbsOnYW1lbnRvIGZpeG86ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICAgICAgfSlcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IExhbmNhbWVudG9GaXhvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbGFuY2FtZW50by1maXhvL2xhbmNhbWVudG8tZml4by5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTGFuY2FtZW50b0ZpeG8gfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtZXhjbHVpci1sYW5jYW1lbnRvLWZpeG8nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9leGNsdWlyLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL2V4Y2x1aXItbGFuY2FtZW50by1maXhvLmNvbXBvbmVudC5jc3MnLFxyXG4gIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBFeGNsdWlyTGFuY2FtZW50b0ZpeG9Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XHJcblxyXG4gIGxhbmNhbWVudG9GaXhvITogTGFuY2FtZW50b0ZpeG87XHJcbiAgYnRuVGV4dDogc3RyaW5nID0gJ1JlbW92ZXInO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbGFuY2FtZW50b0ZpeG9TZXJ2aWNlOiBMYW5jYW1lbnRvRml4b1NlcnZpY2UsIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyICwgcHJpdmF0ZSBsb2dpblNlcnZpY2U6IExvZ2luU2VydmljZSkge1xyXG4gICAgICAgIFxyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICBjb25zdCBpZCA9IE51bWJlcih0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtTWFwLmdldChcImlkXCIpKTtcclxuXHJcbiAgICB0aGlzLmxhbmNhbWVudG9GaXhvU2VydmljZS5nZXRMYW5jYW1lbnRvRml4b1BvcklkKGlkKS5zdWJzY3JpYmUoKGl0ZW0pID0+IHtcclxuICAgICAgdGhpcy5sYW5jYW1lbnRvRml4byA9IGl0ZW07XHJcbiAgICAgIGNvbnNvbGUubG9nKHRoaXMubGFuY2FtZW50b0ZpeG8uZGlhTWVzKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG5cclxuICBhc3luYyBleGNsdWlySGVuZGxlcihsYW5jYW1lbnRvRml4b0RhdGE6IExhbmNhbWVudG9GaXhvKXsgICAgXHJcbiAgICBjb25zdCBpZCA9IHRoaXMubGFuY2FtZW50b0ZpeG8uaWQ7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcblxyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkaWFNZXMnLCBsYW5jYW1lbnRvRml4b0RhdGEuZGlhTWVzLnRvU3RyaW5nKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCd2YWxvcicsIGxhbmNhbWVudG9GaXhvRGF0YS52YWxvci50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnZGVzY3JpY2FvJywgbGFuY2FtZW50b0ZpeG9EYXRhLmRlc2NyaWNhbyk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3N0YXR1cycsIGxhbmNhbWVudG9GaXhvRGF0YS5zdGF0dXMpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdpZENDdXN0bycsIGxhbmNhbWVudG9GaXhvRGF0YS5pZENDdXN0by50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnaWRVc3VhcmlvJywgaWRVc3VhcmlvID8/ICcnKTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLmxhbmNhbWVudG9GaXhvU2VydmljZS5leGNsdWlyTGFuY2FtZW50b0ZpeG8odGhpcy5sYW5jYW1lbnRvRml4by5pZCEpLnN1YnNjcmliZSgocmVzdWx0OiBhbnkpID0+IHtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvbGFuY2FtZW50by1maXhvJ10pO1xyXG4gICAgfSxcclxuICAgICAgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvXCIpO1xyXG4gICAgICB9KVxyXG4gIH1cclxuXHJcbn1cclxuIiwiPGRpdiAqbmdJZj1cImxhbmNhbWVudG9GaXhvXCI+XHJcbiAgICA8aDI+XHJcbiAgICAgICAgRXhjbHVpciA8c3Bhbj5MYW7Dp2FtZW50byBGaXhvPC9zcGFuPlxyXG4gICAgPC9oMj5cclxuICAgIDxhcHAtbGFuY2FtZW50by1maXhvLWZvcm0gKG9uU3VibWl0KT1cImV4Y2x1aXJIZW5kbGVyKCRldmVudClcIiBbbGFuY2FtZW50b0ZpeG9EYXRhXT1cImxhbmNhbWVudG9GaXhvXCIgW2J0blRleHRdPVwiYnRuVGV4dFwiPjwvYXBwLWxhbmNhbWVudG8tZml4by1mb3JtPlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvRml4b1NlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2xhbmNhbWVudG8tZml4by9sYW5jYW1lbnRvLWZpeG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbG9naW4vbG9naW4uc2VydmljZSc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9GaXhvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLW5vdm8tbGFuY2FtZW50by1maXhvJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vbm92by1sYW5jYW1lbnRvLWZpeG8uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9ub3ZvLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTm92b0xhbmNhbWVudG9GaXhvQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xyXG4gIGJ0blRleHQ6IHN0cmluZyA9IFwiUmVnaXN0cmFyXCI7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbGFuY2FtZW50b0ZpeG9TZXJ2aWNlOiBMYW5jYW1lbnRvRml4b1NlcnZpY2UsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2Upe31cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICBcclxuICB9XHJcblxyXG4gIGFzeW5jIGNyZWF0ZUhhbmRsZXIobGFuY2FtZW50b0ZpeG86IExhbmNhbWVudG9GaXhvKXtcclxuICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICBjb25zdCBpZFVzdWFyaW8gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRJZFVzdWFyaW8oKTtcclxuXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2RpYU1lcycsIGxhbmNhbWVudG9GaXhvLmRpYU1lcy50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgndmFsb3InLCBsYW5jYW1lbnRvRml4by52YWxvci50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnZGVzY3JpY2FvJywgbGFuY2FtZW50b0ZpeG8uZGVzY3JpY2FvKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnc3RhdHVzJywgbGFuY2FtZW50b0ZpeG8uc3RhdHVzKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnaWRDQ3VzdG8nLCBsYW5jYW1lbnRvRml4by5pZENDdXN0by50b1N0cmluZygpKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnaWRVc3VhcmlvJywgaWRVc3VhcmlvID8/ICcnKTtcclxuXHJcbiAgICAgLy9Ub2RvXHJcbiAgICBjb25zb2xlLmxvZyhsYW5jYW1lbnRvRml4by5kaWFNZXMpO1xyXG4gICAgY29uc29sZS5sb2coZm9ybURhdGEuZ2V0QWxsKFwiZGlhTWVzXCIpKTtcclxuICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLmdldEFsbChcInZhbG9yXCIpKTtcclxuICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLmdldEFsbChcImRlc2NyaWNhb1wiKSk7XHJcbiAgICBjb25zb2xlLmxvZyhmb3JtRGF0YS5nZXRBbGwoXCJzdGF0dXNcIikpO1xyXG4gICAgY29uc29sZS5sb2coZm9ybURhdGEuZ2V0QWxsKFwiaWRDQ3VzdG9cIikpO1xyXG4gICAgY29uc29sZS5sb2coZm9ybURhdGEuZ2V0QWxsKFwiaWRVc3VhcmlvXCIpKTtcclxuICAgIGF3YWl0IHRoaXMubGFuY2FtZW50b0ZpeG9TZXJ2aWNlLnBvc3RMYW5jYW1lbnRvRml4byhmb3JtRGF0YSkuc3Vic2NyaWJlKChyZXN1bHQ6IGFueSkgPT4ge1xyXG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9sYW5jYW1lbnRvLWZpeG8nXSk7XHJcbiAgICB9LFxyXG4gICAgICAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9cIik7XHJcbiAgICAgIH0pIFxyXG5cclxuICAvL0V4aWJpciBtc2dcclxuXHJcbiAgLy9SZWRpcmVjdFxyXG4gIH1cclxuIFxyXG5cclxufSIsIjxoMj5SZWdpc3RyZSBvIHNldSA8c3Bhbj5MYW7Dp2FtZW50byBGaXhvPC9zcGFuPjwvaDI+XHJcbjxhcHAtbGFuY2FtZW50by1maXhvLWZvcm0gW2J0blRleHRdPVwiYnRuVGV4dFwiIChvblN1Ym1pdCk9XCJjcmVhdGVIYW5kbGVyKCRldmVudClcIj48L2FwcC1sYW5jYW1lbnRvLWZpeG8tZm9ybT4iLCJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2VudHJvQ3VzdG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9jZXRyby1jdXN0by9jZW50cm8tY3VzdG8uc2VydmljZSc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9GaXhvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbGFuY2FtZW50by1maXhvL2xhbmNhbWVudG8tZml4by5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTGFuY2FtZW50b0ZpeG8sIENlbnRyb0N1c3RvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLXRhYmVsYS1sYW5jYW1lbnRvLWZpeG8nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi90YWJlbGEtbGFuY2FtZW50by1maXhvLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vdGFiZWxhLWxhbmNhbWVudG8tZml4by5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgVGFiZWxhTGFuY2FtZW50b0ZpeG9Db21wb25lbnQge1xyXG4gIGxhbmNhbWVudG9zRml4b3M6IExhbmNhbWVudG9GaXhvW10gPSBbXTtcclxuICBjZW50cm9DdXN0b3M6IENlbnRyb0N1c3RvW10gPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBsYW5jYW1lbnRvRml4b1NlcnZpY2U6IExhbmNhbWVudG9GaXhvU2VydmljZSwgcHJpdmF0ZSBjZW50cm9DdXN0b1NlcnZpY2U6IENlbnRyb0N1c3RvU2VydmljZSkge1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICB0aGlzLmxhbmNhbWVudG9GaXhvU2VydmljZS5nZXRBbGxMYW5jYW1lbnRvc0ZpeG9zKCkuc3Vic2NyaWJlKChsYW5jYW1lbnRvcykgPT4gKHRoaXMubGFuY2FtZW50b3NGaXhvcyA9IGxhbmNhbWVudG9zKSk7XHJcbiAgICB0aGlzLmNlbnRyb0N1c3RvU2VydmljZS5nZXRBbGxDZW50cm9DdXN0b3MoKS5zdWJzY3JpYmUoKGNlbnRyb0N1c3RvcykgPT4gKHRoaXMuY2VudHJvQ3VzdG9zID0gY2VudHJvQ3VzdG9zKSk7XHJcbiAgfVxyXG5cclxuICByZW1vdmVyTGFuY2FtZW50byhpZDogTnVtYmVyKTogdm9pZCB7XHJcbiAgICB0aGlzLmxhbmNhbWVudG9GaXhvU2VydmljZS5leGNsdWlyTGFuY2FtZW50b0ZpeG8oaWQpLnN1YnNjcmliZSgpO1xyXG4gIH1cclxufVxyXG4iLCI8ZGl2PlxyXG4gICAgPGRpdiAqbmdJZj1cImxhbmNhbWVudG9zRml4b3MubGVuZ3RoID4gMDsgZWxzZSBub0xhbmNhbWVudG9zXCI+XHJcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsZSB0YWJsZS1zdHJpcGVkIHRhYmxlLWJvcmRlcmVkIGFsaWduLW1pZGRsZSBzaGFkb3ctc21cIj4gICBcclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3M9XCJ0YWJsZS1kYXJrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+RGlhIGRvIE3DqnM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5WYWxvcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkRlc2NyacOnw6NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+QcOnw7VlczwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPiAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRib2R5PiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgKm5nRm9yPVwibGV0IGxhbmNhbWVudG9GaXhvIG9mIGxhbmNhbWVudG9zRml4b3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57e2xhbmNhbWVudG9GaXhvLmRpYU1lc319PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBsYW5jYW1lbnRvRml4by52YWxvciB8IGZvcm1hdFZhbG9yIH19PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57e2xhbmNhbWVudG9GaXhvLmRlc2NyaWNhb319PC90ZD4gICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57e2xhbmNhbWVudG9GaXhvLnN0YXR1c319PC90ZD4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gcm91dGVyTGluaz1cIi9sYW5jYW1lbnRvLWZpeG8vZWRpdC97e2xhbmNhbWVudG9GaXhvLmlkfX1cIiB0eXBlPVwiYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5IGJ0bi1zbSBib3Rhby1lZGl0YXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiYmkgYmktcGVuY2lsLXNxdWFyZVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gcm91dGVyTGluaz1cIi9sYW5jYW1lbnRvLWZpeG8vZXhjbHVpci97e2xhbmNhbWVudG9GaXhvLmlkfX1cIiB0eXBlPVwiYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1kYW5nZXIgYnRuLXNtIGJvdGFvLXJlbW92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiYmkgYmktdHJhc2hcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj4gIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+ICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgPG5nLXRlbXBsYXRlICNub0xhbmNhbWVudG9zPlxyXG4gICAgICAgIDxoMT5Ow6NvIGV4aXRlbSByZWdpc3Ryb3MgY2FkYXN0cmFkb3MgOlA8L2gxPlxyXG4gICAgPC9uZy10ZW1wbGF0ZT5cclxuXHJcbiAgICA8YnV0dG9uIG1hdC1mYWIgY29sb3I9XCJwcmltYXJ5XCIgY2xhc3M9XCJmYWJcIiByb3V0ZXJMaW5rPVwiL2xhbmNhbWVudG8tZml4by9ub3ZvL1wiPlxyXG4gICAgICAgIDxtYXQtaWNvbj5hZGQ8L21hdC1pY29uPlxyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbjwvZGl2PiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRG9tU2FuaXRpemVyLCBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5pbXBvcnQgeyBFTVBUWSwgc3dpdGNoTWFwIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IENlbnRyb0N1c3RvU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvY2V0cm8tY3VzdG8vY2VudHJvLWN1c3RvLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb25maWd1cmFjb2VzSWFTZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9jb25maWd1cmFjb2VzLWlhL2NvbmZpZ3VyYWNvZXMtaWEuc2VydmljZSc7XHJcbmltcG9ydCB7IExhbmNhbWVudG9TZXJ2aWNlIH0gZnJvbSAnc3JjL2FwcC9zZXJ2aWNlcy9sYW5jYW1lbnRvL2xhbmNhbWVudG8uc2VydmljZSc7XHJcbmltcG9ydCB7IEFuYWxpc2VGaW5hbmNlaXJhSWFSZXNwb25zZSwgQ2VudHJvQ3VzdG8sIExhbmNhbWVudG8gfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtdGFiZWxhLWxhbmNhbWVudG8nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi90YWJlbGEtbGFuY2FtZW50by5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL3RhYmVsYS1sYW5jYW1lbnRvLmNvbXBvbmVudC5jc3MnLFxyXG4gIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBUYWJlbGFMYW5jYW1lbnRvQ29tcG9uZW50IHtcclxuICBjZW50cm9DdXN0b3M6IENlbnRyb0N1c3RvW10gPSBbXTtcclxuICBkYXRhRGU6IHN0cmluZyA9IFwiXCI7IC8vdGhpcy5nZXREYXRhRGlhc0F0cmFzKDMwKTtcclxuICBkYXRhQXRlOiBzdHJpbmcgPSB0aGlzLmdldEhvamUoKTtcclxuXHJcbiAgaXNBUGFnYXJDaGVja2VkID0gdHJ1ZTtcclxuICBpc1BhZ29DaGVja2VkID0gdHJ1ZTtcclxuICBpc0FSZWNlYmVyQ2hlY2tlZCA9IHRydWU7XHJcbiAgaXNSZWNlYmlkb0NoZWNrZWQgPSB0cnVlO1xyXG5cclxuICBhUGFnYXIgPSBcIlwiO1xyXG4gIHBhZ28gPSBcIlwiO1xyXG4gIGFSZWNlYmVyID0gXCJcIjtcclxuICByZWNlYmlkbyA9IFwiXCJcclxuXHJcbiAgZmlsdHJvU3RhdHVzID0gXCJcIjtcclxuXHJcbiAgZmlsdHJvQ2VudHJvQ3VzdG8gPSAwO1xyXG5cclxuICBASW5wdXQoKSB2YWxvckFQYWdhcjogbnVtYmVyID0gMDtcclxuICBASW5wdXQoKSB2YWxvclBhZ286IG51bWJlciA9IDA7XHJcbiAgQElucHV0KCkgdmFsb3JBUmVjZWJlcjogbnVtYmVyID0gMDtcclxuICBASW5wdXQoKSB2YWxvclJlY2ViaWRvOiBudW1iZXIgPSAwO1xyXG4gIEBJbnB1dCgpIGRlc3Blc2FzR3JhZmljb0RvbnV0OiBudW1iZXIgPSAwO1xyXG4gIEBJbnB1dCgpIHJlY2VpdGFzR3JhZmljb0RvbnV0OiBudW1iZXIgPSAwO1xyXG4gIEBJbnB1dCgpIGxhbmNhbWVudG9zOiBMYW5jYW1lbnRvW10gPSBbXTtcclxuICBASW5wdXQoKSBpc0xvYWRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIHByaXZhdGUgaWRzSW52YWxpZG9zID0gbmV3IFNldChbMTksIDUxXSk7XHJcblxyXG4gIGh0bWxJYT86IFNhZmVIdG1sO1xyXG4gIGlzUG9wdXBBYmVydG8gPSBmYWxzZTtcclxuICBpc0NvcGlhQWJlcnRvID0gZmFsc2U7XHJcbiAgaXNMb2FkaW5nSW5zaWdodCA9IGZhbHNlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGxhbmNhbWVudG9TZXJ2aWNlOiBMYW5jYW1lbnRvU2VydmljZSxcclxuICAgIHByaXZhdGUgY2VudHJvQ3VzdG9TZXJ2aWNlOiBDZW50cm9DdXN0b1NlcnZpY2UsXHJcbiAgICBwcml2YXRlIGNvbmZpZ3VyYWNvZXNJQVNlcnZpY2U6IENvbmZpZ3VyYWNvZXNJYVNlcnZpY2UsXHJcbiAgICBwcml2YXRlIHNhbml0aXplcjogRG9tU2FuaXRpemVyKSB7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIHRoaXMuZmlsdHJvU3RhdHVzID0gdGhpcy5hZ3J1cGFTdGF0dXMoKTtcclxuICAgIHRoaXMubGFuY2FtZW50b1NlcnZpY2UuZ2V0QWxsTGFuY2FtZW50b3MoKS5zdWJzY3JpYmUoKGxhbmNhbWVudG9zKSA9PiB7XHJcbiAgICAgIGlmIChsYW5jYW1lbnRvcyAhPSBudWxsICYmIGxhbmNhbWVudG9zLmxlbmd0aCA+IDApIHtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IG5ldyBEYXRlKFxyXG4gICAgICAgICAgbGFuY2FtZW50b3NbbGFuY2FtZW50b3MubGVuZ3RoIC0gMV0uZGF0YUhvcmFcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICB0aGlzLmRhdGFEZSA9IGRhdGEudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZyhcIkRhdGEgZGUgaW7DrWNpbyBkZWZpbmlkYSBwYXJhOiBcIiArIHRoaXMuZGF0YURlKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxhbmNhbWVudG9zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICB0aGlzLmxhbmNhbWVudG9zLnB1c2gobGFuY2FtZW50b3NbaV0pO1xyXG4gICAgICAgICAgdGhpcy52YWxvckFQYWdhciArPSBsYW5jYW1lbnRvc1tpXS5zdGF0dXMgPT09IFwiQSBQYWdhclwiID8gbGFuY2FtZW50b3NbaV0udmFsb3IgOiAwO1xyXG4gICAgICAgICAgdGhpcy52YWxvclBhZ28gKz0gbGFuY2FtZW50b3NbaV0uc3RhdHVzID09PSBcIlBhZ29cIiA/IGxhbmNhbWVudG9zW2ldLnZhbG9yIDogMDtcclxuICAgICAgICAgIHRoaXMudmFsb3JBUmVjZWJlciArPSBsYW5jYW1lbnRvc1tpXS5zdGF0dXMgPT09IFwiQSBSZWNlYmVyXCIgPyBsYW5jYW1lbnRvc1tpXS52YWxvciA6IDA7XHJcbiAgICAgICAgICB0aGlzLnZhbG9yUmVjZWJpZG8gKz0gbGFuY2FtZW50b3NbaV0uc3RhdHVzID09PSBcIlJlY2ViaWRvXCIgPyBsYW5jYW1lbnRvc1tpXS52YWxvciA6IDA7XHJcbiAgICAgICAgICBpZiAodGhpcy5sYW5jYW1lbnRvc1tpXS5zdGF0dXMgPT09IFwiUGFnb1wiICYmICF0aGlzLmlkc0ludmFsaWRvcy5oYXModGhpcy5sYW5jYW1lbnRvc1tpXS5pZENDdXN0bykpIHtcclxuICAgICAgICAgICAgdGhpcy5kZXNwZXNhc0dyYWZpY29Eb251dCArPSBsYW5jYW1lbnRvc1tpXS52YWxvcjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmICh0aGlzLmxhbmNhbWVudG9zW2ldLnN0YXR1cyA9PT0gXCJSZWNlYmlkb1wiKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVjZWl0YXNHcmFmaWNvRG9udXQgKz0gbGFuY2FtZW50b3NbaV0udmFsb3I7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuY2VudHJvQ3VzdG9TZXJ2aWNlLmdldEFsbENlbnRyb0N1c3RvcygpLnN1YnNjcmliZSgoY2VudHJvQ3VzdG9zKSA9PiAodGhpcy5jZW50cm9DdXN0b3MgPSBjZW50cm9DdXN0b3MpKTtcclxuICB9XHJcblxyXG4gIGdldEhvamUoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGhvamUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcmV0dXJuIGhvamUudG9JU09TdHJpbmcoKS5zdWJzdHJpbmcoMCwgMTApO1xyXG4gIH1cclxuXHJcbiAgZ2V0RGF0YURpYXNBdHJhcyhkaWFzOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgZGF0YSA9IG5ldyBEYXRlKCk7XHJcbiAgICBkYXRhLnNldERhdGUoZGF0YS5nZXREYXRlKCkgLSBkaWFzKTtcclxuICAgIHJldHVybiBkYXRhLnRvSVNPU3RyaW5nKCkuc3Vic3RyaW5nKDAsIDEwKTtcclxuICB9XHJcblxyXG4gIGZpbHRyYXJDZW50cm9DdXN0byhldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgIHRoaXMuZmlsdHJvQ2VudHJvQ3VzdG8gPSBwYXJzZUludCgoZXZlbnQudGFyZ2V0IGFzIEhUTUxTZWxlY3RFbGVtZW50KS52YWx1ZSwgMTApO1xyXG4gICAgdGhpcy5maWx0cm9EYXRhKCk7XHJcbiAgfVxyXG5cclxuICBmaWx0cm9EYXRhKCk6IHZvaWQge1xyXG5cclxuICAgIHRoaXMudmFsb3JBUGFnYXIgPSAwO1xyXG4gICAgdGhpcy52YWxvclBhZ28gPSAwO1xyXG4gICAgdGhpcy52YWxvckFSZWNlYmVyID0gMDtcclxuICAgIHRoaXMudmFsb3JSZWNlYmlkbyA9IDA7XHJcbiAgICB0aGlzLmRlc3Blc2FzR3JhZmljb0RvbnV0ID0gMDtcclxuICAgIHRoaXMucmVjZWl0YXNHcmFmaWNvRG9udXQgPSAwO1xyXG4gICAgdGhpcy5maWx0cm9TdGF0dXMgPSB0aGlzLmFncnVwYVN0YXR1cygpO1xyXG5cclxuICAgIGlmICh0aGlzLmRhdGFEZSAhPSBcIlwiICYmIHRoaXMuZGF0YUF0ZSAhPSBcIlwiKSB7XHJcbiAgICAgIHRoaXMubGFuY2FtZW50b1NlcnZpY2UuZ2V0TGFuY2FtZW50b0RhdGFEZUF0ZSh0aGlzLmRhdGFEZSwgdGhpcy5kYXRhQXRlLCB0aGlzLmZpbHRyb1N0YXR1cywgdGhpcy5maWx0cm9DZW50cm9DdXN0bykuc3Vic2NyaWJlKGl0ZW0gPT4ge1xyXG4gICAgICAgIHRoaXMubGFuY2FtZW50b3MgPSBbXTtcclxuICAgICAgICB0aGlzLmxhbmNhbWVudG9zID0gaXRlbTtcclxuICAgICAgICBpZiAodGhpcy5sYW5jYW1lbnRvcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMubGFuY2FtZW50b3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy52YWxvckFQYWdhciArPSB0aGlzLmxhbmNhbWVudG9zW2ldLnN0YXR1cyA9PT0gXCJBIFBhZ2FyXCIgPyB0aGlzLmxhbmNhbWVudG9zW2ldLnZhbG9yIDogMDtcclxuICAgICAgICAgICAgdGhpcy52YWxvclBhZ28gKz0gdGhpcy5sYW5jYW1lbnRvc1tpXS5zdGF0dXMgPT09IFwiUGFnb1wiID8gdGhpcy5sYW5jYW1lbnRvc1tpXS52YWxvciA6IDA7XHJcbiAgICAgICAgICAgIHRoaXMudmFsb3JBUmVjZWJlciArPSB0aGlzLmxhbmNhbWVudG9zW2ldLnN0YXR1cyA9PT0gXCJBIFJlY2ViZXJcIiA/IHRoaXMubGFuY2FtZW50b3NbaV0udmFsb3IgOiAwO1xyXG4gICAgICAgICAgICB0aGlzLnZhbG9yUmVjZWJpZG8gKz0gdGhpcy5sYW5jYW1lbnRvc1tpXS5zdGF0dXMgPT09IFwiUmVjZWJpZG9cIiA/IHRoaXMubGFuY2FtZW50b3NbaV0udmFsb3IgOiAwO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMubGFuY2FtZW50b3NbaV0uc3RhdHVzID09PSBcIlBhZ29cIiAmJiAhdGhpcy5pZHNJbnZhbGlkb3MuaGFzKHRoaXMubGFuY2FtZW50b3NbaV0uaWRDQ3VzdG8pKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5kZXNwZXNhc0dyYWZpY29Eb251dCArPSB0aGlzLmxhbmNhbWVudG9zW2ldLnZhbG9yO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmxhbmNhbWVudG9zW2ldLnN0YXR1cyA9PT0gXCJSZWNlYmlkb1wiKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5yZWNlaXRhc0dyYWZpY29Eb251dCArPSB0aGlzLmxhbmNhbWVudG9zW2ldLnZhbG9yO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhZ3J1cGFTdGF0dXMoKTogc3RyaW5nIHtcclxuICAgIHRoaXMuZmlsdHJvU3RhdHVzID0gXCJcIjtcclxuICAgIHRoaXMuYVBhZ2FyID0gdGhpcy5pc0FQYWdhckNoZWNrZWQgPyBcIkEgUGFnYXJcIiA6IFwiXCI7XHJcbiAgICB0aGlzLnBhZ28gPSB0aGlzLmlzUGFnb0NoZWNrZWQgPyBcIlBhZ29cIiA6IFwiXCI7XHJcbiAgICB0aGlzLmFSZWNlYmVyID0gdGhpcy5pc0FSZWNlYmVyQ2hlY2tlZCA/IFwiQSBSZWNlYmVyXCIgOiBcIlwiO1xyXG4gICAgdGhpcy5yZWNlYmlkbyA9IHRoaXMuaXNSZWNlYmlkb0NoZWNrZWQgPyBcIlJlY2ViaWRvXCIgOiBcIlwiO1xyXG5cclxuICAgIHJldHVybiB0aGlzLmFQYWdhciArIHRoaXMucGFnbyArIHRoaXMuYVJlY2ViZXIgKyB0aGlzLnJlY2ViaWRvO1xyXG4gIH1cclxuXHJcbiAgcmVtb3ZlckxhbmNhbWVudG8oaWQ6IE51bWJlcik6IHZvaWQge1xyXG4gICAgdGhpcy5sYW5jYW1lbnRvU2VydmljZS5leGNsdWlyTGFuY2FtZW50byhpZCkuc3Vic2NyaWJlKCk7XHJcbiAgfVxyXG5cclxuICBhYnJpckluc2lnaHQoZXZlbnQ/OiBNb3VzZUV2ZW50KSB7XHJcbiAgICBldmVudD8uc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG4gICAgLy8gU2UgasOhIGVzdGl2ZXIgY2FycmVnYW5kbywgaWdub3JhIGNsaXF1ZVxyXG4gICAgaWYgKHRoaXMuaXNMb2FkaW5nSW5zaWdodCkgcmV0dXJuO1xyXG5cclxuICAgIHRoaXMuaXNMb2FkaW5nSW5zaWdodCA9IHRydWU7XHJcbiAgICB0aGlzLmh0bWxJYSA9IHVuZGVmaW5lZDtcclxuXHJcbiAgICB0aGlzLmNvbmZpZ3VyYWNvZXNJQVNlcnZpY2UuZ2V0Q29uZmlndXJhY2FvSUEoKVxyXG4gICAgICAucGlwZShcclxuICAgICAgICBzd2l0Y2hNYXAoaXRlbSA9PiB7XHJcbiAgICAgICAgICBpZiAoIWl0ZW0pIHtcclxuICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmdJbnNpZ2h0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHJldHVybiBFTVBUWTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWd1cmFjb2VzSUFTZXJ2aWNlLnBvc3RBbmFsaXNlRmluYW5jZWlyYUlhKFxyXG4gICAgICAgICAgICB0aGlzLmZvcm1hdGFyRGF0YShpdGVtLmZpbHRyb0RhdGFEZSksXHJcbiAgICAgICAgICAgIHRoaXMuZm9ybWF0YXJEYXRhKGl0ZW0uZmlsdHJvRGF0YUF0ZSksXHJcbiAgICAgICAgICAgIGl0ZW0ucHJvbXB0XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pXHJcbiAgICAgIClcclxuICAgICAgLnN1YnNjcmliZSh7XHJcbiAgICAgICAgbmV4dDogKHJlczogQW5hbGlzZUZpbmFuY2VpcmFJYVJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLmh0bWxJYSA9IHRoaXMuc2FuaXRpemVyXHJcbiAgICAgICAgICAgIC5ieXBhc3NTZWN1cml0eVRydXN0SHRtbChyZXMuYW5hbGlzZUlBKTtcclxuXHJcbiAgICAgICAgICB0aGlzLmlzUG9wdXBBYmVydG8gPSB0cnVlO1xyXG4gICAgICAgICAgdGhpcy5pc0xvYWRpbmdJbnNpZ2h0ID0gZmFsc2U7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvcjogKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLmlzTG9hZGluZ0luc2lnaHQgPSBmYWxzZTtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm8gYW8gZ2VyYXIgYW7DoWxpc2UgSUEnLCBlcnJvcik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoJ25vLXNjcm9sbCcpO1xyXG4gIH1cclxuXHJcblxyXG4gIGZvcm1hdGFyRGF0YShkYXRhOiBzdHJpbmcgfCBEYXRlKTogc3RyaW5nIHtcclxuICAgIGlmICghZGF0YSkgcmV0dXJuICcnO1xyXG5cclxuICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShkYXRhKTtcclxuICAgIHJldHVybiBkLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcclxuICB9XHJcblxyXG4gIGZlY2hhclBvcHVwKCkge1xyXG4gICAgdGhpcy5pc1BvcHVwQWJlcnRvID0gZmFsc2U7XHJcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoJ25vLXNjcm9sbCcpO1xyXG4gIH1cclxuXHJcbiAgYWJyaXJDb3BpYXJMYW5jYW1lbnRvcygpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiQWJyaW5kbyBwb3B1cCBkZSBjb3BpYXIgbGFuw6dhbWVudG9zXCIpO1xyXG4gICAgdGhpcy5pc0NvcGlhQWJlcnRvID0gdHJ1ZTtcclxuICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZCgnbm8tc2Nyb2xsJyk7XHJcbiAgfVxyXG5cclxuICBmZWNoYXJDb3BpYXJMYW5jYW1lbnRvcygpIHtcclxuICAgIHRoaXMuaXNDb3BpYUFiZXJ0byA9IGZhbHNlO1xyXG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKCduby1zY3JvbGwnKTtcclxuICB9XHJcbn1cclxuIiwiPGFwcC1zYWxkb3MgXHJcbiAgW3ZhbG9yQVBhZ2FyXT1cInZhbG9yQVBhZ2FyXCJcclxuICBbdmFsb3JQYWdvXT1cInZhbG9yUGFnb1wiXHJcbiAgW3ZhbG9yQVJlY2ViZXJdPVwidmFsb3JBUmVjZWJlclwiXHJcbiAgW3ZhbG9yUmVjZWJpZG9dPVwidmFsb3JSZWNlYmlkb1wiXHJcbiAgW2Rlc3Blc2FzR3JhZmljb0RvbnV0XT1cImRlc3Blc2FzR3JhZmljb0RvbnV0XCIgXHJcbiAgW3JlY2VpdGFzR3JhZmljb0RvbnV0XT1cInJlY2VpdGFzR3JhZmljb0RvbnV0XCJcclxuICBbaXNMb2FkaW5nXT1cImlzTG9hZGluZ1wiXHJcbiAgPiAgXHJcbjwvYXBwLXNhbGRvcz5cclxuXHJcbjxkaXZcclxuICBjbGFzcz1cImFpLWluc2lnaHQtY2FyZFwiXHJcbiAgW2NsYXNzLmxvYWRpbmddPVwiaXNMb2FkaW5nSW5zaWdodFwiXHJcbiAgKGNsaWNrKT1cImFicmlySW5zaWdodCgkZXZlbnQpXCJcclxuPlxyXG4gIDxkaXYgY2xhc3M9XCJhaS1pbnNpZ2h0LWNvbnRlbnRcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJhaS10ZXh0XCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJhaS10aXRsZVwiPk9idGVyIEluc2lnaHQgZGUgSUE8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzcz1cImFpLXN1YnRpdGxlXCI+XHJcbiAgICAgICAgQ2xpcXVlIHBhcmEgZ2VyYXIgdW0gaW5zaWdodCBmaW5hbmNlaXJvXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImFpLWljb25cIj7wn5KhPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJhaS1sb2FkaW5nLW92ZXJsYXlcIiAqbmdJZj1cImlzTG9hZGluZ0luc2lnaHRcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XHJcbiAgICA8cCBjbGFzcz1cImxvYWRpbmctdGV4dFwiPkdlcmFuZG8gaW5zaWdodC4uLjwvcD5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcblxyXG5cclxuPCEtLSBQT1BVUCBGT1JBIERPIEJPVMODTyAtLT5cclxuPGFwcC1wb3AtdXAtaWFcclxuICAqbmdJZj1cImlzUG9wdXBBYmVydG9cIlxyXG4gIFtodG1sSWFdPVwiaHRtbElhXCJcclxuICAoZmVjaGFyKT1cImZlY2hhclBvcHVwKClcIj5cclxuPC9hcHAtcG9wLXVwLWlhPlxyXG5cclxuPGJyPlxyXG48ZGl2PlxyXG4gIDwhLS0gQ29udGFpbmVyIHBhcmEgb3MgY2FtcG9zIGRlIGRhdGEgLS0+XHJcbiAgPGRpdiBjbGFzcz1cImRhdGUtY29udGFpbmVyXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZGF0ZS1waWNrZXJcIj5cclxuICAgICAgPGxhYmVsIGZvcj1cInN0YXJ0RGF0ZVwiPkRhdGEgZGU6PC9sYWJlbD5cclxuICAgICAgPGlucHV0IGlkPVwic3RhcnREYXRlXCIgdHlwZT1cImRhdGVcIiBbKG5nTW9kZWwpXT1cImRhdGFEZVwiIChuZ01vZGVsQ2hhbmdlKT1cImZpbHRyb0RhdGEoKVwiIC8+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiZGF0ZS1waWNrZXJcIj5cclxuICAgICAgPGxhYmVsIGZvcj1cImVuZERhdGVcIj5EYXRhIGF0w6k6PC9sYWJlbD5cclxuICAgICAgPGlucHV0IGlkPVwiZW5kRGF0ZVwiIHR5cGU9XCJkYXRlXCIgWyhuZ01vZGVsKV09XCJkYXRhQXRlXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZmlsdHJvRGF0YSgpXCIgLz5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG5cclxuXHJcbiAgPCEtLSBDb250YWluZXIgcGFyYSBvcyBjaGVja2JveGVzIC0tPlxyXG4gIDxkaXYgY2xhc3M9XCJjaGVja2JveC1ncm91cFwiPlxyXG4gICAgPCEtLSBDb2x1bmEgMSAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJjaGVja2JveC1jb2x1bW5cIj5cclxuICAgICAgPGxhYmVsIGNsYXNzPVwiY3VzdG9tLWNoZWNrYm94XCI+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFsobmdNb2RlbCldPVwiaXNBUGFnYXJDaGVja2VkXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZmlsdHJvRGF0YSgpXCIgLz5cclxuICAgICAgICA8c3Bhbj5BIFBhZ2FyPC9zcGFuPlxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgICA8bGFiZWwgY2xhc3M9XCJjdXN0b20tY2hlY2tib3hcIj5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgWyhuZ01vZGVsKV09XCJpc1BhZ29DaGVja2VkXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZmlsdHJvRGF0YSgpXCIgLz5cclxuICAgICAgICA8c3Bhbj5QYWdvPC9zcGFuPlxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBDb2x1bmEgMiAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJjaGVja2JveC1jb2x1bW5cIj5cclxuICAgICAgPGxhYmVsIGNsYXNzPVwiY3VzdG9tLWNoZWNrYm94XCI+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFsobmdNb2RlbCldPVwiaXNBUmVjZWJlckNoZWNrZWRcIiAobmdNb2RlbENoYW5nZSk9XCJmaWx0cm9EYXRhKClcIiAvPlxyXG4gICAgICAgIDxzcGFuPkEgUmVjZWJlcjwvc3Bhbj5cclxuICAgICAgPC9sYWJlbD5cclxuICAgICAgPGxhYmVsIGNsYXNzPVwiY3VzdG9tLWNoZWNrYm94XCI+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFsobmdNb2RlbCldPVwiaXNSZWNlYmlkb0NoZWNrZWRcIiAobmdNb2RlbENoYW5nZSk9XCJmaWx0cm9EYXRhKClcIiAvPlxyXG4gICAgICAgIDxzcGFuPlJlY2ViaWRvPC9zcGFuPlxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJzZWxlY3QtZ3JvdXBcIj5cclxuICAgIDxsYWJlbCBmb3I9XCJzdGF0dXNcIj5DZW50cm8gZGUgQ3VzdG86PC9sYWJlbD5cclxuICAgIDxzZWxlY3QgaWQ9XCJzdGF0dXNcIiByZXF1aXJlZCAoY2hhbmdlKT1cImZpbHRyYXJDZW50cm9DdXN0bygkZXZlbnQpXCI+XHJcbiAgICAgIDxvcHRpb24gZGlzYWJsZWQgc2VsZWN0ZWQgaGlkZGVuPlRvZG9zPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gW3ZhbHVlXT1cIjBcIj5Ub2Rvczwvb3B0aW9uPlxyXG4gICAgICA8b3B0aW9uICpuZ0Zvcj1cImxldCBjZW50cm9DdXN0byBvZiBjZW50cm9DdXN0b3NcIiBbdmFsdWVdPVwiY2VudHJvQ3VzdG8uaWRcIj5cclxuICAgICAgICB7eyBjZW50cm9DdXN0by5kZXNjcmlDQ3VzdG8gfX1cclxuICAgICAgPC9vcHRpb24+XHJcbiAgICA8L3NlbGVjdD4gICAgXHJcbiAgPC9kaXY+ICAgIFxyXG48L2Rpdj5cclxuXHJcbjxicj5cclxuXHJcbjxkaXY+XHJcblxyXG4gIDxkaXY+XHJcbiAgICA8ZGl2ICpuZ0lmPVwibGFuY2FtZW50b3MubGVuZ3RoID4gMDsgZWxzZSBub0xhbmNhbWVudG9zXCI+XHJcbiAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWQgdGFibGUtYm9yZGVyZWQgYWxpZ24tbWlkZGxlIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgIDx0aGVhZCBjbGFzcz1cInRhYmxlLWRhcmtcIj5cclxuICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgPHRoPkRhdGEgSG9yYTwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5WYWxvcjwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5EZXNjcmnDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICA8dGg+QcOnw7VlczwvdGg+XHJcbiAgICAgICAgICA8L3RyPlxyXG4gICAgICAgIDwvdGhlYWQ+XHJcblxyXG4gICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgIDx0ciAqbmdGb3I9XCJsZXQgbGFuY2FtZW50byBvZiBsYW5jYW1lbnRvc1wiIFtuZ0NsYXNzXT1cIntcclxuICAgICAgICAgICAgJ3N0YXR1cy12ZXJkZSc6IGxhbmNhbWVudG8uc3RhdHVzID09PSAnQSBQYWdhcicgfHwgbGFuY2FtZW50by5zdGF0dXMgPT09ICdBIFJlY2ViZXInLFxyXG4gICAgICAgICAgICAnc3RhdHVzLXZlcm1lbGhvJzogbGFuY2FtZW50by5kZXNjcmlDQ3VzdG8gPT09ICdFbXByw6lzdGltbydcclxuICAgICAgICAgIH1cIj5cclxuICAgICAgICAgICAgPHRkPnt7bGFuY2FtZW50by5kYXRhSG9yYSB8IGRhdGU6IFwiZGQvTU0veXl5eSBISDptbVwifX08L3RkPlxyXG4gICAgICAgICAgICA8dGQ+e3sgbGFuY2FtZW50by52YWxvciB8IGZvcm1hdFZhbG9yIH19PC90ZD5cclxuICAgICAgICAgICAgPHRkPnt7bGFuY2FtZW50by5kZXNjcmljYW99fTwvdGQ+XHJcbiAgICAgICAgICAgIDx0ZD57e2xhbmNhbWVudG8uc3RhdHVzfX08L3RkPlxyXG4gICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0bi1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiByb3V0ZXJMaW5rPVwiL2xhbmNhbWVudG8vZWRpdC97e2xhbmNhbWVudG8uaWR9fVwiIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5IGJ0bi1zbSBib3Rhby1lZGl0YXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJiaSBiaS1wZW5jaWwtc3F1YXJlXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHJvdXRlckxpbms9XCIvbGFuY2FtZW50by9leGNsdWlyL3t7bGFuY2FtZW50by5pZH19XCIgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLWRhbmdlciBidG4tc20gYm90YW8tcmVtb3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImJpIGJpLXRyYXNoXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICA8L3RyPlxyXG4gICAgICAgIDwvdGJvZHk+XHJcbiAgICAgIDwvdGFibGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxuZy10ZW1wbGF0ZSAjbm9MYW5jYW1lbnRvcz5cclxuICAgICAgPGgxPk7Do28gZXhpdGVtIHJlZ2lzdHJvcyBjYWRhc3RyYWRvcyA6UDwvaDE+XHJcbiAgICA8L25nLXRlbXBsYXRlPlxyXG5cclxuICAgIDxidXR0b24gbWF0LWZhYiBjb2xvcj1cInByaW1hcnlcIiBjbGFzcz1cImZhYlwiIHJvdXRlckxpbms9XCIvbGFuY2FtZW50by9ub3ZvL1wiPlxyXG4gICAgICA8bWF0LWljb24+YWRkPC9tYXQtaWNvbj5cclxuICAgIDwvYnV0dG9uPlxyXG5cclxuICAgIDxidXR0b24gbWF0LWZhYiBjb2xvcj1cInByaW1hcnlcIiBjbGFzcz1cImJ0bi1jb3BpYXJcIiAoY2xpY2spPVwiYWJyaXJDb3BpYXJMYW5jYW1lbnRvcygpXCI+XHJcbiAgICAgIDxtYXQtaWNvbj5jb250ZW50X2NvcHk8L21hdC1pY29uPlxyXG4gICAgPC9idXR0b24+XHJcblxyXG4gICAgPGFwcC1jb3BpYXItbGFuY2FtZW50b3NcclxuICAgICAgKm5nSWY9XCJpc0NvcGlhQWJlcnRvXCJcclxuICAgICAgW2xhbmNhbWVudG9zXT1cImxhbmNhbWVudG9zXCJcclxuICAgICAgKGZlY2hhcik9XCJmZWNoYXJDb3BpYXJMYW5jYW1lbnRvcygpXCI+XHJcbiAgICA8L2FwcC1jb3BpYXItbGFuY2FtZW50b3M+XHJcblxyXG4gIDwvZGl2PlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICdzcmMvZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuaW1wb3J0IHsgQW5hbGlzZUZpbmFuY2VpcmFJYVJlc3BvbnNlLCBDb25maWd1cmFjb2VzSUEgfSBmcm9tICdzcmMvdHlwZXMnO1xyXG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICcuLi9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJy4uL21lbnNhZ2Vucy9tZW5zYWdlbnMuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDb25maWd1cmFjb2VzSWFTZXJ2aWNlIHtcclxuXHJcbiAgcHJpdmF0ZSBiYXNlQXBpVXJsID0gZW52aXJvbm1lbnQuYmFzZUFwaVVybDtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlLCBwcml2YXRlIG1lbnNhZ2Vuc1NlcnZpY2U6IE1lbnNhZ2Vuc1NlcnZpY2UpIHsgfVxyXG5cclxuICBnZXRDb25maWd1cmFjYW9JQSgpOiBPYnNlcnZhYmxlPENvbmZpZ3VyYWNvZXNJQT4ge1xyXG4gICAgY29uc3QgaWRVc3VhcmlvID0gdGhpcy5sb2dpblNlcnZpY2UuZ2V0SWRVc3VhcmlvKCk7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxDb25maWd1cmFjb2VzSUE+KGAke3RoaXMuYmFzZUFwaVVybH1hcGkvY29uZmlndXJhY29lc2lhL3VzdWFyaW8vJHtpZFVzdWFyaW99YCkucGlwZShcclxuICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XHJcbiAgICAgICAgLy90aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0oJ2Vycm9yJywgJ0Vycm8nLCBgRXJybyBhbyBidXNjYXIgY29uZmlndXJhw6fDtWVzIElBOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycm9yKTtcclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBwdXRDb25maWd1cmFjYW9JQShwYXlsb2FkOiBDb25maWd1cmFjb2VzSUEsIGlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnB1dDx2b2lkPihcclxuICAgICAgYCR7dGhpcy5iYXNlQXBpVXJsfWFwaS9jb25maWd1cmFjb2VzaWEvJHtpZH1gLFxyXG4gICAgICB7XHJcbiAgICAgICAgLi4ucGF5bG9hZCxcclxuICAgICAgICBpZFxyXG4gICAgICB9XHJcbiAgICApLnBpcGUoXHJcbiAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgIHRoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnZXJyb3InLCAnRXJybycsIGBFcnJvIGFvIGF0dWFsaXphciBjb25maWd1cmHDp8O1ZXMgSUE6ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHBvc3RBbmFsaXNlRmluYW5jZWlyYUlhKFxyXG4gICAgZGF0YURlOiBzdHJpbmcsXHJcbiAgICBkYXRhQXRlOiBzdHJpbmcsXHJcbiAgICB0ZXh0b0F1eGlsaWFyOiBzdHJpbmdcclxuICApOiBPYnNlcnZhYmxlPEFuYWxpc2VGaW5hbmNlaXJhSWFSZXNwb25zZT4ge1xyXG5cclxuICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgIGlkVXN1YXJpbzogTnVtYmVyKHRoaXMubG9naW5TZXJ2aWNlLmdldElkVXN1YXJpbygpKSxcclxuICAgICAgZGF0YURlLFxyXG4gICAgICBkYXRhQXRlLFxyXG4gICAgICB0ZXh0b0F1eGlsaWFyXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxBbmFsaXNlRmluYW5jZWlyYUlhUmVzcG9uc2U+KFxyXG4gICAgICBgJHt0aGlzLmJhc2VBcGlVcmx9YXBpL2FuYWxpc2VmaW5hbmNlaXJhaWFgLFxyXG4gICAgICBib2R5XHJcbiAgICApLnBpcGUoXHJcbiAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xyXG4gICAgICAgIHRoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnZXJyb3InLCAnRXJybycsIGBFcnJvIGFvIGFuYWxpc2FyIGZpbmFuw6dhcyBjb20gSUE6ICR7ZXJyb3Iuc3RhdHVzfWAsIHVuZGVmaW5lZCk7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDaGFydERhdGEsIENoYXJ0T3B0aW9ucyB9IGZyb20gJ2NoYXJ0LmpzJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbWVuc2FnZW5zL21lbnNhZ2Vucy5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWRvbnV0LWNoYXJ0JyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZG9udXQtY2hhcnQuY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2RvbnV0LWNoYXJ0LmNvbXBvbmVudC5jc3MnXSxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRG9udXRDaGFydENvbXBvbmVudCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbWVuc2FnZW5zU2VydmljZTogTWVuc2FnZW5zU2VydmljZSkgeyB9XHJcblxyXG4gIHByaXZhdGUgX2Rlc3Blc2FzR3JhZmljb0RvbnV0ID0gMDtcclxuICBwcml2YXRlIF9yZWNlaXRhc0dyYWZpY29Eb251dCA9IDA7XHJcblxyXG4gIEBJbnB1dCgpIHNldCBkZXNwZXNhc0dyYWZpY29Eb251dCh2YWx1ZTogbnVtYmVyKSB7XHJcbiAgICB0aGlzLl9kZXNwZXNhc0dyYWZpY29Eb251dCA9IHZhbHVlIHx8IDA7XHJcbiAgICB0aGlzLnVwZGF0ZUNoYXJ0RGF0YSgpO1xyXG4gIH1cclxuXHJcbiAgQElucHV0KCkgc2V0IHJlY2VpdGFzR3JhZmljb0RvbnV0KHZhbHVlOiBudW1iZXIpIHtcclxuICAgIHRoaXMuX3JlY2VpdGFzR3JhZmljb0RvbnV0ID0gdmFsdWUgfHwgMDtcclxuICAgIHRoaXMudXBkYXRlQ2hhcnREYXRhKCk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZG9udXRDaGFydE9wdGlvbnM6IENoYXJ0T3B0aW9uczwnZG91Z2hudXQnPiA9IHtcclxuICAgIHJlc3BvbnNpdmU6IHRydWUsXHJcbiAgICBjdXRvdXQ6ICc3MCUnLFxyXG4gICAgcGx1Z2luczogeyBsZWdlbmQ6IHsgZGlzcGxheTogZmFsc2UgfSB9XHJcbiAgfTtcclxuXHJcbiAgcHVibGljIGRvbnV0Q2hhcnREYXRhOiBDaGFydERhdGE8J2RvdWdobnV0Jz4gPSB7XHJcbiAgICBsYWJlbHM6IFsnUmVjZWl0YScsICdHYXN0b3MnXSxcclxuICAgIGRhdGFzZXRzOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBkYXRhOiBbMCwgMF0sXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBbJyMyOGE3NDUnLCAnI2RjMzU0NSddLFxyXG4gICAgICAgIGhvdmVyQmFja2dyb3VuZENvbG9yOiBbJyMyMTg4MzgnLCAnI2M4MjMzMyddXHJcbiAgICAgIH1cclxuICAgIF1cclxuICB9O1xyXG5cclxuICBwcml2YXRlIHVwZGF0ZUNoYXJ0RGF0YSgpIHtcclxuICAgIGxldCBiYWNrZ3JvdW5kQ29sb3JzOiBzdHJpbmdbXTtcclxuICAgIGxldCBob3ZlckNvbG9yczogc3RyaW5nW107XHJcblxyXG4gICAgaWYgKHRoaXMuX2Rlc3Blc2FzR3JhZmljb0RvbnV0ID4gMCAmJiB0aGlzLl9yZWNlaXRhc0dyYWZpY29Eb251dCA9PT0gMCkge1xyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3JzID0gWycjZGMzNTQ1JywgJyNkYzM1NDUnXTtcclxuICAgICAgaG92ZXJDb2xvcnMgPSBbJyNjODIzMzMnLCAnI2M4MjMzMyddO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLl9yZWNlaXRhc0dyYWZpY29Eb251dCA+IDAgJiYgdGhpcy5fZGVzcGVzYXNHcmFmaWNvRG9udXQgPT09IDApIHtcclxuICAgICAgYmFja2dyb3VuZENvbG9ycyA9IFsnIzI4YTc0NScsICcjMjhhNzQ1J107XHJcbiAgICAgIGhvdmVyQ29sb3JzID0gWycjMjE4ODM4JywgJyMyMTg4MzgnXTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcnMgPSBbJyMyOGE3NDUnLCAnI2RjMzU0NSddO1xyXG4gICAgICBob3ZlckNvbG9ycyA9IFsnIzIxODgzOCcsICcjYzgyMzMzJ107XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5kb251dENoYXJ0RGF0YSA9IHtcclxuICAgICAgLi4udGhpcy5kb251dENoYXJ0RGF0YSxcclxuICAgICAgZGF0YXNldHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAuLi50aGlzLmRvbnV0Q2hhcnREYXRhLmRhdGFzZXRzWzBdLFxyXG4gICAgICAgICAgZGF0YTogW3RoaXMuX3JlY2VpdGFzR3JhZmljb0RvbnV0LCB0aGlzLl9kZXNwZXNhc0dyYWZpY29Eb251dF0sXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGJhY2tncm91bmRDb2xvcnMsXHJcbiAgICAgICAgICBob3ZlckJhY2tncm91bmRDb2xvcjogaG92ZXJDb2xvcnNcclxuICAgICAgICB9XHJcbiAgICAgIF1cclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBvbkNoYXJ0Q2xpY2soZXZlbnQ6IGFueSkge1xyXG4gICAgLy8gQXBlbmFzIGFicmUgbW9kYWwgc2UgaG91dmVyIGRhZG9zXHJcbiAgICBpZiAodGhpcy5fZGVzcGVzYXNHcmFmaWNvRG9udXQgPT09IDAgJiYgdGhpcy5fcmVjZWl0YXNHcmFmaWNvRG9udXQgPT09IDApIHJldHVybjtcclxuXHJcbiAgICB0aGlzLm1lbnNhZ2Vuc1NlcnZpY2UubWVuc2FnZW0odW5kZWZpbmVkLCAnRGV0YWxoZXMnLCB1bmRlZmluZWQsIGBcclxuICAgIDxwPjxzdHJvbmc+UmVjZWl0YTo8L3N0cm9uZz4gUiQgJHt0aGlzLl9yZWNlaXRhc0dyYWZpY29Eb251dC50b0ZpeGVkKDIpfTwvcD5cclxuICAgIDxwPjxzdHJvbmc+R2FzdG9zOjwvc3Ryb25nPiBSJCAke3RoaXMuX2Rlc3Blc2FzR3JhZmljb0RvbnV0LnRvRml4ZWQoMil9PC9wPlxyXG4gICAgPHA+PHN0cm9uZz5TYWxkbzo8L3N0cm9uZz4gUiQgJHsodGhpcy5fcmVjZWl0YXNHcmFmaWNvRG9udXQgLSB0aGlzLl9kZXNwZXNhc0dyYWZpY29Eb251dCkudG9GaXhlZCgyKX08L3A+XHJcbiAgYCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCI8Y2FudmFzXHJcbiAgYmFzZUNoYXJ0XHJcbiAgW2RhdGFdPVwiZG9udXRDaGFydERhdGFcIlxyXG4gIFtvcHRpb25zXT1cImRvbnV0Q2hhcnRPcHRpb25zXCJcclxuICBbdHlwZV09XCInZG91Z2hudXQnXCJcclxuICAoY2hhcnRDbGljayk9XCJvbkNoYXJ0Q2xpY2soJGV2ZW50KVwiPlxyXG48L2NhbnZhcz4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcG9wLXVwLWNlbnRyby1jdXN0bycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3BvcC11cC1jZW50cm8tY3VzdG8uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9wb3AtdXAtY2VudHJvLWN1c3RvLmNvbXBvbmVudC5jc3MnLFxyXG4gIHN0YW5kYWxvbmU6IGZhbHNlXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBQb3BVcENlbnRyb0N1c3RvQ29tcG9uZW50IHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXI6IFJvdXRlcikgeyB9XHJcblxyXG4gIEBJbnB1dCgpIGFiZXJ0bzogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAvL3JlY2ViZSBleGF0YW1lbnRlIG8gYXJyYXkgcHJlZW5jaGlkbyBubyBtw6l0b2RvIGRvIHBhaVxyXG4gIEBJbnB1dCgpIGRldGFsaGFtZW50b0dhc3Rvc0NDOiBhbnlbXSA9IFtdO1xyXG5cclxuICBAT3V0cHV0KCkgZmVjaGFyID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xyXG5cclxuICBhYnJpckVkaWNhbyhpZDogbnVtYmVyKSB7XHJcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoJ25vLXNjcm9sbCcpO1xyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvbGFuY2FtZW50by9lZGl0JywgaWRdKTtcclxuICB9XHJcblxyXG4gIGFicmlyRXhjbHVzYW8oaWQ6IG51bWJlcikge1xyXG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKCduby1zY3JvbGwnKTtcclxuICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL2xhbmNhbWVudG8vZXhjbHVpcicsIGlkXSk7XHJcbiAgfVxyXG5cclxuICBmZWNoYXJQb3B1cCgpIHtcclxuICAgIHRoaXMuZmVjaGFyLmVtaXQoKTtcclxuICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZSgnbm8tc2Nyb2xsJyk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCI8ZGl2IGNsYXNzPVwib3ZlcmxheVwiICpuZ0lmPVwiYWJlcnRvXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwicG9wdXBcIj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInBvcHVwLWhlYWRlclwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJ0aXR1bG8taDNcIj5EZXRhbGhhbWVudG8gcG9yIENlbnRybyBkZSBDdXN0bzwvaDM+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tZmVjaGFyXCIgKGNsaWNrKT1cImZlY2hhclBvcHVwKClcIj7DlzwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicG9wdXAtYm9keVwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj1cImRldGFsaGFtZW50b0dhc3Rvc0NDLmxlbmd0aCA+IDA7IGVsc2Ugbm9SZWdpc3Ryb3NcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWQgdGFibGUtYm9yZGVyZWQgYWxpZ24tbWlkZGxlIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzcz1cInRhYmxlLWRhcmtcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkRhdGEgSG9yYTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+VmFsb3I8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkRlc2NyacOnw6NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5Bw6fDtWVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciAqbmdGb3I9XCJsZXQgaXRlbSBvZiBkZXRhbGhhbWVudG9HYXN0b3NDQ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IGl0ZW0uZGF0YUhvcmEgfCBkYXRlOiAnZGQvTU0veXl5eSBISDptbScgfX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IGl0ZW0udmFsb3IgfCBmb3JtYXRWYWxvciB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3sgaXRlbS5kZXNjcmljYW9MYW5jYW1lbnRvIH19PC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0bi1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5IGJ0bi1zbSBib3Rhby1lZGl0YXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImFicmlyRWRpY2FvKGl0ZW0uaWQpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImJpIGJpLXBlbmNpbC1zcXVhcmVcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtZGFuZ2VyIGJ0bi1zbSBib3Rhby1yZW1vdmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJhYnJpckV4Y2x1c2FvKGl0ZW0uaWQpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImJpIGJpLXRyYXNoXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjbm9SZWdpc3Ryb3M+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtY2VudGVyIG10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICBOw6NvIGV4aXN0ZW0gcmVnaXN0cm9zIHBhcmEgZXN0ZSBjZW50cm8gZGUgY3VzdG8uXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENvbmZpZ3VyYWNvZXNJYVNlcnZpY2UgfSBmcm9tICdzcmMvYXBwL3NlcnZpY2VzL2NvbmZpZ3VyYWNvZXMtaWEvY29uZmlndXJhY29lcy1pYS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTWVuc2FnZW5zU2VydmljZSB9IGZyb20gJ3NyYy9hcHAvc2VydmljZXMvbWVuc2FnZW5zL21lbnNhZ2Vucy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29uZmlndXJhY29lc0lBIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWNvbmZpZ3VyYWNvZXMtaWEnLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9jb25maWd1cmFjb2VzLWlhLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9jb25maWd1cmFjb2VzLWlhLmNvbXBvbmVudC5jc3MnXSxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ29uZmlndXJhY29lc0lhQ29tcG9uZW50IHtcclxuXHJcbiAgY29uZmlndXJhY29lc0lBRm9ybSE6IEZvcm1Hcm91cDtcclxuICBwdWJsaWMgbGlzdGFDb25maWd1cmFjb2VzSUE6IENvbmZpZ3VyYWNvZXNJQVtdID0gW107XHJcbiAgQE91dHB1dCgpIG9uU3VibWl0ID0gbmV3IEV2ZW50RW1pdHRlcjxDb25maWd1cmFjb2VzSUE+KCk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY29uZmlndXJhY29lc0lBU2VydmljZTogQ29uZmlndXJhY29lc0lhU2VydmljZSwgcHJpdmF0ZSBtZW5zYWdlbnNTZXJ2aWNlOiBNZW5zYWdlbnNTZXJ2aWNlKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICB0aGlzLmJ1c2NhckNvbmZpZ3VyYWNhb0lBKCk7XHJcblxyXG4gICAgdGhpcy5jb25maWd1cmFjb2VzSUFGb3JtID0gbmV3IEZvcm1Hcm91cCh7XHJcbiAgICAgIGlkOiBuZXcgRm9ybUNvbnRyb2woJycpLFxyXG4gICAgICBmaWx0cm9EYXRhRGU6IG5ldyBGb3JtQ29udHJvbCgnJywgVmFsaWRhdG9ycy5yZXF1aXJlZCksXHJcbiAgICAgIGZpbHRyb0RhdGFBdGU6IG5ldyBGb3JtQ29udHJvbCgnJywgVmFsaWRhdG9ycy5yZXF1aXJlZCksXHJcbiAgICAgIHByb21wdDogbmV3IEZvcm1Db250cm9sKCcnLCBWYWxpZGF0b3JzLnJlcXVpcmVkKSxcclxuICAgICAgaWRVc3VhcmlvOiBuZXcgRm9ybUNvbnRyb2woJycpXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGJ1c2NhckNvbmZpZ3VyYWNhb0lBKCkge1xyXG4gICAgdGhpcy5jb25maWd1cmFjb2VzSUFTZXJ2aWNlLmdldENvbmZpZ3VyYWNhb0lBKCkuc3Vic2NyaWJlKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoIWl0ZW0pIHtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5jb25maWd1cmFjb2VzSUFGb3JtLnBhdGNoVmFsdWUoe1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgZmlsdHJvRGF0YURlOiB0aGlzLmZvcm1hdGFyRGF0YShpdGVtLmZpbHRyb0RhdGFEZSksXHJcbiAgICAgICAgZmlsdHJvRGF0YUF0ZTogdGhpcy5mb3JtYXRhckRhdGEoaXRlbS5maWx0cm9EYXRhQXRlKVxyXG4gICAgICB9KTtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5jb25maWd1cmFjb2VzSUFGb3JtKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZm9ybWF0YXJEYXRhKGRhdGE6IHN0cmluZyB8IERhdGUpOiBzdHJpbmcge1xyXG4gICAgaWYgKCFkYXRhKSByZXR1cm4gJyc7XHJcblxyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGEpO1xyXG4gICAgcmV0dXJuIGQudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGlkKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlndXJhY29lc0lBRm9ybS5nZXQoJ2lkJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGZpbHRyb0RhdGFEZSgpIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0uZ2V0KCdmaWx0cm9EYXRhRGUnKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgZmlsdHJvRGF0YUF0ZSgpIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0uZ2V0KCdmaWx0cm9EYXRhQXRlJykhO1xyXG4gIH1cclxuXHJcbiAgZ2V0IHByb21wdCgpIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0uZ2V0KCdwcm9tcHQnKSE7XHJcbiAgfVxyXG5cclxuICBnZXQgaWRVc3VhcmlvKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlndXJhY29lc0lBRm9ybS5nZXQoJ2lkVXN1YXJpbycpITtcclxuICB9XHJcblxyXG4gIHN1Ym1pdCgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0uaW52YWxpZCkge1xyXG4gICAgICB0aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0ubWFya0FsbEFzVG91Y2hlZCgpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcGF5bG9hZDogQ29uZmlndXJhY29lc0lBID0ge1xyXG4gICAgICAuLi50aGlzLmNvbmZpZ3VyYWNvZXNJQUZvcm0udmFsdWVcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaWRSZWdpc3RybyA9IHRoaXMuaWQudmFsdWU7XHJcblxyXG4gICAgdGhpcy5jb25maWd1cmFjb2VzSUFTZXJ2aWNlLnB1dENvbmZpZ3VyYWNhb0lBKHBheWxvYWQsIGlkUmVnaXN0cm8pXHJcbiAgICAgIC5zdWJzY3JpYmUoe1xyXG4gICAgICAgIG5leHQ6ICgpID0+IHtcclxuICAgICAgICAgIHRoaXMubWVuc2FnZW5zU2VydmljZS5tZW5zYWdlbSgnc3VjY2VzcycsIHVuZGVmaW5lZCwgJ0NvbmZpZ3VyYcOnw7VlcyBkZSBJQSBhdHVhbGl6YWRhcyBjb20gc3VjZXNzbyEnLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXHJcbiAgICAgICAgZXJyb3I6IChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsIHVuZGVmaW5lZCwgJ08gc2VndWludGUgZXJybyBmb2kgYXByZXNlbnRhZG86ICR7ZXJyb3J9JywgdW5kZWZpbmVkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG59XHJcbiIsIjxmb3JtIChuZ1N1Ym1pdCk9XCJzdWJtaXQoKVwiIFtmb3JtR3JvdXBdPVwiY29uZmlndXJhY29lc0lBRm9ybVwiPlxyXG4gICAgPGgxIGNsYXNzPVwiaDFcIj5Db25maWd1cmHDp8O1ZXMgSUE8L2gxPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwiZmlsdHJvRGF0YURlXCI+RGF0YSBEZTo8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIHBsYWNlaG9sZGVyPVwiXCIgZm9ybUNvbnRyb2xOYW1lPVwiZmlsdHJvRGF0YURlXCI+XHJcbiAgICAgICAgPGRpdiAqbmdJZj1cImZpbHRyb0RhdGFEZS5pbnZhbGlkICYmIGNvbmZpZ3VyYWNvZXNJQUZvcm0udG91Y2hlZFwiIGNsYXNzPVwidmFsaWRhdGlvbi1lcnJvclwiPlxyXG4gICAgICAgICAgICA8cCAqbmdJZj1cImZpbHRyb0RhdGFEZS5lcnJvcnM/LlsncmVxdWlyZWQnXVwiPkEgZGF0YSDDqSBvYnJpZ2F0w7NyaWEuPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJmaWx0cm9EYXRhQXRlXCI+RGF0YSBBdMOpOjwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgcGxhY2Vob2xkZXI9XCJcIiBmb3JtQ29udHJvbE5hbWU9XCJmaWx0cm9EYXRhQXRlXCI+XHJcbiAgICAgICAgPGRpdiAqbmdJZj1cImZpbHRyb0RhdGFBdGUuaW52YWxpZCAmJiBjb25maWd1cmFjb2VzSUFGb3JtLnRvdWNoZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJmaWx0cm9EYXRhQXRlLmVycm9ycz8uWydyZXF1aXJlZCddXCI+QSBkYXRhIMOpIG9icmlnYXTDs3JpYS48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cInByb21wdFwiPlByb21wdDo8L2xhYmVsPlxyXG4gICAgICAgIDx0ZXh0YXJlYSBjbGFzcz1cInRleHRhcmVhXCIgcGxhY2Vob2xkZXI9XCJEZXNjcmnDp8OjbyBkbyBQcm9tcHRcIiBmb3JtQ29udHJvbE5hbWU9XCJwcm9tcHRcIj48L3RleHRhcmVhPlxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJwcm9tcHQuaW52YWxpZCAmJiBjb25maWd1cmFjb2VzSUFGb3JtLnRvdWNoZWRcIiBjbGFzcz1cInZhbGlkYXRpb24tZXJyb3JcIj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJwcm9tcHQuZXJyb3JzPy5bJ3JlcXVpcmVkJ11cIj5BIGRlc2NyacOnw6NvIMOpIG9icmlnYXTDs3JpYS48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzPVwiYnRuLXNhbHZhclwiIFtkaXNhYmxlZF09XCJjb25maWd1cmFjb2VzSUFGb3JtLmludmFsaWRcIj5cclxuICAgICAgICBTYWx2YXJcclxuICAgIDwvYnV0dG9uPlxyXG48L2Zvcm0+IiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU2FmZUh0bWwgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLXBvcC11cC1pYScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3BvcC11cC1pYS5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL3BvcC11cC1pYS5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgUG9wVXBJYUNvbXBvbmVudCB7IFxyXG5cclxuICBASW5wdXQoKSBodG1sSWE/OiBTYWZlSHRtbDtcclxuICBAT3V0cHV0KCkgZmVjaGFyID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xyXG5cclxufVxyXG4iLCI8ZGl2IGNsYXNzPVwib3ZlcmxheVwiIChjbGljayk9XCJmZWNoYXIuZW1pdCgpXCI+XHJcbiAgPGRpdiBjbGFzcz1cInBvcHVwXCIgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiPlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJwb3B1cC1oZWFkZXJcIj5cclxuICAgICAgPHNwYW4+8J+SoSBJbnNpZ2h0IGRhIElBPC9zcGFuPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzPVwiY2xvc2UtYnRuXCIgKGNsaWNrKT1cImZlY2hhci5lbWl0KClcIj7inJU8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJwb3B1cC1jb250ZW50XCIgW2lubmVySFRNTF09XCJodG1sSWFcIj48L2Rpdj5cclxuXHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBMYW5jYW1lbnRvIH0gZnJvbSAnc3JjL3R5cGVzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLWNvcGlhci1sYW5jYW1lbnRvcycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2NvcGlhci1sYW5jYW1lbnRvcy5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL2NvcGlhci1sYW5jYW1lbnRvcy5jb21wb25lbnQuY3NzJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIENvcGlhckxhbmNhbWVudG9zQ29tcG9uZW50IHtcclxuXHJcbiAgQElucHV0KCkgbGFuY2FtZW50b3M6IExhbmNhbWVudG9bXSA9IFtdO1xyXG4gIEBPdXRwdXQoKSBmZWNoYXIgPSBuZXcgRXZlbnRFbWl0dGVyPHZvaWQ+KCk7XHJcbiAgc2VsZWN0ZWRMYW5jYW1lbnRvczogbnVtYmVyW10gPSBbXTtcclxuXHJcbiAgdG9nZ2xlU2VsZWNhbyhpZDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuc2VsZWN0ZWRMYW5jYW1lbnRvcy5pbmRleE9mKGlkKTtcclxuICAgIGlmIChpbmRleCA+IC0xKSB7XHJcbiAgICAgIHRoaXMuc2VsZWN0ZWRMYW5jYW1lbnRvcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5zZWxlY3RlZExhbmNhbWVudG9zLnB1c2goaWQpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaXNTZWxlY2lvbmFkbyhpZDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy5zZWxlY3RlZExhbmNhbWVudG9zLmluY2x1ZGVzKGlkKTtcclxuICB9XHJcblxyXG4gIHNlbGVjaW9uYXJUb2RvcyhldmVudDogYW55KTogdm9pZCB7XHJcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmNoZWNrZWQpIHtcclxuICAgICAgdGhpcy5zZWxlY3RlZExhbmNhbWVudG9zID0gdGhpcy5sYW5jYW1lbnRvcy5tYXAobCA9PiBsLmlkKS5maWx0ZXIoKGlkKTogaWQgaXMgbnVtYmVyID0+IGlkICE9PSB1bmRlZmluZWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5zZWxlY3RlZExhbmNhbWVudG9zID0gW107XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb3BpYXJTZWxlY2lvbmFkb3MoKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5zZWxlY3RlZExhbmNhbWVudG9zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRmlsdHJhciBhcGVuYXMgb3MgbGFuw6dhbWVudG9zIHNlbGVjaW9uYWRvc1xyXG4gICAgY29uc3QgbGFuY2FtZW50b3NTZWxlY2lvbmFkb3MgPSB0aGlzLmxhbmNhbWVudG9zLmZpbHRlcihsID0+IHRoaXMuc2VsZWN0ZWRMYW5jYW1lbnRvcy5pbmNsdWRlcyhsLmlkISkpO1xyXG5cclxuICAgIC8vIEFncnVwYXIgcG9yIGRhdGFcclxuICAgIGNvbnN0IGxhbmNhbWVudG9zUG9yRGF0YSA9IG5ldyBNYXA8c3RyaW5nLCB0eXBlb2YgbGFuY2FtZW50b3NTZWxlY2lvbmFkb3M+KCk7XHJcbiAgICBsYW5jYW1lbnRvc1NlbGVjaW9uYWRvcy5mb3JFYWNoKGxhbmNhbWVudG8gPT4ge1xyXG4gICAgICBjb25zdCBkYXRhID0gbmV3IERhdGUobGFuY2FtZW50by5kYXRhSG9yYSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdwdC1CUicpO1xyXG4gICAgICBpZiAoIWxhbmNhbWVudG9zUG9yRGF0YS5oYXMoZGF0YSkpIHtcclxuICAgICAgICBsYW5jYW1lbnRvc1BvckRhdGEuc2V0KGRhdGEsIFtdKTtcclxuICAgICAgfVxyXG4gICAgICBsYW5jYW1lbnRvc1BvckRhdGEuZ2V0KGRhdGEpIS5wdXNoKGxhbmNhbWVudG8pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gQ2FsY3VsYXIgbyB0b3RhbFxyXG4gICAgY29uc3QgdG90YWwgPSBsYW5jYW1lbnRvc1NlbGVjaW9uYWRvcy5yZWR1Y2UoKHN1bSwgbGFuY2FtZW50bykgPT4gc3VtICsgbGFuY2FtZW50by52YWxvciwgMCk7XHJcblxyXG4gICAgLy8gRm9ybWF0YXIgb3MgZGFkb3MgcGFyYSBjw7NwaWFcclxuICAgIGxldCB0ZXh0b1BhcmFDb3BpYXIgPSAnJztcclxuXHJcbiAgICAvLyBPcmRlbmFyIGRhdGFzIGUgcHJvY2Vzc2FyXHJcbiAgICBjb25zdCBkYXRhc09yZGVuYWRhcyA9IEFycmF5LmZyb20obGFuY2FtZW50b3NQb3JEYXRhLmtleXMoKSkuc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICBjb25zdCBbZGlhQSwgbWVzQSwgYW5vQV0gPSBhLnNwbGl0KCcvJykubWFwKE51bWJlcik7XHJcbiAgICAgIGNvbnN0IFtkaWFCLCBtZXNCLCBhbm9CXSA9IGIuc3BsaXQoJy8nKS5tYXAoTnVtYmVyKTtcclxuICAgICAgcmV0dXJuIG5ldyBEYXRlKGFub0EsIG1lc0EgLSAxLCBkaWFBKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShhbm9CLCBtZXNCIC0gMSwgZGlhQikuZ2V0VGltZSgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgZGF0YXNPcmRlbmFkYXMuZm9yRWFjaChkYXRhID0+IHtcclxuICAgICAgdGV4dG9QYXJhQ29waWFyICs9IGAke2RhdGF9XFxuYDtcclxuICAgICAgY29uc3QgbGFuY2FtZW50b3NEYXRhID0gbGFuY2FtZW50b3NQb3JEYXRhLmdldChkYXRhKSE7XHJcbiAgICAgIFxyXG4gICAgICBsYW5jYW1lbnRvc0RhdGEuZm9yRWFjaChsYW5jYW1lbnRvID0+IHtcclxuICAgICAgICBjb25zdCB2YWxvciA9IGxhbmNhbWVudG8udmFsb3IudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywgeyBcclxuICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgXHJcbiAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGV4dG9QYXJhQ29waWFyICs9IGBSJCAke3ZhbG9yfSAtICR7bGFuY2FtZW50by5kZXNjcmljYW99XFxuYDtcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB0ZXh0b1BhcmFDb3BpYXIgKz0gJ1xcbic7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXh0b1BhcmFDb3BpYXIgKz0gYFZhbG9yIFRvdGFsOiBSJCAke3RvdGFsLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHsgXHJcbiAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgXHJcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMiBcclxuICAgIH0pfWA7XHJcblxyXG4gICAgLy8gVGVudGFyIGNvcGlhciB1c2FuZG8gZGlmZXJlbnRlcyBtw6l0b2Rvc1xyXG4gICAgdGhpcy5jb3BpYXJQYXJhQ2xpcGJvYXJkKHRleHRvUGFyYUNvcGlhcikudGhlbigoKSA9PiB7XHJcbiAgICAgIHRoaXMuZmVjaGFyUG9wdXAoKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm8gYW8gY29waWFyIHBhcmEgw6FyZWEgZGUgdHJhbnNmZXLDqm5jaWE6JywgZXJyKTtcclxuICAgICAgdGhpcy5tb3N0cmFyVGV4dG9QYXJhQ29waWFyKHRleHRvUGFyYUNvcGlhcik7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgYXN5bmMgY29waWFyUGFyYUNsaXBib2FyZCh0ZXh0bzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICAvLyBNw6l0b2RvIDE6IFVzYXIgbmF2aWdhdG9yLmNsaXBib2FyZCAobW9kZXJubylcclxuICAgIGlmIChuYXZpZ2F0b3IuY2xpcGJvYXJkICYmIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KSB7XHJcbiAgICAgIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHRleHRvKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE3DqXRvZG8gMjogRmFsbGJhY2sgY29tIGRvY3VtZW50LmV4ZWNDb21tYW5kXHJcbiAgICBjb25zdCB0ZXh0QXJlYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RleHRhcmVhJyk7XHJcbiAgICB0ZXh0QXJlYS52YWx1ZSA9IHRleHRvO1xyXG4gICAgdGV4dEFyZWEuc3R5bGUucG9zaXRpb24gPSAnZml4ZWQnO1xyXG4gICAgdGV4dEFyZWEuc3R5bGUubGVmdCA9ICctOTk5OTk5cHgnO1xyXG4gICAgdGV4dEFyZWEuc3R5bGUudG9wID0gJy05OTk5OTlweCc7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRleHRBcmVhKTtcclxuICAgIHRleHRBcmVhLmZvY3VzKCk7XHJcbiAgICB0ZXh0QXJlYS5zZWxlY3QoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBzdWNjZXNzZnVsID0gZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2NvcHknKTtcclxuICAgICAgaWYgKCFzdWNjZXNzZnVsKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWxoYSBubyBleGVjQ29tbWFuZCcpO1xyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRleHRBcmVhKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgbW9zdHJhclRleHRvUGFyYUNvcGlhcih0ZXh0bzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAvLyBDcmlhciB1bSBtb2RhbCBvdSBhbGVydCBjb20gbyB0ZXh0byBwYXJhIGNvcGlhciBtYW51YWxtZW50ZVxyXG4gICAgY29uc3QgbW9kYWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIG1vZGFsLnN0eWxlLmNzc1RleHQgPSBgXHJcbiAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgdG9wOiAwO1xyXG4gICAgICBsZWZ0OiAwO1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuOCk7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICB6LWluZGV4OiA5OTk5O1xyXG4gICAgYDtcclxuXHJcbiAgICBjb25zdCBjb250ZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBjb250ZW50LnN0eWxlLmNzc1RleHQgPSBgXHJcbiAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgIG1heC13aWR0aDogNTAwcHg7XHJcbiAgICAgIHdpZHRoOiA5MCU7XHJcbiAgICAgIG1heC1oZWlnaHQ6IDcwdmg7XHJcbiAgICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBgO1xyXG5cclxuICAgIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8aDM+Q29waWUgbyB0ZXh0byBhYmFpeG86PC9oMz5cclxuICAgICAgPHRleHRhcmVhIHN0eWxlPVwid2lkdGg6IDEwMCU7IGhlaWdodDogMjAwcHg7IG1hcmdpbjogMTBweCAwOyBwYWRkaW5nOiAxMHB4OyBib3JkZXI6IDFweCBzb2xpZCAjY2NjOyBib3JkZXItcmFkaXVzOiA0cHg7IGZvbnQtZmFtaWx5OiBtb25vc3BhY2U7XCIgcmVhZG9ubHk+JHt0ZXh0b308L3RleHRhcmVhPlxyXG4gICAgICA8ZGl2IHN0eWxlPVwidGV4dC1hbGlnbjogcmlnaHQ7XCI+XHJcbiAgICAgICAgPGJ1dHRvbiBpZD1cImZlY2hhci1tb2RhbFwiIHN0eWxlPVwicGFkZGluZzogOHB4IDE2cHg7IGJhY2tncm91bmQ6ICMwMDdiZmY7IGNvbG9yOiB3aGl0ZTsgYm9yZGVyOiBub25lOyBib3JkZXItcmFkaXVzOiA0cHg7IGN1cnNvcjogcG9pbnRlcjtcIj5GZWNoYXI8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG5cclxuICAgIG1vZGFsLmFwcGVuZENoaWxkKGNvbnRlbnQpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChtb2RhbCk7XHJcblxyXG4gICAgLy8gRm9jYXIgYXV0b21hdGljYW1lbnRlIG5vIHRleHRhcmVhXHJcbiAgICBjb25zdCB0ZXh0YXJlYSA9IGNvbnRlbnQucXVlcnlTZWxlY3RvcigndGV4dGFyZWEnKSBhcyBIVE1MVGV4dEFyZWFFbGVtZW50O1xyXG4gICAgdGV4dGFyZWEuZm9jdXMoKTtcclxuICAgIHRleHRhcmVhLnNlbGVjdCgpO1xyXG5cclxuICAgIC8vIEZ1bsOnw6NvIHBhcmEgZmVjaGFyIG8gbW9kYWxcclxuICAgIGNvbnN0IGZlY2hhck1vZGFsID0gKCkgPT4ge1xyXG4gICAgICBpZiAoZG9jdW1lbnQuYm9keS5jb250YWlucyhtb2RhbCkpIHtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKG1vZGFsKTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmZlY2hhclBvcHVwKCk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEV2ZW50byBwYXJhIGZlY2hhciBjb20gYm90w6NvXHJcbiAgICBjb25zdCBmZWNoYXJCdG4gPSBjb250ZW50LnF1ZXJ5U2VsZWN0b3IoJyNmZWNoYXItbW9kYWwnKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcclxuICAgIGZlY2hhckJ0bi5vbmNsaWNrID0gZmVjaGFyTW9kYWw7XHJcblxyXG4gICAgLy8gRXZlbnRvIHBhcmEgZmVjaGFyIGNvbSBFU0NcclxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xyXG4gICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XHJcbiAgICAgICAgZmVjaGFyTW9kYWwoKTtcclxuICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xyXG4gIH1cclxuXHJcbiAgZmVjaGFyUG9wdXAoKSB7XHJcbiAgICB0aGlzLmxhbmNhbWVudG9zID0gW107XHJcbiAgICB0aGlzLnNlbGVjdGVkTGFuY2FtZW50b3MgPSBbXTtcclxuICAgIHRoaXMuZmVjaGFyLmVtaXQoKTtcclxuICB9XHJcblxyXG59XHJcbiIsIjxkaXYgY2xhc3M9XCJvdmVybGF5XCIgKGNsaWNrKT1cImZlY2hhclBvcHVwKClcIj5cclxuICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGVudFwiIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKClcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cclxuICAgICAgPGgyPkNvcGlhciBMYW7Dp2FtZW50b3M8L2gyPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWNsb3NlXCIgKGNsaWNrKT1cImZlY2hhclBvcHVwKClcIiBhcmlhLWxhYmVsPVwiRmVjaGFyXCI+XHJcbiAgICAgICAgPHNwYW4+JnRpbWVzOzwvc3Bhbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxyXG4gICAgICA8ZGl2ICpuZ0lmPVwibGFuY2FtZW50b3MubGVuZ3RoID4gMDsgZWxzZSBub0xhbmNhbWVudG9zXCI+XHJcbiAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtc3RyaXBlZCB0YWJsZS1ib3JkZXJlZCBhbGlnbi1taWRkbGUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICA8dGhlYWQgY2xhc3M9XCJ0YWJsZS1kYXJrXCI+XHJcbiAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICA8dGg+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIChjaGFuZ2UpPVwic2VsZWNpb25hclRvZG9zKCRldmVudClcIiAvPjwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPkRhdGEgSG9yYTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPlZhbG9yPC90aD5cclxuICAgICAgICAgICAgICA8dGg+RGVzY3Jpw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgIDx0aD5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgPC90aGVhZD5cclxuXHJcbiAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgIDx0ciAqbmdGb3I9XCJsZXQgbGFuY2FtZW50byBvZiBsYW5jYW1lbnRvc1wiPlxyXG4gICAgICAgICAgICAgIDx0ZD48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgW2NoZWNrZWRdPVwiaXNTZWxlY2lvbmFkbyhsYW5jYW1lbnRvLmlkISlcIiAoY2hhbmdlKT1cInRvZ2dsZVNlbGVjYW8obGFuY2FtZW50by5pZCEpXCIgLz48L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZD57e2xhbmNhbWVudG8uZGF0YUhvcmEgfCBkYXRlOiBcImRkL01NL3l5eXkgSEg6bW1cIn19PC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+e3sgbGFuY2FtZW50by52YWxvciB8IGZvcm1hdFZhbG9yIH19PC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+e3tsYW5jYW1lbnRvLmRlc2NyaWNhb319PC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+e3tsYW5jYW1lbnRvLnN0YXR1c319PC90ZD5cclxuICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgPC90YWJsZT5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAjbm9MYW5jYW1lbnRvcz5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibm8tZGF0YVwiPlxyXG4gICAgICAgICAgPHA+TmVuaHVtIGxhbsOnYW1lbnRvIGVuY29udHJhZG88L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtZm9vdGVyXCI+XHJcbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBcclxuICAgICAgICBbZGlzYWJsZWRdPVwic2VsZWN0ZWRMYW5jYW1lbnRvcy5sZW5ndGggPT09IDBcIlxyXG4gICAgICAgIChjbGljayk9XCJjb3BpYXJTZWxlY2lvbmFkb3MoKVwiPlxyXG4gICAgICAgIENvcGlhciBTZWxlY2lvbmFkb3MgKHt7IHNlbGVjdGVkTGFuY2FtZW50b3MubGVuZ3RoIH19KVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L2Rpdj4iLCJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AUGlwZSh7XHJcbiAgbmFtZTogJ2Zvcm1hdFZhbG9yJyxcclxuICBzdGFuZGFsb25lOiBmYWxzZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRm9ybWF0VmFsb3JQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XHJcbiAgXHJcbiAgdHJhbnNmb3JtKHZhbG9yOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgaWYgKHZhbG9yID09IG51bGwgfHwgaXNOYU4odmFsb3IpKSB7XHJcbiAgICAgIHJldHVybiAnMCwwMCc7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG51bWVybyA9IHBhcnNlRmxvYXQodmFsb3IpOyAvLyBDb252ZXJ0ZSBwYXJhIG7Dum1lcm8gY29ycmV0YW1lbnRlXHJcblxyXG4gICAgcmV0dXJuIG51bWVyby50b0xvY2FsZVN0cmluZygncHQtQlInLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBJbnRlcmNlcHRvciwgSHR0cFJlcXVlc3QsIEh0dHBIYW5kbGVyLCBIdHRwRXZlbnQsIEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aHJvd0Vycm9yLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgY2F0Y2hFcnJvciwgc3dpdGNoTWFwLCBmaWx0ZXIsIHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IExvZ2luU2VydmljZSB9IGZyb20gJy4uL2xvZ2luL2xvZ2luLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBNZW5zYWdlbnNTZXJ2aWNlIH0gZnJvbSAnLi4vbWVuc2FnZW5zL21lbnNhZ2Vucy5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEF1dGhJbnRlcmNlcHRvciBpbXBsZW1lbnRzIEh0dHBJbnRlcmNlcHRvciB7XHJcbiAgcHJpdmF0ZSBpc1JlZnJlc2hpbmcgPSBmYWxzZTtcclxuICBwcml2YXRlIHJlZnJlc2hUb2tlblN1YmplY3Q6IEJlaGF2aW9yU3ViamVjdDxzdHJpbmcgfCBudWxsPiA9IG5ldyBCZWhhdmlvclN1YmplY3Q8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgbWVuc2FnZW5zU2VydmljZTogTWVuc2FnZW5zU2VydmljZSkge31cclxuXHJcbiAgaW50ZXJjZXB0KHJlcTogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XHJcbiAgICBjb25zdCBhdXRoVG9rZW4gPSB0aGlzLmxvZ2luU2VydmljZS5nZXRBdXRoVG9rZW4oKTtcclxuXHJcbiAgICAvLyBBZGljaW9uYSBvIHRva2VuIG5hIHJlcXVpc2nDp8Ojbywgc2UgZXhpc3RpclxyXG4gICAgaWYgKGF1dGhUb2tlbikge1xyXG4gICAgICByZXEgPSB0aGlzLmFkZFRva2VuKHJlcSwgYXV0aFRva2VuKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbmV4dC5oYW5kbGUocmVxKS5waXBlKFxyXG4gICAgICBjYXRjaEVycm9yKChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEgJiYgIXJlcS51cmwuaW5jbHVkZXMoJ2F1dGgvbG9naW4nKSAmJiAhcmVxLnVybC5pbmNsdWRlcygnYXV0aC9yZWZyZXNoJykpIHtcclxuICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZTQwMUVycm9yKHJlcSwgbmV4dCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChlcnJvci5zdGF0dXMgIT09IDQwMSkge1xyXG4gICAgICAgICAgdGhpcy5tZW5zYWdlbnNTZXJ2aWNlLm1lbnNhZ2VtKCdlcnJvcicsICdFcnJvJywgYEVycm8gbmEgcmVxdWlzacOnw6NvOiAke2Vycm9yLnN0YXR1c31gLCB1bmRlZmluZWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcigoKSA9PiBlcnJvcik7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBoYW5kbGU0MDFFcnJvcihyZXF1ZXN0OiBIdHRwUmVxdWVzdDxhbnk+LCBuZXh0OiBIdHRwSGFuZGxlcik6IE9ic2VydmFibGU8SHR0cEV2ZW50PGFueT4+IHtcclxuICAgIGlmICghdGhpcy5pc1JlZnJlc2hpbmcpIHtcclxuICAgICAgdGhpcy5pc1JlZnJlc2hpbmcgPSB0cnVlO1xyXG4gICAgICB0aGlzLnJlZnJlc2hUb2tlblN1YmplY3QubmV4dChudWxsKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlZnJlc2hUb2tlbiA9IHRoaXMubG9naW5TZXJ2aWNlLmdldFJlZnJlc2hUb2tlbigpOyAvLyBSZWN1cGVyYW5kbyBvIHJlZnJlc2ggdG9rZW4gZG8gbG9jYWxTdG9yYWdlXHJcbiAgICAgIGNvbnNvbGUubG9nKCdSZWZyZXNoIFRva2VuOicsIHJlZnJlc2hUb2tlbik7XHJcblxyXG4gICAgICBpZiAoIXJlZnJlc2hUb2tlbikge1xyXG4gICAgICAgIHRoaXMuaXNSZWZyZXNoaW5nID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvbG9naW4nXSk7ICBcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcigoKSA9PiBuZXcgRXJyb3IoJzQwMScpKTsgICAgICBcclxuICAgICAgICAvL3JldHVybiB0aHJvd0Vycm9yKCgpID0+IG5ldyBFcnJvcignUmVmcmVzaCBUb2tlbiBuw6NvIGVuY29udHJhZG8nKSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiB0aGlzLmxvZ2luU2VydmljZS5yZWZyZXNoVG9rZW4oKS5waXBlKFxyXG4gICAgICAgIHN3aXRjaE1hcCgodG9rZW5zKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLmlzUmVmcmVzaGluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgdGhpcy5yZWZyZXNoVG9rZW5TdWJqZWN0Lm5leHQodG9rZW5zLnRva2VuKTtcclxuICAgICAgICAgIHRoaXMubG9naW5TZXJ2aWNlLnN0b3JlVG9rZW5zKHRva2Vucyk7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIG5leHQuaGFuZGxlKHRoaXMuYWRkVG9rZW4ocmVxdWVzdCwgdG9rZW5zLnRva2VuKSk7XHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgY2F0Y2hFcnJvcigoZXJyKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLmlzUmVmcmVzaGluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgdGhpcy5sb2dpblNlcnZpY2UuY2xlYXJUb2tlbnMoKTsgLy8gTG9nb3V0IGF1dG9tw6F0aWNvIHNlIG8gcmVmcmVzaCBmYWxoYXJcclxuICAgICAgICAgIHRoaXMubG9naW5TZXJ2aWNlLmxvZ291dCgpO1xyXG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gZXJyKTtcclxuICAgICAgICB9KVxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRoaXMucmVmcmVzaFRva2VuU3ViamVjdC5waXBlKFxyXG4gICAgICAgIGZpbHRlcih0b2tlbiA9PiB0b2tlbiAhPT0gbnVsbCksXHJcbiAgICAgICAgdGFrZSgxKSxcclxuICAgICAgICBzd2l0Y2hNYXAodG9rZW4gPT4gbmV4dC5oYW5kbGUodGhpcy5hZGRUb2tlbihyZXF1ZXN0LCB0b2tlbiEpKSlcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgYWRkVG9rZW4ocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55PiwgdG9rZW46IHN0cmluZykge1xyXG4gICAgcmV0dXJuIHJlcXVlc3QuY2xvbmUoe1xyXG4gICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWBcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IHBsYXRmb3JtQnJvd3NlckR5bmFtaWMgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyLWR5bmFtaWMnO1xyXG5cclxuaW1wb3J0IHsgQXBwTW9kdWxlIH0gZnJvbSAnLi9hcHAvYXBwLm1vZHVsZSc7XHJcblxyXG5cclxucGxhdGZvcm1Ccm93c2VyRHluYW1pYygpLmJvb3RzdHJhcE1vZHVsZShBcHBNb2R1bGUpXHJcbiAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmVycm9yKGVycikpO1xyXG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsWUFBQUEsaUJBQWdCO0FBQ3pCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsbUJBQW1CLG1CQUFtQiw4QkFBOEI7QUFDN0UsU0FBUyxhQUFhLDJCQUEyQjs7O0FDSGpELFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsb0JBQTRCOzs7QUNEckMsU0FBUyxhQUFBQyxtQkFBaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUVBMUI7Ozs7U0FBaUIscUJBQXFCO0FBQ3RDLFNBQVMsV0FBVyxpQkFBaUI7Ozs7O0FFQXJDOzs7O1NBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQXFCLEtBQUssWUFBWSxrQkFBa0I7OztBQ0ZqRCxJQUFNLGNBQWM7RUFDdkIsWUFBWTs7RUFFWixZQUFZOztBOzs7Ozs7QUNIaEI7Ozs7U0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxVQUE4Qjs7QUFLL0IsSUFBTyxtQkFBUCxNQUFPLGtCQUFnQjtFQUUzQixjQUFBO0VBQWdCO0VBRWhCLFNBQVMsTUFBdUIsT0FBZ0IsTUFBZSxNQUFhO0FBQzFFLFNBQUssS0FBSztNQUNSO01BQ0E7TUFDQTtNQUNBO0tBQ0Q7RUFDSDs7O3VDQVhXLG1CQUFnQjtJQUFBO0VBQUE7OytFQUFoQixtQkFBZ0IsU0FBaEIsa0JBQWdCLFdBQUEsWUFGZixPQUFNLENBQUE7RUFBQTs7OztBRktkLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFHdkIsWUFBb0IsTUFBMEIsa0JBQWtDO0FBQTVELFNBQUEsT0FBQTtBQUEwQixTQUFBLG1CQUFBO0FBRnRDLFNBQUEsYUFBYSxZQUFZO0VBRW1EO0VBRXBGLFVBQVUsV0FBMkM7QUFDbkQsWUFBUSxJQUFJLFNBQVM7QUFFckIsV0FBTyxLQUFLLEtBQUssS0FBVSxHQUFHLEtBQUssVUFBVSxrQkFBa0IsU0FBUyxFQUFFLEtBQ3hFLElBQUksY0FBVztBQUNiLFdBQUssWUFBWSxRQUFRO0lBQzNCLENBQUMsR0FDRCxXQUFXLFdBQVE7QUFDakIsV0FBSyxpQkFBaUIsU0FBUyxTQUFTLFFBQVEsa0JBQWtCLE1BQU0sTUFBTSxJQUFJLE1BQVM7QUFDM0YsYUFBTyxXQUFXLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRU47O0VBR0EsWUFBWSxRQUFrRTtBQUM1RSxtQkFBZSxRQUFRLGFBQWEsT0FBTyxLQUFLO0FBQ2hELGlCQUFhLFFBQVEsZ0JBQWdCLE9BQU8sWUFBWTtBQUN4RCxpQkFBYSxRQUFRLGFBQWEsT0FBTyxVQUFVLFNBQVEsQ0FBRTtFQUMvRDtFQUVBLGVBQVk7QUFDVixXQUFPLGVBQWUsUUFBUSxXQUFXO0VBQzNDO0VBRUEsZUFBWTtBQUNWLFdBQU8sYUFBYSxRQUFRLFdBQVc7RUFDekM7O0VBR0Esa0JBQWU7QUFDYixXQUFPLGFBQWEsUUFBUSxjQUFjO0VBQzVDOztFQUdBLGVBQVk7QUFDVixVQUFNLGVBQWUsS0FBSyxnQkFBZTtBQUN6QyxXQUFPLEtBQUssS0FBSztNQUNmLEdBQUcsS0FBSyxVQUFVO01BQ2xCLEVBQUUsYUFBWTtNQUNkLEVBQUUsaUJBQWlCLEtBQUk7O01BQ3ZCLEtBQ0EsV0FBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLDBCQUEwQixNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQ25HLGFBQU8sV0FBVyxLQUFLO0lBQ3pCLENBQUMsQ0FBQztFQUVOO0VBRUEsY0FBVztBQUNULG1CQUFlLFdBQVcsV0FBVztBQUNyQyxpQkFBYSxXQUFXLFdBQVc7QUFDbkMsaUJBQWEsV0FBVyxjQUFjO0VBQ3hDO0VBRUEsU0FBTTtBQUNKLFNBQUssWUFBVztBQUNoQixXQUFPLFNBQVMsT0FBTztFQUN6Qjs7O3VDQS9EVyxlQUFZLHVCQUFBLGFBQUEsR0FBQSx1QkFBQSxnQkFBQSxDQUFBO0lBQUE7RUFBQTs7Z0ZBQVosZUFBWSxTQUFaLGNBQVksV0FBQSxZQUZYLE9BQU0sQ0FBQTtFQUFBOzs7Ozs7OztBRFBwQixJQUFBLDZCQUFBLEdBQUEsZUFBQSxFQUFBO0FBQXNELElBQUEseUJBQUEsU0FBQSxTQUFBLG1FQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsTUFBQSw0QkFBQTtBQUFBLFlBQUEsYUFBQSwwQkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxXQUFBLE9BQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQzdFLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQVEsR0FBQSxVQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLE1BQUE7QUFBSSxJQUFBLDJCQUFBLEVBQVc7QUFFM0IsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEdBQUEsc0JBQUE7QUFBaUIsSUFBQSwyQkFBQSxFQUFPOzs7QURPMUIsSUFBTyxlQUFQLE1BQU8sY0FBWTs7RUFLdkIsZ0JBQWE7QUFDWCxTQUFLLFFBQVEsT0FBTTtFQUNyQjs7RUFHQSxlQUFZO0FBQ1YsU0FBSyxRQUFRLE1BQUs7RUFDcEI7RUFLQSxZQUFvQixRQUF3QixjQUEwQjtBQUFsRCxTQUFBLFNBQUE7QUFBd0IsU0FBQSxlQUFBO0FBSDVDLFNBQUEsUUFBUTtBQUNSLFNBQUEsbUJBQW1CO0FBR2pCLFNBQUssT0FBTyxPQUFPLFVBQVUsV0FBUTtBQUNuQyxVQUFJLGlCQUFpQixlQUFlO0FBQ2xDLGFBQUssbUJBQW1CLE1BQU0sUUFBUTtNQUN4QztJQUNGLENBQUM7RUFDSDtFQUVBLGNBQVc7QUFDVCxXQUFPLEtBQUssT0FBTyxRQUFRO0VBQzdCO0VBRUEsYUFBVTtBQUNSLFNBQUssYUFBYSxPQUFNO0VBQzFCOzs7dUNBL0JXLGVBQVksZ0NBQUEsVUFBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzZFQUFaLGVBQVksV0FBQSxDQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLG1CQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7O0FDWHpCLFFBQUEseUJBQUEsR0FBQSxxQ0FBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBT0EsUUFBQSw2QkFBQSxHQUFBLHVCQUFBLEVBQXVCLEdBQUEsZUFBQSxHQUFBLENBQUE7QUFFYSxRQUFBLHlCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQTtBQUFBLGdCQUFBLGFBQUEsMEJBQUEsQ0FBQTtBQUFBLGlCQUFBLDBCQUFTLFdBQUEsTUFBQSxDQUFlO1FBQUEsQ0FBQTtBQUN4RCxRQUFBLDZCQUFBLEdBQUEsY0FBQSxFQUFjLEdBQUEsR0FBQSxFQUNULEdBQUEsVUFBQTtBQUNTLFFBQUEscUJBQUEsR0FBQSxNQUFBO0FBQUksUUFBQSwyQkFBQSxFQUFXO0FBRTNCLFFBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFBNEQsUUFBQSx5QkFBQSxTQUFBLFNBQUEsMkNBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUE7QUFBQSxpQkFBQSwwQkFBUyxJQUFBLGFBQUEsQ0FBYztRQUFBLENBQUE7QUFDakYsUUFBQSw2QkFBQSxHQUFBLFVBQUE7QUFBVSxRQUFBLHFCQUFBLElBQUEsTUFBQTtBQUFJLFFBQUEsMkJBQUE7QUFDZCxRQUFBLHFCQUFBLElBQUEsa0JBQUE7QUFDRixRQUFBLDJCQUFBO0FBQ0EsUUFBQSw2QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUFvRSxRQUFBLHlCQUFBLFNBQUEsU0FBQSw0Q0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQTtBQUFBLGlCQUFBLDBCQUFTLElBQUEsYUFBQSxDQUFjO1FBQUEsQ0FBQTtBQUN6RixRQUFBLDZCQUFBLElBQUEsVUFBQTtBQUFVLFFBQUEscUJBQUEsSUFBQSxXQUFBO0FBQVMsUUFBQSwyQkFBQTtBQUNuQixRQUFBLHFCQUFBLElBQUEsZUFBQTtBQUNGLFFBQUEsMkJBQUE7QUFDQSxRQUFBLDZCQUFBLElBQUEsS0FBQSxDQUFBO0FBQXdFLFFBQUEseUJBQUEsU0FBQSxTQUFBLDRDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBO0FBQUEsaUJBQUEsMEJBQVMsSUFBQSxhQUFBLENBQWM7UUFBQSxDQUFBO0FBQzdGLFFBQUEsNkJBQUEsSUFBQSxVQUFBO0FBQVUsUUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxRQUFBLDJCQUFBO0FBQ2xCLFFBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUNGLFFBQUEsMkJBQUE7QUFDQSxRQUFBLDZCQUFBLElBQUEsS0FBQSxDQUFBO0FBQTJFLFFBQUEseUJBQUEsU0FBQSxTQUFBLDRDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBO0FBQUEsaUJBQUEsMEJBQVMsSUFBQSxhQUFBLENBQWM7UUFBQSxDQUFBO0FBQ2hHLFFBQUEsNkJBQUEsSUFBQSxVQUFBO0FBQVUsUUFBQSxxQkFBQSxJQUFBLE9BQUE7QUFBSyxRQUFBLDJCQUFBO0FBQ2YsUUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQ0YsUUFBQSwyQkFBQTtBQUNBLFFBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBNEUsUUFBQSx5QkFBQSxTQUFBLFNBQUEsNENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUE7QUFBQSxpQkFBQSwwQkFBUyxJQUFBLGFBQUEsQ0FBYztRQUFBLENBQUE7QUFDakcsUUFBQSw2QkFBQSxJQUFBLFVBQUE7QUFBVSxRQUFBLHFCQUFBLElBQUEsY0FBQTtBQUFZLFFBQUEsMkJBQUE7QUFDdEIsUUFBQSxxQkFBQSxJQUFBLDBCQUFBO0FBQ0YsUUFBQSwyQkFBQTtBQUNBLFFBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBaUUsUUFBQSx5QkFBQSxTQUFBLFNBQUEsNENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUE7QUFBQSxpQkFBQSwwQkFBUyxJQUFBLFdBQUEsQ0FBWTtRQUFBLENBQUE7QUFDcEYsUUFBQSw2QkFBQSxJQUFBLFVBQUE7QUFBVSxRQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLFFBQUEsMkJBQUE7QUFDaEIsUUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFDRixRQUFBLDJCQUFBLEVBQUksRUFDUztBQUdqQixRQUFBLDZCQUFBLElBQUEscUJBQUEsRUFBcUIsSUFBQSxPQUFBLENBQUE7QUFFakIsUUFBQSx3QkFBQSxJQUFBLGVBQUE7QUFDRixRQUFBLDJCQUFBLEVBQU0sRUFDYztBQUd4QixRQUFBLHdCQUFBLElBQUEsWUFBQTs7O0FBaERjLFFBQUEseUJBQUEsUUFBQSxJQUFBLGdCQUFBOzs7Ozs7aUZEV0QsY0FBWSxFQUFBLFdBQUEsZ0JBQUEsVUFBQSw0QkFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQVosY0FBWSxFQUFBLFNBQUEsQ0FBQUMsS0FBQUMsS0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLHFCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLHFCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FLWHpCOzs7O1NBQVMsYUFBQUMsa0JBQWlCOztBQVFwQixJQUFPLGtCQUFQLE1BQU8saUJBQWU7Ozt1Q0FBZixrQkFBZTtJQUFBO0VBQUE7OzZFQUFmLGtCQUFlLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFVBQUEsU0FBQSx5QkFBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1I1QixRQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFRLEdBQUEsSUFBQTtBQUNBLFFBQUEscUJBQUEsR0FBQSx5QkFBQTtBQUF1QixRQUFBLDJCQUFBO0FBQzNCLFFBQUEsNkJBQUEsR0FBQSxHQUFBLEVBQUcsR0FBQSxNQUFBO0FBQU0sUUFBQSxxQkFBQSxHQUFBLHNCQUFBO0FBQWlCLFFBQUEsMkJBQUE7QUFBUSxRQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFXLFFBQUEsMkJBQUEsRUFBSTs7Ozs7O2lGRE14QyxpQkFBZSxFQUFBLFdBQUEsbUJBQUEsVUFBQSxpREFBQSxZQUFBLEVBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQWYsaUJBQWUsRUFBQSxTQUFBLENBQUFDLEdBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSx3QkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSx3QkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRVI1Qjs7OztTQUFTLGFBQUFDLGtCQUF5Qjs7O0FFQWxDLFNBQVMsU0FBUyxLQUFXO0FBQzNCLFFBQU0sSUFBSSxJQUFJLFFBQVEsS0FBSSxFQUFFO0FBQzVCLFFBQU0sU0FBUyxTQUFTLEVBQUUsV0FBVyxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsSUFBSSxPQUFHLElBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRTtBQUNqRixTQUFPLEVBQUUsR0FBSSxVQUFVLEtBQU0sS0FBSyxHQUFJLFVBQVUsSUFBSyxLQUFLLEdBQUcsU0FBUyxJQUFHO0FBQzNFO0FBRUEsU0FBUyxTQUFTLEdBQVcsR0FBVyxHQUFTO0FBQy9DLFFBQU0sUUFBUSxDQUFDLE1BQWE7QUFDMUIsVUFBTSxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRTtBQUMvRCxXQUFPLEVBQUUsV0FBVyxJQUFJLE1BQU0sSUFBSTtFQUNwQztBQUNBLFNBQU8sSUFBSSxNQUFNLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRyxZQUFXO0FBQ3pEO0FBRUEsU0FBUyxLQUFLLEdBQVcsR0FBVyxHQUFTO0FBQzNDLFNBQU8sS0FBSyxJQUFJLEtBQUs7QUFDdkI7QUFFQSxTQUFTLGVBQWUsTUFBYyxNQUFjLEdBQVM7QUFDM0QsUUFBTSxLQUFLLFNBQVMsSUFBSTtBQUN4QixRQUFNLEtBQUssU0FBUyxJQUFJO0FBQ3hCLFFBQU0sSUFBSSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUM1QixRQUFNLElBQUksS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDNUIsUUFBTSxJQUFJLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQzVCLFNBQU8sU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUN6QjtBQUVNLFNBQVUsaUJBQWlCLE9BQWE7QUFDNUMsUUFBTSxRQUFRO0FBQ2QsUUFBTSxTQUFTO0FBQ2YsUUFBTSxNQUFNO0FBRVosTUFBSSxTQUFTLEtBQU07QUFDakIsV0FBTztFQUNUO0FBRUEsTUFBSSxRQUFRLEdBQUc7QUFDYixXQUFPO0VBQ1Q7QUFFQSxRQUFNLElBQUksSUFBSyxRQUFRO0FBQ3ZCLFNBQU8sZUFBZSxPQUFPLFFBQVEsQ0FBQztBQUN4Qzs7O0FGckNBLFNBQWlDLGtCQUFrQjs7OztBR0puRDs7OztTQUFTLGNBQUFDLG1CQUFrQjtBQUMzQixTQUFxQixjQUFBQyxhQUFZLGNBQUFDLG1CQUFrQjtBOztBQVM3QyxJQUFPLHVCQUFQLE1BQU8sc0JBQW9CO0VBSS9CLFlBQW9CLE1BQTBCLGNBQW9DLGtCQUFrQztBQUFoRyxTQUFBLE9BQUE7QUFBMEIsU0FBQSxlQUFBO0FBQW9DLFNBQUEsbUJBQUE7QUFGMUUsU0FBQSxhQUFhLFlBQVk7RUFFdUY7RUFFeEgsaUJBQWlCLFFBQWdCLFNBQWU7QUFDOUMsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFFBQUksVUFBVSxTQUFTO0FBQ3JCLGFBQU8sS0FBSyxLQUFLLElBQXFCLEdBQUcsS0FBSyxVQUFVLCtCQUErQixTQUFTLFdBQVcsTUFBTSxZQUFZLE9BQU8sRUFBRSxFQUFFLEtBQ3RJQyxZQUFXLFdBQVE7QUFFakIsZUFBT0MsWUFBVyxLQUFLO01BQ3pCLENBQUMsQ0FBQztJQUVOLE9BQU87QUFDTCxhQUFPLEtBQUssS0FBSyxJQUFxQixHQUFHLEtBQUssVUFBVSwrQkFBK0IsU0FBUyxFQUFFLEVBQUUsS0FDbEdELFlBQVcsV0FBUTtBQUVqQixlQUFPQyxZQUFXLEtBQUs7TUFDekIsQ0FBQyxDQUFDO0lBRU47RUFFRjs7O3VDQXhCVyx1QkFBb0IsdUJBQUEsY0FBQSxHQUFBLHVCQUFBLFlBQUEsR0FBQSx1QkFBQSxnQkFBQSxDQUFBO0lBQUE7RUFBQTs7Z0ZBQXBCLHVCQUFvQixTQUFwQixzQkFBb0IsV0FBQSxZQUZuQixPQUFNLENBQUE7RUFBQTs7OztBQ1JwQjs7OztTQUFTLGNBQUFDLG1CQUFrQjtBQUUzQixTQUFxQixjQUFBQyxhQUFZLGNBQUFDLG1CQUFrQjs7O0FBUTdDLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7RUFJbkMsWUFBb0IsTUFBMEIsY0FBb0Msa0JBQWtDO0FBQWhHLFNBQUEsT0FBQTtBQUEwQixTQUFBLGVBQUE7QUFBb0MsU0FBQSxtQkFBQTtBQUYxRSxTQUFBLGFBQWEsWUFBWTtFQUV5RjtFQUUxSCx5QkFBeUIsUUFBZTtBQUN0QyxVQUFNLFlBQVksS0FBSyxhQUFhLGFBQVk7QUFDaEQsV0FBTyxLQUFLLEtBQUssSUFBeUIsR0FBRyxLQUFLLFVBQVUsa0NBQWtDLFNBQVMsV0FBVyxNQUFNLEVBQUUsRUFBRSxLQUMxSEMsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjs7O3VDQWRXLDJCQUF3Qix1QkFBQSxjQUFBLEdBQUEsdUJBQUEsWUFBQSxHQUFBLHVCQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOztnRkFBeEIsMkJBQXdCLFNBQXhCLDBCQUF3QixXQUFBLFlBRnZCLE9BQU0sQ0FBQTtFQUFBOzs7O0FDUnBCOzs7O1NBQVMsY0FBQUMsbUJBQWtCO0FBRTNCLFNBQXFCLGNBQUFDLGFBQVksY0FBQUMsbUJBQWtCOzs7QUFRN0MsSUFBTyx1Q0FBUCxNQUFPLHNDQUFvQztFQUkvQyxZQUFvQixNQUEwQixjQUFvQyxrQkFBa0M7QUFBaEcsU0FBQSxPQUFBO0FBQTBCLFNBQUEsZUFBQTtBQUFvQyxTQUFBLG1CQUFBO0FBRjFFLFNBQUEsYUFBYSxZQUFZO0VBRXVGO0VBRXhILHFDQUFxQyxRQUFpQixRQUFlO0FBQ25FLFVBQU0sWUFBWSxLQUFLLGFBQWEsYUFBWTtBQUNoRCxXQUFPLEtBQUssS0FBSyxJQUFxQyxHQUFHLEtBQUssVUFBVSw0REFBNEQsU0FBUyxXQUFXLE1BQU0sV0FBVyxNQUFNLEVBQUUsRUFBRSxLQUNqTEMsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjs7O3VDQWRXLHVDQUFvQyx1QkFBQSxjQUFBLEdBQUEsdUJBQUEsWUFBQSxHQUFBLHVCQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOztnRkFBcEMsdUNBQW9DLFNBQXBDLHNDQUFvQyxXQUFBLFlBRm5DLE9BQU0sQ0FBQTtFQUFBOzs7Ozs7Ozs7Ozs7Ozs7QUpFWixJQUFBLDZCQUFBLEdBQUEsV0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSwyQkFBQTtBQUNKLElBQUEsMkJBQUE7Ozs7O0FBU0EsSUFBQSxzQ0FBQSxDQUFBO0FBRUksSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsd0JBQUEsR0FBQSx1QkFBQSxFQUFBO0FBU0osSUFBQSwyQkFBQTs7OztBQU5RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQTs7Ozs7QUFSaEIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsR0FBQSx1REFBQSxHQUFBLEdBQUEsZ0JBQUEsRUFBQTtBQWVKLElBQUEsMkJBQUE7OztBQWZrQyxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUEsR0FBQSxDQUFBOzs7OztBQUp0QyxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBRUksSUFBQSx5QkFBQSxHQUFBLHdDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUFtQkosSUFBQSwyQkFBQTs7O0FBbkJvRCxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQTs7Ozs7O0FBOEJ0QyxJQUFBLHNDQUFBLENBQUE7QUFFSSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBR0ssSUFBQSx5QkFBQSxTQUFBLFNBQUEsNEdBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLE9BQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsT0FBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsY0FBQSxPQUFBLFVBQUEsT0FBNEIsSUFBQyxJQUFBLENBQUEsQ0FBTTtJQUFBLENBQUE7QUFFN0MsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUVBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBRUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUEsRUFBSTs7Ozs7OztBQWpCSCxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxvQkFBQSxPQUFBLGtCQUFBLE9BQUEsSUFBQSxJQUFBLENBQUE7QUFEQSxJQUFBLDBCQUFBLHlCQUFBLE9BQUEsVUFBQSxPQUFBLElBQUEsSUFBQSxNQUFBLE9BQUEsaUJBQUE7QUFLRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsT0FBQSxZQUFBLE9BQUEsSUFBQSxJQUFBLEdBQUEsR0FBQTtBQUlBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsVUFBQSxPQUFBLHdCQUFBLE9BQUEsSUFBQSxJQUFBLEdBQUEsR0FBQTtBQUlBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsVUFBQSxPQUFBLGFBQUEsT0FBQSxJQUFBLElBQUEsR0FBQSxHQUFBO0FBSUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxVQUFBLE9BQUEsZ0JBQUEsT0FBQSxJQUFBLElBQUEsR0FBQSxHQUFBOzs7OztBQXRCaEIsSUFBQSxzQ0FBQSxDQUFBO0FBRUksSUFBQSx5QkFBQSxHQUFBLHNGQUFBLElBQUEsR0FBQSxnQkFBQSxFQUFBOzs7Ozs7Ozs7QUFBZSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsWUFBQSxPQUFBLElBQUEsSUFBQSxDQUFBLEVBQThCLFlBQUEsY0FBQTs7Ozs7QUFKckQsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsR0FBQSx1RUFBQSxHQUFBLEdBQUEsZ0JBQUEsRUFBQTtBQTZCSixJQUFBLDJCQUFBOzs7QUE3QmtDLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxHQUFBLENBQUE7Ozs7O0FBZ0M5QixJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXVDLEdBQUEsUUFBQSxFQUFBO0FBQ1gsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQyxJQUFBLDJCQUFBLEVBQU87Ozs7O0FBckM1QyxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBRUksSUFBQSx5QkFBQSxHQUFBLHdEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMkUsR0FBQSxnRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUF1Qy9FLElBQUEsMkJBQUE7OztBQXZDb0QsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBQSxJQUFBLENBQUE7Ozs7O0FBMkNoRCxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXVDLEdBQUEsTUFBQTtBQUM3QixJQUFBLHFCQUFBLEdBQUEsK0JBQUE7QUFBMEIsSUFBQSwyQkFBQSxFQUFPOzs7OztBQWhEakQsSUFBQSxzQ0FBQSxDQUFBO0FBRUUsSUFBQSx5QkFBQSxHQUFBLGtEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMkYsR0FBQSwwREFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7Ozs7OztBQUExRCxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsVUFBQSxTQUFBLENBQUEsRUFBNEIsWUFBQSwwQkFBQTs7Ozs7QUEwRDdELElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBbUQsR0FBQSxPQUFBLEVBQUE7QUFHL0MsSUFBQSx3QkFBQSxHQUFBLHVCQUFBLEVBQUEsRUFPc0IsR0FBQSx1QkFBQSxFQUFBO0FBVXhCLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSx3QkFBQSxHQUFBLHVCQUFBLEVBQUE7QUFRRixJQUFBLDJCQUFBO0FBRUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsd0JBQUEsR0FBQSx1QkFBQSxFQUFBO0FBUUYsSUFBQSwyQkFBQSxFQUFNOzs7QUFyQ0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLDhCQUFBLEdBQUEsR0FBQSxDQUFBO0FBU0EsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsU0FBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQTtBQVdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQTtBQVdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQTs7Ozs7QUFyQ1IsSUFBQSxzQ0FBQSxDQUFBO0FBQ0UsSUFBQSx5QkFBQSxHQUFBLGtEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUFBbUMsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQTs7Ozs7O0FBaURyQyxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTZELEdBQUEsT0FBQSxFQUFBO0FBQ3BDLElBQUEseUJBQUEsU0FBQSxTQUFBLHlEQUFBO0FBQUEsWUFBQSxXQUFBLDRCQUFBLEdBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVMsT0FBQSxvQ0FBQSxTQUFBLFNBQUEsU0FBQSxvQkFBQSxDQUE0RTtJQUFBLENBQUE7QUFDMUcsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFzQixJQUFBLHFCQUFBLENBQUE7QUFBK0IsSUFBQSwyQkFBQTtBQUNyRCxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0UsSUFBQSxxQkFBQSxDQUFBOzs7QUFHRixJQUFBLDJCQUFBLEVBQU87QUFHVCxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUlNLElBQUEsT0FBQSxFQUFBO0FBTVIsSUFBQSwyQkFBQTtBQUVBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRSxJQUFBLHFCQUFBLEVBQUE7O0FBQ0YsSUFBQSwyQkFBQSxFQUFNOzs7OztBQXZCa0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBLG9CQUFBO0FBRXBCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsUUFBQSwwQkFBQSxHQUFBLEdBQUEsU0FBQSxPQUFBLE9BQUEsR0FBQSxPQUFBLDBCQUFBLEdBQUEsSUFBQSxTQUFBLFFBQUEsT0FBQSxHQUFBLEdBQUE7QUFVQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFNBQUEsT0FBQSxjQUFBLFFBQUEsR0FBQSxHQUFBO0FBREEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsVUFBQSxRQUFBLENBQUE7QUFNQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLEtBQUEsR0FBQTtBQUtGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxJQUFBLElBQUEsT0FBQSxjQUFBLFFBQUEsR0FBQSxPQUFBLEdBQUEsSUFBQTs7O0FEbEtFLElBQU8sb0JBQVAsTUFBTyxtQkFBaUI7RUE2QjVCLFlBQW9CLGNBQ1YsMEJBQ0EsK0JBQ0EsSUFBZTtBQUhMLFNBQUEsZUFBQTtBQUNWLFNBQUEsMkJBQUE7QUFDQSxTQUFBLGdDQUFBO0FBQ0EsU0FBQSxLQUFBO0FBNUJILFNBQUEsY0FBcUIsQ0FBQTtBQUNyQixTQUFBLFlBQW1CLENBQUE7QUFDbkIsU0FBQSxlQUFzQixDQUFBO0FBQ3RCLFNBQUEsa0JBQXlCLENBQUE7QUFDekIsU0FBQSxvQkFBMkIsQ0FBQTtBQUMzQixTQUFBLDBCQUFpQyxDQUFBO0FBSWhDLFNBQUEsWUFBbUIsQ0FBQTtBQUNuQixTQUFBLGtCQUF5QixDQUFBO0FBQ3pCLFNBQUEsZ0JBQXVCLENBQUE7QUFDdkIsU0FBQSxrQkFBeUIsQ0FBQTtBQUdqQyxTQUFBLGNBQWM7QUFDZCxTQUFBLHVCQUE4QixDQUFBO0FBRzlCLFNBQUEsT0FBaUIsQ0FBQTtBQUVqQixTQUFBLHVCQUF1QjtBQUN2QixTQUFBLHNCQUFzQjtBQUN0QixTQUFBLG9CQUFtQztBQTZFbkMsU0FBQSxxQkFLTSxDQUFBO0VBNUVOO0VBRUEsV0FBUTtBQUVOLFNBQUssT0FBTyxLQUFLLEdBQUcsTUFBTTtNQUN4QixLQUFLLENBQUMsTUFBTSxXQUFXLFFBQVE7S0FDaEM7QUFHRCxTQUFLLCtCQUErQixJQUFJLEVBQUU7RUFFNUM7RUFFQSxJQUFJLE1BQUc7QUFDTCxXQUFPLEtBQUssS0FBSyxJQUFJLEtBQUs7RUFDNUI7RUFFQSxlQUFlLE1BQVksWUFBZTtBQUN4QyxVQUFNLE1BQU0sS0FBSyxZQUFXO0FBQzVCLFNBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBQ2xELGVBQVcsTUFBSztBQUVoQixVQUFNLFNBQVMsR0FBRyxHQUFHO0FBQ3JCLFVBQU0sVUFBVSxHQUFHLEdBQUc7QUFHdEIsU0FBSyxjQUFjLENBQUE7QUFDbkIsU0FBSyxZQUFZLENBQUE7QUFDakIsU0FBSyxlQUFlLENBQUE7QUFDcEIsU0FBSyxrQkFBa0IsQ0FBQTtBQUN2QixTQUFLLG9CQUFvQixDQUFBO0FBQ3pCLFNBQUssMEJBQTBCLENBQUE7QUFDL0IsU0FBSyxxQkFBcUIsQ0FBQTtBQUMxQixTQUFLLG9CQUFvQjtBQUd6QixTQUFLLCtCQUErQixRQUFRLE9BQU87RUFFckQ7RUFFQSxZQUFZLE9BQWE7QUFDdkIsV0FBTyxDQUFDLENBQUMsS0FBSyxrQkFBa0IsS0FBSztFQUN2QztFQUVBLGNBQWMsUUFBYztBQUMxQixTQUFLLG9CQUFvQjtBQUN6QixTQUFLLDZCQUE2QixNQUFNO0VBQzFDO0VBRUEsK0JBQStCLFFBQWdCLFNBQWU7QUFDNUQsU0FBSyx1QkFBdUI7QUFDNUIsU0FBSyxhQUFhLGlCQUFpQixRQUFRLE9BQU8sRUFBRSxVQUFVLFVBQU87QUFDbkUsVUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLEdBQUc7QUFDOUIsYUFBSyx1QkFBdUI7QUFDNUI7TUFDRjtBQUNBLGVBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFDcEMsYUFBSyxZQUFZLEtBQUssS0FBSyxDQUFDLEVBQUUsR0FBRztBQUNqQyxhQUFLLFVBQVUsS0FBSyxLQUFLLENBQUMsRUFBRSxNQUFNLFFBQVEsS0FBSyxDQUFDLEVBQUUsR0FBRztBQUNyRCxhQUFLLGFBQWEsS0FBSyxLQUFLLENBQUMsRUFBRSxLQUFLO0FBQ3BDLGFBQUssZ0JBQWdCLEtBQUssS0FBSyxDQUFDLEVBQUUsUUFBUTtBQUMxQyxhQUFLLGtCQUFrQixLQUFLLEtBQUssU0FBUyxLQUFLLENBQUMsRUFBRSxRQUFRLENBQUM7QUFDM0QsYUFBSyx3QkFBd0IsS0FBSyxLQUFLLENBQUMsRUFBRSxnQkFBZ0I7TUFDNUQ7QUFDQSxXQUFLLHVCQUF1QjtBQUM1QixZQUFNLFlBQVksS0FBSyxVQUFVLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDMUQsV0FBSyxvQkFBb0I7QUFDekIsV0FBSyw2QkFBNkIsU0FBUztJQUM3QyxDQUFDO0VBQ0g7RUFTQSw2QkFBNkIsUUFBZTtBQUMxQyxTQUFLLHNCQUFzQjtBQUUzQixTQUFLLHlCQUF5Qix5QkFBeUIsTUFBTSxFQUFFLFVBQVUsVUFBTztBQUM5RSxXQUFLLGNBQWM7QUFDbkIsV0FBSyxZQUFZLENBQUE7QUFDakIsV0FBSyxrQkFBa0IsQ0FBQTtBQUN2QixXQUFLLGdCQUFnQixDQUFBO0FBQ3JCLFdBQUssa0JBQWtCLENBQUE7QUFHdkIsV0FBSyxxQkFBcUIsQ0FBQTtBQUMxQixVQUFJLEtBQUssZUFBZSxNQUFNO0FBQzVCLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssWUFBWSxRQUFRLEtBQUs7QUFFaEQsZ0JBQU0sV0FBVyxLQUFLLFlBQVksQ0FBQztBQUVuQyxlQUFLLFVBQVUsS0FBSyxLQUFLLFlBQVksQ0FBQyxFQUFFLEtBQUs7QUFDN0MsZUFBSyxnQkFBZ0IsS0FBSyxLQUFLLFlBQVksQ0FBQyxFQUFFLFdBQVc7QUFDekQsZUFBSyxjQUFjLEtBQUssS0FBSyxZQUFZLENBQUMsRUFBRSxTQUFTO0FBQ3JELGVBQUssZ0JBQWdCLEtBQUssS0FBSyxZQUFZLENBQUMsRUFBRSxNQUFNO0FBRXBELGVBQUssbUJBQW1CLEtBQUs7WUFDM0IsT0FBTyxTQUFTO1lBQ2hCLFFBQVEsU0FBUztZQUNqQixTQUFTLFNBQVM7WUFDbEIsc0JBQXNCLFNBQVM7V0FDaEM7QUFFRCxrQkFBUSxJQUFJLEtBQUssa0JBQWtCO1FBQ3JDO0FBQ0EsYUFBSyxzQkFBc0I7TUFDN0I7SUFDRixDQUFDO0VBRUg7RUFFQSxjQUFjLE1BQVM7QUFDckIsUUFBSSxDQUFDLEtBQUs7QUFBUSxhQUFPO0FBQ3pCLFdBQU8sS0FBSyxJQUFLLEtBQUssUUFBUSxLQUFLLFNBQVUsR0FBRztFQUNsRDtFQUVBLFVBQVUsTUFBUztBQUNqQixVQUFNLGFBQWEsS0FBSyxjQUFjLElBQUk7QUFFMUMsUUFBSSxhQUFhO0FBQUssYUFBTztBQUM3QixRQUFJLGNBQWM7QUFBSSxhQUFPO0FBQzdCLFdBQU87RUFDVDtFQUVRLGFBQWEsTUFBbUI7QUFDdEMsVUFBTSxJQUFJLElBQUksS0FBSyxJQUFJO0FBQ3ZCLFdBQU8sRUFBRSxtQkFBbUIsT0FBTyxJQUFJLE1BQ3JDLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxNQUFNLFdBQVcsUUFBUSxVQUFTLENBQUU7RUFDeEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBZ0VBLG9DQUFvQyxRQUFpQixPQUFjO0FBQ2pFLFNBQUssOEJBQThCLHFDQUFxQyxRQUFRLEtBQUssRUFBRSxVQUFVLFVBQU87QUFDdEcsV0FBSyx1QkFBdUIsQ0FBQTtBQUM1QixVQUFJLFFBQVEsS0FBSyxTQUFTLEdBQUc7QUFDM0IsYUFBSyx1QkFBdUI7QUFDNUIsYUFBSyxjQUFjO0FBQ25CLGlCQUFTLEtBQUssVUFBVSxJQUFJLFdBQVc7TUFDekM7SUFDRixDQUFDO0VBQ0g7RUFFQSxTQUFTLE9BQWE7QUFDcEIsV0FBTyxpQkFBaUIsS0FBSztFQUMvQjs7O3VDQWxQVyxvQkFBaUIsZ0NBQUEsb0JBQUEsR0FBQSxnQ0FBQSx3QkFBQSxHQUFBLGdDQUFBLG9DQUFBLEdBQUEsZ0NBQUEsY0FBQSxDQUFBO0lBQUE7RUFBQTs7NkVBQWpCLG9CQUFpQixXQUFBLENBQUEsQ0FBQSxjQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxVQUFBLEVBQUEsR0FBQSxDQUFBLDJCQUFBLEVBQUEsR0FBQSxDQUFBLGVBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxjQUFBLFdBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxZQUFBLElBQUEsbUJBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxhQUFBLGNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLFNBQUEsc0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxTQUFBLFdBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxVQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxTQUFBLG9CQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxTQUFBLEtBQUEsY0FBQSxRQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsU0FBQSxzQkFBQSxHQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLGNBQUEsUUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDJCQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBOztBQ2I5QixRQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBLEVBQXlCLEdBQUEsa0JBQUEsQ0FBQSxFQUNrQyxHQUFBLFdBQUE7QUFDeEMsUUFBQSxxQkFBQSxHQUFBLEtBQUE7QUFBRyxRQUFBLDJCQUFBO0FBRWQsUUFBQSx3QkFBQSxHQUFBLFNBQUEsQ0FBQSxFQUF3RSxHQUFBLHlCQUFBLENBQUE7QUFJeEUsUUFBQSw2QkFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQTtBQUErQyxRQUFBLHlCQUFBLGdCQUFBLFNBQUEsa0VBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQTtBQUFBLGdCQUFBLFlBQUEsMEJBQUEsQ0FBQTtBQUFBLGlCQUFBLDBCQUFnQixJQUFBLGVBQUEsUUFBQSxTQUFBLENBQThCO1FBQUEsQ0FBQTtBQUM3RixRQUFBLDJCQUFBO0FBRUEsUUFBQSx5QkFBQSxHQUFBLHdDQUFBLEdBQUEsR0FBQSxhQUFBLENBQUE7QUFHSixRQUFBLDJCQUFBLEVBQWlCO0FBSXJCLFFBQUEseUJBQUEsR0FBQSxrQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTZELElBQUEsNENBQUEsR0FBQSxHQUFBLGdCQUFBLENBQUE7QUFnRjdELFFBQUEsd0JBQUEsSUFBQSxJQUFBO0FBR0EsUUFBQSx5QkFBQSxJQUFBLDRDQUFBLEdBQUEsR0FBQSxnQkFBQSxDQUFBLEVBQTBDLElBQUEsbUNBQUEsSUFBQSxJQUFBLE9BQUEsRUFBQTtBQThFMUMsUUFBQSw2QkFBQSxJQUFBLDJCQUFBLEVBQUE7QUFHRSxRQUFBLHlCQUFBLFVBQUEsU0FBQSx3RUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQTtBQUFBLGlCQUFBLDBCQUFBLElBQUEsY0FBd0IsS0FBSztRQUFBLENBQUE7QUFDL0IsUUFBQSwyQkFBQTs7OztBQXZMTSxRQUFBLHlCQUFBLGFBQUEsSUFBQSxJQUFBO0FBSWtCLFFBQUEsd0JBQUEsQ0FBQTtBQUFBLFFBQUEseUJBQUEsaUJBQUEsU0FBQTtBQUVpQixRQUFBLHdCQUFBO0FBQUEsUUFBQSx5QkFBQSxPQUFBLFNBQUE7QUFLckIsUUFBQSx3QkFBQSxDQUFBO0FBQUEsUUFBQSx5QkFBQSxRQUFBLElBQUEsSUFBQSxPQUFBO0FBT2EsUUFBQSx3QkFBQTtBQUFBLFFBQUEseUJBQUEsUUFBQSxJQUFBLG9CQUFBO0FBd0JsQixRQUFBLHdCQUFBO0FBQUEsUUFBQSx5QkFBQSxRQUFBLENBQUEsSUFBQSxvQkFBQTtBQTJEQSxRQUFBLHdCQUFBLENBQUE7QUFBQSxRQUFBLHlCQUFBLFFBQUEsSUFBQSxtQkFBQTtBQWtEdUIsUUFBQSx3QkFBQTtBQUFBLFFBQUEseUJBQUEsV0FBQSxJQUFBLGtCQUFBO0FBNkJwQyxRQUFBLHdCQUFBO0FBQUEsUUFBQSx5QkFBQSxVQUFBLElBQUEsV0FBQSxFQUFzQix3QkFBQSxJQUFBLG9CQUFBOzs7Ozs7aUZEdktYLG1CQUFpQixFQUFBLFdBQUEscUJBQUEsVUFBQSxnREFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQWpCLG1CQUFpQixFQUFBLFNBQUEsQ0FBQUMsS0FBQSxnQ0FBQSxxQ0FBQSxrREFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsMEJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsMEJBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QU1iOUI7Ozs7U0FBUyxhQUFBQyxrQkFBeUI7Ozs7QUVDbEM7Ozs7U0FBUyxjQUFBQyxtQkFBa0I7QUFDM0IsU0FBUyxjQUFBQyxhQUF3QixjQUFBQyxtQkFBa0I7QTs7QUFTN0MsSUFBTyxvQkFBUCxNQUFPLG1CQUFpQjtFQUc1QixZQUFvQixNQUEwQixjQUFvQyxrQkFBa0M7QUFBaEcsU0FBQSxPQUFBO0FBQTBCLFNBQUEsZUFBQTtBQUFvQyxTQUFBLG1CQUFBO0FBRjFFLFNBQUEsYUFBYSxZQUFZO0VBRXVGO0VBRXhILG9CQUFpQjtBQUNmLFVBQU0sWUFBWSxLQUFLLGFBQWEsYUFBWTtBQUNoRCxXQUFPLEtBQUssS0FBSyxJQUFrQixHQUFHLEtBQUssVUFBVSwyQkFBMkIsU0FBUyxFQUFFLEVBQUUsS0FDM0ZDLFlBQVcsV0FBUTtBQUVqQixhQUFPQyxZQUFXLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRU47RUFFQSxtQkFBbUIsSUFBVTtBQUMzQixXQUFPLEtBQUssS0FBSyxJQUFnQixHQUFHLEtBQUssVUFBVSxtQkFBbUIsRUFBRSxFQUFFLEVBQUUsS0FDMUVELFlBQVcsV0FBUTtBQUVqQixhQUFPQyxZQUFXLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRU47RUFFQSx1QkFBdUIsUUFBZ0IsU0FBaUIsUUFBZ0IsZUFBcUI7QUFDM0YsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFVBQU0sTUFBTSxHQUFHLEtBQUssVUFBVSx1Q0FBdUMsU0FBUyxXQUFXLE1BQU0sWUFBWSxPQUFPLFdBQVcsTUFBTSxrQkFBa0IsYUFBYTtBQUNsSyxZQUFRLElBQUksR0FBRztBQUNmLFdBQU8sS0FBSyxLQUFLLElBQWtCLEdBQUcsRUFBRSxLQUN0Q0QsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGVBQWUsVUFBa0I7QUFDL0IsUUFBSSxpQkFBaUIsb0JBQUksS0FBSyxTQUFTLE9BQU8sVUFBVSxFQUFFLFNBQVEsSUFBSyxHQUFHO0FBQzFFLFFBQUksT0FBTztNQUNULFVBQVU7TUFDVixPQUFPLE9BQU8sU0FBUyxPQUFPLE9BQU8sQ0FBQztNQUN0QyxXQUFXLFNBQVMsT0FBTyxXQUFXLEVBQUUsU0FBUSxFQUFHLEtBQUk7TUFDdkQsUUFBUSxTQUFTLE9BQU8sUUFBUSxFQUFFLFNBQVE7TUFDMUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxVQUFVLENBQUM7TUFDNUMsV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLENBQUM7O0FBR2hELFlBQVEsSUFBSSxJQUFJO0FBRWhCLFdBQU8sS0FBSyxLQUFLLEtBQVUsR0FBRyxLQUFLLFVBQVUsbUJBQW1CLElBQUksRUFBRSxLQUNwRUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLGdDQUE2QixNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQ3RHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGtCQUFrQixJQUFVO0FBQzFCLFFBQUksT0FBTztNQUNULFVBQVU7O0FBRVosV0FBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVSx1QkFBdUIsRUFBRSxJQUFJLElBQUksRUFBRSxLQUN4RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLGtDQUErQixNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQ3hHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGNBQWMsSUFBWSxVQUFrQjtBQUMxQyxRQUFJLGlCQUFpQixvQkFBSSxLQUFLLFNBQVMsT0FBTyxVQUFVLEVBQUUsU0FBUSxJQUFLLEdBQUc7QUFDMUUsWUFBUSxJQUFJLE9BQU8sU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzVDLFFBQUksT0FBTztNQUNULFVBQVU7TUFDVixPQUFPLE9BQU8sU0FBUyxPQUFPLE9BQU8sQ0FBQztNQUN0QyxXQUFXLFNBQVMsT0FBTyxXQUFXLEVBQUUsU0FBUSxFQUFHLEtBQUk7TUFDdkQsUUFBUSxTQUFTLE9BQU8sUUFBUSxFQUFFLFNBQVE7TUFDMUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxVQUFVLENBQUM7TUFDNUMsV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLENBQUM7O0FBR2hELFdBQU8sS0FBSyxLQUFLLElBQVMsR0FBRyxLQUFLLFVBQVUsbUJBQW1CLEVBQUUsSUFBSSxJQUFJLEVBQUUsS0FDekVELFlBQVcsV0FBUTtBQUNqQixXQUFLLGlCQUFpQixTQUFTLFNBQVMsUUFBUSxvQ0FBaUMsTUFBTSxNQUFNLElBQUksTUFBUztBQUMxRyxhQUFPQyxZQUFXLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRU47RUFFQSxxQkFBcUIsV0FBbUIsZUFBcUI7QUFDM0QsV0FBTyxLQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssVUFBVSwyQkFBMkIsU0FBUyxrQkFBa0IsYUFBYSxFQUFFLEVBQUUsS0FDakhELFlBQVcsV0FBUTtBQUNqQixXQUFLLGlCQUFpQixTQUFTLFNBQVMsUUFBUSxzQ0FBc0MsTUFBTSxNQUFNLElBQUksTUFBUztBQUMvRyxhQUFPQyxZQUFXLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRU47Ozt1Q0FoR1csb0JBQWlCLHVCQUFBLGNBQUEsR0FBQSx1QkFBQSxZQUFBLEdBQUEsdUJBQUEsZ0JBQUEsQ0FBQTtJQUFBO0VBQUE7O2dGQUFqQixvQkFBaUIsU0FBakIsbUJBQWlCLFdBQUEsWUFGaEIsT0FBTSxDQUFBO0VBQUE7O0E7OztBRkdkLElBQU8sMEJBQVAsTUFBTyx5QkFBdUI7RUFHbEMsWUFBb0IsbUJBQThDLFFBQXdCLGNBQTBCO0FBQWhHLFNBQUEsb0JBQUE7QUFBOEMsU0FBQSxTQUFBO0FBQXdCLFNBQUEsZUFBQTtBQUYxRixTQUFBLFVBQWtCO0VBRW9HO0VBRXRILFdBQVE7RUFFUjtFQUVNLGNBQWMsWUFBc0I7O0FBQ3hDLFlBQU0sV0FBVyxJQUFJLFNBQVE7QUFDN0IsWUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBRWhELGVBQVMsT0FBTyxZQUFZLFdBQVcsU0FBUyxTQUFRLENBQUU7QUFDMUQsZUFBUyxPQUFPLFNBQVMsV0FBVyxNQUFNLFNBQVEsQ0FBRTtBQUNwRCxlQUFTLE9BQU8sYUFBYSxXQUFXLFNBQVM7QUFDakQsZUFBUyxPQUFPLFVBQVUsV0FBVyxNQUFNO0FBQzNDLGVBQVMsT0FBTyxZQUFZLFdBQVcsU0FBUyxTQUFRLENBQUU7QUFDMUQsZUFBUyxPQUFPLGFBQWEsYUFBYSxFQUFFO0FBRzVDLGNBQVEsSUFBSSxXQUFXLFFBQVE7QUFDL0IsY0FBUSxJQUFJLFNBQVMsT0FBTyxVQUFVLENBQUM7QUFDdkMsY0FBUSxJQUFJLFNBQVMsT0FBTyxPQUFPLENBQUM7QUFDcEMsY0FBUSxJQUFJLFNBQVMsT0FBTyxXQUFXLENBQUM7QUFDeEMsY0FBUSxJQUFJLFNBQVMsT0FBTyxRQUFRLENBQUM7QUFDckMsY0FBUSxJQUFJLFNBQVMsT0FBTyxVQUFVLENBQUM7QUFDdkMsY0FBUSxJQUFJLFNBQVMsT0FBTyxXQUFXLENBQUM7QUFDeEMsWUFBTSxLQUFLLGtCQUFrQixlQUFlLFFBQVEsRUFBRSxVQUFVLENBQUMsV0FBZTtBQUM5RSxhQUFLLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUM1QixHQUNFLENBQUMsVUFBUztBQUNSLGdCQUFRLElBQUksTUFBTTtNQUNwQixDQUFDO0lBT0w7Ozs7dUNBeENXLDBCQUF1QixpQ0FBQSxpQkFBQSxHQUFBLGlDQUFBLFNBQUEsR0FBQSxpQ0FBQSxZQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBdkIsMEJBQXVCLFdBQUEsQ0FBQSxDQUFBLHFCQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBO0FDWnBDLFFBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksUUFBQSxzQkFBQSxHQUFBLGlCQUFBO0FBQWUsUUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTSxRQUFBLHNCQUFBLEdBQUEsZUFBQTtBQUFVLFFBQUEsNEJBQUEsRUFBTztBQUMxQyxRQUFBLDhCQUFBLEdBQUEsdUJBQUEsQ0FBQTtBQUF5QyxRQUFBLDBCQUFBLFlBQUEsU0FBQSx5RUFBQSxRQUFBO0FBQUEsaUJBQVksSUFBQSxjQUFBLE1BQUE7UUFBcUIsQ0FBQTtBQUFFLFFBQUEsNEJBQUE7OztBQUF2RCxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFdBQUEsSUFBQSxPQUFBOzs7Ozs7a0ZEV1IseUJBQXVCLEVBQUEsV0FBQSwyQkFBQSxVQUFBLDBFQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBdkIseUJBQXVCLEVBQUEsU0FBQSxDQUFBQyxNQUFBLDRCQUFBLElBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxnQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxnQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR1pwQzs7OztTQUFTLGFBQUFDLFlBQW1CLE9BQU8sUUFBUSxvQkFBb0I7QUFDL0QsU0FBUyxhQUFhLFdBQVcsY0FBQUMsbUJBQWtCOzs7O0FFQW5EOzs7O1NBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQXFCLGNBQUFDLGFBQVksY0FBQUMsbUJBQWtCO0E7O0FBUzdDLElBQU8scUJBQVAsTUFBTyxvQkFBa0I7RUFJN0IsWUFBb0IsTUFBMEIsY0FBb0Msa0JBQWtDO0FBQWhHLFNBQUEsT0FBQTtBQUEwQixTQUFBLGVBQUE7QUFBb0MsU0FBQSxtQkFBQTtBQUYxRSxTQUFBLGFBQWEsWUFBWTtFQUV1RjtFQUV4SCxxQkFBa0I7QUFDaEIsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFdBQU8sS0FBSyxLQUFLLElBQW1CLEdBQUcsS0FBSyxVQUFVLDRCQUE0QixTQUFTLEVBQUUsRUFBRSxLQUM3RkMsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGtCQUFrQixJQUFVO0FBQzFCLFdBQU8sS0FBSyxLQUFLLElBQWlCLEdBQUcsS0FBSyxVQUFVLG9CQUFvQixFQUFFLEVBQUUsRUFBRSxLQUM1RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLG1DQUFtQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzVHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGdCQUFnQixVQUFrQjtBQUNoQyxRQUFJLE9BQU87TUFDVCxjQUFjLFNBQVMsT0FBTyxjQUFjLEVBQUUsU0FBUSxFQUFHLEtBQUk7TUFDN0QsYUFBYSxPQUFPLFNBQVMsT0FBTyxhQUFhLENBQUM7TUFDbEQsV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLENBQUM7O0FBRWhELFlBQVEsSUFBSSxRQUFRO0FBQ3BCLFlBQVEsSUFBSSxJQUFJO0FBQ2hCLFdBQU8sS0FBSyxLQUFLLEtBQVUsR0FBRyxLQUFLLFVBQVUsb0JBQW9CLElBQUksRUFBRSxLQUNyRUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLGtDQUFrQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzNHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGdCQUFnQixJQUFZLFVBQWtCO0FBQzVDLFFBQUksT0FBTztNQUNULGNBQWMsU0FBUyxPQUFPLGNBQWMsRUFBRSxTQUFRLEVBQUcsS0FBSTtNQUM3RCxhQUFhLE9BQU8sU0FBUyxPQUFPLGFBQWEsQ0FBQzs7QUFHcEQsV0FBTyxLQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssVUFBVSxvQkFBb0IsRUFBRSxJQUFJLElBQUksRUFBRSxLQUMxRUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLHNDQUFzQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQy9HLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLG1CQUFtQixJQUFVO0FBQzNCLFFBQUksT0FBTztNQUNULFVBQVU7O0FBRVosV0FBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVSx3QkFBd0IsRUFBRSxJQUFJLElBQUksRUFBRSxLQUN6RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLG9DQUFvQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzdHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjs7O3VDQWpFVyxxQkFBa0Isd0JBQUEsY0FBQSxHQUFBLHdCQUFBLFlBQUEsR0FBQSx3QkFBQSxnQkFBQSxDQUFBO0lBQUE7RUFBQTs7aUZBQWxCLHFCQUFrQixTQUFsQixvQkFBa0IsV0FBQSxZQUZqQixPQUFNLENBQUE7RUFBQTs7Ozs7O0FEQVIsSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBeUMsSUFBQSxzQkFBQSxHQUFBLDZCQUFBO0FBQXFCLElBQUEsNEJBQUE7Ozs7O0FBRGxFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsNENBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsU0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLFNBQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBT0osSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBc0MsSUFBQSxzQkFBQSxHQUFBLDhCQUFBO0FBQXNCLElBQUEsNEJBQUE7Ozs7O0FBRGhFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsNkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsTUFBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE1BQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBT0osSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBMEMsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQTBCLElBQUEsNEJBQUE7Ozs7O0FBRHhFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsNkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBaUJKLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBMEUsSUFBQSxzQkFBQSxDQUFBO0FBQTRCLElBQUEsNEJBQUE7Ozs7QUFBckQsSUFBQSxxQ0FBQSxTQUFBLGVBQUEsRUFBQTtBQUF5QixJQUFBLHlCQUFBO0FBQUEsSUFBQSxpQ0FBQSxlQUFBLFlBQUE7Ozs7O0FBSzlFLElBQUEsOEJBQUEsR0FBQSxHQUFBO0FBQXlDLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFnQyxJQUFBLDRCQUFBOzs7OztBQUQ3RSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSwwQkFBQSxHQUFBLDZDQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBOzs7O0FBRFEsSUFBQSx5QkFBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLFNBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxTQUFBLE9BQUEsVUFBQSxDQUFBOzs7QURsQ04sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtFQU9sQyxZQUFvQixvQkFBc0M7QUFBdEMsU0FBQSxxQkFBQTtBQU5WLFNBQUEsV0FBVyxJQUFJLGFBQVk7QUFFNUIsU0FBQSxpQkFBb0M7QUFFN0MsU0FBQSxlQUE4QixDQUFBO0VBRWdDO0VBRTlELFdBQVE7QUFDTixTQUFLLGlCQUFpQixJQUFJLFVBQVU7TUFDbEMsSUFBSSxJQUFJLFlBQVksS0FBSyxpQkFBaUIsS0FBSyxlQUFlLEtBQUssRUFBRTtNQUNyRSxVQUFVLElBQUksWUFBWSxLQUFLLGlCQUFpQixLQUFLLGVBQWUsV0FBVyxLQUFLLGlCQUFnQixHQUFJLENBQUNDLFlBQVcsUUFBUSxDQUFDO01BQzdILE9BQU8sSUFBSSxZQUFZLEtBQUssaUJBQWlCLEtBQUssbUJBQW1CLEtBQUssZUFBZSxLQUFLLElBQUksSUFBSSxDQUFDQSxZQUFXLFFBQVEsQ0FBQztNQUMzSCxXQUFXLElBQUksWUFBWSxLQUFLLGlCQUFpQixLQUFLLGVBQWUsWUFBWSxJQUFJLENBQUNBLFlBQVcsUUFBUSxDQUFDO01BQzFHLFFBQVEsSUFBSSxZQUFZLEtBQUssaUJBQWlCLEtBQUssZUFBZSxTQUFTLElBQUksQ0FBQ0EsWUFBVyxRQUFRLENBQUM7TUFDcEcsVUFBVSxJQUFJLFlBQVksS0FBSyxpQkFBaUIsS0FBSyxlQUFlLFdBQVcsSUFBSSxDQUFDQSxZQUFXLFFBQVEsQ0FBQztLQUN6RztBQUVELFNBQUssbUJBQW1CLG1CQUFrQixFQUFHLFVBQVUsQ0FBQyxpQkFBa0IsS0FBSyxlQUFlLFlBQWE7RUFDN0c7O0VBR0EsbUJBQW1CLE9BQXNCO0FBQ3ZDLFFBQUksV0FBVyxNQUFNLFNBQVEsRUFBRyxRQUFRLEtBQUssR0FBRztBQUNoRCxRQUFJLFNBQVMsU0FBUyxNQUFNLEdBQUc7QUFDL0IsUUFBSSxVQUFVLE9BQU8sQ0FBQyxFQUFFLFFBQVEseUJBQXlCLEdBQUc7QUFDNUQsUUFBSSxVQUFVLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxFQUFFLE9BQU8sR0FBRyxHQUFHLElBQUk7QUFDckQsV0FBTyxHQUFHLE9BQU8sSUFBSSxPQUFPO0VBQzlCO0VBRUEsY0FBVztBQUNULFFBQUksUUFBUSxLQUFLLE1BQU0sTUFBTSxRQUFRLE9BQU8sRUFBRTtBQUU5QyxRQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFdBQUssZUFBZSxTQUFTLE9BQU8sRUFBRSxTQUFTLElBQUksRUFBRSxXQUFXLE1BQUssQ0FBRTtBQUN2RTtJQUNGO0FBR0EsWUFBUSxNQUFNLFFBQVEsWUFBWSxFQUFFO0FBR3BDLFFBQUksTUFBTSxVQUFVLEdBQUc7QUFDckIsV0FBSyxlQUFlLFNBQVMsT0FBTyxFQUFFLFNBQVMsS0FBSyxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLFdBQVcsTUFBSyxDQUFFO0FBQ2xHO0lBQ0Y7QUFHQSxRQUFJLFVBQVUsTUFBTSxNQUFNLEdBQUcsRUFBRTtBQUMvQixRQUFJLFVBQVUsTUFBTSxNQUFNLEVBQUU7QUFHNUIsY0FBVSxRQUFRLFFBQVEseUJBQXlCLEdBQUc7QUFHdEQsUUFBSSxpQkFBaUIsR0FBRyxPQUFPLElBQUksT0FBTztBQUcxQyxTQUFLLGVBQWUsU0FBUyxPQUFPLEVBQUUsU0FBUyxnQkFBZ0IsRUFBRSxXQUFXLE1BQUssQ0FBRTtFQUNyRjtFQUVBLG1CQUFnQjtBQUNkLFVBQU0sTUFBTSxvQkFBSSxLQUFJO0FBQ3BCLFFBQUksV0FBVyxJQUFJLFdBQVUsSUFBSyxJQUFJLGtCQUFpQixDQUFFO0FBQ3pELFdBQU8sSUFBSSxZQUFXLEVBQUcsTUFBTSxHQUFHLEVBQUU7RUFDdEM7RUFFQSxJQUFJLFdBQVE7QUFDVixXQUFPLEtBQUssZUFBZSxJQUFJLFVBQVU7RUFDM0M7RUFFQSxJQUFJLFFBQUs7QUFDUCxXQUFPLEtBQUssZUFBZSxJQUFJLE9BQU87RUFDeEM7RUFFQSxJQUFJLFlBQVM7QUFDWCxXQUFPLEtBQUssZUFBZSxJQUFJLFdBQVc7RUFDNUM7RUFFQSxJQUFJLFNBQU07QUFDUixXQUFPLEtBQUssZUFBZSxJQUFJLFFBQVE7RUFDekM7RUFFQSxJQUFJLFdBQVE7QUFDVixXQUFPLEtBQUssZUFBZSxJQUFJLFVBQVU7RUFDM0M7RUFFQSxJQUFJLFlBQVM7QUFDWCxXQUFPLEtBQUssZUFBZSxJQUFJLFdBQVc7RUFDNUM7RUFFQSxTQUFNO0FBQ0osUUFBSSxLQUFLLGVBQWUsU0FBUztBQUMvQjtJQUNGO0FBRUEsUUFBSSxpQkFBaUIsT0FBTyxLQUFLLE1BQU0sS0FBSyxFQUN6QyxRQUFRLE9BQU8sRUFBRSxFQUNqQixRQUFRLEtBQUssR0FBRztBQUVuQixRQUFJLHNCQUFzQixpQ0FDckIsS0FBSyxlQUFlLFFBREM7TUFFeEIsT0FBTzs7QUFHVCxTQUFLLFNBQVMsS0FBSyxtQkFBbUI7RUFDeEM7Ozt1Q0EzR1csMEJBQXVCLGlDQUFBLGtCQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBdkIsMEJBQXVCLFdBQUEsQ0FBQSxDQUFBLHFCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsU0FBQSxXQUFBLGdCQUFBLGlCQUFBLEdBQUEsU0FBQSxFQUFBLFVBQUEsV0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLFdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLG1CQUFBLElBQUEsR0FBQSxDQUFBLE9BQUEsVUFBQSxHQUFBLENBQUEsUUFBQSxrQkFBQSxlQUFBLG1DQUFBLG1CQUFBLFlBQUEsWUFBQSxFQUFBLEdBQUEsQ0FBQSxTQUFBLG9CQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsYUFBQSxXQUFBLGVBQUEsb0NBQUEsbUJBQUEsU0FBQSxZQUFBLElBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsR0FBQSxDQUFBLGVBQUEsaUNBQUEsbUJBQUEsYUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLE9BQUEsUUFBQSxHQUFBLENBQUEsbUJBQUEsVUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLFNBQUEsV0FBQSxHQUFBLENBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFNBQUEsTUFBQSxHQUFBLENBQUEsbUJBQUEsWUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTs7QUNYcEMsUUFBQSw4QkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBO0FBQU0sUUFBQSwwQkFBQSxZQUFBLFNBQUEsNERBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBWSxJQUFBLE9BQUEsQ0FBUTtRQUFBLENBQUE7QUFFdEIsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFFBQUEseUJBQUEsR0FBQSxTQUFBLENBQUE7QUFDSixRQUFBLDRCQUFBO0FBQ0EsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixHQUFBLFNBQUEsQ0FBQTtBQUNFLFFBQUEsc0JBQUEsR0FBQSxPQUFBO0FBQUssUUFBQSw0QkFBQTtBQUMzQixRQUFBLHlCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0EsUUFBQSwwQkFBQSxHQUFBLHdDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFHSixRQUFBLDRCQUFBO0FBQ0EsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLFNBQUEsQ0FBQTtBQUNELFFBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQU0sUUFBQSw0QkFBQTtBQUN6QixRQUFBLDhCQUFBLElBQUEsU0FBQSxDQUFBO0FBQW9ILFFBQUEsMEJBQUEsU0FBQSxTQUFBLDJEQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBO0FBQUEsaUJBQUEsMkJBQVMsSUFBQSxZQUFBLENBQWE7UUFBQSxDQUFBO0FBQTFJLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDBCQUFBLElBQUEseUNBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUdKLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsU0FBQSxDQUFBO0FBQ0ssUUFBQSxzQkFBQSxJQUFBLGtCQUFBO0FBQVUsUUFBQSw0QkFBQTtBQUNuQyxRQUFBLHlCQUFBLElBQUEsWUFBQSxFQUFBO0FBQ0EsUUFBQSwwQkFBQSxJQUFBLHlDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFHSixRQUFBLDRCQUFBO0FBRUEsUUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNBLFFBQUEsc0JBQUEsSUFBQSxTQUFBO0FBQU8sUUFBQSw0QkFBQTtBQUMzQixRQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBLEVBQTBDLElBQUEsVUFBQSxFQUFBO0FBQ1osUUFBQSxzQkFBQSxJQUFBLFdBQUE7QUFBUyxRQUFBLDRCQUFBO0FBQ25DLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBd0IsUUFBQSxzQkFBQSxJQUFBLFNBQUE7QUFBTyxRQUFBLDRCQUFBO0FBQy9CLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBeUIsUUFBQSxzQkFBQSxJQUFBLFVBQUE7QUFBUSxRQUFBLDRCQUFBO0FBQ2pDLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBcUIsUUFBQSxzQkFBQSxJQUFBLE1BQUE7QUFBSSxRQUFBLDRCQUFBLEVBQVMsRUFDN0I7QUFHYixRQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsU0FBQSxFQUFBO0FBQ0EsUUFBQSxzQkFBQSxJQUFBLGVBQUE7QUFBYSxRQUFBLDRCQUFBO0FBQ2pDLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDSSxRQUFBLDBCQUFBLElBQUEsNENBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQTtBQUNKLFFBQUEsNEJBQUEsRUFBUztBQUdiLFFBQUEsMEJBQUEsSUFBQSx5Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBS0EsUUFBQSx5QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNKLFFBQUEsNEJBQUE7Ozs7QUFsRDRCLFFBQUEsMEJBQUEsYUFBQSxJQUFBLGNBQUE7QUFRZCxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxTQUFBLFdBQUEsV0FBQSxTQUFBO0FBT0EsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsTUFBQSxXQUFBLFdBQUEsU0FBQTtBQU9BLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLFVBQUEsV0FBQSxXQUFBLFNBQUE7QUFrQjhCLFFBQUEseUJBQUEsRUFBQTtBQUFBLFFBQUEsMEJBQUEsV0FBQSxJQUFBLFlBQUE7QUFJbEMsUUFBQSx5QkFBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLFNBQUEsV0FBQSxXQUFBLFNBQUE7QUFLZSxRQUFBLHlCQUFBO0FBQUEsUUFBQSxxQ0FBQSxTQUFBLElBQUEsT0FBQTs7Ozs7O2tGRHRDWix5QkFBdUIsRUFBQSxXQUFBLDJCQUFBLFVBQUEsbUVBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUF2Qix5QkFBdUIsRUFBQSxTQUFBLENBQUFDLE1BQUEsNEJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxnQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxnQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR1hwQzs7OztTQUFTLGFBQUFDLGtCQUF5Qjs7QTs7OztBQ0FsQyxJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUF3QixHQUFBLElBQUEsRUFDaEIsR0FBQSxNQUFBO0FBQ00sSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBO0FBQVEsSUFBQSxzQkFBQSxHQUFBLGNBQUE7QUFDeEIsSUFBQSw0QkFBQTtBQUNBLElBQUEsOEJBQUEsR0FBQSx1QkFBQSxDQUFBO0FBQXFCLElBQUEsMEJBQUEsWUFBQSxTQUFBLCtFQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFZLE9BQUEsWUFBQSxNQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUFvRCxJQUFBLDRCQUFBLEVBQXNCOzs7O0FBQXhFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsa0JBQUEsT0FBQSxVQUFBLEVBQTZCLFdBQUEsT0FBQSxPQUFBOzs7QURRakYsSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtFQUtsQyxZQUFvQixtQkFBOEMsT0FBK0IsUUFBd0IsY0FBMEI7QUFBL0gsU0FBQSxvQkFBQTtBQUE4QyxTQUFBLFFBQUE7QUFBK0IsU0FBQSxTQUFBO0FBQXdCLFNBQUEsZUFBQTtBQUZ6SCxTQUFBLFVBQWtCO0VBSWxCO0VBRUEsV0FBUTtBQUNOLFVBQU0sS0FBSyxPQUFPLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFFeEQsU0FBSyxrQkFBa0IsbUJBQW1CLEVBQUUsRUFBRSxVQUFVLENBQUMsU0FBUTtBQUMvRCxXQUFLLGFBQWE7QUFDbEIsY0FBUSxJQUFJLEtBQUssV0FBVyxRQUFRO0lBQ3RDLENBQUM7RUFDSDtFQUVNLFlBQVksZ0JBQTBCOztBQUMxQyxZQUFNLEtBQUssS0FBSyxXQUFXO0FBQzNCLFlBQU0sV0FBVyxJQUFJLFNBQVE7QUFDN0IsWUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBRWhELGVBQVMsT0FBTyxZQUFZLGVBQWUsU0FBUyxTQUFRLENBQUU7QUFDOUQsZUFBUyxPQUFPLFNBQVMsZUFBZSxNQUFNLFNBQVEsQ0FBRTtBQUN4RCxlQUFTLE9BQU8sYUFBYSxlQUFlLFNBQVM7QUFDckQsZUFBUyxPQUFPLFVBQVUsZUFBZSxNQUFNO0FBQy9DLGVBQVMsT0FBTyxZQUFZLGVBQWUsU0FBUyxTQUFRLENBQUU7QUFDOUQsZUFBUyxPQUFPLGFBQWEsYUFBYSxFQUFFO0FBRTVDLFlBQU0sS0FBSyxrQkFBa0IsY0FBYyxJQUFLLFFBQVEsRUFBRSxVQUFVLENBQUMsV0FBZTtBQUNsRixhQUFLLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUM1QixHQUNFLENBQUMsVUFBUztBQUNSLGdCQUFRLElBQUksTUFBTTtNQUNwQixDQUFDO0lBQ0w7Ozs7dUNBcENXLDBCQUF1QixpQ0FBQSxpQkFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUF2QiwwQkFBdUIsV0FBQSxDQUFBLENBQUEscUJBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGtCQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1pwQyxRQUFBLDBCQUFBLEdBQUEsd0NBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTs7O0FBQU0sUUFBQSwwQkFBQSxRQUFBLElBQUEsVUFBQTs7Ozs7O2tGRFlPLHlCQUF1QixFQUFBLFdBQUEsMkJBQUEsVUFBQSwwRUFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQXZCLHlCQUF1QixFQUFBLFNBQUEsQ0FBQUMsTUFBQSw0QkFBQUMsS0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGdDQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGdDQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWnBDOzs7O1NBQVMsYUFBQUMsa0JBQXlCOztBOzs7O0FDQWxDLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQXdCLEdBQUEsSUFBQTtBQUVoQixJQUFBLHNCQUFBLEdBQUEsV0FBQTtBQUFRLElBQUEsOEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBVSxJQUFBLDRCQUFBLEVBQU87QUFFbkMsSUFBQSw4QkFBQSxHQUFBLHVCQUFBLENBQUE7QUFBcUIsSUFBQSwwQkFBQSxZQUFBLFNBQUEsa0ZBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVksT0FBQSxlQUFBLE1BQUEsQ0FBc0I7SUFBQSxDQUFBO0FBQW9ELElBQUEsNEJBQUEsRUFBc0I7Ozs7QUFBeEUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxrQkFBQSxPQUFBLFVBQUEsRUFBNkIsV0FBQSxPQUFBLE9BQUE7OztBRFFwRixJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO0VBS3JDLFlBQW9CLG1CQUE4QyxPQUErQixRQUF5QixjQUEwQjtBQUFoSSxTQUFBLG9CQUFBO0FBQThDLFNBQUEsUUFBQTtBQUErQixTQUFBLFNBQUE7QUFBeUIsU0FBQSxlQUFBO0FBRjFILFNBQUEsVUFBa0I7RUFJbEI7RUFFQSxXQUFRO0FBQ04sVUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNLFNBQVMsU0FBUyxJQUFJLElBQUksQ0FBQztBQUV4RCxTQUFLLGtCQUFrQixtQkFBbUIsRUFBRSxFQUFFLFVBQVUsQ0FBQyxTQUFRO0FBQy9ELFdBQUssYUFBYTtBQUNsQixjQUFRLElBQUksS0FBSyxXQUFXLFFBQVE7SUFDdEMsQ0FBQztFQUNIO0VBR00sZUFBZSxnQkFBMEI7O0FBQzdDLFlBQU0sS0FBSyxLQUFLLFdBQVc7QUFDM0IsWUFBTSxXQUFXLElBQUksU0FBUTtBQUM3QixZQUFNLFlBQVksS0FBSyxhQUFhLGFBQVk7QUFFaEQsZUFBUyxPQUFPLFlBQVksZUFBZSxTQUFTLFNBQVEsQ0FBRTtBQUM5RCxlQUFTLE9BQU8sU0FBUyxlQUFlLE1BQU0sU0FBUSxDQUFFO0FBQ3hELGVBQVMsT0FBTyxhQUFhLGVBQWUsU0FBUztBQUNyRCxlQUFTLE9BQU8sVUFBVSxlQUFlLE1BQU07QUFDL0MsZUFBUyxPQUFPLFlBQVksZUFBZSxTQUFTLFNBQVEsQ0FBRTtBQUM5RCxlQUFTLE9BQU8sYUFBYSxhQUFhLEVBQUU7QUFFNUMsWUFBTSxLQUFLLGtCQUFrQixrQkFBa0IsS0FBSyxXQUFXLEVBQUcsRUFBRSxVQUFVLENBQUMsV0FBZTtBQUM1RixhQUFLLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUM1QixHQUNFLENBQUMsVUFBUztBQUNSLGdCQUFRLElBQUksTUFBTTtNQUNwQixDQUFDO0lBQ0w7Ozs7dUNBckNXLDZCQUEwQixpQ0FBQSxpQkFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUExQiw2QkFBMEIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGtCQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1p2QyxRQUFBLDBCQUFBLEdBQUEsMkNBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTs7O0FBQU0sUUFBQSwwQkFBQSxRQUFBLElBQUEsVUFBQTs7Ozs7O2tGRFlPLDRCQUEwQixFQUFBLFdBQUEsOEJBQUEsVUFBQSxnRkFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQTFCLDRCQUEwQixFQUFBLFNBQUEsQ0FBQUMsTUFBQSw0QkFBQUMsS0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLG1DQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLG1DQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWnZDOzs7O1NBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFhOzs7O0FFQ2pDOzs7O1NBQVMsY0FBQUMsbUJBQWtCO0FBRTNCLFNBQXFCLGNBQUFDLG1CQUFrQjtBQUN2QyxTQUFTLGNBQUFDLG1CQUFrQjs7O0FBUXJCLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFHdkIsWUFBb0IsTUFBMEIsY0FBb0Msa0JBQWtDO0FBQWhHLFNBQUEsT0FBQTtBQUEwQixTQUFBLGVBQUE7QUFBb0MsU0FBQSxtQkFBQTtBQUYxRSxTQUFBLGFBQWEsWUFBWTtFQUV1RjtFQUV4SCxZQUFTO0FBQ1AsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFdBQU8sS0FBSyxLQUFLLElBQVcsR0FBRyxLQUFLLFVBQVUsbUNBQW1DLFNBQVMsRUFBRSxFQUFFLEtBQzVGQyxZQUFXLFdBQVE7QUFFakIsYUFBT0MsWUFBVyxLQUFLO0lBQ3pCLENBQUMsQ0FBQztFQUVOOzs7dUNBYlcsZUFBWSx3QkFBQSxjQUFBLEdBQUEsd0JBQUEsWUFBQSxHQUFBLHdCQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOztpRkFBWixlQUFZLFNBQVosY0FBWSxXQUFBLFlBRlgsT0FBTSxDQUFBO0VBQUE7Ozs7Ozs7O0FEUmhCLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxJQUFBLHlCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXFELEdBQUEsT0FBQSxFQUFBO0FBRXZELElBQUEsNEJBQUE7Ozs7O0FBSUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEseUJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBcUQsR0FBQSxPQUFBLEVBQUE7QUFFdkQsSUFBQSw0QkFBQTs7Ozs7QUFaSixJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQW9FLEdBQUEsT0FBQSxDQUFBO0FBRWhFLElBQUEsMEJBQUEsR0FBQSxzQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBSUYsSUFBQSw0QkFBQTtBQUVBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxJQUFBLDBCQUFBLEdBQUEsc0NBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUlBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxJQUFBLHlCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0YsSUFBQSw0QkFBQSxFQUFNLEVBQ0Y7OztBQWQwRCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsK0JBQUEsR0FBQUMsSUFBQSxDQUFBO0FBT1ksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLCtCQUFBLEdBQUFDLElBQUEsQ0FBQTs7Ozs7QUFXNUUsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUE4QixHQUFBLE9BQUEsQ0FBQSxFQUNXLEdBQUEsT0FBQSxFQUFBLEVBQ04sR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsT0FBQTtBQUFLLElBQUEsNEJBQUE7QUFDOUIsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFpQyxJQUFBLHNCQUFBLENBQUE7O0FBQW1DLElBQUEsNEJBQUEsRUFBUztBQUcvRSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQStCLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLGNBQUE7QUFBWSxJQUFBLDRCQUFBO0FBQ3JDLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBaUMsSUFBQSxzQkFBQSxFQUFBOztBQUE4QyxJQUFBLDRCQUFBLEVBQVM7QUFHMUYsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUErQixJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxxQkFBQTtBQUFnQixJQUFBLDRCQUFBO0FBQ3pDLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBaUMsSUFBQSxzQkFBQSxFQUFBOztBQUFrRCxJQUFBLDRCQUFBLEVBQVMsRUFDeEY7QUFHUixJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXVDLElBQUEsT0FBQSxFQUFBLEVBQ00sSUFBQSxPQUFBLEVBQUEsRUFDUixJQUFBLEtBQUEsRUFBQTtBQUNDLElBQUEsc0JBQUEsSUFBQSxTQUFBO0FBQU8sSUFBQSw0QkFBQTtBQUN2QyxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXdDLElBQUEsc0JBQUEsRUFBQTs7QUFBa0MsSUFBQSw0QkFBQSxFQUFTLEVBQy9FO0FBR1IsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEyQyxJQUFBLE9BQUEsRUFBQSxFQUNSLElBQUEsS0FBQSxFQUFBO0FBQ0MsSUFBQSxzQkFBQSxJQUFBLE1BQUE7QUFBSSxJQUFBLDRCQUFBO0FBQ3BDLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBd0MsSUFBQSxzQkFBQSxFQUFBOztBQUFnQyxJQUFBLDRCQUFBLEVBQVMsRUFDN0U7QUFHUixJQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTJDLElBQUEsT0FBQSxFQUFBLEVBQ1IsSUFBQSxLQUFBLEVBQUE7QUFDQyxJQUFBLHNCQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsNEJBQUE7QUFDekMsSUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF3QyxJQUFBLHNCQUFBLEVBQUE7O0FBQW9DLElBQUEsNEJBQUEsRUFBUyxFQUNqRjtBQUdSLElBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMkMsSUFBQSxPQUFBLEVBQUEsRUFDUixJQUFBLEtBQUEsRUFBQTtBQUNDLElBQUEsc0JBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSw0QkFBQTtBQUN4QyxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXdDLElBQUEsc0JBQUEsRUFBQTs7QUFBb0MsSUFBQSw0QkFBQSxFQUFTLEVBQ2pGO0FBR1IsSUFBQSx5QkFBQSxJQUFBLG1CQUFBLEVBQUE7QUFHRixJQUFBLDRCQUFBLEVBQU07Ozs7QUE5QytCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsT0FBQSwyQkFBQSxHQUFBLEdBQUEsT0FBQSxTQUFBLE9BQUEsT0FBQSxPQUFBLE1BQUEsS0FBQSxHQUFBLEVBQUE7QUFLQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLE9BQUEsMkJBQUEsSUFBQSxJQUFBLE9BQUEsU0FBQSxPQUFBLE9BQUEsT0FBQSxNQUFBLGdCQUFBLEdBQUEsRUFBQTtBQUtBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsT0FBQSwyQkFBQSxJQUFBLElBQUEsT0FBQSxTQUFBLE9BQUEsT0FBQSxPQUFBLE1BQUEsb0JBQUEsR0FBQSxFQUFBO0FBUVMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxPQUFBLDJCQUFBLElBQUEsSUFBQSxPQUFBLFdBQUEsR0FBQSxFQUFBO0FBT0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxPQUFBLDJCQUFBLElBQUEsSUFBQSxPQUFBLFNBQUEsR0FBQSxFQUFBO0FBT0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxPQUFBLDJCQUFBLElBQUEsSUFBQSxPQUFBLGFBQUEsR0FBQSxFQUFBO0FBT0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxPQUFBLDJCQUFBLElBQUEsSUFBQSxPQUFBLGFBQUEsR0FBQSxFQUFBO0FBSU0sSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSx3QkFBQSxPQUFBLG9CQUFBLEVBQTZDLHdCQUFBLE9BQUEsb0JBQUE7OztBRHpEL0YsSUFBTyxrQkFBUCxNQUFPLGlCQUFlO0VBVTFCLFlBQW9CLGNBQTBCO0FBQTFCLFNBQUEsZUFBQTtBQVRYLFNBQUEsY0FBc0I7QUFDdEIsU0FBQSxZQUFvQjtBQUNwQixTQUFBLGdCQUF3QjtBQUN4QixTQUFBLGdCQUF3QjtBQUd4QixTQUFBLFlBQXFCO0VBSTlCO0VBRUEsV0FBUTtBQUNOLFNBQUssYUFBYSxVQUFTLEVBQUcsVUFBVSxDQUFDLFNBQVE7QUFDL0MsV0FBSyxRQUFRO0lBQ2YsQ0FBQztFQUNIOzs7dUNBakJXLGtCQUFlLGlDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUFmLGtCQUFlLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxhQUFBLGVBQUEsV0FBQSxhQUFBLGVBQUEsaUJBQUEsZUFBQSxpQkFBQSxzQkFBQSx3QkFBQSxzQkFBQSx3QkFBQSxXQUFBLFlBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxpQkFBQSxFQUFBLEdBQUEsQ0FBQSxTQUFBLG9CQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLDJCQUFBLEdBQUEsQ0FBQSxTQUFBLG1DQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLDJCQUFBLEdBQUEsQ0FBQSxTQUFBLCtDQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLDRCQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxpQ0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsK0JBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsc0JBQUEsR0FBQSxDQUFBLEdBQUEseUJBQUEsR0FBQSxDQUFBLEdBQUEsNEJBQUEsR0FBQSx3QkFBQSxzQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHlCQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBO0FDVjVCLFFBQUEsMEJBQUEsR0FBQSxnQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBLEVBQW9FLEdBQUEsd0NBQUEsSUFBQSxJQUFBLGVBQUEsTUFBQSxHQUFBLHFDQUFBOzs7O0FBQXJDLFFBQUEsMEJBQUEsUUFBQSxJQUFBLFNBQUEsRUFBaUIsWUFBQSxnQkFBQTs7Ozs7O2tGRFVuQyxpQkFBZSxFQUFBLFdBQUEsbUJBQUEsVUFBQSxpREFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQWYsaUJBQWUsRUFBQSxTQUFBLENBQUFDLE1BQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSx3QkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSx3QkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR1Y1Qjs7OztTQUFTLGFBQUFDLGtCQUFpQjtBQUMxQixTQUFpQyxjQUFBQyxtQkFBa0I7Ozs7OztBQ1UzQyxJQUFBLDhCQUFBLEdBQUEsT0FBQTtBQUNFLElBQUEsc0JBQUEsR0FBQSxzQkFBQTtBQUNGLElBQUEsNEJBQUE7Ozs7O0FBTUEsSUFBQSw4QkFBQSxHQUFBLE9BQUE7QUFDRSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFDRixJQUFBLDRCQUFBOzs7OztBQUdGLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBNEMsSUFBQSxzQkFBQSxDQUFBO0FBQWdCLElBQUEsNEJBQUE7Ozs7QUFBaEIsSUFBQSx5QkFBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxVQUFBOzs7OztBQUkxQyxJQUFBLHVDQUFBLENBQUE7QUFDRSxJQUFBLHNCQUFBLEdBQUEsVUFBQTs7Ozs7O0FBSUEsSUFBQSx5QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxlQUFBOzs7QUR2QkosSUFBTyxpQkFBUCxNQUFPLGdCQUFjO0VBTXpCLFlBQ1UsSUFDQSxjQUNBLFFBQWM7QUFGZCxTQUFBLEtBQUE7QUFDQSxTQUFBLGVBQUE7QUFDQSxTQUFBLFNBQUE7QUFQVixTQUFBLGFBQTRCO0FBRTVCLFNBQUEsWUFBcUI7QUFPbkIsU0FBSyxZQUFZLEtBQUssR0FBRyxNQUFNO01BQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUNDLFlBQVcsVUFBVUEsWUFBVyxLQUFLLENBQUM7TUFDbkQsT0FBTyxDQUFDLElBQUksQ0FBQ0EsWUFBVyxVQUFVQSxZQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUM7S0FDM0Q7RUFDSDtFQUVBLFdBQVE7QUFDTixRQUFJLEtBQUssVUFBVSxTQUFTO0FBQzFCO0lBQ0Y7QUFFQSxTQUFLLGFBQWE7QUFDbEIsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sWUFBWSxLQUFLLFVBQVU7QUFFakMsU0FBSyxhQUFhLFVBQVUsU0FBUyxFQUFFLFVBQ3JDLENBQUMsYUFBWTtBQUNYLFVBQUksWUFBWSxTQUFTLFNBQVMsU0FBUyxjQUFjO0FBQ3ZELGFBQUssYUFBYSxZQUFZO1VBQzVCLE9BQU8sU0FBUztVQUNoQixjQUFjLFNBQVM7VUFDdkIsV0FBVyxTQUFTO1NBQ3JCO0FBRUQsYUFBSyxZQUFZO0FBQ2pCLGFBQUssT0FBTyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQzVCLE9BQU87QUFDTCxhQUFLLGFBQWE7QUFDbEIsYUFBSyxZQUFZO01BQ25CO0lBQ0YsR0FDQSxDQUFDLFVBQVM7QUFDUixXQUFLLGFBQWE7QUFDbEIsV0FBSyxZQUFZO0lBQ25CLENBQUM7RUFFTDs7O3VDQS9DVyxpQkFBYyxpQ0FBQSxlQUFBLEdBQUEsaUNBQUEsWUFBQSxHQUFBLGlDQUFBLFNBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUFkLGlCQUFjLFdBQUEsQ0FBQSxDQUFBLFdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLFdBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLFNBQUEsbUJBQUEsU0FBQSxRQUFBLFNBQUEsZUFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxPQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEsWUFBQSxtQkFBQSxTQUFBLFFBQUEsWUFBQSxlQUFBLGtCQUFBLEdBQUEsQ0FBQSxTQUFBLGlCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEsU0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHdCQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBOztBQ1gzQixRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWlDLEdBQUEsT0FBQSxDQUFBLEVBQ0YsR0FBQSxRQUFBLENBQUE7QUFLRyxRQUFBLDBCQUFBLFlBQUEsU0FBQSxtREFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFZLElBQUEsU0FBQSxDQUFVO1FBQUEsQ0FBQTtBQUVsRCxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsU0FBQSxDQUFBO0FBQ0gsUUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBTSxRQUFBLDRCQUFBO0FBQ3pCLFFBQUEseUJBQUEsR0FBQSxTQUFBLENBQUE7QUFDQSxRQUFBLDBCQUFBLEdBQUEsaUNBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTtBQUdGLFFBQUEsNEJBQUE7QUFFQSxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsU0FBQSxDQUFBO0FBQ0EsUUFBQSxzQkFBQSxJQUFBLE9BQUE7QUFBSyxRQUFBLDRCQUFBO0FBQzNCLFFBQUEseUJBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxRQUFBLDBCQUFBLElBQUEsa0NBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTtBQUdGLFFBQUEsNEJBQUE7QUFFQSxRQUFBLDBCQUFBLElBQUEsOEJBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUVBLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFFRSxRQUFBLDBCQUFBLElBQUEseUNBQUEsR0FBQSxHQUFBLGdCQUFBLEVBQUEsRUFBK0MsSUFBQSx3Q0FBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEscUNBQUE7QUFRakQsUUFBQSw0QkFBQSxFQUFTLEVBSUosRUFDSDs7Ozs7O0FBbkNFLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsYUFBQSxJQUFBLFNBQUE7QUFLTSxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFVBQUEsVUFBQSxJQUFBLFVBQUEsSUFBQSxPQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLElBQUEsVUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxRQUFBO0FBUUEsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxVQUFBLFVBQUEsSUFBQSxVQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLGNBQUEsVUFBQSxJQUFBLFVBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsUUFBQTtBQUtOLFFBQUEseUJBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxVQUFBO0FBRWtDLFFBQUEseUJBQUE7QUFBQSxRQUFBLDBCQUFBLFlBQUEsSUFBQSxhQUFBLElBQUEsVUFBQSxPQUFBO0FBRXJCLFFBQUEseUJBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsQ0FBQSxJQUFBLFNBQUEsRUFBa0IsWUFBQSxVQUFBOzs7Ozs7a0ZEakI1QixnQkFBYyxFQUFBLFdBQUEsa0JBQUEsVUFBQSwwQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQWQsZ0JBQWMsRUFBQSxTQUFBLENBQUFDLE1BQUFDLEtBQUEsdUJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLHVCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLHVCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWDNCOzs7O1NBQVMsYUFBQUMsYUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFlLFVBQUFDLGVBQWM7QUFDL0QsU0FBUyxlQUFBQyxjQUFhLGFBQUFDLFlBQVcsY0FBQUMsbUJBQWtCOzs7O0FDU3ZDLElBQUEsOEJBQUEsR0FBQSxHQUFBO0FBQTZDLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUEwQixJQUFBLDRCQUFBOzs7OztBQUQzRSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSwwQkFBQSxHQUFBLDZDQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBOzs7O0FBRFEsSUFBQSx5QkFBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLGFBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLE9BQUEsVUFBQSxDQUFBOzs7OztBQVFKLElBQUEsOEJBQUEsR0FBQSxHQUFBO0FBQTRDLElBQUEsc0JBQUEsR0FBQSxxQ0FBQTtBQUE2QixJQUFBLDRCQUFBOzs7OztBQUQ3RSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSwwQkFBQSxHQUFBLDhDQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBOzs7O0FBRFEsSUFBQSx5QkFBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLFlBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxZQUFBLE9BQUEsVUFBQSxDQUFBOzs7QURQVixJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO0VBT25DLFlBQW9CLG9CQUFzQztBQUF0QyxTQUFBLHFCQUFBO0FBTlYsU0FBQSxXQUFXLElBQUlDLGNBQVk7QUFFNUIsU0FBQSxrQkFBc0M7QUFFL0MsU0FBQSxlQUE4QixDQUFBO0VBRStCO0VBRTdELFdBQVE7QUFDSixTQUFLLGtCQUFrQixJQUFJQyxXQUFVO01BQ25DLElBQUksSUFBSUMsYUFBWSxLQUFLLGtCQUFrQixLQUFLLGdCQUFnQixLQUFLLEVBQUU7TUFDdkUsY0FBYyxJQUFJQSxhQUFZLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLGVBQWUsSUFBSSxDQUFDQyxZQUFXLFFBQVEsQ0FBQztNQUNsSCxhQUFhLElBQUlELGFBQVksS0FBSyxrQkFBa0IsS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0IsV0FBVyxJQUFJLElBQUksQ0FBQ0MsWUFBVyxRQUFRLENBQUM7S0FDMUk7RUFDTDtFQUVBLElBQUksZUFBWTtBQUNkLFdBQU8sS0FBSyxnQkFBZ0IsSUFBSSxjQUFjO0VBQ2hEO0VBRUMsSUFBSSxjQUFXO0FBQ2QsV0FBTyxLQUFLLGdCQUFnQixJQUFJLGFBQWE7RUFDL0M7RUFFQSxTQUFNO0FBQ0osUUFBRyxLQUFLLGdCQUFnQixTQUFRO0FBQzlCO0lBQ0Y7QUFFQSxRQUFJLGlCQUFpQixPQUFPLEtBQUssWUFBWSxLQUFLLEVBQy9DLFFBQVEsT0FBTyxFQUFFLEVBQ2pCLFFBQVEsS0FBSyxHQUFHO0FBRW5CLFFBQUksdUJBQXVCLGlDQUN0QixLQUFLLGdCQUFnQixRQURDO01BRXpCLGFBQWE7O0FBR2YsU0FBSyxTQUFTLEtBQUssb0JBQW9CO0VBQ3pDOztFQUdBLG1CQUFtQixhQUE0QjtBQUM3QyxRQUFJLFdBQVcsWUFBWSxTQUFRLEVBQUcsUUFBUSxLQUFLLEdBQUc7QUFDdEQsUUFBSSxTQUFTLFNBQVMsTUFBTSxHQUFHO0FBQy9CLFFBQUksVUFBVSxPQUFPLENBQUMsRUFBRSxRQUFRLHlCQUF5QixHQUFHO0FBQzVELFFBQUksVUFBVSxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLEdBQUcsR0FBRyxJQUFJO0FBQ3JELFdBQU8sR0FBRyxPQUFPLElBQUksT0FBTztFQUM5QjtFQUVBLGNBQVc7QUFDVCxRQUFJLGNBQWMsS0FBSyxZQUFZLE1BQU0sUUFBUSxPQUFPLEVBQUU7QUFFMUQsUUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixXQUFLLGdCQUFnQixTQUFTLGFBQWEsRUFBRSxTQUFTLElBQUksRUFBRSxXQUFXLE1BQUssQ0FBRTtBQUM5RTtJQUNGO0FBR0Esa0JBQWMsWUFBWSxRQUFRLFlBQVksRUFBRTtBQUdoRCxRQUFJLFlBQVksVUFBVSxHQUFHO0FBQzNCLFdBQUssZ0JBQWdCLFNBQVMsYUFBYSxFQUFFLFNBQVMsS0FBSyxZQUFZLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLFdBQVcsTUFBSyxDQUFFO0FBQy9HO0lBQ0Y7QUFHQSxRQUFJLFVBQVUsWUFBWSxNQUFNLEdBQUcsRUFBRTtBQUNyQyxRQUFJLFVBQVUsWUFBWSxNQUFNLEVBQUU7QUFHbEMsY0FBVSxRQUFRLFFBQVEseUJBQXlCLEdBQUc7QUFHdEQsUUFBSSxpQkFBaUIsR0FBRyxPQUFPLElBQUksT0FBTztBQUMxQyxZQUFRLElBQUksY0FBYztBQUUxQixTQUFLLGdCQUFnQixTQUFTLGFBQWEsRUFBRSxTQUFTLGdCQUFnQixFQUFFLFdBQVcsTUFBSyxDQUFFO0VBQzVGOzs7dUNBaEZXLDJCQUF3QixpQ0FBQSxrQkFBQSxDQUFBO0lBQUE7RUFBQTs7OEVBQXhCLDJCQUF3QixXQUFBLENBQUEsQ0FBQSx1QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFNBQUEsV0FBQSxpQkFBQSxrQkFBQSxHQUFBLFNBQUEsRUFBQSxVQUFBLFdBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxXQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxtQkFBQSxJQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsR0FBQSxDQUFBLGVBQUEsc0NBQUEsbUJBQUEsZ0JBQUEsWUFBQSxFQUFBLEdBQUEsQ0FBQSxTQUFBLG9CQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsYUFBQSxXQUFBLGVBQUEsMEJBQUEsbUJBQUEsZUFBQSxZQUFBLElBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTs7QUNYckMsUUFBQSw4QkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBO0FBQU0sUUFBQSwwQkFBQSxZQUFBLFNBQUEsNkRBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBWSxJQUFBLE9BQUEsQ0FBUTtRQUFBLENBQUE7QUFFdEIsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFFBQUEseUJBQUEsR0FBQSxTQUFBLENBQUE7QUFDSixRQUFBLDRCQUFBO0FBRUEsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixHQUFBLFNBQUEsQ0FBQTtBQUNLLFFBQUEsc0JBQUEsR0FBQSxrQkFBQTtBQUFVLFFBQUEsNEJBQUE7QUFDbkMsUUFBQSx5QkFBQSxHQUFBLFlBQUEsQ0FBQTtBQUNBLFFBQUEsMEJBQUEsR0FBQSx5Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBR0osUUFBQSw0QkFBQTtBQUVBLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLENBQUE7QUFDRCxRQUFBLHNCQUFBLElBQUEsZUFBQTtBQUFhLFFBQUEsNEJBQUE7QUFDaEMsUUFBQSw4QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUFtSCxRQUFBLDBCQUFBLFNBQUEsU0FBQSw0REFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFTLElBQUEsWUFBQSxDQUFhO1FBQUEsQ0FBQTtBQUF6SSxRQUFBLDRCQUFBO0FBQ0EsUUFBQSwwQkFBQSxJQUFBLDBDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFHSixRQUFBLDRCQUFBO0FBRUEsUUFBQSx5QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNKLFFBQUEsNEJBQUE7Ozs7QUF2QjRCLFFBQUEsMEJBQUEsYUFBQSxJQUFBLGVBQUE7QUFTZCxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxhQUFBLFdBQUEsV0FBQSxTQUFBO0FBUUEsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsWUFBQSxXQUFBLFdBQUEsU0FBQTtBQUtXLFFBQUEseUJBQUE7QUFBQSxRQUFBLHFDQUFBLFNBQUEsSUFBQSxPQUFBOzs7Ozs7a0ZEWFosMEJBQXdCLEVBQUEsV0FBQSw0QkFBQSxVQUFBLHVFQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBeEIsMEJBQXdCLEVBQUEsU0FBQSxDQUFBQyxNQUFBLDRCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsaUNBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsaUNBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVYckM7Ozs7U0FBUyxhQUFBQyxtQkFBeUI7O0E7Ozs7QUNBbEMsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBeUIsR0FBQSxJQUFBLEVBQ2pCLEdBQUEsTUFBQTtBQUNNLElBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQU0sSUFBQSw0QkFBQTtBQUFRLElBQUEsc0JBQUEsR0FBQSxtQkFBQTtBQUN4QixJQUFBLDRCQUFBO0FBQ0EsSUFBQSw4QkFBQSxHQUFBLHlCQUFBLENBQUE7QUFBdUIsSUFBQSwwQkFBQSxZQUFBLFNBQUEsa0ZBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVksT0FBQSxZQUFBLE1BQUEsQ0FBbUI7SUFBQSxDQUFBO0FBQXNELElBQUEsNEJBQUEsRUFBd0I7Ozs7QUFBNUUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxtQkFBQSxPQUFBLFdBQUEsRUFBK0IsV0FBQSxPQUFBLE9BQUE7OztBRFFyRixJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO0VBS25DLFlBQW9CLG9CQUFnRCxPQUErQixRQUF3QixjQUEwQjtBQUFqSSxTQUFBLHFCQUFBO0FBQWdELFNBQUEsUUFBQTtBQUErQixTQUFBLFNBQUE7QUFBd0IsU0FBQSxlQUFBO0FBRjNILFNBQUEsVUFBa0I7RUFJbEI7RUFFQSxXQUFRO0FBQ04sVUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNLFNBQVMsU0FBUyxJQUFJLElBQUksQ0FBQztBQUV4RCxTQUFLLG1CQUFtQixrQkFBa0IsRUFBRSxFQUFFLFVBQVUsQ0FBQyxTQUFRO0FBQy9ELFdBQUssY0FBYztJQUNyQixDQUFDO0VBQ0g7RUFFTSxZQUFZLGlCQUE0Qjs7QUFDNUMsWUFBTSxLQUFLLEtBQUssWUFBWTtBQUM1QixZQUFNLFdBQVcsSUFBSSxTQUFRO0FBRTdCLGVBQVMsT0FBTyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixFQUFFO0FBQ2xFLGVBQVMsT0FBTyxlQUFlLGdCQUFnQixZQUFZLFNBQVEsQ0FBRTtBQUVyRSxZQUFNLEtBQUssbUJBQW1CLGdCQUFnQixJQUFLLFFBQVEsRUFBRSxVQUFVLENBQUMsV0FBZTtBQUNyRixhQUFLLE9BQU8sU0FBUyxDQUFDLGVBQWUsQ0FBQztNQUN4QyxHQUNFLENBQUMsVUFBUztBQUNSLGdCQUFRLElBQUksTUFBTTtNQUNwQixDQUFDO0lBQ0w7Ozs7dUNBOUJXLDJCQUF3QixpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUF4QiwyQkFBd0IsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLG1CQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1pyQyxRQUFBLDBCQUFBLEdBQUEseUNBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTs7O0FBQU0sUUFBQSwwQkFBQSxRQUFBLElBQUEsV0FBQTs7Ozs7O2tGRFlPLDBCQUF3QixFQUFBLFdBQUEsNEJBQUEsVUFBQSwrRUFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQXhCLDBCQUF3QixFQUFBLFNBQUEsQ0FBQUMsTUFBQSw4QkFBQUMsS0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGlDQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGlDQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWnJDOzs7O1NBQVMsYUFBQUMsbUJBQXlCO0FBRWxDLFNBQVMsc0JBQXNCOztBOzs7O0FDRi9CLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQXlCLEdBQUEsSUFBQTtBQUVqQixJQUFBLHNCQUFBLEdBQUEsV0FBQTtBQUFRLElBQUEsOEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxzQkFBQSxHQUFBLGlCQUFBO0FBQWUsSUFBQSw0QkFBQSxFQUFPO0FBRXhDLElBQUEsOEJBQUEsR0FBQSx5QkFBQSxDQUFBO0FBQXVCLElBQUEsMEJBQUEsWUFBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFZLE9BQUEsZUFBQSxNQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUFzRCxJQUFBLDRCQUFBLEVBQXdCOzs7O0FBQTVFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsbUJBQUEsT0FBQSxXQUFBLEVBQStCLFdBQUEsT0FBQSxPQUFBOzs7QURXeEYsSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtFQU10QyxZQUFvQixvQkFDVixtQkFDQSxPQUNBLFFBQ0EsY0FDQSxrQkFBa0M7QUFMeEIsU0FBQSxxQkFBQTtBQUNWLFNBQUEsb0JBQUE7QUFDQSxTQUFBLFFBQUE7QUFDQSxTQUFBLFNBQUE7QUFDQSxTQUFBLGVBQUE7QUFDQSxTQUFBLG1CQUFBO0FBUlYsU0FBQSxVQUFrQjtBQUNsQixTQUFBLGFBQXFCO0VBU3JCO0VBRUEsV0FBUTtBQUNOLFVBQU0sS0FBSyxPQUFPLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFFeEQsU0FBSyxtQkFBbUIsa0JBQWtCLEVBQUUsRUFBRSxVQUFVLENBQUMsU0FBUTtBQUMvRCxXQUFLLGNBQWM7SUFDckIsQ0FBQztFQUNIO0VBR00sZUFBZSxpQkFBNEI7O0FBQy9DLFlBQU0sZ0JBQWdCLEtBQUssWUFBWTtBQUN2QyxZQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLFlBQU0sWUFBWSxLQUFLLGFBQWEsYUFBWSxHQUFJLFNBQVE7QUFFNUQsZUFBUyxPQUFPLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLEVBQUU7QUFDbEUsZUFBUyxPQUFPLGVBQWUsZ0JBQWdCLFlBQVksU0FBUSxDQUFFO0FBRXJFLFlBQU0sT0FBTyxNQUFNLGVBQWUsS0FBSyxrQkFBa0IscUJBQXFCLGFBQWEsSUFBSSxhQUFhLENBQUM7QUFDN0csV0FBSyxhQUFhLEtBQUs7QUFFdkIsVUFBSSxLQUFLLFdBQVcsUUFBTyxLQUFNLEdBQUc7QUFDbEMsY0FBTSxLQUFLLG1CQUFtQixtQkFBbUIsYUFBYSxFQUFFLFVBQVUsQ0FBQyxXQUFlO0FBQ3hGLGVBQUssT0FBTyxTQUFTLENBQUMsZUFBZSxDQUFDO1FBQ3hDLEdBQ0UsQ0FBQyxVQUFTO0FBQ1Isa0JBQVEsSUFBSSxNQUFNO1FBQ3BCLENBQUM7TUFDTCxPQUFPO0FBQ0wsYUFBSyxpQkFBaUIsU0FBUyxXQUM3QixpQkFDQSwwREFBb0QsS0FBSyxlQUFlLElBQUksWUFBWSxVQUFVLElBQUksS0FBSyxVQUFVLElBQUksS0FBSyxlQUFlLElBQUksbUJBQWdCLGlCQUFjLElBQUksS0FBSyxlQUFlLElBQUksaUJBQWMsZUFBWSxXQUNyTyxNQUFTO01BQ2I7SUFDRjs7Ozt1Q0FoRFcsOEJBQTJCLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsaUJBQUEsR0FBQSxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBQUEsZ0JBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEsMEJBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLG1CQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxxQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ2Z4QyxRQUFBLDBCQUFBLEdBQUEsNENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTs7O0FBQU0sUUFBQSwwQkFBQSxRQUFBLElBQUEsV0FBQTs7Ozs7O2tGRGVPLDZCQUEyQixFQUFBLFdBQUEsK0JBQUEsVUFBQSxxRkFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQTNCLDZCQUEyQixFQUFBLFNBQUEsQ0FBQUMsTUFBQSw4QkFBQSw0QkFBQUMsS0FBQSx1QkFBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLG9DQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLG9DQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFZnhDOzs7O1NBQVMsYUFBQUMsbUJBQXlCOztBO0FBWTVCLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7RUFHbkMsWUFBb0Isb0JBQWdELFFBQXdCLGNBQTBCO0FBQWxHLFNBQUEscUJBQUE7QUFBZ0QsU0FBQSxTQUFBO0FBQXdCLFNBQUEsZUFBQTtBQUY1RixTQUFBLFVBQWtCO0VBRXNHO0VBRXhILFdBQVE7RUFFUjtFQUVNLGNBQWMsYUFBd0I7O0FBQzFDLFlBQU0sV0FBVyxJQUFJLFNBQVE7QUFDN0IsWUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBRWhELGVBQVMsT0FBTyxnQkFBZ0IsWUFBWSxnQkFBZ0IsRUFBRTtBQUM5RCxlQUFTLE9BQU8sZUFBZSxZQUFZLFlBQVksU0FBUSxDQUFFO0FBQ2pFLGVBQVMsT0FBTyxhQUFhLGFBQWEsRUFBRTtBQUU1QyxXQUFLLG1CQUFtQixnQkFBZ0IsUUFBUSxFQUFFLFVBQVUsQ0FBQyxXQUFlO0FBQzFFLGFBQUssT0FBTyxTQUFTLENBQUMsZUFBZSxDQUFDO01BQ3hDLEdBQ0UsQ0FBQyxVQUFTO0FBQ1IsZ0JBQVEsSUFBSSxNQUFNO01BQ3BCLENBQUM7SUFDTDs7Ozt1Q0F2QlcsMkJBQXdCLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLFlBQUEsQ0FBQTtJQUFBO0VBQUE7OzhFQUF4QiwyQkFBd0IsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0NBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7QUNackMsUUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxRQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBZSxRQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLFFBQUEsc0JBQUEsR0FBQSxpQkFBQTtBQUFlLFFBQUEsNEJBQUEsRUFBTztBQUMvQyxRQUFBLDhCQUFBLEdBQUEseUJBQUEsQ0FBQTtBQUEyQyxRQUFBLDBCQUFBLFlBQUEsU0FBQSw0RUFBQSxRQUFBO0FBQUEsaUJBQVksSUFBQSxjQUFBLE1BQUE7UUFBcUIsQ0FBQTtBQUFFLFFBQUEsNEJBQUE7OztBQUF2RCxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFdBQUEsSUFBQSxPQUFBOzs7Ozs7a0ZEV1YsMEJBQXdCLEVBQUEsV0FBQSw0QkFBQSxVQUFBLCtFQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBeEIsMEJBQXdCLEVBQUEsU0FBQSxDQUFBQyxNQUFBLDhCQUFBQyxLQUFBLHFCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsaUNBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsaUNBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVackM7Ozs7U0FBUyxhQUFBQyxtQkFBaUI7Ozs7Ozs7QUNnQk4sSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBNkMsR0FBQSxJQUFBO0FBQ3JDLElBQUEsc0JBQUEsQ0FBQTtBQUFvQixJQUFBLDRCQUFBO0FBQ3hCLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBO0FBQThCLElBQUEsNEJBQUE7QUFDbEMsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7O0FBQTJDLElBQUEsNEJBQUE7QUFDL0MsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF1QixHQUFBLFVBQUEsQ0FBQTtBQUdmLElBQUEseUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBLEVBQVMsRUFDUDs7OztBQVpGLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsZUFBQSxFQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxlQUFBLFlBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLEdBQUEsR0FBQSxlQUFBLFdBQUEsQ0FBQTtBQUVRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwrQkFBQSxHQUFBQyxNQUFBLGVBQUEsRUFBQSxDQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxjQUFBLCtCQUFBLEdBQUFDLE1BQUEsZUFBQSxFQUFBLENBQUE7Ozs7O0FBcEI1QixJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUEwRCxHQUFBLFNBQUEsQ0FBQSxFQUNtQixHQUFBLFNBQUEsQ0FBQSxFQUMzQyxHQUFBLElBQUEsRUFDbEIsR0FBQSxJQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLElBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQ04sSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBUyxJQUFBLDRCQUFBO0FBQ2IsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsY0FBQTtBQUFZLElBQUEsNEJBQUE7QUFDaEIsSUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUF3QixJQUFBLHNCQUFBLElBQUEsYUFBQTtBQUFLLElBQUEsNEJBQUEsRUFBSyxFQUNqQztBQUVULElBQUEsOEJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSwwQkFBQSxJQUFBLGlEQUFBLElBQUEsSUFBQSxNQUFBLENBQUE7QUFlSixJQUFBLDRCQUFBLEVBQVEsRUFDSjs7OztBQWhCNEIsSUFBQSx5QkFBQSxFQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLE9BQUEsWUFBQTs7Ozs7QUFvQnBDLElBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFBd0IsSUFBQSxzQkFBQSxHQUFBLGdEQUFBO0FBQW9DLElBQUEsNEJBQUE7OztBRDFCbEUsSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtFQUdyQyxZQUFvQixvQkFBc0M7QUFBdEMsU0FBQSxxQkFBQTtBQUZwQixTQUFBLGVBQThCLENBQUE7RUFHOUI7RUFFQSxXQUFRO0FBQ04sU0FBSyxtQkFBbUIsbUJBQWtCLEVBQUcsVUFBVSxDQUFDLGlCQUFrQixLQUFLLGVBQWUsWUFBYTtFQUM3RztFQUVBLG1CQUFtQixJQUFVO0FBQzNCLFNBQUssbUJBQW1CLG1CQUFtQixFQUFFLEVBQUUsVUFBUztFQUMxRDs7O3VDQVpXLDZCQUEwQixpQ0FBQSxrQkFBQSxDQUFBO0lBQUE7RUFBQTs7OEVBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsWUFBQSxPQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsa0JBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxXQUFBLElBQUEsU0FBQSxXQUFBLEdBQUEsT0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxpQkFBQSxrQkFBQSxnQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsdUJBQUEsVUFBQSxnQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxzQkFBQSxVQUFBLGlCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLFVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1Z2QyxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXVCLEdBQUEsTUFBQSxDQUFBO0FBQ0ssUUFBQSxzQkFBQSxHQUFBLGtCQUFBO0FBQWdCLFFBQUEsNEJBQUE7QUFDeEMsUUFBQSx5QkFBQSxHQUFBLElBQUE7QUFFQSxRQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFFBQUEsMEJBQUEsR0FBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTBELEdBQUEsbURBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLHFDQUFBO0FBa0MxRCxRQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBLEVBQWtGLEdBQUEsVUFBQTtBQUNwRSxRQUFBLHNCQUFBLElBQUEsS0FBQTtBQUFHLFFBQUEsNEJBQUEsRUFBVyxFQUNuQixFQUNQOzs7O0FBckNJLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGFBQUEsU0FBQSxDQUFBLEVBQStCLFlBQUEsaUJBQUE7QUFrQ08sUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxjQUFBLCtCQUFBLEdBQUFDLElBQUEsQ0FBQTs7Ozs7O2tGRDdCdkMsNEJBQTBCLEVBQUEsV0FBQSw4QkFBQSxVQUFBLG1GQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBMUIsNEJBQTBCLEVBQUEsU0FBQSxDQUFBQyxNQUFBLDRCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsbUNBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsbUNBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVWdkM7Ozs7U0FBUyxhQUFBQyxhQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQWUsVUFBQUMsZUFBYztBQUMvRCxTQUFTLGVBQUFDLGNBQWEsYUFBQUMsWUFBVyxjQUFBQyxtQkFBa0I7Ozs7QUNRdkMsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUErQyxJQUFBLHNCQUFBLENBQUE7QUFBUyxJQUFBLDRCQUFBOzs7O0FBQXZCLElBQUEsMEJBQUEsU0FBQSxNQUFBO0FBQWMsSUFBQSx5QkFBQTtBQUFBLElBQUEsaUNBQUEsTUFBQTs7Ozs7QUFHL0MsSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBdUMsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQW9CLElBQUEsNEJBQUE7Ozs7O0FBRC9ELElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsaURBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBUUosSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBc0MsSUFBQSxzQkFBQSxHQUFBLDhCQUFBO0FBQXNCLElBQUEsNEJBQUE7Ozs7O0FBRGhFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsaURBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsTUFBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE1BQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBT0osSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBMEMsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQTBCLElBQUEsNEJBQUE7Ozs7O0FBRHhFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsaURBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBZUosSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUEwRSxJQUFBLHNCQUFBLENBQUE7QUFBNEIsSUFBQSw0QkFBQTs7OztBQUFyRCxJQUFBLHFDQUFBLFNBQUEsZUFBQSxFQUFBO0FBQXlCLElBQUEseUJBQUE7QUFBQSxJQUFBLGlDQUFBLGVBQUEsWUFBQTs7Ozs7QUFLOUUsSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBeUMsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQWdDLElBQUEsNEJBQUE7Ozs7O0FBRDdFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsaURBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsU0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLFNBQUEsT0FBQSxVQUFBLENBQUE7OztBRHBDTixJQUFPLDhCQUFQLE1BQU8sNkJBQTJCO0VBUXRDLFlBQW9CLG9CQUFzQztBQUF0QyxTQUFBLHFCQUFBO0FBUFYsU0FBQSxXQUFXLElBQUlDLGNBQVk7QUFFNUIsU0FBQSxxQkFBNEM7QUFFckQsU0FBQSxlQUE4QixDQUFBO0FBQzlCLFNBQUEsT0FBaUIsTUFBTSxLQUFLLEVBQUUsUUFBUSxHQUFFLEdBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0VBRUc7RUFFOUQsV0FBUTtBQUNOLFNBQUsscUJBQXFCLElBQUlDLFdBQVU7TUFDdEMsSUFBSSxJQUFJQyxhQUFZLEtBQUsscUJBQXFCLEtBQUssbUJBQW1CLEtBQUssRUFBRTtNQUM3RSxRQUFRLElBQUlBLGFBQVksS0FBSyxvQkFBb0IsUUFBUSxDQUFDQyxZQUFXLFFBQVEsQ0FBQztNQUM5RSxPQUFPLElBQUlELGFBQVksS0FBSyxxQkFBcUIsS0FBSyxtQkFBbUIsS0FBSyxtQkFBbUIsS0FBSyxJQUFJLElBQUksQ0FBQ0MsWUFBVyxRQUFRLENBQUM7TUFDbkksV0FBVyxJQUFJRCxhQUFZLEtBQUsscUJBQXFCLEtBQUssbUJBQW1CLFlBQVksSUFBSSxDQUFDQyxZQUFXLFFBQVEsQ0FBQztNQUNsSCxRQUFRLElBQUlELGFBQVksS0FBSyxxQkFBcUIsS0FBSyxtQkFBbUIsU0FBUyxJQUFJLENBQUNDLFlBQVcsUUFBUSxDQUFDO01BQzVHLFVBQVUsSUFBSUQsYUFBWSxLQUFLLHFCQUFxQixLQUFLLG1CQUFtQixXQUFXLElBQUksQ0FBQ0MsWUFBVyxRQUFRLENBQUM7S0FDakg7QUFFRCxTQUFLLG1CQUFtQixtQkFBa0IsRUFBRyxVQUFVLENBQUMsaUJBQWtCLEtBQUssZUFBZSxZQUFhO0VBQzdHOztFQUdBLG1CQUFtQixPQUFzQjtBQUN2QyxRQUFJLFdBQVcsTUFBTSxTQUFRLEVBQUcsUUFBUSxLQUFLLEdBQUc7QUFDaEQsUUFBSSxTQUFTLFNBQVMsTUFBTSxHQUFHO0FBQy9CLFFBQUksVUFBVSxPQUFPLENBQUMsRUFBRSxRQUFRLHlCQUF5QixHQUFHO0FBQzVELFFBQUksVUFBVSxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLEdBQUcsR0FBRyxJQUFJO0FBQ3JELFdBQU8sR0FBRyxPQUFPLElBQUksT0FBTztFQUM5QjtFQUVBLGNBQVc7QUFDVCxRQUFJLFFBQVEsS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLEVBQUU7QUFFOUMsUUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixXQUFLLG1CQUFtQixTQUFTLE9BQU8sRUFBRSxTQUFTLElBQUksRUFBRSxXQUFXLE1BQUssQ0FBRTtBQUMzRTtJQUNGO0FBR0EsWUFBUSxNQUFNLFFBQVEsWUFBWSxFQUFFO0FBR3BDLFFBQUksTUFBTSxVQUFVLEdBQUc7QUFDckIsV0FBSyxtQkFBbUIsU0FBUyxPQUFPLEVBQUUsU0FBUyxLQUFLLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUUsV0FBVyxNQUFLLENBQUU7QUFDdEc7SUFDRjtBQUdBLFFBQUksVUFBVSxNQUFNLE1BQU0sR0FBRyxFQUFFO0FBQy9CLFFBQUksVUFBVSxNQUFNLE1BQU0sRUFBRTtBQUc1QixjQUFVLFFBQVEsUUFBUSx5QkFBeUIsR0FBRztBQUd0RCxRQUFJLGlCQUFpQixHQUFHLE9BQU8sSUFBSSxPQUFPO0FBRzFDLFNBQUssbUJBQW1CLFNBQVMsT0FBTyxFQUFFLFNBQVMsZ0JBQWdCLEVBQUUsV0FBVyxNQUFLLENBQUU7RUFDekY7RUFFQSxJQUFJLFNBQU07QUFDUixXQUFPLEtBQUssbUJBQW1CLElBQUksUUFBUTtFQUM3QztFQUVBLElBQUksUUFBSztBQUNQLFdBQU8sS0FBSyxtQkFBbUIsSUFBSSxPQUFPO0VBQzVDO0VBRUEsSUFBSSxZQUFTO0FBQ1gsV0FBTyxLQUFLLG1CQUFtQixJQUFJLFdBQVc7RUFDaEQ7RUFFQSxJQUFJLFNBQU07QUFDUixXQUFPLEtBQUssbUJBQW1CLElBQUksUUFBUTtFQUM3QztFQUVBLElBQUksV0FBUTtBQUNWLFdBQU8sS0FBSyxtQkFBbUIsSUFBSSxVQUFVO0VBQy9DO0VBRUEsSUFBSSxZQUFTO0FBQ1gsV0FBTyxLQUFLLG1CQUFtQixJQUFJLFdBQVc7RUFDaEQ7RUFFQSxTQUFNO0FBQ0osUUFBSSxLQUFLLG1CQUFtQixTQUFTO0FBQ25DO0lBQ0Y7QUFFQSxRQUFJLGlCQUFpQixPQUFPLEtBQUssTUFBTSxLQUFLLEVBQ3pDLFFBQVEsT0FBTyxFQUFFLEVBQ2pCLFFBQVEsS0FBSyxHQUFHO0FBRW5CLFFBQUksc0JBQXNCLGlDQUNyQixLQUFLLG1CQUFtQixRQURIO01BRXhCLE9BQU87O0FBR1QsU0FBSyxTQUFTLEtBQUssbUJBQW1CO0VBQ3hDOzs7dUNBdEdXLDhCQUEyQixpQ0FBQSxrQkFBQSxDQUFBO0lBQUE7RUFBQTs7OEVBQTNCLDhCQUEyQixXQUFBLENBQUEsQ0FBQSwwQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFNBQUEsV0FBQSxvQkFBQSxxQkFBQSxHQUFBLFNBQUEsRUFBQSxVQUFBLFdBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxXQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxtQkFBQSxJQUFBLEdBQUEsQ0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLE1BQUEsT0FBQSxtQkFBQSxVQUFBLFlBQUEsRUFBQSxHQUFBLENBQUEsU0FBQSxJQUFBLFlBQUEsSUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsU0FBQSxvQkFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLE9BQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGFBQUEsV0FBQSxlQUFBLG9DQUFBLG1CQUFBLFNBQUEsWUFBQSxJQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSxhQUFBLEdBQUEsQ0FBQSxlQUFBLGlDQUFBLG1CQUFBLGFBQUEsWUFBQSxFQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLG1CQUFBLFVBQUEsWUFBQSxFQUFBLEdBQUEsQ0FBQSxTQUFBLFdBQUEsR0FBQSxDQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsbUJBQUEsWUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7O0FDWHhDLFFBQUEsOEJBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQTtBQUFNLFFBQUEsMEJBQUEsWUFBQSxTQUFBLGdFQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBO0FBQUEsaUJBQUEsMkJBQVksSUFBQSxPQUFBLENBQVE7UUFBQSxDQUFBO0FBRXRCLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxRQUFBLHlCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0osUUFBQSw0QkFBQTtBQUNBLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBd0IsR0FBQSxTQUFBLENBQUE7QUFDSCxRQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBVyxRQUFBLDRCQUFBO0FBQzVCLFFBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUEsRUFBbUQsR0FBQSxVQUFBLENBQUE7QUFDWixRQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBZSxRQUFBLDRCQUFBO0FBQ2xELFFBQUEsMEJBQUEsSUFBQSxnREFBQSxHQUFBLEdBQUEsVUFBQSxDQUFBO0FBQ0osUUFBQSw0QkFBQTtBQUNBLFFBQUEsMEJBQUEsSUFBQSw2Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBR0osUUFBQSw0QkFBQTtBQUVBLFFBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLENBQUE7QUFDRCxRQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLFFBQUEsNEJBQUE7QUFDekIsUUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFvSCxRQUFBLDBCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFTLElBQUEsWUFBQSxDQUFhO1FBQUEsQ0FBQTtBQUExSSxRQUFBLDRCQUFBO0FBQ0EsUUFBQSwwQkFBQSxJQUFBLDZDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFHSixRQUFBLDRCQUFBO0FBQ0EsUUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNLLFFBQUEsc0JBQUEsSUFBQSxrQkFBQTtBQUFVLFFBQUEsNEJBQUE7QUFDbkMsUUFBQSx5QkFBQSxJQUFBLFlBQUEsRUFBQTtBQUNBLFFBQUEsMEJBQUEsSUFBQSw2Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBR0osUUFBQSw0QkFBQTtBQUVBLFFBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLEVBQUE7QUFDQSxRQUFBLHNCQUFBLElBQUEsU0FBQTtBQUFPLFFBQUEsNEJBQUE7QUFDM0IsUUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQSxFQUEwQyxJQUFBLFVBQUEsRUFBQTtBQUNaLFFBQUEsc0JBQUEsSUFBQSxXQUFBO0FBQVMsUUFBQSw0QkFBQTtBQUNuQyxRQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXdCLFFBQUEsc0JBQUEsSUFBQSxTQUFBO0FBQU8sUUFBQSw0QkFBQSxFQUFTLEVBQ25DO0FBR2IsUUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNBLFFBQUEsc0JBQUEsSUFBQSxlQUFBO0FBQWEsUUFBQSw0QkFBQTtBQUNqQyxRQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0ksUUFBQSwwQkFBQSxJQUFBLGdEQUFBLEdBQUEsR0FBQSxVQUFBLENBQUE7QUFDSixRQUFBLDRCQUFBLEVBQVM7QUFHYixRQUFBLDBCQUFBLElBQUEsNkNBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUtBLFFBQUEseUJBQUEsSUFBQSxTQUFBLEVBQUE7QUFDSixRQUFBLDRCQUFBOzs7O0FBcEQ0QixRQUFBLDBCQUFBLGFBQUEsSUFBQSxrQkFBQTtBQVNRLFFBQUEseUJBQUEsRUFBQTtBQUFBLFFBQUEsMEJBQUEsV0FBQSxJQUFBLElBQUE7QUFFdEIsUUFBQSx5QkFBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLE9BQUEsV0FBQSxXQUFBLFNBQUE7QUFRQSxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxNQUFBLFdBQUEsV0FBQSxTQUFBO0FBT0EsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsVUFBQSxXQUFBLFdBQUEsU0FBQTtBQWdCOEIsUUFBQSx5QkFBQSxFQUFBO0FBQUEsUUFBQSwwQkFBQSxXQUFBLElBQUEsWUFBQTtBQUlsQyxRQUFBLHlCQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsU0FBQSxXQUFBLFdBQUEsU0FBQTtBQUtlLFFBQUEseUJBQUE7QUFBQSxRQUFBLHFDQUFBLFNBQUEsSUFBQSxPQUFBOzs7Ozs7a0ZEeENaLDZCQUEyQixFQUFBLFdBQUEsK0JBQUEsVUFBQSw2RUFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQTNCLDZCQUEyQixFQUFBLFNBQUEsQ0FBQUMsTUFBQSw0QkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLG9DQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLG9DQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWHhDOzs7O1NBQVMsYUFBQUMsbUJBQXlCOzs7O0FFQ2xDOzs7O1NBQVMsY0FBQUMsbUJBQWtCO0FBRTNCLFNBQXFCLGNBQUFDLGFBQVksY0FBQUMsbUJBQWtCO0E7O0FBUTdDLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7RUFHaEMsWUFBb0IsTUFBMEIsY0FBb0Msa0JBQWtDO0FBQWhHLFNBQUEsT0FBQTtBQUEwQixTQUFBLGVBQUE7QUFBb0MsU0FBQSxtQkFBQTtBQUQxRSxTQUFBLGFBQWEsWUFBWTtFQUN1RjtFQUV4SCx5QkFBc0I7QUFDbEIsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFdBQU8sS0FBSyxLQUFLLElBQXNCLEdBQUcsS0FBSyxVQUFVLGdDQUFnQyxTQUFTLEVBQUUsRUFBRSxLQUNwR0MsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLHVCQUF1QixJQUFVO0FBQy9CLFdBQU8sS0FBSyxLQUFLLElBQW9CLEdBQUcsS0FBSyxVQUFVLHdCQUF3QixFQUFFLEVBQUUsRUFBRSxLQUNuRkQsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLG1CQUFtQixVQUFrQjtBQUNuQyxRQUFJLE9BQU87TUFDVCxRQUFRLE9BQU8sU0FBUyxPQUFPLFFBQVEsQ0FBQztNQUN4QyxPQUFPLE9BQU8sU0FBUyxPQUFPLE9BQU8sQ0FBQztNQUN0QyxXQUFXLFNBQVMsT0FBTyxXQUFXLEVBQUUsU0FBUSxFQUFHLEtBQUk7TUFDdkQsUUFBUSxTQUFTLE9BQU8sUUFBUSxFQUFFLFNBQVE7TUFDMUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxVQUFVLENBQUM7TUFDNUMsV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLENBQUM7O0FBR2hELFlBQVEsSUFBSSxJQUFJO0FBRWhCLFdBQU8sS0FBSyxLQUFLLEtBQVUsR0FBRyxLQUFLLFVBQVUsd0JBQXdCLElBQUksRUFBRSxLQUN6RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLHFDQUFrQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzNHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLHNCQUFzQixJQUFVO0FBQzlCLFFBQUksT0FBTztNQUNULFVBQVU7O0FBRVosV0FBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVSw0QkFBNEIsRUFBRSxJQUFJLElBQUksRUFBRSxLQUM3RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLHVDQUFvQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzdHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGtCQUFrQixJQUFZLFVBQWtCO0FBQzlDLFFBQUksT0FBTztNQUNULFFBQVEsT0FBTyxTQUFTLE9BQU8sUUFBUSxDQUFDO01BQ3hDLE9BQU8sT0FBTyxTQUFTLE9BQU8sT0FBTyxDQUFDO01BQ3RDLFdBQVcsU0FBUyxPQUFPLFdBQVcsRUFBRSxTQUFRLEVBQUcsS0FBSTtNQUN2RCxRQUFRLFNBQVMsT0FBTyxRQUFRLEVBQUUsU0FBUTtNQUMxQyxVQUFVLE9BQU8sU0FBUyxPQUFPLFVBQVUsQ0FBQztNQUM1QyxXQUFXLE9BQU8sU0FBUyxPQUFPLFdBQVcsQ0FBQzs7QUFHaEQsV0FBTyxLQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssVUFBVSx3QkFBd0IsRUFBRSxJQUFJLElBQUksRUFBRSxLQUM5RUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLHlDQUFzQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQy9HLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjs7O3VDQXhFUyx3QkFBcUIsd0JBQUEsZUFBQSxHQUFBLHdCQUFBLFlBQUEsR0FBQSx3QkFBQSxnQkFBQSxDQUFBO0lBQUE7RUFBQTs7aUZBQXJCLHdCQUFxQixTQUFyQix1QkFBcUIsV0FBQSxZQUZwQixPQUFNLENBQUE7RUFBQTs7QTs7Ozs7O0FEVHBCLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQTRCLEdBQUEsSUFBQSxFQUNwQixHQUFBLE1BQUE7QUFDTSxJQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFBUSxJQUFBLHNCQUFBLEdBQUEsc0JBQUE7QUFDeEIsSUFBQSw0QkFBQTtBQUNBLElBQUEsOEJBQUEsR0FBQSw0QkFBQSxDQUFBO0FBQTBCLElBQUEsMEJBQUEsWUFBQSxTQUFBLHdGQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFZLE9BQUEsWUFBQSxNQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUE0RCxJQUFBLDRCQUFBLEVBQTJCOzs7O0FBQXJGLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsc0JBQUEsT0FBQSxjQUFBLEVBQXFDLFdBQUEsT0FBQSxPQUFBOzs7QURROUYsSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtFQUt0QyxZQUFvQix1QkFBc0QsT0FBK0IsUUFBd0IsY0FBMEI7QUFBdkksU0FBQSx3QkFBQTtBQUFzRCxTQUFBLFFBQUE7QUFBK0IsU0FBQSxTQUFBO0FBQXdCLFNBQUEsZUFBQTtBQUZqSSxTQUFBLFVBQWtCO0VBSWxCO0VBRUEsV0FBUTtBQUNOLFVBQU0sS0FBSyxPQUFPLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFFeEQsU0FBSyxzQkFBc0IsdUJBQXVCLEVBQUUsRUFBRSxVQUFVLENBQUMsU0FBUTtBQUN2RSxXQUFLLGlCQUFpQjtBQUN0QixjQUFRLElBQUksS0FBSyxlQUFlLE1BQU07SUFDeEMsQ0FBQztFQUNIO0VBRU0sWUFBWSxvQkFBa0M7O0FBQ2xELFlBQU0sS0FBSyxLQUFLLGVBQWU7QUFDL0IsWUFBTSxXQUFXLElBQUksU0FBUTtBQUM3QixZQUFNLFlBQVksS0FBSyxhQUFhLGFBQVk7QUFFaEQsZUFBUyxPQUFPLFVBQVUsbUJBQW1CLE9BQU8sU0FBUSxDQUFFO0FBQzlELGVBQVMsT0FBTyxTQUFTLG1CQUFtQixNQUFNLFNBQVEsQ0FBRTtBQUM1RCxlQUFTLE9BQU8sYUFBYSxtQkFBbUIsU0FBUztBQUN6RCxlQUFTLE9BQU8sVUFBVSxtQkFBbUIsTUFBTTtBQUNuRCxlQUFTLE9BQU8sWUFBWSxtQkFBbUIsU0FBUyxTQUFRLENBQUU7QUFDbEUsZUFBUyxPQUFPLGFBQWEsYUFBYSxFQUFFO0FBRTVDLFlBQU0sS0FBSyxzQkFBc0Isa0JBQWtCLElBQUssUUFBUSxFQUFFLFVBQVUsQ0FBQyxXQUFlO0FBQzFGLGFBQUssT0FBTyxTQUFTLENBQUMsa0JBQWtCLENBQUM7TUFDM0MsR0FDRSxDQUFDLFVBQVM7QUFDUixnQkFBUSxJQUFJLE1BQU07TUFDcEIsQ0FBQztJQUNMOzs7O3VDQXBDVyw4QkFBMkIsaUNBQUEscUJBQUEsR0FBQSxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxZQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxzQkFBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7QUNaeEMsUUFBQSwwQkFBQSxHQUFBLDRDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7OztBQUFNLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGNBQUE7Ozs7OztrRkRZTyw2QkFBMkIsRUFBQSxXQUFBLCtCQUFBLFVBQUEsd0ZBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUEzQiw2QkFBMkIsRUFBQSxTQUFBLENBQUFDLE1BQUEsaUNBQUFDLEtBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxvQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxvQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR1p4Qzs7OztTQUFTLGFBQUFDLG1CQUF5Qjs7QTs7OztBQ0FsQyxJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUE0QixHQUFBLElBQUE7QUFFcEIsSUFBQSxzQkFBQSxHQUFBLFdBQUE7QUFBUSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFlLElBQUEsNEJBQUEsRUFBTztBQUV4QyxJQUFBLDhCQUFBLEdBQUEsNEJBQUEsQ0FBQTtBQUEwQixJQUFBLDBCQUFBLFlBQUEsU0FBQSwyRkFBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBWSxPQUFBLGVBQUEsTUFBQSxDQUFzQjtJQUFBLENBQUE7QUFBNEQsSUFBQSw0QkFBQSxFQUEyQjs7OztBQUFyRixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLHNCQUFBLE9BQUEsY0FBQSxFQUFxQyxXQUFBLE9BQUEsT0FBQTs7O0FEUWpHLElBQU8saUNBQVAsTUFBTyxnQ0FBOEI7RUFLekMsWUFBb0IsdUJBQXNELE9BQStCLFFBQXlCLGNBQTBCO0FBQXhJLFNBQUEsd0JBQUE7QUFBc0QsU0FBQSxRQUFBO0FBQStCLFNBQUEsU0FBQTtBQUF5QixTQUFBLGVBQUE7QUFGbEksU0FBQSxVQUFrQjtFQUlsQjtFQUVBLFdBQVE7QUFDTixVQUFNLEtBQUssT0FBTyxLQUFLLE1BQU0sU0FBUyxTQUFTLElBQUksSUFBSSxDQUFDO0FBRXhELFNBQUssc0JBQXNCLHVCQUF1QixFQUFFLEVBQUUsVUFBVSxDQUFDLFNBQVE7QUFDdkUsV0FBSyxpQkFBaUI7QUFDdEIsY0FBUSxJQUFJLEtBQUssZUFBZSxNQUFNO0lBQ3hDLENBQUM7RUFDSDtFQUdNLGVBQWUsb0JBQWtDOztBQUNyRCxZQUFNLEtBQUssS0FBSyxlQUFlO0FBQy9CLFlBQU0sV0FBVyxJQUFJLFNBQVE7QUFDN0IsWUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBRWhELGVBQVMsT0FBTyxVQUFVLG1CQUFtQixPQUFPLFNBQVEsQ0FBRTtBQUM5RCxlQUFTLE9BQU8sU0FBUyxtQkFBbUIsTUFBTSxTQUFRLENBQUU7QUFDNUQsZUFBUyxPQUFPLGFBQWEsbUJBQW1CLFNBQVM7QUFDekQsZUFBUyxPQUFPLFVBQVUsbUJBQW1CLE1BQU07QUFDbkQsZUFBUyxPQUFPLFlBQVksbUJBQW1CLFNBQVMsU0FBUSxDQUFFO0FBQ2xFLGVBQVMsT0FBTyxhQUFhLGFBQWEsRUFBRTtBQUU1QyxZQUFNLEtBQUssc0JBQXNCLHNCQUFzQixLQUFLLGVBQWUsRUFBRyxFQUFFLFVBQVUsQ0FBQyxXQUFlO0FBQ3hHLGFBQUssT0FBTyxTQUFTLENBQUMsa0JBQWtCLENBQUM7TUFDM0MsR0FDRSxDQUFDLFVBQVM7QUFDUixnQkFBUSxJQUFJLE1BQU07TUFDcEIsQ0FBQztJQUNMOzs7O3VDQXJDVyxpQ0FBOEIsaUNBQUEscUJBQUEsR0FBQSxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxZQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBOUIsaUNBQThCLFdBQUEsQ0FBQSxDQUFBLDZCQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxzQkFBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsd0NBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7QUNaM0MsUUFBQSwwQkFBQSxHQUFBLCtDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7OztBQUFNLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGNBQUE7Ozs7OztrRkRZTyxnQ0FBOEIsRUFBQSxXQUFBLGtDQUFBLFVBQUEsOEZBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUE5QixnQ0FBOEIsRUFBQSxTQUFBLENBQUFDLE1BQUEsaUNBQUFDLEtBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSx1Q0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSx1Q0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRVozQzs7OztTQUFTLGFBQUFDLG1CQUF5Qjs7QTtBQVk1QixJQUFPLDhCQUFQLE1BQU8sNkJBQTJCO0VBR3RDLFlBQW9CLHVCQUFzRCxRQUF3QixjQUEwQjtBQUF4RyxTQUFBLHdCQUFBO0FBQXNELFNBQUEsU0FBQTtBQUF3QixTQUFBLGVBQUE7QUFGbEcsU0FBQSxVQUFrQjtFQUU0RztFQUU5SCxXQUFRO0VBRVI7RUFFTSxjQUFjLGdCQUE4Qjs7QUFDaEQsWUFBTSxXQUFXLElBQUksU0FBUTtBQUM3QixZQUFNLFlBQVksS0FBSyxhQUFhLGFBQVk7QUFFaEQsZUFBUyxPQUFPLFVBQVUsZUFBZSxPQUFPLFNBQVEsQ0FBRTtBQUMxRCxlQUFTLE9BQU8sU0FBUyxlQUFlLE1BQU0sU0FBUSxDQUFFO0FBQ3hELGVBQVMsT0FBTyxhQUFhLGVBQWUsU0FBUztBQUNyRCxlQUFTLE9BQU8sVUFBVSxlQUFlLE1BQU07QUFDL0MsZUFBUyxPQUFPLFlBQVksZUFBZSxTQUFTLFNBQVEsQ0FBRTtBQUM5RCxlQUFTLE9BQU8sYUFBYSxhQUFhLEVBQUU7QUFHNUMsY0FBUSxJQUFJLGVBQWUsTUFBTTtBQUNqQyxjQUFRLElBQUksU0FBUyxPQUFPLFFBQVEsQ0FBQztBQUNyQyxjQUFRLElBQUksU0FBUyxPQUFPLE9BQU8sQ0FBQztBQUNwQyxjQUFRLElBQUksU0FBUyxPQUFPLFdBQVcsQ0FBQztBQUN4QyxjQUFRLElBQUksU0FBUyxPQUFPLFFBQVEsQ0FBQztBQUNyQyxjQUFRLElBQUksU0FBUyxPQUFPLFVBQVUsQ0FBQztBQUN2QyxjQUFRLElBQUksU0FBUyxPQUFPLFdBQVcsQ0FBQztBQUN4QyxZQUFNLEtBQUssc0JBQXNCLG1CQUFtQixRQUFRLEVBQUUsVUFBVSxDQUFDLFdBQWU7QUFDdEYsYUFBSyxPQUFPLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQztNQUMzQyxHQUNFLENBQUMsVUFBUztBQUNSLGdCQUFRLElBQUksTUFBTTtNQUNwQixDQUFDO0lBS0w7Ozs7dUNBdENXLDhCQUEyQixpQ0FBQSxxQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxZQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBO0FDWnhDLFFBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksUUFBQSxzQkFBQSxHQUFBLGlCQUFBO0FBQWUsUUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTSxRQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBZSxRQUFBLDRCQUFBLEVBQU87QUFDL0MsUUFBQSw4QkFBQSxHQUFBLDRCQUFBLENBQUE7QUFBOEMsUUFBQSwwQkFBQSxZQUFBLFNBQUEsa0ZBQUEsUUFBQTtBQUFBLGlCQUFZLElBQUEsY0FBQSxNQUFBO1FBQXFCLENBQUE7QUFBRSxRQUFBLDRCQUFBOzs7QUFBdkQsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxXQUFBLElBQUEsT0FBQTs7Ozs7O2tGRFdiLDZCQUEyQixFQUFBLFdBQUEsK0JBQUEsVUFBQSx3RkFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQTNCLDZCQUEyQixFQUFBLFNBQUEsQ0FBQUMsTUFBQSxpQ0FBQUMsS0FBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLG9DQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLG9DQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWnhDOzs7O1NBQVMsYUFBQUMsbUJBQWlCOzs7O0FDWUYsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBb0QsR0FBQSxJQUFBO0FBQzVDLElBQUEsc0JBQUEsQ0FBQTtBQUF5QixJQUFBLDRCQUFBO0FBQzdCLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBOztBQUF3QyxJQUFBLDRCQUFBO0FBQzVDLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBO0FBQTRCLElBQUEsNEJBQUE7QUFDaEMsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBeUIsSUFBQSw0QkFBQTtBQUM3QixJQUFBLDhCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsT0FBQSxDQUFBLEVBQ3VCLElBQUEsVUFBQSxDQUFBO0FBR2YsSUFBQSx5QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUNKLElBQUEsNEJBQUE7QUFDQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxDQUFBO0FBRUksSUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUEsRUFBUyxFQUNQLEVBQ0w7Ozs7QUFmRCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtCQUFBLE1BQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLEdBQUEsR0FBQSxrQkFBQSxLQUFBLENBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtCQUFBLFNBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtCQUFBLE1BQUE7QUFHWSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLHNDQUFBLGNBQUEsMEJBQUEsa0JBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxzQ0FBQSxjQUFBLDZCQUFBLGtCQUFBLElBQUEsRUFBQTs7Ozs7QUF0QnhDLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQTZELEdBQUEsU0FBQSxDQUFBLEVBQ3dCLEdBQUEsU0FBQSxDQUFBLEVBQzNDLEdBQUEsSUFBQSxFQUNsQixHQUFBLElBQUE7QUFDRSxJQUFBLHNCQUFBLEdBQUEsZUFBQTtBQUFVLElBQUEsNEJBQUE7QUFDZCxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsR0FBQSxPQUFBO0FBQUssSUFBQSw0QkFBQTtBQUNULElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLGlCQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNiLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBO0FBQ1YsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsYUFBQTtBQUFLLElBQUEsNEJBQUEsRUFBSyxFQUxaO0FBT04sSUFBQSw4QkFBQSxJQUFBLE9BQUE7QUFDRSxJQUFBLDBCQUFBLElBQUEsb0RBQUEsSUFBQSxJQUFBLE1BQUEsQ0FBQTtBQWtCSixJQUFBLDRCQUFBLEVBQVEsRUFDSjs7OztBQW5CK0IsSUFBQSx5QkFBQSxFQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLE9BQUEsZ0JBQUE7Ozs7O0FBc0IvQyxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFtQyxJQUFBLDRCQUFBOzs7QUR2QnpDLElBQU8sZ0NBQVAsTUFBTywrQkFBNkI7RUFJeEMsWUFBb0IsdUJBQXNELG9CQUFzQztBQUE1RixTQUFBLHdCQUFBO0FBQXNELFNBQUEscUJBQUE7QUFIMUUsU0FBQSxtQkFBcUMsQ0FBQTtBQUNyQyxTQUFBLGVBQThCLENBQUE7RUFHOUI7RUFFQSxXQUFRO0FBQ04sU0FBSyxzQkFBc0IsdUJBQXNCLEVBQUcsVUFBVSxDQUFDLGdCQUFpQixLQUFLLG1CQUFtQixXQUFZO0FBQ3BILFNBQUssbUJBQW1CLG1CQUFrQixFQUFHLFVBQVUsQ0FBQyxpQkFBa0IsS0FBSyxlQUFlLFlBQWE7RUFDN0c7RUFFQSxrQkFBa0IsSUFBVTtBQUMxQixTQUFLLHNCQUFzQixzQkFBc0IsRUFBRSxFQUFFLFVBQVM7RUFDaEU7Ozt1Q0FkVyxnQ0FBNkIsaUNBQUEscUJBQUEsR0FBQSxpQ0FBQSxrQkFBQSxDQUFBO0lBQUE7RUFBQTs7OEVBQTdCLGdDQUE2QixXQUFBLENBQUEsQ0FBQSw0QkFBQSxDQUFBLEdBQUEsWUFBQSxPQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsaUJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLFdBQUEsSUFBQSxTQUFBLFdBQUEsY0FBQSwwQkFBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxpQkFBQSxrQkFBQSxnQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsdUJBQUEsVUFBQSxnQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxzQkFBQSxVQUFBLGlCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLFVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx1Q0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1gxQyxRQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFFBQUEsMEJBQUEsR0FBQSw4Q0FBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTZELEdBQUEsc0RBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLHFDQUFBO0FBb0M3RCxRQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBLEVBQWdGLEdBQUEsVUFBQTtBQUNsRSxRQUFBLHNCQUFBLEdBQUEsS0FBQTtBQUFHLFFBQUEsNEJBQUEsRUFBVyxFQUNqQjs7OztBQXRDTCxRQUFBLHlCQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsaUJBQUEsU0FBQSxDQUFBLEVBQW1DLFlBQUEsZ0JBQUE7Ozs7OztrRkRVaEMsK0JBQTZCLEVBQUEsV0FBQSxpQ0FBQSxVQUFBLDRGQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBN0IsK0JBQTZCLEVBQUEsU0FBQSxDQUFBQyxNQUFBLGlDQUFBLDRCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsc0NBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsc0NBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVYMUM7Ozs7U0FBUyxhQUFBQyxhQUFXLFNBQUFDLGNBQWE7QUFFakMsU0FBUyxPQUFPLGlCQUFpQjs7OztBRURqQzs7OztTQUFTLGNBQUFDLG9CQUFrQjtBQUMzQixTQUFxQixjQUFBQyxhQUFZLGNBQUFDLG1CQUFrQjtBOztBQVM3QyxJQUFPLHlCQUFQLE1BQU8sd0JBQXNCO0VBSWpDLFlBQW9CLE1BQTBCLGNBQW9DLGtCQUFrQztBQUFoRyxTQUFBLE9BQUE7QUFBMEIsU0FBQSxlQUFBO0FBQW9DLFNBQUEsbUJBQUE7QUFGMUUsU0FBQSxhQUFhLFlBQVk7RUFFdUY7RUFFeEgsb0JBQWlCO0FBQ2YsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBQ2hELFdBQU8sS0FBSyxLQUFLLElBQXFCLEdBQUcsS0FBSyxVQUFVLCtCQUErQixTQUFTLEVBQUUsRUFBRSxLQUNsR0MsWUFBVyxXQUFRO0FBRWpCLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjtFQUVBLGtCQUFrQixTQUEwQixJQUFVO0FBRXBELFdBQU8sS0FBSyxLQUFLLElBQ2YsR0FBRyxLQUFLLFVBQVUsdUJBQXVCLEVBQUUsSUFDM0MsaUNBQ0ssVUFETDtNQUVFO01BQ0QsRUFDRCxLQUNBRCxZQUFXLFdBQVE7QUFDakIsV0FBSyxpQkFBaUIsU0FBUyxTQUFTLFFBQVEsNkNBQXVDLE1BQU0sTUFBTSxJQUFJLE1BQVM7QUFDaEgsYUFBT0MsWUFBVyxLQUFLO0lBQ3pCLENBQUMsQ0FBQztFQUVOO0VBRUEsd0JBQ0UsUUFDQSxTQUNBLGVBQXFCO0FBR3JCLFVBQU0sT0FBTztNQUNYLFdBQVcsT0FBTyxLQUFLLGFBQWEsYUFBWSxDQUFFO01BQ2xEO01BQ0E7TUFDQTs7QUFHRixXQUFPLEtBQUssS0FBSyxLQUNmLEdBQUcsS0FBSyxVQUFVLDJCQUNsQixJQUFJLEVBQ0osS0FDQUQsWUFBVyxXQUFRO0FBQ2pCLFdBQUssaUJBQWlCLFNBQVMsU0FBUyxRQUFRLHdDQUFxQyxNQUFNLE1BQU0sSUFBSSxNQUFTO0FBQzlHLGFBQU9DLFlBQVcsS0FBSztJQUN6QixDQUFDLENBQUM7RUFFTjs7O3VDQXREVyx5QkFBc0Isd0JBQUEsZUFBQSxHQUFBLHdCQUFBLFlBQUEsR0FBQSx3QkFBQSxnQkFBQSxDQUFBO0lBQUE7RUFBQTs7aUZBQXRCLHlCQUFzQixTQUF0Qix3QkFBc0IsV0FBQSxZQUZyQixPQUFNLENBQUE7RUFBQTs7Ozs7Ozs7QURrQmxCLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDRSxJQUFBLHlCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUF3QixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSw0QkFBQSxFQUFJOzs7Ozs7QUFNbEQsSUFBQSw4QkFBQSxHQUFBLGlCQUFBLEVBQUE7QUFHRSxJQUFBLDBCQUFBLFVBQUEsU0FBQSxzRkFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVUsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQ3pCLElBQUEsNEJBQUE7Ozs7QUFGRSxJQUFBLDBCQUFBLFVBQUEsT0FBQSxNQUFBOzs7OztBQW9ESSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0UsSUFBQSxzQkFBQSxDQUFBO0FBQ0YsSUFBQSw0QkFBQTs7OztBQUZpRCxJQUFBLDBCQUFBLFNBQUEsZUFBQSxFQUFBO0FBQy9DLElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsZUFBQSxjQUFBLEdBQUE7Ozs7O0FBd0JFLElBQUEsOEJBQUEsR0FBQSxNQUFBLEVBQUEsRUFHRyxHQUFBLElBQUE7QUFDRyxJQUFBLHNCQUFBLENBQUE7O0FBQWtELElBQUEsNEJBQUE7QUFDdEQsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7O0FBQW9DLElBQUEsNEJBQUE7QUFDeEMsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBd0IsSUFBQSw0QkFBQTtBQUM1QixJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsRUFBQTtBQUFxQixJQUFBLDRCQUFBO0FBQ3pCLElBQUEsOEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxPQUFBLEVBQUEsRUFDcUIsSUFBQSxVQUFBLEVBQUE7QUFHbkIsSUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNGLElBQUEsNEJBQUE7QUFDQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBRUUsSUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNGLElBQUEsNEJBQUEsRUFBUyxFQUNMLEVBQ0g7Ozs7QUFuQm9DLElBQUEsMEJBQUEsV0FBQSwrQkFBQSxJQUFBQyxNQUFBLGNBQUEsV0FBQSxhQUFBLGNBQUEsV0FBQSxhQUFBLGNBQUEsaUJBQUEsZUFBQSxDQUFBO0FBSXJDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLGNBQUEsVUFBQSxrQkFBQSxDQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxHQUFBLElBQUEsY0FBQSxLQUFBLENBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGNBQUEsU0FBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsY0FBQSxNQUFBO0FBR1EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxzQ0FBQSxjQUFBLHFCQUFBLGNBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxzQ0FBQSxjQUFBLHdCQUFBLGNBQUEsSUFBQSxFQUFBOzs7OztBQTNCcEIsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBd0QsR0FBQSxTQUFBLEVBQUEsRUFDbUIsR0FBQSxTQUFBLEVBQUEsRUFDN0MsR0FBQSxJQUFBLEVBQ3BCLEdBQUEsSUFBQTtBQUNFLElBQUEsc0JBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNiLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLE9BQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ1QsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBUyxJQUFBLDRCQUFBO0FBQ2IsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFDVixJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSxhQUFBO0FBQUssSUFBQSw0QkFBQSxFQUFLLEVBQ1g7QUFHUCxJQUFBLDhCQUFBLElBQUEsT0FBQTtBQUNFLElBQUEsMEJBQUEsSUFBQSxpREFBQSxJQUFBLElBQUEsTUFBQSxFQUFBO0FBcUJGLElBQUEsNEJBQUEsRUFBUSxFQUNGOzs7O0FBdEJ1QixJQUFBLHlCQUFBLEVBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsT0FBQSxXQUFBOzs7OztBQXlCL0IsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBbUMsSUFBQSw0QkFBQTs7Ozs7O0FBV3pDLElBQUEsOEJBQUEsR0FBQSwwQkFBQSxFQUFBO0FBR0UsSUFBQSwwQkFBQSxVQUFBLFNBQUEsd0dBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFVLE9BQUEsd0JBQUEsQ0FBeUI7SUFBQSxDQUFBO0FBQ3JDLElBQUEsNEJBQUE7Ozs7QUFGRSxJQUFBLDBCQUFBLGVBQUEsT0FBQSxXQUFBOzs7QUQxSUEsSUFBTyw0QkFBUCxNQUFPLDJCQUF5QjtFQWtDcEMsWUFBb0IsbUJBQ1Ysb0JBQ0Esd0JBQ0EsV0FBdUI7QUFIYixTQUFBLG9CQUFBO0FBQ1YsU0FBQSxxQkFBQTtBQUNBLFNBQUEseUJBQUE7QUFDQSxTQUFBLFlBQUE7QUFwQ1YsU0FBQSxlQUE4QixDQUFBO0FBQzlCLFNBQUEsU0FBaUI7QUFDakIsU0FBQSxVQUFrQixLQUFLLFFBQU87QUFFOUIsU0FBQSxrQkFBa0I7QUFDbEIsU0FBQSxnQkFBZ0I7QUFDaEIsU0FBQSxvQkFBb0I7QUFDcEIsU0FBQSxvQkFBb0I7QUFFcEIsU0FBQSxTQUFTO0FBQ1QsU0FBQSxPQUFPO0FBQ1AsU0FBQSxXQUFXO0FBQ1gsU0FBQSxXQUFXO0FBRVgsU0FBQSxlQUFlO0FBRWYsU0FBQSxvQkFBb0I7QUFFWCxTQUFBLGNBQXNCO0FBQ3RCLFNBQUEsWUFBb0I7QUFDcEIsU0FBQSxnQkFBd0I7QUFDeEIsU0FBQSxnQkFBd0I7QUFDeEIsU0FBQSx1QkFBK0I7QUFDL0IsU0FBQSx1QkFBK0I7QUFDL0IsU0FBQSxjQUE0QixDQUFBO0FBQzVCLFNBQUEsWUFBcUI7QUFDdEIsU0FBQSxlQUFlLG9CQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUd2QyxTQUFBLGdCQUFnQjtBQUNoQixTQUFBLGdCQUFnQjtBQUNoQixTQUFBLG1CQUFtQjtFQU1uQjtFQUVBLFdBQVE7QUFDTixTQUFLLGVBQWUsS0FBSyxhQUFZO0FBQ3JDLFNBQUssa0JBQWtCLGtCQUFpQixFQUFHLFVBQVUsQ0FBQyxnQkFBZTtBQUNuRSxVQUFJLGVBQWUsUUFBUSxZQUFZLFNBQVMsR0FBRztBQUVqRCxjQUFNLE9BQU8sSUFBSSxLQUNmLFlBQVksWUFBWSxTQUFTLENBQUMsRUFBRSxRQUFRO0FBRzlDLGFBQUssU0FBUyxLQUFLLFlBQVcsRUFBRyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRTdDLGdCQUFRLElBQUksc0NBQW1DLEtBQUssTUFBTTtBQUMxRCxpQkFBUyxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztBQUMzQyxlQUFLLFlBQVksS0FBSyxZQUFZLENBQUMsQ0FBQztBQUNwQyxlQUFLLGVBQWUsWUFBWSxDQUFDLEVBQUUsV0FBVyxZQUFZLFlBQVksQ0FBQyxFQUFFLFFBQVE7QUFDakYsZUFBSyxhQUFhLFlBQVksQ0FBQyxFQUFFLFdBQVcsU0FBUyxZQUFZLENBQUMsRUFBRSxRQUFRO0FBQzVFLGVBQUssaUJBQWlCLFlBQVksQ0FBQyxFQUFFLFdBQVcsY0FBYyxZQUFZLENBQUMsRUFBRSxRQUFRO0FBQ3JGLGVBQUssaUJBQWlCLFlBQVksQ0FBQyxFQUFFLFdBQVcsYUFBYSxZQUFZLENBQUMsRUFBRSxRQUFRO0FBQ3BGLGNBQUksS0FBSyxZQUFZLENBQUMsRUFBRSxXQUFXLFVBQVUsQ0FBQyxLQUFLLGFBQWEsSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFFLFFBQVEsR0FBRztBQUNqRyxpQkFBSyx3QkFBd0IsWUFBWSxDQUFDLEVBQUU7VUFDOUM7QUFDQSxjQUFJLEtBQUssWUFBWSxDQUFDLEVBQUUsV0FBVyxZQUFZO0FBQzdDLGlCQUFLLHdCQUF3QixZQUFZLENBQUMsRUFBRTtVQUM5QztRQUNGO0FBQ0EsYUFBSyxZQUFZO01BQ25CO0lBQ0YsQ0FBQztBQUVELFNBQUssbUJBQW1CLG1CQUFrQixFQUFHLFVBQVUsQ0FBQyxpQkFBa0IsS0FBSyxlQUFlLFlBQWE7RUFDN0c7RUFFQSxVQUFPO0FBQ0wsVUFBTSxPQUFPLG9CQUFJLEtBQUk7QUFDckIsV0FBTyxLQUFLLFlBQVcsRUFBRyxVQUFVLEdBQUcsRUFBRTtFQUMzQztFQUVBLGlCQUFpQixNQUFZO0FBQzNCLFVBQU0sT0FBTyxvQkFBSSxLQUFJO0FBQ3JCLFNBQUssUUFBUSxLQUFLLFFBQU8sSUFBSyxJQUFJO0FBQ2xDLFdBQU8sS0FBSyxZQUFXLEVBQUcsVUFBVSxHQUFHLEVBQUU7RUFDM0M7RUFFQSxtQkFBbUIsT0FBWTtBQUM3QixTQUFLLG9CQUFvQixTQUFVLE1BQU0sT0FBNkIsT0FBTyxFQUFFO0FBQy9FLFNBQUssV0FBVTtFQUNqQjtFQUVBLGFBQVU7QUFFUixTQUFLLGNBQWM7QUFDbkIsU0FBSyxZQUFZO0FBQ2pCLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssdUJBQXVCO0FBQzVCLFNBQUssdUJBQXVCO0FBQzVCLFNBQUssZUFBZSxLQUFLLGFBQVk7QUFFckMsUUFBSSxLQUFLLFVBQVUsTUFBTSxLQUFLLFdBQVcsSUFBSTtBQUMzQyxXQUFLLGtCQUFrQix1QkFBdUIsS0FBSyxRQUFRLEtBQUssU0FBUyxLQUFLLGNBQWMsS0FBSyxpQkFBaUIsRUFBRSxVQUFVLFVBQU87QUFDbkksYUFBSyxjQUFjLENBQUE7QUFDbkIsYUFBSyxjQUFjO0FBQ25CLFlBQUksS0FBSyxlQUFlLE1BQU07QUFDNUIsbUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxZQUFZLFFBQVEsS0FBSztBQUNoRCxpQkFBSyxlQUFlLEtBQUssWUFBWSxDQUFDLEVBQUUsV0FBVyxZQUFZLEtBQUssWUFBWSxDQUFDLEVBQUUsUUFBUTtBQUMzRixpQkFBSyxhQUFhLEtBQUssWUFBWSxDQUFDLEVBQUUsV0FBVyxTQUFTLEtBQUssWUFBWSxDQUFDLEVBQUUsUUFBUTtBQUN0RixpQkFBSyxpQkFBaUIsS0FBSyxZQUFZLENBQUMsRUFBRSxXQUFXLGNBQWMsS0FBSyxZQUFZLENBQUMsRUFBRSxRQUFRO0FBQy9GLGlCQUFLLGlCQUFpQixLQUFLLFlBQVksQ0FBQyxFQUFFLFdBQVcsYUFBYSxLQUFLLFlBQVksQ0FBQyxFQUFFLFFBQVE7QUFFOUYsZ0JBQUksS0FBSyxZQUFZLENBQUMsRUFBRSxXQUFXLFVBQVUsQ0FBQyxLQUFLLGFBQWEsSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFFLFFBQVEsR0FBRztBQUNqRyxtQkFBSyx3QkFBd0IsS0FBSyxZQUFZLENBQUMsRUFBRTtZQUNuRDtBQUNBLGdCQUFJLEtBQUssWUFBWSxDQUFDLEVBQUUsV0FBVyxZQUFZO0FBQzdDLG1CQUFLLHdCQUF3QixLQUFLLFlBQVksQ0FBQyxFQUFFO1lBQ25EO1VBQ0Y7QUFDQSxlQUFLLFlBQVk7UUFDbkI7TUFDRixDQUFDO0lBQ0g7RUFDRjtFQUVBLGVBQVk7QUFDVixTQUFLLGVBQWU7QUFDcEIsU0FBSyxTQUFTLEtBQUssa0JBQWtCLFlBQVk7QUFDakQsU0FBSyxPQUFPLEtBQUssZ0JBQWdCLFNBQVM7QUFDMUMsU0FBSyxXQUFXLEtBQUssb0JBQW9CLGNBQWM7QUFDdkQsU0FBSyxXQUFXLEtBQUssb0JBQW9CLGFBQWE7QUFFdEQsV0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssV0FBVyxLQUFLO0VBQ3hEO0VBRUEsa0JBQWtCLElBQVU7QUFDMUIsU0FBSyxrQkFBa0Isa0JBQWtCLEVBQUUsRUFBRSxVQUFTO0VBQ3hEO0VBRUEsYUFBYSxPQUFrQjtBQUM3QixXQUFPLGdCQUFlO0FBR3RCLFFBQUksS0FBSztBQUFrQjtBQUUzQixTQUFLLG1CQUFtQjtBQUN4QixTQUFLLFNBQVM7QUFFZCxTQUFLLHVCQUF1QixrQkFBaUIsRUFDMUMsS0FDQyxVQUFVLFVBQU87QUFDZixVQUFJLENBQUMsTUFBTTtBQUNULGFBQUssbUJBQW1CO0FBQ3hCLGVBQU87TUFDVDtBQUVBLGFBQU8sS0FBSyx1QkFBdUIsd0JBQ2pDLEtBQUssYUFBYSxLQUFLLFlBQVksR0FDbkMsS0FBSyxhQUFhLEtBQUssYUFBYSxHQUNwQyxLQUFLLE1BQU07SUFFZixDQUFDLENBQUMsRUFFSCxVQUFVO01BQ1QsTUFBTSxDQUFDLFFBQW9DO0FBQ3pDLGFBQUssU0FBUyxLQUFLLFVBQ2hCLHdCQUF3QixJQUFJLFNBQVM7QUFFeEMsYUFBSyxnQkFBZ0I7QUFDckIsYUFBSyxtQkFBbUI7TUFDMUI7TUFDQSxPQUFPLENBQUMsVUFBUztBQUNmLGFBQUssbUJBQW1CO0FBQ3hCLGdCQUFRLE1BQU0sK0JBQTRCLEtBQUs7TUFDakQ7S0FDRDtBQUVILGFBQVMsS0FBSyxVQUFVLElBQUksV0FBVztFQUN6QztFQUdBLGFBQWEsTUFBbUI7QUFDOUIsUUFBSSxDQUFDO0FBQU0sYUFBTztBQUVsQixVQUFNLElBQUksSUFBSSxLQUFLLElBQUk7QUFDdkIsV0FBTyxFQUFFLFlBQVcsRUFBRyxNQUFNLEdBQUcsRUFBRSxDQUFDO0VBQ3JDO0VBRUEsY0FBVztBQUNULFNBQUssZ0JBQWdCO0FBQ3JCLGFBQVMsS0FBSyxVQUFVLE9BQU8sV0FBVztFQUM1QztFQUVBLHlCQUFzQjtBQUNwQixZQUFRLElBQUksd0NBQXFDO0FBQ2pELFNBQUssZ0JBQWdCO0FBQ3JCLGFBQVMsS0FBSyxVQUFVLElBQUksV0FBVztFQUN6QztFQUVBLDBCQUF1QjtBQUNyQixTQUFLLGdCQUFnQjtBQUNyQixhQUFTLEtBQUssVUFBVSxPQUFPLFdBQVc7RUFDNUM7Ozt1Q0F2TVcsNEJBQXlCLGlDQUFBLGlCQUFBLEdBQUEsaUNBQUEsa0JBQUEsR0FBQSxpQ0FBQSxzQkFBQSxHQUFBLGlDQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBekIsNEJBQXlCLFdBQUEsQ0FBQSxDQUFBLHVCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsYUFBQSxlQUFBLFdBQUEsYUFBQSxlQUFBLGlCQUFBLGVBQUEsaUJBQUEsc0JBQUEsd0JBQUEsc0JBQUEsd0JBQUEsYUFBQSxlQUFBLFdBQUEsWUFBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLGlCQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxhQUFBLGlCQUFBLGlCQUFBLHdCQUFBLHdCQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFNBQUEsc0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsVUFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsT0FBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLGFBQUEsUUFBQSxRQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsT0FBQSxTQUFBLEdBQUEsQ0FBQSxNQUFBLFdBQUEsUUFBQSxRQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsVUFBQSxZQUFBLElBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxZQUFBLElBQUEsWUFBQSxJQUFBLFVBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxXQUFBLElBQUEsU0FBQSxXQUFBLGNBQUEscUJBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxXQUFBLElBQUEsU0FBQSxXQUFBLEdBQUEsY0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxVQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsaUJBQUEsa0JBQUEsZ0JBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLHVCQUFBLFVBQUEsZ0JBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsa0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsc0JBQUEsVUFBQSxpQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsYUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFVBQUEsS0FBQSxHQUFBOztBQ2R0QyxRQUFBLHlCQUFBLEdBQUEsY0FBQSxDQUFBO0FBV0EsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUdFLFFBQUEsMEJBQUEsU0FBQSxTQUFBLHdEQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBUyxJQUFBLGFBQUEsTUFBQSxDQUFvQjtRQUFBLENBQUE7QUFFN0IsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFnQyxHQUFBLE9BQUEsQ0FBQSxFQUNULEdBQUEsT0FBQSxDQUFBO0FBQ0csUUFBQSxzQkFBQSxHQUFBLHFCQUFBO0FBQW1CLFFBQUEsNEJBQUE7QUFDekMsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNFLFFBQUEsc0JBQUEsR0FBQSwyQ0FBQTtBQUNGLFFBQUEsNEJBQUEsRUFBTTtBQUdSLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFBcUIsUUFBQSxzQkFBQSxHQUFBLFdBQUE7QUFBRSxRQUFBLDRCQUFBLEVBQU07QUFHL0IsUUFBQSwwQkFBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFJRixRQUFBLDRCQUFBO0FBSUEsUUFBQSwwQkFBQSxJQUFBLHFEQUFBLEdBQUEsR0FBQSxpQkFBQSxDQUFBO0FBTUEsUUFBQSx5QkFBQSxJQUFBLElBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsS0FBQSxFQUFLLElBQUEsT0FBQSxFQUFBLEVBRXlCLElBQUEsT0FBQSxFQUFBLEVBQ0QsSUFBQSxTQUFBLEVBQUE7QUFDQSxRQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFRLFFBQUEsNEJBQUE7QUFDL0IsUUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFrQyxRQUFBLGdDQUFBLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLFVBQUEsa0NBQUEsSUFBQSxRQUFBLE1BQUEsTUFBQSxJQUFBLFNBQUE7QUFBQSxpQkFBQSwyQkFBQSxNQUFBO1FBQUEsQ0FBQTtBQUFxQixRQUFBLDBCQUFBLGlCQUFBLFNBQUEscUVBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBaUIsSUFBQSxXQUFBLENBQVk7UUFBQSxDQUFBO0FBQXBGLFFBQUEsNEJBQUEsRUFBd0Y7QUFHMUYsUUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF5QixJQUFBLFNBQUEsRUFBQTtBQUNGLFFBQUEsc0JBQUEsSUFBQSxjQUFBO0FBQVMsUUFBQSw0QkFBQTtBQUM5QixRQUFBLDhCQUFBLElBQUEsU0FBQSxFQUFBO0FBQWdDLFFBQUEsZ0NBQUEsaUJBQUEsU0FBQSxtRUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBO0FBQUEsVUFBQSxrQ0FBQSxJQUFBLFNBQUEsTUFBQSxNQUFBLElBQUEsVUFBQTtBQUFBLGlCQUFBLDJCQUFBLE1BQUE7UUFBQSxDQUFBO0FBQXNCLFFBQUEsMEJBQUEsaUJBQUEsU0FBQSxxRUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFpQixJQUFBLFdBQUEsQ0FBWTtRQUFBLENBQUE7QUFBbkYsUUFBQSw0QkFBQSxFQUF1RixFQUNuRjtBQUtSLFFBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxPQUFBLEVBQUEsRUFFRyxJQUFBLFNBQUEsRUFBQSxFQUNJLElBQUEsU0FBQSxFQUFBO0FBQ04sUUFBQSxnQ0FBQSxpQkFBQSxTQUFBLG1FQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxVQUFBLGtDQUFBLElBQUEsaUJBQUEsTUFBQSxNQUFBLElBQUEsa0JBQUE7QUFBQSxpQkFBQSwyQkFBQSxNQUFBO1FBQUEsQ0FBQTtBQUE4QixRQUFBLDBCQUFBLGlCQUFBLFNBQUEscUVBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBaUIsSUFBQSxXQUFBLENBQVk7UUFBQSxDQUFBO0FBQWxGLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsTUFBQTtBQUFNLFFBQUEsc0JBQUEsSUFBQSxTQUFBO0FBQU8sUUFBQSw0QkFBQSxFQUFPO0FBRXRCLFFBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUEsRUFBK0IsSUFBQSxTQUFBLEVBQUE7QUFDTixRQUFBLGdDQUFBLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLFVBQUEsa0NBQUEsSUFBQSxlQUFBLE1BQUEsTUFBQSxJQUFBLGdCQUFBO0FBQUEsaUJBQUEsMkJBQUEsTUFBQTtRQUFBLENBQUE7QUFBNEIsUUFBQSwwQkFBQSxpQkFBQSxTQUFBLHFFQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBO0FBQUEsaUJBQUEsMkJBQWlCLElBQUEsV0FBQSxDQUFZO1FBQUEsQ0FBQTtBQUFoRixRQUFBLDRCQUFBO0FBQ0EsUUFBQSw4QkFBQSxJQUFBLE1BQUE7QUFBTSxRQUFBLHNCQUFBLElBQUEsTUFBQTtBQUFJLFFBQUEsNEJBQUEsRUFBTyxFQUNYO0FBSVYsUUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE2QixJQUFBLFNBQUEsRUFBQSxFQUNJLElBQUEsU0FBQSxFQUFBO0FBQ04sUUFBQSxnQ0FBQSxpQkFBQSxTQUFBLG1FQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxVQUFBLGtDQUFBLElBQUEsbUJBQUEsTUFBQSxNQUFBLElBQUEsb0JBQUE7QUFBQSxpQkFBQSwyQkFBQSxNQUFBO1FBQUEsQ0FBQTtBQUFnQyxRQUFBLDBCQUFBLGlCQUFBLFNBQUEscUVBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBaUIsSUFBQSxXQUFBLENBQVk7UUFBQSxDQUFBO0FBQXBGLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsTUFBQTtBQUFNLFFBQUEsc0JBQUEsSUFBQSxXQUFBO0FBQVMsUUFBQSw0QkFBQSxFQUFPO0FBRXhCLFFBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUEsRUFBK0IsSUFBQSxTQUFBLEVBQUE7QUFDTixRQUFBLGdDQUFBLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLFVBQUEsa0NBQUEsSUFBQSxtQkFBQSxNQUFBLE1BQUEsSUFBQSxvQkFBQTtBQUFBLGlCQUFBLDJCQUFBLE1BQUE7UUFBQSxDQUFBO0FBQWdDLFFBQUEsMEJBQUEsaUJBQUEsU0FBQSxxRUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFpQixJQUFBLFdBQUEsQ0FBWTtRQUFBLENBQUE7QUFBcEYsUUFBQSw0QkFBQTtBQUNBLFFBQUEsOEJBQUEsSUFBQSxNQUFBO0FBQU0sUUFBQSxzQkFBQSxJQUFBLFVBQUE7QUFBUSxRQUFBLDRCQUFBLEVBQU8sRUFDZixFQUNKO0FBR1IsUUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwQixJQUFBLFNBQUEsRUFBQTtBQUNKLFFBQUEsc0JBQUEsSUFBQSxrQkFBQTtBQUFnQixRQUFBLDRCQUFBO0FBQ3BDLFFBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBNkIsUUFBQSwwQkFBQSxVQUFBLFNBQUEsNkRBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFVLElBQUEsbUJBQUEsTUFBQSxDQUEwQjtRQUFBLENBQUE7QUFDL0QsUUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFpQyxRQUFBLHNCQUFBLElBQUEsT0FBQTtBQUFLLFFBQUEsNEJBQUE7QUFDdEMsUUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFvQixRQUFBLHNCQUFBLElBQUEsT0FBQTtBQUFLLFFBQUEsNEJBQUE7QUFDekIsUUFBQSwwQkFBQSxJQUFBLDhDQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFHRixRQUFBLDRCQUFBLEVBQVMsRUFDTDtBQUdSLFFBQUEseUJBQUEsSUFBQSxJQUFBO0FBRUEsUUFBQSw4QkFBQSxJQUFBLEtBQUEsRUFBSyxJQUFBLEtBQUE7QUFHRCxRQUFBLDBCQUFBLElBQUEsMkNBQUEsSUFBQSxHQUFBLE9BQUEsRUFBQSxFQUF3RCxJQUFBLG1EQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxxQ0FBQTtBQXlDeEQsUUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQSxFQUEyRSxJQUFBLFVBQUE7QUFDL0QsUUFBQSxzQkFBQSxJQUFBLEtBQUE7QUFBRyxRQUFBLDRCQUFBLEVBQVc7QUFHMUIsUUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFtRCxRQUFBLDBCQUFBLFNBQUEsU0FBQSw4REFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFTLElBQUEsdUJBQUEsQ0FBd0I7UUFBQSxDQUFBO0FBQ2xGLFFBQUEsOEJBQUEsSUFBQSxVQUFBO0FBQVUsUUFBQSxzQkFBQSxJQUFBLGNBQUE7QUFBWSxRQUFBLDRCQUFBLEVBQVc7QUFHbkMsUUFBQSwwQkFBQSxJQUFBLDhEQUFBLEdBQUEsR0FBQSwwQkFBQSxFQUFBO0FBTUYsUUFBQSw0QkFBQSxFQUFNOzs7O0FBM0pOLFFBQUEsMEJBQUEsZUFBQSxJQUFBLFdBQUEsRUFBMkIsYUFBQSxJQUFBLFNBQUEsRUFDSixpQkFBQSxJQUFBLGFBQUEsRUFDUSxpQkFBQSxJQUFBLGFBQUEsRUFDQSx3QkFBQSxJQUFBLG9CQUFBLEVBQ2Msd0JBQUEsSUFBQSxvQkFBQSxFQUNBLGFBQUEsSUFBQSxTQUFBO0FBTzdDLFFBQUEseUJBQUE7QUFBQSxRQUFBLDJCQUFBLFdBQUEsSUFBQSxnQkFBQTtBQWNpQyxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxnQkFBQTtBQVNoQyxRQUFBLHlCQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsYUFBQTtBQVdxQyxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLGdDQUFBLFdBQUEsSUFBQSxNQUFBO0FBS0YsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSxnQ0FBQSxXQUFBLElBQUEsT0FBQTtBQVVQLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsZ0NBQUEsV0FBQSxJQUFBLGVBQUE7QUFJQSxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLGdDQUFBLFdBQUEsSUFBQSxhQUFBO0FBUUEsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSxnQ0FBQSxXQUFBLElBQUEsaUJBQUE7QUFJQSxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLGdDQUFBLFdBQUEsSUFBQSxpQkFBQTtBQVVqQixRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFNBQUEsQ0FBQTtBQUN3QixRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFdBQUEsSUFBQSxZQUFBO0FBWTVCLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLFlBQUEsU0FBQSxDQUFBLEVBQThCLFlBQUEsZ0JBQUE7QUFrRGpDLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tGRHpJTSwyQkFBeUIsRUFBQSxXQUFBLDZCQUFBLFVBQUEsdUVBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUF6QiwyQkFBeUIsRUFBQSxTQUFBLENBQUFDLE1BQUEsNEJBQUEsOEJBQUEsa0NBQUFDLEdBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxrQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxrQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR2R0Qzs7OztTQUFTLGFBQUFDLGFBQVcsU0FBQUMsY0FBYTs7QUFVM0IsSUFBTyxzQkFBUCxNQUFPLHFCQUFtQjtFQUU5QixZQUFvQixrQkFBa0M7QUFBbEMsU0FBQSxtQkFBQTtBQUVaLFNBQUEsd0JBQXdCO0FBQ3hCLFNBQUEsd0JBQXdCO0FBWXpCLFNBQUEsb0JBQThDO01BQ25ELFlBQVk7TUFDWixRQUFRO01BQ1IsU0FBUyxFQUFFLFFBQVEsRUFBRSxTQUFTLE1BQUssRUFBRTs7QUFHaEMsU0FBQSxpQkFBd0M7TUFDN0MsUUFBUSxDQUFDLFdBQVcsUUFBUTtNQUM1QixVQUFVO1FBQ1I7VUFDRSxNQUFNLENBQUMsR0FBRyxDQUFDO1VBQ1gsaUJBQWlCLENBQUMsV0FBVyxTQUFTO1VBQ3RDLHNCQUFzQixDQUFDLFdBQVcsU0FBUzs7OztFQTNCUztFQUsxRCxJQUFhLHFCQUFxQixPQUFhO0FBQzdDLFNBQUssd0JBQXdCLFNBQVM7QUFDdEMsU0FBSyxnQkFBZTtFQUN0QjtFQUVBLElBQWEscUJBQXFCLE9BQWE7QUFDN0MsU0FBSyx3QkFBd0IsU0FBUztBQUN0QyxTQUFLLGdCQUFlO0VBQ3RCO0VBbUJRLGtCQUFlO0FBQ3JCLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxLQUFLLHdCQUF3QixLQUFLLEtBQUssMEJBQTBCLEdBQUc7QUFDdEUseUJBQW1CLENBQUMsV0FBVyxTQUFTO0FBQ3hDLG9CQUFjLENBQUMsV0FBVyxTQUFTO0lBQ3JDLFdBQVcsS0FBSyx3QkFBd0IsS0FBSyxLQUFLLDBCQUEwQixHQUFHO0FBQzdFLHlCQUFtQixDQUFDLFdBQVcsU0FBUztBQUN4QyxvQkFBYyxDQUFDLFdBQVcsU0FBUztJQUNyQyxPQUFPO0FBQ0wseUJBQW1CLENBQUMsV0FBVyxTQUFTO0FBQ3hDLG9CQUFjLENBQUMsV0FBVyxTQUFTO0lBQ3JDO0FBRUEsU0FBSyxpQkFBaUIsaUNBQ2pCLEtBQUssaUJBRFk7TUFFcEIsVUFBVTtRQUNSLGlDQUNLLEtBQUssZUFBZSxTQUFTLENBQUMsSUFEbkM7VUFFRSxNQUFNLENBQUMsS0FBSyx1QkFBdUIsS0FBSyxxQkFBcUI7VUFDN0QsaUJBQWlCO1VBQ2pCLHNCQUFzQjs7OztFQUk5QjtFQUVBLGFBQWEsT0FBVTtBQUVyQixRQUFJLEtBQUssMEJBQTBCLEtBQUssS0FBSywwQkFBMEI7QUFBRztBQUUxRSxTQUFLLGlCQUFpQixTQUFTLFFBQVcsWUFBWSxRQUFXO3NDQUMvQixLQUFLLHNCQUFzQixRQUFRLENBQUMsQ0FBQztxQ0FDdEMsS0FBSyxzQkFBc0IsUUFBUSxDQUFDLENBQUM7cUNBQ3JDLEtBQUssd0JBQXdCLEtBQUssdUJBQXVCLFFBQVEsQ0FBQyxDQUFDO0dBQ3JHO0VBQ0Q7Ozt1Q0F2RVcsc0JBQW1CLGlDQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBbkIsc0JBQW1CLFdBQUEsQ0FBQSxDQUFBLGlCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsc0JBQUEsd0JBQUEsc0JBQUEsdUJBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxjQUFBLFFBQUEsV0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7QUNWaEMsUUFBQSw4QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUtFLFFBQUEsMEJBQUEsY0FBQSxTQUFBLDBEQUFBLFFBQUE7QUFBQSxpQkFBYyxJQUFBLGFBQUEsTUFBQTtRQUFvQixDQUFBO0FBQ3BDLFFBQUEsNEJBQUE7OztBQUpFLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGNBQUEsRUFBdUIsV0FBQSxJQUFBLGlCQUFBLEVBQ00sUUFBQSxVQUFBOzs7Ozs7a0ZET2xCLHFCQUFtQixFQUFBLFdBQUEsdUJBQUEsVUFBQSwyREFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQW5CLHFCQUFtQixFQUFBLFNBQUEsQ0FBQUMsTUFBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLDRCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLDRCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFVmhDOzs7O1NBQVMsYUFBQUMsYUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7Ozs7OztBQ3NCL0IsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBOEMsR0FBQSxJQUFBO0FBQ3RDLElBQUEsc0JBQUEsQ0FBQTs7QUFBOEMsSUFBQSw0QkFBQTtBQUNsRCxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTs7QUFBOEIsSUFBQSw0QkFBQTtBQUNsQyxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTtBQUE4QixJQUFBLDRCQUFBO0FBRWxDLElBQUEsOEJBQUEsR0FBQSxJQUFBLEVBQUksSUFBQSxPQUFBLEVBQUEsRUFDdUIsSUFBQSxVQUFBLEVBQUE7QUFFZixJQUFBLDBCQUFBLFNBQUEsU0FBQSxnRkFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxZQUFBLFFBQUEsRUFBQSxDQUFvQjtJQUFBLENBQUE7QUFDN0IsSUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7QUFFQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSwwQkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsY0FBQSxRQUFBLEVBQUEsQ0FBc0I7SUFBQSxDQUFBO0FBQy9CLElBQUEseUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSixJQUFBLDRCQUFBLEVBQVMsRUFDUCxFQUNMOzs7O0FBaEJELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLFFBQUEsVUFBQSxrQkFBQSxDQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxHQUFBLEdBQUEsUUFBQSxLQUFBLENBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFFBQUEsbUJBQUE7Ozs7O0FBZnBCLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQStELEdBQUEsU0FBQSxDQUFBLEVBQ2MsR0FBQSxTQUFBLEVBQUEsRUFDM0MsR0FBQSxJQUFBLEVBQ2xCLEdBQUEsSUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNiLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLE9BQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ1QsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBUyxJQUFBLDRCQUFBO0FBQ2IsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsYUFBQTtBQUFLLElBQUEsNEJBQUEsRUFBSyxFQUNiO0FBR1QsSUFBQSw4QkFBQSxJQUFBLE9BQUE7QUFDSSxJQUFBLDBCQUFBLElBQUEsc0RBQUEsSUFBQSxHQUFBLE1BQUEsRUFBQTtBQW9CSixJQUFBLDRCQUFBLEVBQVEsRUFDSjs7OztBQXJCcUIsSUFBQSx5QkFBQSxFQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLE9BQUEsb0JBQUE7Ozs7O0FBeUI3QixJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHVEQUFBO0FBQ0osSUFBQSw0QkFBQTs7Ozs7O0FBakRoQixJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQW9DLEdBQUEsT0FBQSxDQUFBLEVBQ2IsR0FBQSxPQUFBLENBQUEsRUFFVyxHQUFBLE1BQUEsQ0FBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxrQ0FBQTtBQUFnQyxJQUFBLDRCQUFBO0FBQ3RELElBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBMkIsSUFBQSwwQkFBQSxTQUFBLFNBQUEsbUVBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUFFLElBQUEsc0JBQUEsR0FBQSxNQUFBO0FBQUMsSUFBQSw0QkFBQSxFQUFTO0FBR2pFLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFFSSxJQUFBLDBCQUFBLEdBQUEsZ0RBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQSxFQUErRCxHQUFBLHdEQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxxQ0FBQTtBQTBDbkUsSUFBQSw0QkFBQSxFQUFNLEVBRUo7Ozs7O0FBNUNRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLHFCQUFBLFNBQUEsQ0FBQSxFQUF1QyxZQUFBLGNBQUE7OztBRERuRCxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO0VBRXBDLFlBQW9CLFFBQWM7QUFBZCxTQUFBLFNBQUE7QUFFWCxTQUFBLFNBQWtCO0FBR2xCLFNBQUEsdUJBQThCLENBQUE7QUFFN0IsU0FBQSxTQUFTLElBQUlGLGNBQVk7RUFQRztFQVN0QyxZQUFZLElBQVU7QUFDcEIsYUFBUyxLQUFLLFVBQVUsT0FBTyxXQUFXO0FBQzFDLFNBQUssT0FBTyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztFQUMvQztFQUVBLGNBQWMsSUFBVTtBQUN0QixhQUFTLEtBQUssVUFBVSxPQUFPLFdBQVc7QUFDMUMsU0FBSyxPQUFPLFNBQVMsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0VBQ2xEO0VBRUEsY0FBVztBQUNULFNBQUssT0FBTyxLQUFJO0FBQ2hCLGFBQVMsS0FBSyxVQUFVLE9BQU8sV0FBVztFQUM1Qzs7O3VDQXhCVyw0QkFBeUIsaUNBQUEsV0FBQSxDQUFBO0lBQUE7RUFBQTs7OEVBQXpCLDRCQUF5QixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFFBQUEsVUFBQSxzQkFBQSx1QkFBQSxHQUFBLFNBQUEsRUFBQSxRQUFBLFNBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxlQUFBLEVBQUEsR0FBQSxDQUFBLFNBQUEsV0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGlCQUFBLGtCQUFBLGdCQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSx1QkFBQSxVQUFBLGdCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLGtCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLHNCQUFBLFVBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxtQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1R0QyxRQUFBLDBCQUFBLEdBQUEsMENBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQTs7O0FBQXNCLFFBQUEsMEJBQUEsUUFBQSxJQUFBLE1BQUE7Ozs7OztrRkRTVCwyQkFBeUIsRUFBQSxXQUFBLDZCQUFBLFVBQUEsMkVBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUF6QiwyQkFBeUIsRUFBQSxTQUFBLENBQUFHLE1BQUFDLElBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxrQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxrQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRVR0Qzs7OztTQUFTLGFBQUFDLGFBQVcsZ0JBQUFDLGVBQWMsVUFBQUMsZUFBYztBQUNoRCxTQUFTLGVBQUFDLGNBQWEsYUFBQUMsWUFBVyxjQUFBQyxtQkFBa0I7Ozs7QUNLdkMsSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBNkMsSUFBQSxzQkFBQSxHQUFBLDZCQUFBO0FBQXFCLElBQUEsNEJBQUE7Ozs7O0FBRHRFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsNkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsYUFBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLGFBQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBT0osSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBOEMsSUFBQSxzQkFBQSxHQUFBLDZCQUFBO0FBQXFCLElBQUEsNEJBQUE7Ozs7O0FBRHZFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsOENBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsY0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSxVQUFBLENBQUE7Ozs7O0FBT0osSUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBdUMsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQTBCLElBQUEsNEJBQUE7Ozs7O0FBRHJFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLDBCQUFBLEdBQUEsOENBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7Ozs7QUFEUSxJQUFBLHlCQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLENBQUE7OztBRFJWLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7RUFNbkMsWUFBb0Isd0JBQXdELGtCQUFrQztBQUExRixTQUFBLHlCQUFBO0FBQXdELFNBQUEsbUJBQUE7QUFIckUsU0FBQSx1QkFBMEMsQ0FBQTtBQUN2QyxTQUFBLFdBQVcsSUFBSUMsY0FBWTtFQUU2RTtFQUVsSCxXQUFRO0FBQ04sU0FBSyxxQkFBb0I7QUFFekIsU0FBSyxzQkFBc0IsSUFBSUMsV0FBVTtNQUN2QyxJQUFJLElBQUlDLGFBQVksRUFBRTtNQUN0QixjQUFjLElBQUlBLGFBQVksSUFBSUMsWUFBVyxRQUFRO01BQ3JELGVBQWUsSUFBSUQsYUFBWSxJQUFJQyxZQUFXLFFBQVE7TUFDdEQsUUFBUSxJQUFJRCxhQUFZLElBQUlDLFlBQVcsUUFBUTtNQUMvQyxXQUFXLElBQUlELGFBQVksRUFBRTtLQUM5QjtFQUNIO0VBRUEsdUJBQW9CO0FBQ2xCLFNBQUssdUJBQXVCLGtCQUFpQixFQUFHLFVBQVUsVUFBTztBQUMvRCxVQUFJLENBQUMsTUFBTTtBQUNUO01BQ0Y7QUFDQSxXQUFLLG9CQUFvQixXQUFXLGlDQUMvQixPQUQrQjtRQUVsQyxjQUFjLEtBQUssYUFBYSxLQUFLLFlBQVk7UUFDakQsZUFBZSxLQUFLLGFBQWEsS0FBSyxhQUFhO1FBQ3BEO0FBQ0QsY0FBUSxJQUFJLEtBQUssbUJBQW1CO0lBQ3RDLENBQUM7RUFDSDtFQUVBLGFBQWEsTUFBbUI7QUFDOUIsUUFBSSxDQUFDO0FBQU0sYUFBTztBQUVsQixVQUFNLElBQUksSUFBSSxLQUFLLElBQUk7QUFDdkIsV0FBTyxFQUFFLFlBQVcsRUFBRyxNQUFNLEdBQUcsRUFBRSxDQUFDO0VBQ3JDO0VBRUEsSUFBSSxLQUFFO0FBQ0osV0FBTyxLQUFLLG9CQUFvQixJQUFJLElBQUk7RUFDMUM7RUFFQSxJQUFJLGVBQVk7QUFDZCxXQUFPLEtBQUssb0JBQW9CLElBQUksY0FBYztFQUNwRDtFQUVBLElBQUksZ0JBQWE7QUFDZixXQUFPLEtBQUssb0JBQW9CLElBQUksZUFBZTtFQUNyRDtFQUVBLElBQUksU0FBTTtBQUNSLFdBQU8sS0FBSyxvQkFBb0IsSUFBSSxRQUFRO0VBQzlDO0VBRUEsSUFBSSxZQUFTO0FBQ1gsV0FBTyxLQUFLLG9CQUFvQixJQUFJLFdBQVc7RUFDakQ7RUFFQSxTQUFNO0FBQ0osUUFBSSxLQUFLLG9CQUFvQixTQUFTO0FBQ3BDLFdBQUssb0JBQW9CLGlCQUFnQjtBQUN6QztJQUNGO0FBRUEsVUFBTSxVQUEyQixtQkFDNUIsS0FBSyxvQkFBb0I7QUFHOUIsVUFBTSxhQUFhLEtBQUssR0FBRztBQUUzQixTQUFLLHVCQUF1QixrQkFBa0IsU0FBUyxVQUFVLEVBQzlELFVBQVU7TUFDVCxNQUFNLE1BQUs7QUFDVCxhQUFLLGlCQUFpQixTQUFTLFdBQVcsUUFBVyxzREFBZ0QsTUFBUztNQUNoSDtNQUVBLE9BQU8sQ0FBQyxVQUFTO0FBQ2YsYUFBSyxpQkFBaUIsU0FBUyxTQUFTLFFBQVcsNkNBQTZDLE1BQVM7TUFDM0c7S0FDRDtFQUNMOzs7dUNBbkZXLDJCQUF3QixpQ0FBQSxzQkFBQSxHQUFBLGlDQUFBLGdCQUFBLENBQUE7SUFBQTtFQUFBOzs4RUFBeEIsMkJBQXdCLFdBQUEsQ0FBQSxDQUFBLHNCQUFBLENBQUEsR0FBQSxTQUFBLEVBQUEsVUFBQSxXQUFBLEdBQUEsWUFBQSxPQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxlQUFBLElBQUEsbUJBQUEsY0FBQSxHQUFBLENBQUEsU0FBQSxvQkFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLE9BQUEsZUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGVBQUEsSUFBQSxtQkFBQSxlQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLGVBQUEsNkJBQUEsbUJBQUEsVUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGNBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1pyQyxRQUFBLDhCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQU0sUUFBQSwwQkFBQSxZQUFBLFNBQUEsNkRBQUE7QUFBQSxpQkFBWSxJQUFBLE9BQUE7UUFBUSxDQUFBO0FBQ3RCLFFBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFBZSxRQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBZ0IsUUFBQSw0QkFBQTtBQUMvQixRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsU0FBQSxDQUFBO0FBQ00sUUFBQSxzQkFBQSxHQUFBLFVBQUE7QUFBUSxRQUFBLDRCQUFBO0FBQ2xDLFFBQUEseUJBQUEsR0FBQSxTQUFBLENBQUE7QUFDQSxRQUFBLDBCQUFBLEdBQUEseUNBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUdKLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsU0FBQSxDQUFBO0FBQ08sUUFBQSxzQkFBQSxJQUFBLGNBQUE7QUFBUyxRQUFBLDRCQUFBO0FBQ3BDLFFBQUEseUJBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxRQUFBLDBCQUFBLElBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUdKLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsU0FBQSxDQUFBO0FBQ0EsUUFBQSxzQkFBQSxJQUFBLFNBQUE7QUFBTyxRQUFBLDRCQUFBO0FBQzNCLFFBQUEseUJBQUEsSUFBQSxZQUFBLENBQUE7QUFDQSxRQUFBLDBCQUFBLElBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUdKLFFBQUEsNEJBQUE7QUFDQSxRQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0ksUUFBQSxzQkFBQSxJQUFBLFVBQUE7QUFDSixRQUFBLDRCQUFBLEVBQVM7OztBQXpCZSxRQUFBLDBCQUFBLGFBQUEsSUFBQSxtQkFBQTtBQUtkLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLGFBQUEsV0FBQSxJQUFBLG9CQUFBLE9BQUE7QUFPQSxRQUFBLHlCQUFBLENBQUE7QUFBQSxRQUFBLDBCQUFBLFFBQUEsSUFBQSxjQUFBLFdBQUEsSUFBQSxvQkFBQSxPQUFBO0FBT0EsUUFBQSx5QkFBQSxDQUFBO0FBQUEsUUFBQSwwQkFBQSxRQUFBLElBQUEsT0FBQSxXQUFBLElBQUEsb0JBQUEsT0FBQTtBQUkrQixRQUFBLHlCQUFBO0FBQUEsUUFBQSwwQkFBQSxZQUFBLElBQUEsb0JBQUEsT0FBQTs7Ozs7O2tGRFhoQywwQkFBd0IsRUFBQSxXQUFBLDRCQUFBLFVBQUEsZ0VBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUF4QiwwQkFBd0IsRUFBQSxTQUFBLENBQUFFLE1BQUEsa0NBQUEseUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxpQ0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxpQ0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRVpyQzs7OztTQUFTLGFBQUFDLGFBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBTyxVQUFBQyxlQUFjOztBQVNqRCxJQUFPLG1CQUFQLE1BQU8sa0JBQWdCO0VBTjdCLGNBQUE7QUFTWSxTQUFBLFNBQVMsSUFBSUYsY0FBWTs7Ozt1Q0FIeEIsbUJBQWdCO0lBQUE7RUFBQTs7OEVBQWhCLG1CQUFnQixXQUFBLENBQUEsQ0FBQSxlQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsUUFBQSxTQUFBLEdBQUEsU0FBQSxFQUFBLFFBQUEsU0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwwQkFBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTtBQ1Q3QixRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQXFCLFFBQUEsMEJBQUEsU0FBQSxTQUFBLGlEQUFBO0FBQUEsaUJBQVMsSUFBQSxPQUFBLEtBQUE7UUFBYSxDQUFBO0FBQ3pDLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFBbUIsUUFBQSwwQkFBQSxTQUFBLFNBQUEsK0NBQUEsUUFBQTtBQUFBLGlCQUFTLE9BQUEsZ0JBQUE7UUFBd0IsQ0FBQTtBQUVsRCxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTBCLEdBQUEsTUFBQTtBQUNsQixRQUFBLHNCQUFBLEdBQUEseUJBQUE7QUFBZ0IsUUFBQSw0QkFBQTtBQUN0QixRQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQTBCLFFBQUEsMEJBQUEsU0FBQSxTQUFBLG9EQUFBO0FBQUEsaUJBQVMsSUFBQSxPQUFBLEtBQUE7UUFBYSxDQUFBO0FBQUUsUUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQyxRQUFBLDRCQUFBLEVBQVM7QUFHOUQsUUFBQSx5QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVGLFFBQUEsNEJBQUEsRUFBTTs7O0FBRnVCLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsYUFBQSxJQUFBLFFBQUEsNkJBQUE7Ozs7OztrRkRDbEIsa0JBQWdCLEVBQUEsV0FBQSxvQkFBQSxVQUFBLHVEQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBaEIsa0JBQWdCLEVBQUEsU0FBQSxDQUFBRyxJQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEseUJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEseUJBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVUN0I7Ozs7U0FBUyxhQUFBQyxhQUFXLFNBQUFDLFFBQU8sVUFBQUMsU0FBUSxnQkFBQUMscUJBQW9COzs7OztBQ3VCM0MsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBMkMsR0FBQSxJQUFBLEVBQ3JDLEdBQUEsU0FBQSxFQUFBO0FBQWlFLElBQUEsMEJBQUEsVUFBQSxTQUFBLDBFQUFBO0FBQUEsWUFBQSxnQkFBQSw2QkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQUEsMkJBQVUsT0FBQSxjQUFBLGNBQUEsRUFBQSxDQUE2QjtJQUFBLENBQUE7QUFBeEcsSUFBQSw0QkFBQSxFQUE0RztBQUNoSCxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTs7QUFBa0QsSUFBQSw0QkFBQTtBQUN0RCxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTs7QUFBb0MsSUFBQSw0QkFBQTtBQUN4QyxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsRUFBQTtBQUF3QixJQUFBLDRCQUFBO0FBQzVCLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxFQUFBO0FBQXFCLElBQUEsNEJBQUEsRUFBSzs7Ozs7QUFKSCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsT0FBQSxjQUFBLGNBQUEsRUFBQSxDQUFBO0FBQ3ZCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLGNBQUEsVUFBQSxrQkFBQSxDQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxHQUFBLEdBQUEsY0FBQSxLQUFBLENBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGNBQUEsU0FBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsY0FBQSxNQUFBOzs7Ozs7QUFsQlosSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBd0QsR0FBQSxTQUFBLENBQUEsRUFDbUIsR0FBQSxTQUFBLEVBQUEsRUFDN0MsR0FBQSxJQUFBLEVBQ3BCLEdBQUEsSUFBQSxFQUNFLEdBQUEsU0FBQSxFQUFBO0FBQXVCLElBQUEsMEJBQUEsVUFBQSxTQUFBLGtFQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFVLE9BQUEsZ0JBQUEsTUFBQSxDQUF1QjtJQUFBLENBQUE7QUFBeEQsSUFBQSw0QkFBQSxFQUE0RDtBQUNoRSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNiLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLE9BQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ1QsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsaUJBQUE7QUFBUyxJQUFBLDRCQUFBO0FBQ2IsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUEsRUFBSyxFQUNaO0FBR1AsSUFBQSw4QkFBQSxJQUFBLE9BQUE7QUFDRSxJQUFBLDBCQUFBLElBQUEsaURBQUEsSUFBQSxJQUFBLE1BQUEsRUFBQTtBQU9GLElBQUEsNEJBQUEsRUFBUSxFQUNGOzs7O0FBUnVCLElBQUEseUJBQUEsRUFBQTtBQUFBLElBQUEsMEJBQUEsV0FBQSxPQUFBLFdBQUE7Ozs7O0FBVy9CLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBcUIsR0FBQSxHQUFBO0FBQ2hCLElBQUEsc0JBQUEsR0FBQSxpQ0FBQTtBQUE0QixJQUFBLDRCQUFBLEVBQUk7OztBRHpCdkMsSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtFQVB2QyxjQUFBO0FBU1csU0FBQSxjQUE0QixDQUFBO0FBQzNCLFNBQUEsU0FBUyxJQUFJQyxjQUFZO0FBQ25DLFNBQUEsc0JBQWdDLENBQUE7O0VBRWhDLGNBQWMsSUFBVTtBQUN0QixVQUFNLFFBQVEsS0FBSyxvQkFBb0IsUUFBUSxFQUFFO0FBQ2pELFFBQUksUUFBUSxJQUFJO0FBQ2QsV0FBSyxvQkFBb0IsT0FBTyxPQUFPLENBQUM7SUFDMUMsT0FBTztBQUNMLFdBQUssb0JBQW9CLEtBQUssRUFBRTtJQUNsQztFQUNGO0VBRUEsY0FBYyxJQUFVO0FBQ3RCLFdBQU8sS0FBSyxvQkFBb0IsU0FBUyxFQUFFO0VBQzdDO0VBRUEsZ0JBQWdCLE9BQVU7QUFDeEIsUUFBSSxNQUFNLE9BQU8sU0FBUztBQUN4QixXQUFLLHNCQUFzQixLQUFLLFlBQVksSUFBSSxPQUFLLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxPQUFxQixPQUFPLE1BQVM7SUFDMUcsT0FBTztBQUNMLFdBQUssc0JBQXNCLENBQUE7SUFDN0I7RUFDRjtFQUVBLHFCQUFrQjtBQUNoQixRQUFJLEtBQUssb0JBQW9CLFdBQVcsR0FBRztBQUN6QztJQUNGO0FBR0EsVUFBTSwwQkFBMEIsS0FBSyxZQUFZLE9BQU8sT0FBSyxLQUFLLG9CQUFvQixTQUFTLEVBQUUsRUFBRyxDQUFDO0FBR3JHLFVBQU0scUJBQXFCLG9CQUFJLElBQUc7QUFDbEMsNEJBQXdCLFFBQVEsZ0JBQWE7QUFDM0MsWUFBTSxPQUFPLElBQUksS0FBSyxXQUFXLFFBQVEsRUFBRSxtQkFBbUIsT0FBTztBQUNyRSxVQUFJLENBQUMsbUJBQW1CLElBQUksSUFBSSxHQUFHO0FBQ2pDLDJCQUFtQixJQUFJLE1BQU0sQ0FBQSxDQUFFO01BQ2pDO0FBQ0EseUJBQW1CLElBQUksSUFBSSxFQUFHLEtBQUssVUFBVTtJQUMvQyxDQUFDO0FBR0QsVUFBTSxRQUFRLHdCQUF3QixPQUFPLENBQUMsS0FBSyxlQUFlLE1BQU0sV0FBVyxPQUFPLENBQUM7QUFHM0YsUUFBSSxrQkFBa0I7QUFHdEIsVUFBTSxpQkFBaUIsTUFBTSxLQUFLLG1CQUFtQixLQUFJLENBQUUsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFLO0FBQ3pFLFlBQU0sQ0FBQyxNQUFNLE1BQU0sSUFBSSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNO0FBQ2xELFlBQU0sQ0FBQyxNQUFNLE1BQU0sSUFBSSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNO0FBQ2xELGFBQU8sSUFBSSxLQUFLLE1BQU0sT0FBTyxHQUFHLElBQUksRUFBRSxRQUFPLElBQUssSUFBSSxLQUFLLE1BQU0sT0FBTyxHQUFHLElBQUksRUFBRSxRQUFPO0lBQzFGLENBQUM7QUFFRCxtQkFBZSxRQUFRLFVBQU87QUFDNUIseUJBQW1CLEdBQUcsSUFBSTs7QUFDMUIsWUFBTSxrQkFBa0IsbUJBQW1CLElBQUksSUFBSTtBQUVuRCxzQkFBZ0IsUUFBUSxnQkFBYTtBQUNuQyxjQUFNLFFBQVEsV0FBVyxNQUFNLGVBQWUsU0FBUztVQUNyRCx1QkFBdUI7VUFDdkIsdUJBQXVCO1NBQ3hCO0FBQ0QsMkJBQW1CLE1BQU0sS0FBSyxNQUFNLFdBQVcsU0FBUzs7TUFDMUQsQ0FBQztBQUVELHlCQUFtQjtJQUNyQixDQUFDO0FBRUQsdUJBQW1CLG1CQUFtQixNQUFNLGVBQWUsU0FBUztNQUNsRSx1QkFBdUI7TUFDdkIsdUJBQXVCO0tBQ3hCLENBQUM7QUFHRixTQUFLLG9CQUFvQixlQUFlLEVBQUUsS0FBSyxNQUFLO0FBQ2xELFdBQUssWUFBVztJQUNsQixDQUFDLEVBQUUsTUFBTSxTQUFNO0FBQ2IsY0FBUSxNQUFNLG9EQUE4QyxHQUFHO0FBQy9ELFdBQUssdUJBQXVCLGVBQWU7SUFDN0MsQ0FBQztFQUNIO0VBRWMsb0JBQW9CLE9BQWE7O0FBRTdDLFVBQUksVUFBVSxhQUFhLFVBQVUsVUFBVSxXQUFXO0FBQ3hELGNBQU0sVUFBVSxVQUFVLFVBQVUsS0FBSztBQUN6QztNQUNGO0FBR0EsWUFBTSxXQUFXLFNBQVMsY0FBYyxVQUFVO0FBQ2xELGVBQVMsUUFBUTtBQUNqQixlQUFTLE1BQU0sV0FBVztBQUMxQixlQUFTLE1BQU0sT0FBTztBQUN0QixlQUFTLE1BQU0sTUFBTTtBQUNyQixlQUFTLEtBQUssWUFBWSxRQUFRO0FBQ2xDLGVBQVMsTUFBSztBQUNkLGVBQVMsT0FBTTtBQUVmLFVBQUk7QUFDRixjQUFNLGFBQWEsU0FBUyxZQUFZLE1BQU07QUFDOUMsWUFBSSxDQUFDLFlBQVk7QUFDZixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO1FBQ3hDO01BQ0Y7QUFDRSxpQkFBUyxLQUFLLFlBQVksUUFBUTtNQUNwQztJQUNGOztFQUVRLHVCQUF1QixPQUFhO0FBRTFDLFVBQU0sUUFBUSxTQUFTLGNBQWMsS0FBSztBQUMxQyxVQUFNLE1BQU0sVUFBVTs7Ozs7Ozs7Ozs7O0FBYXRCLFVBQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztBQUM1QyxZQUFRLE1BQU0sVUFBVTs7Ozs7Ozs7O0FBVXhCLFlBQVEsWUFBWTs7a0tBRTBJLEtBQUs7Ozs7O0FBTW5LLFVBQU0sWUFBWSxPQUFPO0FBQ3pCLGFBQVMsS0FBSyxZQUFZLEtBQUs7QUFHL0IsVUFBTSxXQUFXLFFBQVEsY0FBYyxVQUFVO0FBQ2pELGFBQVMsTUFBSztBQUNkLGFBQVMsT0FBTTtBQUdmLFVBQU0sY0FBYyxNQUFLO0FBQ3ZCLFVBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxHQUFHO0FBQ2pDLGlCQUFTLEtBQUssWUFBWSxLQUFLO01BQ2pDO0FBQ0EsV0FBSyxZQUFXO0lBQ2xCO0FBR0EsVUFBTSxZQUFZLFFBQVEsY0FBYyxlQUFlO0FBQ3ZELGNBQVUsVUFBVTtBQUdwQixVQUFNLGdCQUFnQixDQUFDLE1BQW9CO0FBQ3pDLFVBQUksRUFBRSxRQUFRLFVBQVU7QUFDdEIsb0JBQVc7QUFDWCxpQkFBUyxvQkFBb0IsV0FBVyxhQUFhO01BQ3ZEO0lBQ0Y7QUFFQSxhQUFTLGlCQUFpQixXQUFXLGFBQWE7RUFDcEQ7RUFFQSxjQUFXO0FBQ1QsU0FBSyxjQUFjLENBQUE7QUFDbkIsU0FBSyxzQkFBc0IsQ0FBQTtBQUMzQixTQUFLLE9BQU8sS0FBSTtFQUNsQjs7O3VDQXhMVyw2QkFBMEI7SUFBQTtFQUFBOzs4RUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLHdCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsYUFBQSxjQUFBLEdBQUEsU0FBQSxFQUFBLFFBQUEsU0FBQSxHQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLGlCQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLGNBQUEsVUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsaUJBQUEsa0JBQUEsZ0JBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxZQUFBLEdBQUEsVUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxVQUFBLEtBQUEsR0FBQTs7QUNWdkMsUUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFxQixRQUFBLDBCQUFBLFNBQUEsU0FBQSwyREFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQTtBQUFBLGlCQUFBLDJCQUFTLElBQUEsWUFBQSxDQUFhO1FBQUEsQ0FBQTtBQUN6QyxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTJCLFFBQUEsMEJBQUEsU0FBQSxTQUFBLHlEQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBUyxPQUFBLGdCQUFBLENBQXdCO1FBQUEsQ0FBQTtBQUMxRCxRQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTBCLEdBQUEsSUFBQTtBQUNwQixRQUFBLHNCQUFBLEdBQUEsdUJBQUE7QUFBa0IsUUFBQSw0QkFBQTtBQUN0QixRQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQTBCLFFBQUEsMEJBQUEsU0FBQSxTQUFBLDhEQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBO0FBQUEsaUJBQUEsMkJBQVMsSUFBQSxZQUFBLENBQWE7UUFBQSxDQUFBO0FBQzlDLFFBQUEsOEJBQUEsR0FBQSxNQUFBO0FBQU0sUUFBQSxzQkFBQSxHQUFBLE1BQUE7QUFBTyxRQUFBLDRCQUFBLEVBQU8sRUFDYjtBQUdYLFFBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxRQUFBLDBCQUFBLEdBQUEsMkNBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3RCxJQUFBLG9EQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxxQ0FBQTtBQTRCMUQsUUFBQSw0QkFBQTtBQUVBLFFBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBMEIsSUFBQSxVQUFBLENBQUE7QUFHdEIsUUFBQSwwQkFBQSxTQUFBLFNBQUEsK0RBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUE7QUFBQSxpQkFBQSwyQkFBUyxJQUFBLG1CQUFBLENBQW9CO1FBQUEsQ0FBQTtBQUM3QixRQUFBLHNCQUFBLEVBQUE7QUFDRixRQUFBLDRCQUFBLEVBQVMsRUFDTCxFQUNGOzs7O0FBckNJLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsUUFBQSxJQUFBLFlBQUEsU0FBQSxDQUFBLEVBQThCLFlBQUEsZ0JBQUE7QUFnQ2xDLFFBQUEseUJBQUEsQ0FBQTtBQUFBLFFBQUEsMEJBQUEsWUFBQSxJQUFBLG9CQUFBLFdBQUEsQ0FBQTtBQUVBLFFBQUEseUJBQUE7QUFBQSxRQUFBLGtDQUFBLDBCQUFBLElBQUEsb0JBQUEsUUFBQSxJQUFBOzs7Ozs7a0ZEbENLLDRCQUEwQixFQUFBLFdBQUEsOEJBQUEsVUFBQSx5RUFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQTFCLDRCQUEwQixFQUFBLFNBQUEsQ0FBQUMsSUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLG1DQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLG1DQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFVnZDOzs7O1NBQVMsWUFBMkI7O0FBTTlCLElBQU8sa0JBQVAsTUFBTyxpQkFBZTtFQUUxQixVQUFVLE9BQVU7QUFDbEIsUUFBSSxTQUFTLFFBQVEsTUFBTSxLQUFLLEdBQUc7QUFDakMsYUFBTztJQUNUO0FBRUEsUUFBSSxTQUFTLFdBQVcsS0FBSztBQUU3QixXQUFPLE9BQU8sZUFBZSxTQUFTLEVBQUUsdUJBQXVCLEdBQUcsdUJBQXVCLEVBQUMsQ0FBRTtFQUM5Rjs7O3VDQVZXLGtCQUFlO0lBQUE7RUFBQTs7K0ZBQWYsa0JBQWUsTUFBQSxNQUFBLFlBQUEsTUFBQSxDQUFBO0VBQUE7Ozs7QWhFRXRCLElBQU8sZ0JBQVAsTUFBTyxlQUFhOzs7dUNBQWIsZ0JBQWE7SUFBQTtFQUFBOzs4RUFBYixnQkFBYSxXQUFBLENBQUEsQ0FBQSxVQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxVQUFBLFNBQUEsdUJBQUEsSUFBQSxLQUFBO0FBQUEsVUFBQSxLQUFBLEdBQUE7QUNSMUIsUUFBQSx5QkFBQSxHQUFBLHVCQUFBOzs7Ozs7a0ZEUWEsZUFBYSxFQUFBLFdBQUEsaUJBQUEsVUFBQSx3Q0FBQSxZQUFBLEVBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQWIsZUFBYSxFQUFBLFNBQUEsQ0FBQUMsTUFBQUMsTUFBQUMsS0FBQUMsS0FBQUMsS0FBQSxJQUFBLElBQUEsSUFBQSxJQUFBLElBQUEsS0FBQSxLQUFBQyxNQUFBQyxNQUFBQyxNQUFBQyxNQUFBQyxNQUFBQyxNQUFBQyxNQUFBLHVCQUFBLDBCQUFBLDRCQUFBLG1DQUFBLG1DQUFBLG1DQUFBLHNDQUFBLDBCQUFBLHlCQUFBLHFDQUFBLHFDQUFBLHdDQUFBLHFDQUFBLHVDQUFBLHdDQUFBLHdDQUFBLDJDQUFBLHdDQUFBLDBDQUFBLHFDQUFBLCtCQUFBLHVDQUFBLG9DQUFBLDZCQUFBLHNDQUFBLHlCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsc0JBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsc0JBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7O0FEVTFCLElBQU0sU0FBaUI7RUFDckIsRUFBQyxNQUFNLFNBQVMsV0FBVyxlQUFjO0VBQ3pDLEVBQUMsTUFBTSxJQUFJLFdBQVcsY0FBYTtFQUNuQyxFQUFDLE1BQU0sWUFBWSxXQUFXLGtCQUFpQjtFQUMvQyxFQUFDLE1BQU0sdUJBQXVCLFdBQVcsd0JBQXVCO0VBQ2hFLEVBQUMsTUFBTSwwQkFBMEIsV0FBVywyQkFBMEI7RUFDdEUsRUFBQyxNQUFNLG1CQUFtQixXQUFXLHdCQUF1QjtFQUM1RCxFQUFDLE1BQU0sbUJBQW1CLFdBQVcsOEJBQTZCO0VBQ2xFLEVBQUMsTUFBTSw0QkFBNEIsV0FBVyw0QkFBMkI7RUFDekUsRUFBQyxNQUFNLCtCQUErQixXQUFXLCtCQUE4QjtFQUMvRSxFQUFDLE1BQU0sd0JBQXdCLFdBQVcsNEJBQTJCO0VBQ3JFLEVBQUMsTUFBTSxnQkFBZ0IsV0FBVywyQkFBMEI7RUFDNUQsRUFBQyxNQUFNLHlCQUF5QixXQUFXLHlCQUF3QjtFQUNuRSxFQUFDLE1BQU0sNEJBQTRCLFdBQVcsNEJBQTJCO0VBQ3pFLEVBQUMsTUFBTSxxQkFBcUIsV0FBVyx5QkFBd0I7RUFDL0QsRUFBQyxNQUFNLG9CQUFvQixXQUFXLHlCQUF3Qjs7QUFPMUQsSUFBTyxtQkFBUCxNQUFPLGtCQUFnQjs7O3VDQUFoQixtQkFBZ0I7SUFBQTtFQUFBOzs2RUFBaEIsa0JBQWdCLENBQUE7RUFBQTs7aUZBSGpCLGFBQWEsUUFBUSxNQUFNLEdBQzNCLFlBQVksRUFBQSxDQUFBO0VBQUE7Ozs7QURkeEIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUywwQkFBMEI7QUFDbkMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUywrQkFBK0I7OztBbUVuQ3hDLFNBQVMsY0FBQUMsb0JBQWtCO0FBRTNCLFNBQXFCLGNBQUFDLGNBQVksdUJBQXVCO0FBQ3hELFNBQVMsY0FBQUMsY0FBWSxhQUFBQyxZQUFXLFFBQVEsWUFBWTs7QTtBQU05QyxJQUFPLGtCQUFQLE1BQU8saUJBQWU7RUFJMUIsWUFBb0IsY0FBb0MsUUFBd0Isa0JBQWtDO0FBQTlGLFNBQUEsZUFBQTtBQUFvQyxTQUFBLFNBQUE7QUFBd0IsU0FBQSxtQkFBQTtBQUh4RSxTQUFBLGVBQWU7QUFDZixTQUFBLHNCQUFzRCxJQUFJLGdCQUErQixJQUFJO0VBRWdCO0VBRXJILFVBQVUsS0FBdUIsTUFBaUI7QUFDaEQsVUFBTSxZQUFZLEtBQUssYUFBYSxhQUFZO0FBR2hELFFBQUksV0FBVztBQUNiLFlBQU0sS0FBSyxTQUFTLEtBQUssU0FBUztJQUNwQztBQUVBLFdBQU8sS0FBSyxPQUFPLEdBQUcsRUFBRSxLQUN0QkMsYUFBVyxDQUFDLFVBQTRCO0FBQ3RDLFVBQUksTUFBTSxXQUFXLE9BQU8sQ0FBQyxJQUFJLElBQUksU0FBUyxZQUFZLEtBQUssQ0FBQyxJQUFJLElBQUksU0FBUyxjQUFjLEdBQUc7QUFDaEcsZUFBTyxLQUFLLGVBQWUsS0FBSyxJQUFJO01BQ3RDLFdBQVcsTUFBTSxXQUFXLEtBQUs7QUFDL0IsYUFBSyxpQkFBaUIsU0FBUyxTQUFTLFFBQVEsNkJBQXVCLE1BQU0sTUFBTSxJQUFJLE1BQVM7TUFDbEc7QUFDQSxhQUFPQyxhQUFXLE1BQU0sS0FBSztJQUMvQixDQUFDLENBQUM7RUFFTjtFQUVRLGVBQWUsU0FBMkIsTUFBaUI7QUFDakUsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN0QixXQUFLLGVBQWU7QUFDcEIsV0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBRWxDLFlBQU0sZUFBZSxLQUFLLGFBQWEsZ0JBQWU7QUFDdEQsY0FBUSxJQUFJLGtCQUFrQixZQUFZO0FBRTFDLFVBQUksQ0FBQyxjQUFjO0FBQ2pCLGFBQUssZUFBZTtBQUNwQixhQUFLLE9BQU8sU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUMvQixlQUFPQSxhQUFXLE1BQU0sSUFBSSxNQUFNLEtBQUssQ0FBQztNQUUxQztBQUVBLGFBQU8sS0FBSyxhQUFhLGFBQVksRUFBRyxLQUN0Q0MsV0FBVSxDQUFDLFdBQVU7QUFDbkIsYUFBSyxlQUFlO0FBQ3BCLGFBQUssb0JBQW9CLEtBQUssT0FBTyxLQUFLO0FBQzFDLGFBQUssYUFBYSxZQUFZLE1BQU07QUFFcEMsZUFBTyxLQUFLLE9BQU8sS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUM7TUFDekQsQ0FBQyxHQUNERixhQUFXLENBQUMsUUFBTztBQUNqQixhQUFLLGVBQWU7QUFDcEIsYUFBSyxhQUFhLFlBQVc7QUFDN0IsYUFBSyxhQUFhLE9BQU07QUFDeEIsZUFBT0MsYUFBVyxNQUFNLEdBQUc7TUFDN0IsQ0FBQyxDQUFDO0lBRU4sT0FBTztBQUNMLGFBQU8sS0FBSyxvQkFBb0IsS0FDOUIsT0FBTyxXQUFTLFVBQVUsSUFBSSxHQUM5QixLQUFLLENBQUMsR0FDTkMsV0FBVSxXQUFTLEtBQUssT0FBTyxLQUFLLFNBQVMsU0FBUyxLQUFNLENBQUMsQ0FBQyxDQUFDO0lBRW5FO0VBQ0Y7RUFFUSxTQUFTLFNBQTJCLE9BQWE7QUFDdkQsV0FBTyxRQUFRLE1BQU07TUFDbkIsWUFBWTtRQUNWLGVBQWUsVUFBVSxLQUFLOztLQUVqQztFQUNIOzs7dUNBdkVXLGtCQUFlLHdCQUFBLFlBQUEsR0FBQSx3QkFBQSxXQUFBLEdBQUEsd0JBQUEsZ0JBQUEsQ0FBQTtJQUFBO0VBQUE7O2lGQUFmLGtCQUFlLFNBQWYsaUJBQWUsVUFBQSxDQUFBO0VBQUE7Ozs7QW5FbUM1QixTQUFTLHNCQUFzQjtBQUUvQixTQUFTLCtCQUErQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEyRGxDLElBQU8sWUFBUCxNQUFPLFdBQVM7Ozt1Q0FBVCxZQUFTO0lBQUE7RUFBQTs7NkVBQVQsWUFBUyxXQUFBLENBdkJOLFlBQVksRUFBQSxDQUFBO0VBQUE7O2tGQWtCZDtNQUNGLEVBQUUsU0FBUyxtQkFBbUIsVUFBVSxpQkFBaUIsT0FBTyxLQUFJO01BQ3BFLGtCQUFrQix1QkFBc0IsQ0FBRTtPQUM3QyxTQUFBO01BcEJMO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7SUFBdUIsRUFBQSxDQUFBO0VBQUE7O21DQTdDbkIsY0FBWTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQ1o7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7QUFBMEIsR0FBQSxDQUFBLGVBQUEsbUJBQUEsbUJBQUEsY0FBQSxlQUFBLGlCQUFBLGlCQUFBLG1CQUFBLGtCQUFBLGNBQUEsb0JBQUEsb0JBQUEsa0JBWDFCLGVBQWUsQ0FBQTttQ0FkZixpQkFBZTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBRGY7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7QUFBMEIsR0FBQSxDQUFBLGVBQUEsbUJBQUEsbUJBQUEsY0FBQSxlQUFBLGlCQUFBLGlCQUFBLG1CQUFBLGtCQUFBLGNBQUEsb0JBQUEsb0JBQUEsa0JBWDFCLGVBQWUsQ0FBQTttQ0FaZixtQkFBaUI7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUhqQjtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVhmLHlCQUF1QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBSnZCO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0FBQTBCLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGtCQVgxQixlQUFlLENBQUE7bUNBVmYseUJBQXVCO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFMdkI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7QUFBMEIsR0FBQSxDQUFBLGVBQUEsbUJBQUEsbUJBQUEsY0FBQSxlQUFBLGlCQUFBLGlCQUFBLG1CQUFBLGtCQUFBLGNBQUEsb0JBQUEsb0JBQUEsa0JBWDFCLGVBQWUsQ0FBQTttQ0FUZix5QkFBdUI7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQU52QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVJmLDRCQUEwQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBUDFCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0FBQTBCLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGtCQVgxQixlQUFlLENBQUE7bUNBUGYsaUJBQWU7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQVJmO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0FBQTBCLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGtCQVgxQixlQUFlLENBQUE7bUNBTmYsZ0JBQWM7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQVRkO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0FBQTBCLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGtCQVgxQixlQUFlLENBQUE7bUNBTGYsMEJBQXdCO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFWeEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7QUFBMEIsR0FBQSxDQUFBLGVBQUEsbUJBQUEsbUJBQUEsY0FBQSxlQUFBLGlCQUFBLGlCQUFBLG1CQUFBLGtCQUFBLGNBQUEsb0JBQUEsb0JBQUEsa0JBWDFCLGVBQWUsQ0FBQTttQ0FKZiwwQkFBd0I7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQVh4QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUhmLDZCQUEyQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBWjNCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0FBQTBCLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGtCQVgxQixlQUFlLENBQUE7bUNBRmYsMEJBQXdCO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFieEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7QUFBMEIsR0FBQSxDQUFBLGVBQUEsbUJBQUEsbUJBQUEsY0FBQSxlQUFBLGlCQUFBLGlCQUFBLG1CQUFBLGtCQUFBLGNBQUEsb0JBQUEsb0JBQUEsa0JBWDFCLGVBQWUsQ0FBQTttQ0FEZiw0QkFBMEI7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQWQxQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBR0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUNmLDZCQUEyQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBaEIzQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFHQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUVmLDZCQUEyQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBakIzQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUdmLGdDQUE4QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBbEI5QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUlmLDZCQUEyQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBbkIzQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQUtmLCtCQUE2QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBcEI3QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQU1mLDJCQUF5QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBckJ6QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQU9mLHFCQUFtQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBdEJuQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVFmLDJCQUF5QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBdkJ6QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVNmLDBCQUF3QjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBeEJ4QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVVmLGtCQUFnQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBekJoQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtBQUEwQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFYMUIsZUFBZSxDQUFBO21DQVdmLDRCQUEwQjtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBMUIxQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtBQUFnQixHQUFBLENBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxrQkFWaEIsZUFBZSxDQUFBOzs7QW9FaEV2QixvQ0FBQSxFQUF5QixnQkFBZ0IsU0FBUyxFQUMvQyxNQUFNLFNBQU8sUUFBUSxNQUFNLEdBQUcsQ0FBQzsiLCJuYW1lcyI6WyJOZ01vZHVsZSIsIkNvbXBvbmVudCIsIkluamVjdGFibGUiLCJpMCIsImkxIiwiQ29tcG9uZW50IiwiaTAiLCJDb21wb25lbnQiLCJJbmplY3RhYmxlIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsIkluamVjdGFibGUiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsImNhdGNoRXJyb3IiLCJ0aHJvd0Vycm9yIiwiSW5qZWN0YWJsZSIsImNhdGNoRXJyb3IiLCJ0aHJvd0Vycm9yIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJfYzAiLCJpMCIsIkNvbXBvbmVudCIsIkluamVjdGFibGUiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsImNhdGNoRXJyb3IiLCJ0aHJvd0Vycm9yIiwiaTAiLCJDb21wb25lbnQiLCJWYWxpZGF0b3JzIiwiSW5qZWN0YWJsZSIsImNhdGNoRXJyb3IiLCJ0aHJvd0Vycm9yIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJWYWxpZGF0b3JzIiwiaTAiLCJDb21wb25lbnQiLCJpMCIsImkyIiwiQ29tcG9uZW50IiwiaTAiLCJpMiIsIkNvbXBvbmVudCIsIklucHV0IiwiSW5qZWN0YWJsZSIsInRocm93RXJyb3IiLCJjYXRjaEVycm9yIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJfYzAiLCJfYzEiLCJpMCIsIkNvbXBvbmVudCIsIlZhbGlkYXRvcnMiLCJWYWxpZGF0b3JzIiwiaTAiLCJpMSIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiRm9ybUNvbnRyb2wiLCJGb3JtR3JvdXAiLCJWYWxpZGF0b3JzIiwiRXZlbnRFbWl0dGVyIiwiRm9ybUdyb3VwIiwiRm9ybUNvbnRyb2wiLCJWYWxpZGF0b3JzIiwiaTAiLCJDb21wb25lbnQiLCJpMCIsImkyIiwiQ29tcG9uZW50IiwiaTAiLCJpMyIsIkNvbXBvbmVudCIsImkwIiwiaTIiLCJDb21wb25lbnQiLCJfYzEiLCJfYzIiLCJfYzAiLCJpMCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiRm9ybUNvbnRyb2wiLCJGb3JtR3JvdXAiLCJWYWxpZGF0b3JzIiwiRXZlbnRFbWl0dGVyIiwiRm9ybUdyb3VwIiwiRm9ybUNvbnRyb2wiLCJWYWxpZGF0b3JzIiwiaTAiLCJDb21wb25lbnQiLCJJbmplY3RhYmxlIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsImkwIiwiaTIiLCJDb21wb25lbnQiLCJpMCIsImkyIiwiQ29tcG9uZW50IiwiaTAiLCJpMiIsIkNvbXBvbmVudCIsImkwIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJJbmplY3RhYmxlIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsIl9jMCIsImkwIiwiaTQiLCJDb21wb25lbnQiLCJJbnB1dCIsImkwIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJpMCIsImkxIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiT3V0cHV0IiwiRm9ybUNvbnRyb2wiLCJGb3JtR3JvdXAiLCJWYWxpZGF0b3JzIiwiRXZlbnRFbWl0dGVyIiwiRm9ybUdyb3VwIiwiRm9ybUNvbnRyb2wiLCJWYWxpZGF0b3JzIiwiaTAiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsImkwIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJPdXRwdXQiLCJFdmVudEVtaXR0ZXIiLCJFdmVudEVtaXR0ZXIiLCJpMCIsImkwIiwiaTEiLCJpMiIsImkzIiwiaTQiLCJpMTIiLCJpMTMiLCJpMTQiLCJpMTUiLCJpMTYiLCJpMTciLCJpMTgiLCJJbmplY3RhYmxlIiwidGhyb3dFcnJvciIsImNhdGNoRXJyb3IiLCJzd2l0Y2hNYXAiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciIsInN3aXRjaE1hcCJdfQ==