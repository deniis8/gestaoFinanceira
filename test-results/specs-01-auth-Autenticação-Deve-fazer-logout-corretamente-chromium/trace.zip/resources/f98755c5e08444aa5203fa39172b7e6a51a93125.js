/*!
  * Bootstrap v5.3.5 (https://getbootstrap.com/)
  * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
  */
!function(t, e) {
  "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).bootstrap = e();
}(this, function() {
  "use strict";
  const t = /* @__PURE__ */ new Map(), e = { set(e2, i2, n2) {
    t.has(e2) || t.set(e2, /* @__PURE__ */ new Map());
    const s2 = t.get(e2);
    s2.has(i2) || 0 === s2.size ? s2.set(i2, n2) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(s2.keys())[0]}.`);
  }, get: (e2, i2) => t.has(e2) && t.get(e2).get(i2) || null, remove(e2, i2) {
    if (!t.has(e2)) return;
    const n2 = t.get(e2);
    n2.delete(i2), 0 === n2.size && t.delete(e2);
  } }, i = "transitionend", n = (t2) => (t2 && window.CSS && window.CSS.escape && (t2 = t2.replace(/#([^\s"#']+)/g, (t3, e2) => `#${CSS.escape(e2)}`)), t2), s = (t2) => {
    t2.dispatchEvent(new Event(i));
  }, o = (t2) => !(!t2 || "object" != typeof t2) && (void 0 !== t2.jquery && (t2 = t2[0]), void 0 !== t2.nodeType), r = (t2) => o(t2) ? t2.jquery ? t2[0] : t2 : "string" == typeof t2 && t2.length > 0 ? document.querySelector(n(t2)) : null, a = (t2) => {
    if (!o(t2) || 0 === t2.getClientRects().length) return false;
    const e2 = "visible" === getComputedStyle(t2).getPropertyValue("visibility"), i2 = t2.closest("details:not([open])");
    if (!i2) return e2;
    if (i2 !== t2) {
      const e3 = t2.closest("summary");
      if (e3 && e3.parentNode !== i2) return false;
      if (null === e3) return false;
    }
    return e2;
  }, l = (t2) => !t2 || t2.nodeType !== Node.ELEMENT_NODE || !!t2.classList.contains("disabled") || (void 0 !== t2.disabled ? t2.disabled : t2.hasAttribute("disabled") && "false" !== t2.getAttribute("disabled")), c = (t2) => {
    if (!document.documentElement.attachShadow) return null;
    if ("function" == typeof t2.getRootNode) {
      const e2 = t2.getRootNode();
      return e2 instanceof ShadowRoot ? e2 : null;
    }
    return t2 instanceof ShadowRoot ? t2 : t2.parentNode ? c(t2.parentNode) : null;
  }, h = () => {
  }, d = (t2) => {
    t2.offsetHeight;
  }, u = () => window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null, f = [], p = () => "rtl" === document.documentElement.dir, m = (t2) => {
    var e2;
    e2 = () => {
      const e3 = u();
      if (e3) {
        const i2 = t2.NAME, n2 = e3.fn[i2];
        e3.fn[i2] = t2.jQueryInterface, e3.fn[i2].Constructor = t2, e3.fn[i2].noConflict = () => (e3.fn[i2] = n2, t2.jQueryInterface);
      }
    }, "loading" === document.readyState ? (f.length || document.addEventListener("DOMContentLoaded", () => {
      for (const t3 of f) t3();
    }), f.push(e2)) : e2();
  }, g = (t2, e2 = [], i2 = t2) => "function" == typeof t2 ? t2.call(...e2) : i2, _ = (t2, e2, n2 = true) => {
    if (!n2) return void g(t2);
    const o2 = ((t3) => {
      if (!t3) return 0;
      let { transitionDuration: e3, transitionDelay: i2 } = window.getComputedStyle(t3);
      const n3 = Number.parseFloat(e3), s2 = Number.parseFloat(i2);
      return n3 || s2 ? (e3 = e3.split(",")[0], i2 = i2.split(",")[0], 1e3 * (Number.parseFloat(e3) + Number.parseFloat(i2))) : 0;
    })(e2) + 5;
    let r2 = false;
    const a2 = ({ target: n3 }) => {
      n3 === e2 && (r2 = true, e2.removeEventListener(i, a2), g(t2));
    };
    e2.addEventListener(i, a2), setTimeout(() => {
      r2 || s(e2);
    }, o2);
  }, b = (t2, e2, i2, n2) => {
    const s2 = t2.length;
    let o2 = t2.indexOf(e2);
    return -1 === o2 ? !i2 && n2 ? t2[s2 - 1] : t2[0] : (o2 += i2 ? 1 : -1, n2 && (o2 = (o2 + s2) % s2), t2[Math.max(0, Math.min(o2, s2 - 1))]);
  }, v = /[^.]*(?=\..*)\.|.*/, y = /\..*/, w = /::\d+$/, A = {};
  let E = 1;
  const T = { mouseenter: "mouseover", mouseleave: "mouseout" }, C = /* @__PURE__ */ new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);
  function O(t2, e2) {
    return e2 && `${e2}::${E++}` || t2.uidEvent || E++;
  }
  function x(t2) {
    const e2 = O(t2);
    return t2.uidEvent = e2, A[e2] = A[e2] || {}, A[e2];
  }
  function k(t2, e2, i2 = null) {
    return Object.values(t2).find((t3) => t3.callable === e2 && t3.delegationSelector === i2);
  }
  function L(t2, e2, i2) {
    const n2 = "string" == typeof e2, s2 = n2 ? i2 : e2 || i2;
    let o2 = I(t2);
    return C.has(o2) || (o2 = t2), [n2, s2, o2];
  }
  function S(t2, e2, i2, n2, s2) {
    if ("string" != typeof e2 || !t2) return;
    let [o2, r2, a2] = L(e2, i2, n2);
    if (e2 in T) {
      const t3 = (t4) => function(e3) {
        if (!e3.relatedTarget || e3.relatedTarget !== e3.delegateTarget && !e3.delegateTarget.contains(e3.relatedTarget)) return t4.call(this, e3);
      };
      r2 = t3(r2);
    }
    const l2 = x(t2), c2 = l2[a2] || (l2[a2] = {}), h2 = k(c2, r2, o2 ? i2 : null);
    if (h2) return void (h2.oneOff = h2.oneOff && s2);
    const d2 = O(r2, e2.replace(v, "")), u2 = o2 ? /* @__PURE__ */ function(t3, e3, i3) {
      return function n3(s3) {
        const o3 = t3.querySelectorAll(e3);
        for (let { target: r3 } = s3; r3 && r3 !== this; r3 = r3.parentNode) for (const a3 of o3) if (a3 === r3) return P(s3, { delegateTarget: r3 }), n3.oneOff && N.off(t3, s3.type, e3, i3), i3.apply(r3, [s3]);
      };
    }(t2, i2, r2) : /* @__PURE__ */ function(t3, e3) {
      return function i3(n3) {
        return P(n3, { delegateTarget: t3 }), i3.oneOff && N.off(t3, n3.type, e3), e3.apply(t3, [n3]);
      };
    }(t2, r2);
    u2.delegationSelector = o2 ? i2 : null, u2.callable = r2, u2.oneOff = s2, u2.uidEvent = d2, c2[d2] = u2, t2.addEventListener(a2, u2, o2);
  }
  function D(t2, e2, i2, n2, s2) {
    const o2 = k(e2[i2], n2, s2);
    o2 && (t2.removeEventListener(i2, o2, Boolean(s2)), delete e2[i2][o2.uidEvent]);
  }
  function $(t2, e2, i2, n2) {
    const s2 = e2[i2] || {};
    for (const [o2, r2] of Object.entries(s2)) o2.includes(n2) && D(t2, e2, i2, r2.callable, r2.delegationSelector);
  }
  function I(t2) {
    return t2 = t2.replace(y, ""), T[t2] || t2;
  }
  const N = { on(t2, e2, i2, n2) {
    S(t2, e2, i2, n2, false);
  }, one(t2, e2, i2, n2) {
    S(t2, e2, i2, n2, true);
  }, off(t2, e2, i2, n2) {
    if ("string" != typeof e2 || !t2) return;
    const [s2, o2, r2] = L(e2, i2, n2), a2 = r2 !== e2, l2 = x(t2), c2 = l2[r2] || {}, h2 = e2.startsWith(".");
    if (void 0 === o2) {
      if (h2) for (const i3 of Object.keys(l2)) $(t2, l2, i3, e2.slice(1));
      for (const [i3, n3] of Object.entries(c2)) {
        const s3 = i3.replace(w, "");
        a2 && !e2.includes(s3) || D(t2, l2, r2, n3.callable, n3.delegationSelector);
      }
    } else {
      if (!Object.keys(c2).length) return;
      D(t2, l2, r2, o2, s2 ? i2 : null);
    }
  }, trigger(t2, e2, i2) {
    if ("string" != typeof e2 || !t2) return null;
    const n2 = u();
    let s2 = null, o2 = true, r2 = true, a2 = false;
    e2 !== I(e2) && n2 && (s2 = n2.Event(e2, i2), n2(t2).trigger(s2), o2 = !s2.isPropagationStopped(), r2 = !s2.isImmediatePropagationStopped(), a2 = s2.isDefaultPrevented());
    const l2 = P(new Event(e2, { bubbles: o2, cancelable: true }), i2);
    return a2 && l2.preventDefault(), r2 && t2.dispatchEvent(l2), l2.defaultPrevented && s2 && s2.preventDefault(), l2;
  } };
  function P(t2, e2 = {}) {
    for (const [i2, n2] of Object.entries(e2)) try {
      t2[i2] = n2;
    } catch (e3) {
      Object.defineProperty(t2, i2, { configurable: true, get: () => n2 });
    }
    return t2;
  }
  function j(t2) {
    if ("true" === t2) return true;
    if ("false" === t2) return false;
    if (t2 === Number(t2).toString()) return Number(t2);
    if ("" === t2 || "null" === t2) return null;
    if ("string" != typeof t2) return t2;
    try {
      return JSON.parse(decodeURIComponent(t2));
    } catch (e2) {
      return t2;
    }
  }
  function M(t2) {
    return t2.replace(/[A-Z]/g, (t3) => `-${t3.toLowerCase()}`);
  }
  const F = { setDataAttribute(t2, e2, i2) {
    t2.setAttribute(`data-bs-${M(e2)}`, i2);
  }, removeDataAttribute(t2, e2) {
    t2.removeAttribute(`data-bs-${M(e2)}`);
  }, getDataAttributes(t2) {
    if (!t2) return {};
    const e2 = {}, i2 = Object.keys(t2.dataset).filter((t3) => t3.startsWith("bs") && !t3.startsWith("bsConfig"));
    for (const n2 of i2) {
      let i3 = n2.replace(/^bs/, "");
      i3 = i3.charAt(0).toLowerCase() + i3.slice(1), e2[i3] = j(t2.dataset[n2]);
    }
    return e2;
  }, getDataAttribute: (t2, e2) => j(t2.getAttribute(`data-bs-${M(e2)}`)) };
  class H {
    static get Default() {
      return {};
    }
    static get DefaultType() {
      return {};
    }
    static get NAME() {
      throw new Error('You have to implement the static method "NAME", for each component!');
    }
    _getConfig(t2) {
      return t2 = this._mergeConfigObj(t2), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    _configAfterMerge(t2) {
      return t2;
    }
    _mergeConfigObj(t2, e2) {
      const i2 = o(e2) ? F.getDataAttribute(e2, "config") : {};
      return { ...this.constructor.Default, ..."object" == typeof i2 ? i2 : {}, ...o(e2) ? F.getDataAttributes(e2) : {}, ..."object" == typeof t2 ? t2 : {} };
    }
    _typeCheckConfig(t2, e2 = this.constructor.DefaultType) {
      for (const [n2, s2] of Object.entries(e2)) {
        const e3 = t2[n2], r2 = o(e3) ? "element" : null == (i2 = e3) ? `${i2}` : Object.prototype.toString.call(i2).match(/\s([a-z]+)/i)[1].toLowerCase();
        if (!new RegExp(s2).test(r2)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${n2}" provided type "${r2}" but expected type "${s2}".`);
      }
      var i2;
    }
  }
  class W extends H {
    constructor(t2, i2) {
      super(), (t2 = r(t2)) && (this._element = t2, this._config = this._getConfig(i2), e.set(this._element, this.constructor.DATA_KEY, this));
    }
    dispose() {
      e.remove(this._element, this.constructor.DATA_KEY), N.off(this._element, this.constructor.EVENT_KEY);
      for (const t2 of Object.getOwnPropertyNames(this)) this[t2] = null;
    }
    _queueCallback(t2, e2, i2 = true) {
      _(t2, e2, i2);
    }
    _getConfig(t2) {
      return t2 = this._mergeConfigObj(t2, this._element), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    static getInstance(t2) {
      return e.get(r(t2), this.DATA_KEY);
    }
    static getOrCreateInstance(t2, e2 = {}) {
      return this.getInstance(t2) || new this(t2, "object" == typeof e2 ? e2 : null);
    }
    static get VERSION() {
      return "5.3.5";
    }
    static get DATA_KEY() {
      return `bs.${this.NAME}`;
    }
    static get EVENT_KEY() {
      return `.${this.DATA_KEY}`;
    }
    static eventName(t2) {
      return `${t2}${this.EVENT_KEY}`;
    }
  }
  const B = (t2) => {
    let e2 = t2.getAttribute("data-bs-target");
    if (!e2 || "#" === e2) {
      let i2 = t2.getAttribute("href");
      if (!i2 || !i2.includes("#") && !i2.startsWith(".")) return null;
      i2.includes("#") && !i2.startsWith("#") && (i2 = `#${i2.split("#")[1]}`), e2 = i2 && "#" !== i2 ? i2.trim() : null;
    }
    return e2 ? e2.split(",").map((t3) => n(t3)).join(",") : null;
  }, z = { find: (t2, e2 = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(e2, t2)), findOne: (t2, e2 = document.documentElement) => Element.prototype.querySelector.call(e2, t2), children: (t2, e2) => [].concat(...t2.children).filter((t3) => t3.matches(e2)), parents(t2, e2) {
    const i2 = [];
    let n2 = t2.parentNode.closest(e2);
    for (; n2; ) i2.push(n2), n2 = n2.parentNode.closest(e2);
    return i2;
  }, prev(t2, e2) {
    let i2 = t2.previousElementSibling;
    for (; i2; ) {
      if (i2.matches(e2)) return [i2];
      i2 = i2.previousElementSibling;
    }
    return [];
  }, next(t2, e2) {
    let i2 = t2.nextElementSibling;
    for (; i2; ) {
      if (i2.matches(e2)) return [i2];
      i2 = i2.nextElementSibling;
    }
    return [];
  }, focusableChildren(t2) {
    const e2 = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map((t3) => `${t3}:not([tabindex^="-"])`).join(",");
    return this.find(e2, t2).filter((t3) => !l(t3) && a(t3));
  }, getSelectorFromElement(t2) {
    const e2 = B(t2);
    return e2 && z.findOne(e2) ? e2 : null;
  }, getElementFromSelector(t2) {
    const e2 = B(t2);
    return e2 ? z.findOne(e2) : null;
  }, getMultipleElementsFromSelector(t2) {
    const e2 = B(t2);
    return e2 ? z.find(e2) : [];
  } }, R = (t2, e2 = "hide") => {
    const i2 = `click.dismiss${t2.EVENT_KEY}`, n2 = t2.NAME;
    N.on(document, i2, `[data-bs-dismiss="${n2}"]`, function(i3) {
      if (["A", "AREA"].includes(this.tagName) && i3.preventDefault(), l(this)) return;
      const s2 = z.getElementFromSelector(this) || this.closest(`.${n2}`);
      t2.getOrCreateInstance(s2)[e2]();
    });
  }, q = ".bs.alert", V = `close${q}`, K = `closed${q}`;
  class Q extends W {
    static get NAME() {
      return "alert";
    }
    close() {
      if (N.trigger(this._element, V).defaultPrevented) return;
      this._element.classList.remove("show");
      const t2 = this._element.classList.contains("fade");
      this._queueCallback(() => this._destroyElement(), this._element, t2);
    }
    _destroyElement() {
      this._element.remove(), N.trigger(this._element, K), this.dispose();
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Q.getOrCreateInstance(this);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  R(Q, "close"), m(Q);
  const X = '[data-bs-toggle="button"]';
  class Y extends W {
    static get NAME() {
      return "button";
    }
    toggle() {
      this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"));
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Y.getOrCreateInstance(this);
        "toggle" === t2 && e2[t2]();
      });
    }
  }
  N.on(document, "click.bs.button.data-api", X, (t2) => {
    t2.preventDefault();
    const e2 = t2.target.closest(X);
    Y.getOrCreateInstance(e2).toggle();
  }), m(Y);
  const U = ".bs.swipe", G = `touchstart${U}`, J = `touchmove${U}`, Z = `touchend${U}`, tt = `pointerdown${U}`, et = `pointerup${U}`, it = { endCallback: null, leftCallback: null, rightCallback: null }, nt = { endCallback: "(function|null)", leftCallback: "(function|null)", rightCallback: "(function|null)" };
  class st extends H {
    constructor(t2, e2) {
      super(), this._element = t2, t2 && st.isSupported() && (this._config = this._getConfig(e2), this._deltaX = 0, this._supportPointerEvents = Boolean(window.PointerEvent), this._initEvents());
    }
    static get Default() {
      return it;
    }
    static get DefaultType() {
      return nt;
    }
    static get NAME() {
      return "swipe";
    }
    dispose() {
      N.off(this._element, U);
    }
    _start(t2) {
      this._supportPointerEvents ? this._eventIsPointerPenTouch(t2) && (this._deltaX = t2.clientX) : this._deltaX = t2.touches[0].clientX;
    }
    _end(t2) {
      this._eventIsPointerPenTouch(t2) && (this._deltaX = t2.clientX - this._deltaX), this._handleSwipe(), g(this._config.endCallback);
    }
    _move(t2) {
      this._deltaX = t2.touches && t2.touches.length > 1 ? 0 : t2.touches[0].clientX - this._deltaX;
    }
    _handleSwipe() {
      const t2 = Math.abs(this._deltaX);
      if (t2 <= 40) return;
      const e2 = t2 / this._deltaX;
      this._deltaX = 0, e2 && g(e2 > 0 ? this._config.rightCallback : this._config.leftCallback);
    }
    _initEvents() {
      this._supportPointerEvents ? (N.on(this._element, tt, (t2) => this._start(t2)), N.on(this._element, et, (t2) => this._end(t2)), this._element.classList.add("pointer-event")) : (N.on(this._element, G, (t2) => this._start(t2)), N.on(this._element, J, (t2) => this._move(t2)), N.on(this._element, Z, (t2) => this._end(t2)));
    }
    _eventIsPointerPenTouch(t2) {
      return this._supportPointerEvents && ("pen" === t2.pointerType || "touch" === t2.pointerType);
    }
    static isSupported() {
      return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0;
    }
  }
  const ot = ".bs.carousel", rt = ".data-api", at = "ArrowLeft", lt = "ArrowRight", ct = "next", ht = "prev", dt = "left", ut = "right", ft = `slide${ot}`, pt = `slid${ot}`, mt = `keydown${ot}`, gt = `mouseenter${ot}`, _t = `mouseleave${ot}`, bt = `dragstart${ot}`, vt = `load${ot}${rt}`, yt = `click${ot}${rt}`, wt = "carousel", At = "active", Et = ".active", Tt = ".carousel-item", Ct = Et + Tt, Ot = { [at]: ut, [lt]: dt }, xt = { interval: 5e3, keyboard: true, pause: "hover", ride: false, touch: true, wrap: true }, kt = { interval: "(number|boolean)", keyboard: "boolean", pause: "(string|boolean)", ride: "(boolean|string)", touch: "boolean", wrap: "boolean" };
  class Lt extends W {
    constructor(t2, e2) {
      super(t2, e2), this._interval = null, this._activeElement = null, this._isSliding = false, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = z.findOne(".carousel-indicators", this._element), this._addEventListeners(), this._config.ride === wt && this.cycle();
    }
    static get Default() {
      return xt;
    }
    static get DefaultType() {
      return kt;
    }
    static get NAME() {
      return "carousel";
    }
    next() {
      this._slide(ct);
    }
    nextWhenVisible() {
      !document.hidden && a(this._element) && this.next();
    }
    prev() {
      this._slide(ht);
    }
    pause() {
      this._isSliding && s(this._element), this._clearInterval();
    }
    cycle() {
      this._clearInterval(), this._updateInterval(), this._interval = setInterval(() => this.nextWhenVisible(), this._config.interval);
    }
    _maybeEnableCycle() {
      this._config.ride && (this._isSliding ? N.one(this._element, pt, () => this.cycle()) : this.cycle());
    }
    to(t2) {
      const e2 = this._getItems();
      if (t2 > e2.length - 1 || t2 < 0) return;
      if (this._isSliding) return void N.one(this._element, pt, () => this.to(t2));
      const i2 = this._getItemIndex(this._getActive());
      if (i2 === t2) return;
      const n2 = t2 > i2 ? ct : ht;
      this._slide(n2, e2[t2]);
    }
    dispose() {
      this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
    }
    _configAfterMerge(t2) {
      return t2.defaultInterval = t2.interval, t2;
    }
    _addEventListeners() {
      this._config.keyboard && N.on(this._element, mt, (t2) => this._keydown(t2)), "hover" === this._config.pause && (N.on(this._element, gt, () => this.pause()), N.on(this._element, _t, () => this._maybeEnableCycle())), this._config.touch && st.isSupported() && this._addTouchEventListeners();
    }
    _addTouchEventListeners() {
      for (const t3 of z.find(".carousel-item img", this._element)) N.on(t3, bt, (t4) => t4.preventDefault());
      const t2 = { leftCallback: () => this._slide(this._directionToOrder(dt)), rightCallback: () => this._slide(this._directionToOrder(ut)), endCallback: () => {
        "hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(() => this._maybeEnableCycle(), 500 + this._config.interval));
      } };
      this._swipeHelper = new st(this._element, t2);
    }
    _keydown(t2) {
      if (/input|textarea/i.test(t2.target.tagName)) return;
      const e2 = Ot[t2.key];
      e2 && (t2.preventDefault(), this._slide(this._directionToOrder(e2)));
    }
    _getItemIndex(t2) {
      return this._getItems().indexOf(t2);
    }
    _setActiveIndicatorElement(t2) {
      if (!this._indicatorsElement) return;
      const e2 = z.findOne(Et, this._indicatorsElement);
      e2.classList.remove(At), e2.removeAttribute("aria-current");
      const i2 = z.findOne(`[data-bs-slide-to="${t2}"]`, this._indicatorsElement);
      i2 && (i2.classList.add(At), i2.setAttribute("aria-current", "true"));
    }
    _updateInterval() {
      const t2 = this._activeElement || this._getActive();
      if (!t2) return;
      const e2 = Number.parseInt(t2.getAttribute("data-bs-interval"), 10);
      this._config.interval = e2 || this._config.defaultInterval;
    }
    _slide(t2, e2 = null) {
      if (this._isSliding) return;
      const i2 = this._getActive(), n2 = t2 === ct, s2 = e2 || b(this._getItems(), i2, n2, this._config.wrap);
      if (s2 === i2) return;
      const o2 = this._getItemIndex(s2), r2 = (e3) => N.trigger(this._element, e3, { relatedTarget: s2, direction: this._orderToDirection(t2), from: this._getItemIndex(i2), to: o2 });
      if (r2(ft).defaultPrevented) return;
      if (!i2 || !s2) return;
      const a2 = Boolean(this._interval);
      this.pause(), this._isSliding = true, this._setActiveIndicatorElement(o2), this._activeElement = s2;
      const l2 = n2 ? "carousel-item-start" : "carousel-item-end", c2 = n2 ? "carousel-item-next" : "carousel-item-prev";
      s2.classList.add(c2), d(s2), i2.classList.add(l2), s2.classList.add(l2), this._queueCallback(() => {
        s2.classList.remove(l2, c2), s2.classList.add(At), i2.classList.remove(At, c2, l2), this._isSliding = false, r2(pt);
      }, i2, this._isAnimated()), a2 && this.cycle();
    }
    _isAnimated() {
      return this._element.classList.contains("slide");
    }
    _getActive() {
      return z.findOne(Ct, this._element);
    }
    _getItems() {
      return z.find(Tt, this._element);
    }
    _clearInterval() {
      this._interval && (clearInterval(this._interval), this._interval = null);
    }
    _directionToOrder(t2) {
      return p() ? t2 === dt ? ht : ct : t2 === dt ? ct : ht;
    }
    _orderToDirection(t2) {
      return p() ? t2 === ht ? dt : ut : t2 === ht ? ut : dt;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Lt.getOrCreateInstance(this, t2);
        if ("number" != typeof t2) {
          if ("string" == typeof t2) {
            if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
            e2[t2]();
          }
        } else e2.to(t2);
      });
    }
  }
  N.on(document, yt, "[data-bs-slide], [data-bs-slide-to]", function(t2) {
    const e2 = z.getElementFromSelector(this);
    if (!e2 || !e2.classList.contains(wt)) return;
    t2.preventDefault();
    const i2 = Lt.getOrCreateInstance(e2), n2 = this.getAttribute("data-bs-slide-to");
    return n2 ? (i2.to(n2), void i2._maybeEnableCycle()) : "next" === F.getDataAttribute(this, "slide") ? (i2.next(), void i2._maybeEnableCycle()) : (i2.prev(), void i2._maybeEnableCycle());
  }), N.on(window, vt, () => {
    const t2 = z.find('[data-bs-ride="carousel"]');
    for (const e2 of t2) Lt.getOrCreateInstance(e2);
  }), m(Lt);
  const St = ".bs.collapse", Dt = `show${St}`, $t = `shown${St}`, It = `hide${St}`, Nt = `hidden${St}`, Pt = `click${St}.data-api`, jt = "show", Mt = "collapse", Ft = "collapsing", Ht = `:scope .${Mt} .${Mt}`, Wt = '[data-bs-toggle="collapse"]', Bt = { parent: null, toggle: true }, zt = { parent: "(null|element)", toggle: "boolean" };
  class Rt extends W {
    constructor(t2, e2) {
      super(t2, e2), this._isTransitioning = false, this._triggerArray = [];
      const i2 = z.find(Wt);
      for (const t3 of i2) {
        const e3 = z.getSelectorFromElement(t3), i3 = z.find(e3).filter((t4) => t4 === this._element);
        null !== e3 && i3.length && this._triggerArray.push(t3);
      }
      this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle();
    }
    static get Default() {
      return Bt;
    }
    static get DefaultType() {
      return zt;
    }
    static get NAME() {
      return "collapse";
    }
    toggle() {
      this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (this._isTransitioning || this._isShown()) return;
      let t2 = [];
      if (this._config.parent && (t2 = this._getFirstLevelChildren(".collapse.show, .collapse.collapsing").filter((t3) => t3 !== this._element).map((t3) => Rt.getOrCreateInstance(t3, { toggle: false }))), t2.length && t2[0]._isTransitioning) return;
      if (N.trigger(this._element, Dt).defaultPrevented) return;
      for (const e3 of t2) e3.hide();
      const e2 = this._getDimension();
      this._element.classList.remove(Mt), this._element.classList.add(Ft), this._element.style[e2] = 0, this._addAriaAndCollapsedClass(this._triggerArray, true), this._isTransitioning = true;
      const i2 = `scroll${e2[0].toUpperCase() + e2.slice(1)}`;
      this._queueCallback(() => {
        this._isTransitioning = false, this._element.classList.remove(Ft), this._element.classList.add(Mt, jt), this._element.style[e2] = "", N.trigger(this._element, $t);
      }, this._element, true), this._element.style[e2] = `${this._element[i2]}px`;
    }
    hide() {
      if (this._isTransitioning || !this._isShown()) return;
      if (N.trigger(this._element, It).defaultPrevented) return;
      const t2 = this._getDimension();
      this._element.style[t2] = `${this._element.getBoundingClientRect()[t2]}px`, d(this._element), this._element.classList.add(Ft), this._element.classList.remove(Mt, jt);
      for (const t3 of this._triggerArray) {
        const e2 = z.getElementFromSelector(t3);
        e2 && !this._isShown(e2) && this._addAriaAndCollapsedClass([t3], false);
      }
      this._isTransitioning = true, this._element.style[t2] = "", this._queueCallback(() => {
        this._isTransitioning = false, this._element.classList.remove(Ft), this._element.classList.add(Mt), N.trigger(this._element, Nt);
      }, this._element, true);
    }
    _isShown(t2 = this._element) {
      return t2.classList.contains(jt);
    }
    _configAfterMerge(t2) {
      return t2.toggle = Boolean(t2.toggle), t2.parent = r(t2.parent), t2;
    }
    _getDimension() {
      return this._element.classList.contains("collapse-horizontal") ? "width" : "height";
    }
    _initializeChildren() {
      if (!this._config.parent) return;
      const t2 = this._getFirstLevelChildren(Wt);
      for (const e2 of t2) {
        const t3 = z.getElementFromSelector(e2);
        t3 && this._addAriaAndCollapsedClass([e2], this._isShown(t3));
      }
    }
    _getFirstLevelChildren(t2) {
      const e2 = z.find(Ht, this._config.parent);
      return z.find(t2, this._config.parent).filter((t3) => !e2.includes(t3));
    }
    _addAriaAndCollapsedClass(t2, e2) {
      if (t2.length) for (const i2 of t2) i2.classList.toggle("collapsed", !e2), i2.setAttribute("aria-expanded", e2);
    }
    static jQueryInterface(t2) {
      const e2 = {};
      return "string" == typeof t2 && /show|hide/.test(t2) && (e2.toggle = false), this.each(function() {
        const i2 = Rt.getOrCreateInstance(this, e2);
        if ("string" == typeof t2) {
          if (void 0 === i2[t2]) throw new TypeError(`No method named "${t2}"`);
          i2[t2]();
        }
      });
    }
  }
  N.on(document, Pt, Wt, function(t2) {
    ("A" === t2.target.tagName || t2.delegateTarget && "A" === t2.delegateTarget.tagName) && t2.preventDefault();
    for (const t3 of z.getMultipleElementsFromSelector(this)) Rt.getOrCreateInstance(t3, { toggle: false }).toggle();
  }), m(Rt);
  var qt = "top", Vt = "bottom", Kt = "right", Qt = "left", Xt = "auto", Yt = [qt, Vt, Kt, Qt], Ut = "start", Gt = "end", Jt = "clippingParents", Zt = "viewport", te = "popper", ee = "reference", ie = Yt.reduce(function(t2, e2) {
    return t2.concat([e2 + "-" + Ut, e2 + "-" + Gt]);
  }, []), ne = [].concat(Yt, [Xt]).reduce(function(t2, e2) {
    return t2.concat([e2, e2 + "-" + Ut, e2 + "-" + Gt]);
  }, []), se = "beforeRead", oe = "read", re = "afterRead", ae = "beforeMain", le = "main", ce = "afterMain", he = "beforeWrite", de = "write", ue = "afterWrite", fe = [se, oe, re, ae, le, ce, he, de, ue];
  function pe(t2) {
    return t2 ? (t2.nodeName || "").toLowerCase() : null;
  }
  function me(t2) {
    if (null == t2) return window;
    if ("[object Window]" !== t2.toString()) {
      var e2 = t2.ownerDocument;
      return e2 && e2.defaultView || window;
    }
    return t2;
  }
  function ge(t2) {
    return t2 instanceof me(t2).Element || t2 instanceof Element;
  }
  function _e(t2) {
    return t2 instanceof me(t2).HTMLElement || t2 instanceof HTMLElement;
  }
  function be(t2) {
    return "undefined" != typeof ShadowRoot && (t2 instanceof me(t2).ShadowRoot || t2 instanceof ShadowRoot);
  }
  const ve = { name: "applyStyles", enabled: true, phase: "write", fn: function(t2) {
    var e2 = t2.state;
    Object.keys(e2.elements).forEach(function(t3) {
      var i2 = e2.styles[t3] || {}, n2 = e2.attributes[t3] || {}, s2 = e2.elements[t3];
      _e(s2) && pe(s2) && (Object.assign(s2.style, i2), Object.keys(n2).forEach(function(t4) {
        var e3 = n2[t4];
        false === e3 ? s2.removeAttribute(t4) : s2.setAttribute(t4, true === e3 ? "" : e3);
      }));
    });
  }, effect: function(t2) {
    var e2 = t2.state, i2 = { popper: { position: e2.options.strategy, left: "0", top: "0", margin: "0" }, arrow: { position: "absolute" }, reference: {} };
    return Object.assign(e2.elements.popper.style, i2.popper), e2.styles = i2, e2.elements.arrow && Object.assign(e2.elements.arrow.style, i2.arrow), function() {
      Object.keys(e2.elements).forEach(function(t3) {
        var n2 = e2.elements[t3], s2 = e2.attributes[t3] || {}, o2 = Object.keys(e2.styles.hasOwnProperty(t3) ? e2.styles[t3] : i2[t3]).reduce(function(t4, e3) {
          return t4[e3] = "", t4;
        }, {});
        _e(n2) && pe(n2) && (Object.assign(n2.style, o2), Object.keys(s2).forEach(function(t4) {
          n2.removeAttribute(t4);
        }));
      });
    };
  }, requires: ["computeStyles"] };
  function ye(t2) {
    return t2.split("-")[0];
  }
  var we = Math.max, Ae = Math.min, Ee = Math.round;
  function Te() {
    var t2 = navigator.userAgentData;
    return null != t2 && t2.brands && Array.isArray(t2.brands) ? t2.brands.map(function(t3) {
      return t3.brand + "/" + t3.version;
    }).join(" ") : navigator.userAgent;
  }
  function Ce() {
    return !/^((?!chrome|android).)*safari/i.test(Te());
  }
  function Oe(t2, e2, i2) {
    void 0 === e2 && (e2 = false), void 0 === i2 && (i2 = false);
    var n2 = t2.getBoundingClientRect(), s2 = 1, o2 = 1;
    e2 && _e(t2) && (s2 = t2.offsetWidth > 0 && Ee(n2.width) / t2.offsetWidth || 1, o2 = t2.offsetHeight > 0 && Ee(n2.height) / t2.offsetHeight || 1);
    var r2 = (ge(t2) ? me(t2) : window).visualViewport, a2 = !Ce() && i2, l2 = (n2.left + (a2 && r2 ? r2.offsetLeft : 0)) / s2, c2 = (n2.top + (a2 && r2 ? r2.offsetTop : 0)) / o2, h2 = n2.width / s2, d2 = n2.height / o2;
    return { width: h2, height: d2, top: c2, right: l2 + h2, bottom: c2 + d2, left: l2, x: l2, y: c2 };
  }
  function xe(t2) {
    var e2 = Oe(t2), i2 = t2.offsetWidth, n2 = t2.offsetHeight;
    return Math.abs(e2.width - i2) <= 1 && (i2 = e2.width), Math.abs(e2.height - n2) <= 1 && (n2 = e2.height), { x: t2.offsetLeft, y: t2.offsetTop, width: i2, height: n2 };
  }
  function ke(t2, e2) {
    var i2 = e2.getRootNode && e2.getRootNode();
    if (t2.contains(e2)) return true;
    if (i2 && be(i2)) {
      var n2 = e2;
      do {
        if (n2 && t2.isSameNode(n2)) return true;
        n2 = n2.parentNode || n2.host;
      } while (n2);
    }
    return false;
  }
  function Le(t2) {
    return me(t2).getComputedStyle(t2);
  }
  function Se(t2) {
    return ["table", "td", "th"].indexOf(pe(t2)) >= 0;
  }
  function De(t2) {
    return ((ge(t2) ? t2.ownerDocument : t2.document) || window.document).documentElement;
  }
  function $e(t2) {
    return "html" === pe(t2) ? t2 : t2.assignedSlot || t2.parentNode || (be(t2) ? t2.host : null) || De(t2);
  }
  function Ie(t2) {
    return _e(t2) && "fixed" !== Le(t2).position ? t2.offsetParent : null;
  }
  function Ne(t2) {
    for (var e2 = me(t2), i2 = Ie(t2); i2 && Se(i2) && "static" === Le(i2).position; ) i2 = Ie(i2);
    return i2 && ("html" === pe(i2) || "body" === pe(i2) && "static" === Le(i2).position) ? e2 : i2 || function(t3) {
      var e3 = /firefox/i.test(Te());
      if (/Trident/i.test(Te()) && _e(t3) && "fixed" === Le(t3).position) return null;
      var i3 = $e(t3);
      for (be(i3) && (i3 = i3.host); _e(i3) && ["html", "body"].indexOf(pe(i3)) < 0; ) {
        var n2 = Le(i3);
        if ("none" !== n2.transform || "none" !== n2.perspective || "paint" === n2.contain || -1 !== ["transform", "perspective"].indexOf(n2.willChange) || e3 && "filter" === n2.willChange || e3 && n2.filter && "none" !== n2.filter) return i3;
        i3 = i3.parentNode;
      }
      return null;
    }(t2) || e2;
  }
  function Pe(t2) {
    return ["top", "bottom"].indexOf(t2) >= 0 ? "x" : "y";
  }
  function je(t2, e2, i2) {
    return we(t2, Ae(e2, i2));
  }
  function Me(t2) {
    return Object.assign({}, { top: 0, right: 0, bottom: 0, left: 0 }, t2);
  }
  function Fe(t2, e2) {
    return e2.reduce(function(e3, i2) {
      return e3[i2] = t2, e3;
    }, {});
  }
  const He = { name: "arrow", enabled: true, phase: "main", fn: function(t2) {
    var e2, i2 = t2.state, n2 = t2.name, s2 = t2.options, o2 = i2.elements.arrow, r2 = i2.modifiersData.popperOffsets, a2 = ye(i2.placement), l2 = Pe(a2), c2 = [Qt, Kt].indexOf(a2) >= 0 ? "height" : "width";
    if (o2 && r2) {
      var h2 = function(t3, e3) {
        return Me("number" != typeof (t3 = "function" == typeof t3 ? t3(Object.assign({}, e3.rects, { placement: e3.placement })) : t3) ? t3 : Fe(t3, Yt));
      }(s2.padding, i2), d2 = xe(o2), u2 = "y" === l2 ? qt : Qt, f2 = "y" === l2 ? Vt : Kt, p2 = i2.rects.reference[c2] + i2.rects.reference[l2] - r2[l2] - i2.rects.popper[c2], m2 = r2[l2] - i2.rects.reference[l2], g2 = Ne(o2), _2 = g2 ? "y" === l2 ? g2.clientHeight || 0 : g2.clientWidth || 0 : 0, b2 = p2 / 2 - m2 / 2, v2 = h2[u2], y2 = _2 - d2[c2] - h2[f2], w2 = _2 / 2 - d2[c2] / 2 + b2, A2 = je(v2, w2, y2), E2 = l2;
      i2.modifiersData[n2] = ((e2 = {})[E2] = A2, e2.centerOffset = A2 - w2, e2);
    }
  }, effect: function(t2) {
    var e2 = t2.state, i2 = t2.options.element, n2 = void 0 === i2 ? "[data-popper-arrow]" : i2;
    null != n2 && ("string" != typeof n2 || (n2 = e2.elements.popper.querySelector(n2))) && ke(e2.elements.popper, n2) && (e2.elements.arrow = n2);
  }, requires: ["popperOffsets"], requiresIfExists: ["preventOverflow"] };
  function We(t2) {
    return t2.split("-")[1];
  }
  var Be = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
  function ze(t2) {
    var e2, i2 = t2.popper, n2 = t2.popperRect, s2 = t2.placement, o2 = t2.variation, r2 = t2.offsets, a2 = t2.position, l2 = t2.gpuAcceleration, c2 = t2.adaptive, h2 = t2.roundOffsets, d2 = t2.isFixed, u2 = r2.x, f2 = void 0 === u2 ? 0 : u2, p2 = r2.y, m2 = void 0 === p2 ? 0 : p2, g2 = "function" == typeof h2 ? h2({ x: f2, y: m2 }) : { x: f2, y: m2 };
    f2 = g2.x, m2 = g2.y;
    var _2 = r2.hasOwnProperty("x"), b2 = r2.hasOwnProperty("y"), v2 = Qt, y2 = qt, w2 = window;
    if (c2) {
      var A2 = Ne(i2), E2 = "clientHeight", T2 = "clientWidth";
      A2 === me(i2) && "static" !== Le(A2 = De(i2)).position && "absolute" === a2 && (E2 = "scrollHeight", T2 = "scrollWidth"), (s2 === qt || (s2 === Qt || s2 === Kt) && o2 === Gt) && (y2 = Vt, m2 -= (d2 && A2 === w2 && w2.visualViewport ? w2.visualViewport.height : A2[E2]) - n2.height, m2 *= l2 ? 1 : -1), s2 !== Qt && (s2 !== qt && s2 !== Vt || o2 !== Gt) || (v2 = Kt, f2 -= (d2 && A2 === w2 && w2.visualViewport ? w2.visualViewport.width : A2[T2]) - n2.width, f2 *= l2 ? 1 : -1);
    }
    var C2, O2 = Object.assign({ position: a2 }, c2 && Be), x2 = true === h2 ? function(t3, e3) {
      var i3 = t3.x, n3 = t3.y, s3 = e3.devicePixelRatio || 1;
      return { x: Ee(i3 * s3) / s3 || 0, y: Ee(n3 * s3) / s3 || 0 };
    }({ x: f2, y: m2 }, me(i2)) : { x: f2, y: m2 };
    return f2 = x2.x, m2 = x2.y, l2 ? Object.assign({}, O2, ((C2 = {})[y2] = b2 ? "0" : "", C2[v2] = _2 ? "0" : "", C2.transform = (w2.devicePixelRatio || 1) <= 1 ? "translate(" + f2 + "px, " + m2 + "px)" : "translate3d(" + f2 + "px, " + m2 + "px, 0)", C2)) : Object.assign({}, O2, ((e2 = {})[y2] = b2 ? m2 + "px" : "", e2[v2] = _2 ? f2 + "px" : "", e2.transform = "", e2));
  }
  const Re = { name: "computeStyles", enabled: true, phase: "beforeWrite", fn: function(t2) {
    var e2 = t2.state, i2 = t2.options, n2 = i2.gpuAcceleration, s2 = void 0 === n2 || n2, o2 = i2.adaptive, r2 = void 0 === o2 || o2, a2 = i2.roundOffsets, l2 = void 0 === a2 || a2, c2 = { placement: ye(e2.placement), variation: We(e2.placement), popper: e2.elements.popper, popperRect: e2.rects.popper, gpuAcceleration: s2, isFixed: "fixed" === e2.options.strategy };
    null != e2.modifiersData.popperOffsets && (e2.styles.popper = Object.assign({}, e2.styles.popper, ze(Object.assign({}, c2, { offsets: e2.modifiersData.popperOffsets, position: e2.options.strategy, adaptive: r2, roundOffsets: l2 })))), null != e2.modifiersData.arrow && (e2.styles.arrow = Object.assign({}, e2.styles.arrow, ze(Object.assign({}, c2, { offsets: e2.modifiersData.arrow, position: "absolute", adaptive: false, roundOffsets: l2 })))), e2.attributes.popper = Object.assign({}, e2.attributes.popper, { "data-popper-placement": e2.placement });
  }, data: {} };
  var qe = { passive: true };
  const Ve = { name: "eventListeners", enabled: true, phase: "write", fn: function() {
  }, effect: function(t2) {
    var e2 = t2.state, i2 = t2.instance, n2 = t2.options, s2 = n2.scroll, o2 = void 0 === s2 || s2, r2 = n2.resize, a2 = void 0 === r2 || r2, l2 = me(e2.elements.popper), c2 = [].concat(e2.scrollParents.reference, e2.scrollParents.popper);
    return o2 && c2.forEach(function(t3) {
      t3.addEventListener("scroll", i2.update, qe);
    }), a2 && l2.addEventListener("resize", i2.update, qe), function() {
      o2 && c2.forEach(function(t3) {
        t3.removeEventListener("scroll", i2.update, qe);
      }), a2 && l2.removeEventListener("resize", i2.update, qe);
    };
  }, data: {} };
  var Ke = { left: "right", right: "left", bottom: "top", top: "bottom" };
  function Qe(t2) {
    return t2.replace(/left|right|bottom|top/g, function(t3) {
      return Ke[t3];
    });
  }
  var Xe = { start: "end", end: "start" };
  function Ye(t2) {
    return t2.replace(/start|end/g, function(t3) {
      return Xe[t3];
    });
  }
  function Ue(t2) {
    var e2 = me(t2);
    return { scrollLeft: e2.pageXOffset, scrollTop: e2.pageYOffset };
  }
  function Ge(t2) {
    return Oe(De(t2)).left + Ue(t2).scrollLeft;
  }
  function Je(t2) {
    var e2 = Le(t2), i2 = e2.overflow, n2 = e2.overflowX, s2 = e2.overflowY;
    return /auto|scroll|overlay|hidden/.test(i2 + s2 + n2);
  }
  function Ze(t2) {
    return ["html", "body", "#document"].indexOf(pe(t2)) >= 0 ? t2.ownerDocument.body : _e(t2) && Je(t2) ? t2 : Ze($e(t2));
  }
  function ti(t2, e2) {
    var i2;
    void 0 === e2 && (e2 = []);
    var n2 = Ze(t2), s2 = n2 === (null == (i2 = t2.ownerDocument) ? void 0 : i2.body), o2 = me(n2), r2 = s2 ? [o2].concat(o2.visualViewport || [], Je(n2) ? n2 : []) : n2, a2 = e2.concat(r2);
    return s2 ? a2 : a2.concat(ti($e(r2)));
  }
  function ei(t2) {
    return Object.assign({}, t2, { left: t2.x, top: t2.y, right: t2.x + t2.width, bottom: t2.y + t2.height });
  }
  function ii(t2, e2, i2) {
    return e2 === Zt ? ei(function(t3, e3) {
      var i3 = me(t3), n2 = De(t3), s2 = i3.visualViewport, o2 = n2.clientWidth, r2 = n2.clientHeight, a2 = 0, l2 = 0;
      if (s2) {
        o2 = s2.width, r2 = s2.height;
        var c2 = Ce();
        (c2 || !c2 && "fixed" === e3) && (a2 = s2.offsetLeft, l2 = s2.offsetTop);
      }
      return { width: o2, height: r2, x: a2 + Ge(t3), y: l2 };
    }(t2, i2)) : ge(e2) ? function(t3, e3) {
      var i3 = Oe(t3, false, "fixed" === e3);
      return i3.top = i3.top + t3.clientTop, i3.left = i3.left + t3.clientLeft, i3.bottom = i3.top + t3.clientHeight, i3.right = i3.left + t3.clientWidth, i3.width = t3.clientWidth, i3.height = t3.clientHeight, i3.x = i3.left, i3.y = i3.top, i3;
    }(e2, i2) : ei(function(t3) {
      var e3, i3 = De(t3), n2 = Ue(t3), s2 = null == (e3 = t3.ownerDocument) ? void 0 : e3.body, o2 = we(i3.scrollWidth, i3.clientWidth, s2 ? s2.scrollWidth : 0, s2 ? s2.clientWidth : 0), r2 = we(i3.scrollHeight, i3.clientHeight, s2 ? s2.scrollHeight : 0, s2 ? s2.clientHeight : 0), a2 = -n2.scrollLeft + Ge(t3), l2 = -n2.scrollTop;
      return "rtl" === Le(s2 || i3).direction && (a2 += we(i3.clientWidth, s2 ? s2.clientWidth : 0) - o2), { width: o2, height: r2, x: a2, y: l2 };
    }(De(t2)));
  }
  function ni(t2) {
    var e2, i2 = t2.reference, n2 = t2.element, s2 = t2.placement, o2 = s2 ? ye(s2) : null, r2 = s2 ? We(s2) : null, a2 = i2.x + i2.width / 2 - n2.width / 2, l2 = i2.y + i2.height / 2 - n2.height / 2;
    switch (o2) {
      case qt:
        e2 = { x: a2, y: i2.y - n2.height };
        break;
      case Vt:
        e2 = { x: a2, y: i2.y + i2.height };
        break;
      case Kt:
        e2 = { x: i2.x + i2.width, y: l2 };
        break;
      case Qt:
        e2 = { x: i2.x - n2.width, y: l2 };
        break;
      default:
        e2 = { x: i2.x, y: i2.y };
    }
    var c2 = o2 ? Pe(o2) : null;
    if (null != c2) {
      var h2 = "y" === c2 ? "height" : "width";
      switch (r2) {
        case Ut:
          e2[c2] = e2[c2] - (i2[h2] / 2 - n2[h2] / 2);
          break;
        case Gt:
          e2[c2] = e2[c2] + (i2[h2] / 2 - n2[h2] / 2);
      }
    }
    return e2;
  }
  function si(t2, e2) {
    void 0 === e2 && (e2 = {});
    var i2 = e2, n2 = i2.placement, s2 = void 0 === n2 ? t2.placement : n2, o2 = i2.strategy, r2 = void 0 === o2 ? t2.strategy : o2, a2 = i2.boundary, l2 = void 0 === a2 ? Jt : a2, c2 = i2.rootBoundary, h2 = void 0 === c2 ? Zt : c2, d2 = i2.elementContext, u2 = void 0 === d2 ? te : d2, f2 = i2.altBoundary, p2 = void 0 !== f2 && f2, m2 = i2.padding, g2 = void 0 === m2 ? 0 : m2, _2 = Me("number" != typeof g2 ? g2 : Fe(g2, Yt)), b2 = u2 === te ? ee : te, v2 = t2.rects.popper, y2 = t2.elements[p2 ? b2 : u2], w2 = function(t3, e3, i3, n3) {
      var s3 = "clippingParents" === e3 ? function(t4) {
        var e4 = ti($e(t4)), i4 = ["absolute", "fixed"].indexOf(Le(t4).position) >= 0 && _e(t4) ? Ne(t4) : t4;
        return ge(i4) ? e4.filter(function(t5) {
          return ge(t5) && ke(t5, i4) && "body" !== pe(t5);
        }) : [];
      }(t3) : [].concat(e3), o3 = [].concat(s3, [i3]), r3 = o3[0], a3 = o3.reduce(function(e4, i4) {
        var s4 = ii(t3, i4, n3);
        return e4.top = we(s4.top, e4.top), e4.right = Ae(s4.right, e4.right), e4.bottom = Ae(s4.bottom, e4.bottom), e4.left = we(s4.left, e4.left), e4;
      }, ii(t3, r3, n3));
      return a3.width = a3.right - a3.left, a3.height = a3.bottom - a3.top, a3.x = a3.left, a3.y = a3.top, a3;
    }(ge(y2) ? y2 : y2.contextElement || De(t2.elements.popper), l2, h2, r2), A2 = Oe(t2.elements.reference), E2 = ni({ reference: A2, element: v2, placement: s2 }), T2 = ei(Object.assign({}, v2, E2)), C2 = u2 === te ? T2 : A2, O2 = { top: w2.top - C2.top + _2.top, bottom: C2.bottom - w2.bottom + _2.bottom, left: w2.left - C2.left + _2.left, right: C2.right - w2.right + _2.right }, x2 = t2.modifiersData.offset;
    if (u2 === te && x2) {
      var k2 = x2[s2];
      Object.keys(O2).forEach(function(t3) {
        var e3 = [Kt, Vt].indexOf(t3) >= 0 ? 1 : -1, i3 = [qt, Vt].indexOf(t3) >= 0 ? "y" : "x";
        O2[t3] += k2[i3] * e3;
      });
    }
    return O2;
  }
  function oi(t2, e2) {
    void 0 === e2 && (e2 = {});
    var i2 = e2, n2 = i2.placement, s2 = i2.boundary, o2 = i2.rootBoundary, r2 = i2.padding, a2 = i2.flipVariations, l2 = i2.allowedAutoPlacements, c2 = void 0 === l2 ? ne : l2, h2 = We(n2), d2 = h2 ? a2 ? ie : ie.filter(function(t3) {
      return We(t3) === h2;
    }) : Yt, u2 = d2.filter(function(t3) {
      return c2.indexOf(t3) >= 0;
    });
    0 === u2.length && (u2 = d2);
    var f2 = u2.reduce(function(e3, i3) {
      return e3[i3] = si(t2, { placement: i3, boundary: s2, rootBoundary: o2, padding: r2 })[ye(i3)], e3;
    }, {});
    return Object.keys(f2).sort(function(t3, e3) {
      return f2[t3] - f2[e3];
    });
  }
  const ri = { name: "flip", enabled: true, phase: "main", fn: function(t2) {
    var e2 = t2.state, i2 = t2.options, n2 = t2.name;
    if (!e2.modifiersData[n2]._skip) {
      for (var s2 = i2.mainAxis, o2 = void 0 === s2 || s2, r2 = i2.altAxis, a2 = void 0 === r2 || r2, l2 = i2.fallbackPlacements, c2 = i2.padding, h2 = i2.boundary, d2 = i2.rootBoundary, u2 = i2.altBoundary, f2 = i2.flipVariations, p2 = void 0 === f2 || f2, m2 = i2.allowedAutoPlacements, g2 = e2.options.placement, _2 = ye(g2), b2 = l2 || (_2 !== g2 && p2 ? function(t3) {
        if (ye(t3) === Xt) return [];
        var e3 = Qe(t3);
        return [Ye(t3), e3, Ye(e3)];
      }(g2) : [Qe(g2)]), v2 = [g2].concat(b2).reduce(function(t3, i3) {
        return t3.concat(ye(i3) === Xt ? oi(e2, { placement: i3, boundary: h2, rootBoundary: d2, padding: c2, flipVariations: p2, allowedAutoPlacements: m2 }) : i3);
      }, []), y2 = e2.rects.reference, w2 = e2.rects.popper, A2 = /* @__PURE__ */ new Map(), E2 = true, T2 = v2[0], C2 = 0; C2 < v2.length; C2++) {
        var O2 = v2[C2], x2 = ye(O2), k2 = We(O2) === Ut, L2 = [qt, Vt].indexOf(x2) >= 0, S2 = L2 ? "width" : "height", D2 = si(e2, { placement: O2, boundary: h2, rootBoundary: d2, altBoundary: u2, padding: c2 }), $2 = L2 ? k2 ? Kt : Qt : k2 ? Vt : qt;
        y2[S2] > w2[S2] && ($2 = Qe($2));
        var I2 = Qe($2), N2 = [];
        if (o2 && N2.push(D2[x2] <= 0), a2 && N2.push(D2[$2] <= 0, D2[I2] <= 0), N2.every(function(t3) {
          return t3;
        })) {
          T2 = O2, E2 = false;
          break;
        }
        A2.set(O2, N2);
      }
      if (E2) for (var P2 = function(t3) {
        var e3 = v2.find(function(e4) {
          var i3 = A2.get(e4);
          if (i3) return i3.slice(0, t3).every(function(t4) {
            return t4;
          });
        });
        if (e3) return T2 = e3, "break";
      }, j2 = p2 ? 3 : 1; j2 > 0 && "break" !== P2(j2); j2--) ;
      e2.placement !== T2 && (e2.modifiersData[n2]._skip = true, e2.placement = T2, e2.reset = true);
    }
  }, requiresIfExists: ["offset"], data: { _skip: false } };
  function ai(t2, e2, i2) {
    return void 0 === i2 && (i2 = { x: 0, y: 0 }), { top: t2.top - e2.height - i2.y, right: t2.right - e2.width + i2.x, bottom: t2.bottom - e2.height + i2.y, left: t2.left - e2.width - i2.x };
  }
  function li(t2) {
    return [qt, Kt, Vt, Qt].some(function(e2) {
      return t2[e2] >= 0;
    });
  }
  const ci = { name: "hide", enabled: true, phase: "main", requiresIfExists: ["preventOverflow"], fn: function(t2) {
    var e2 = t2.state, i2 = t2.name, n2 = e2.rects.reference, s2 = e2.rects.popper, o2 = e2.modifiersData.preventOverflow, r2 = si(e2, { elementContext: "reference" }), a2 = si(e2, { altBoundary: true }), l2 = ai(r2, n2), c2 = ai(a2, s2, o2), h2 = li(l2), d2 = li(c2);
    e2.modifiersData[i2] = { referenceClippingOffsets: l2, popperEscapeOffsets: c2, isReferenceHidden: h2, hasPopperEscaped: d2 }, e2.attributes.popper = Object.assign({}, e2.attributes.popper, { "data-popper-reference-hidden": h2, "data-popper-escaped": d2 });
  } }, hi = { name: "offset", enabled: true, phase: "main", requires: ["popperOffsets"], fn: function(t2) {
    var e2 = t2.state, i2 = t2.options, n2 = t2.name, s2 = i2.offset, o2 = void 0 === s2 ? [0, 0] : s2, r2 = ne.reduce(function(t3, i3) {
      return t3[i3] = function(t4, e3, i4) {
        var n3 = ye(t4), s3 = [Qt, qt].indexOf(n3) >= 0 ? -1 : 1, o3 = "function" == typeof i4 ? i4(Object.assign({}, e3, { placement: t4 })) : i4, r3 = o3[0], a3 = o3[1];
        return r3 = r3 || 0, a3 = (a3 || 0) * s3, [Qt, Kt].indexOf(n3) >= 0 ? { x: a3, y: r3 } : { x: r3, y: a3 };
      }(i3, e2.rects, o2), t3;
    }, {}), a2 = r2[e2.placement], l2 = a2.x, c2 = a2.y;
    null != e2.modifiersData.popperOffsets && (e2.modifiersData.popperOffsets.x += l2, e2.modifiersData.popperOffsets.y += c2), e2.modifiersData[n2] = r2;
  } }, di = { name: "popperOffsets", enabled: true, phase: "read", fn: function(t2) {
    var e2 = t2.state, i2 = t2.name;
    e2.modifiersData[i2] = ni({ reference: e2.rects.reference, element: e2.rects.popper, placement: e2.placement });
  }, data: {} }, ui = { name: "preventOverflow", enabled: true, phase: "main", fn: function(t2) {
    var e2 = t2.state, i2 = t2.options, n2 = t2.name, s2 = i2.mainAxis, o2 = void 0 === s2 || s2, r2 = i2.altAxis, a2 = void 0 !== r2 && r2, l2 = i2.boundary, c2 = i2.rootBoundary, h2 = i2.altBoundary, d2 = i2.padding, u2 = i2.tether, f2 = void 0 === u2 || u2, p2 = i2.tetherOffset, m2 = void 0 === p2 ? 0 : p2, g2 = si(e2, { boundary: l2, rootBoundary: c2, padding: d2, altBoundary: h2 }), _2 = ye(e2.placement), b2 = We(e2.placement), v2 = !b2, y2 = Pe(_2), w2 = "x" === y2 ? "y" : "x", A2 = e2.modifiersData.popperOffsets, E2 = e2.rects.reference, T2 = e2.rects.popper, C2 = "function" == typeof m2 ? m2(Object.assign({}, e2.rects, { placement: e2.placement })) : m2, O2 = "number" == typeof C2 ? { mainAxis: C2, altAxis: C2 } : Object.assign({ mainAxis: 0, altAxis: 0 }, C2), x2 = e2.modifiersData.offset ? e2.modifiersData.offset[e2.placement] : null, k2 = { x: 0, y: 0 };
    if (A2) {
      if (o2) {
        var L2, S2 = "y" === y2 ? qt : Qt, D2 = "y" === y2 ? Vt : Kt, $2 = "y" === y2 ? "height" : "width", I2 = A2[y2], N2 = I2 + g2[S2], P2 = I2 - g2[D2], j2 = f2 ? -T2[$2] / 2 : 0, M2 = b2 === Ut ? E2[$2] : T2[$2], F2 = b2 === Ut ? -T2[$2] : -E2[$2], H2 = e2.elements.arrow, W2 = f2 && H2 ? xe(H2) : { width: 0, height: 0 }, B2 = e2.modifiersData["arrow#persistent"] ? e2.modifiersData["arrow#persistent"].padding : { top: 0, right: 0, bottom: 0, left: 0 }, z2 = B2[S2], R2 = B2[D2], q2 = je(0, E2[$2], W2[$2]), V2 = v2 ? E2[$2] / 2 - j2 - q2 - z2 - O2.mainAxis : M2 - q2 - z2 - O2.mainAxis, K2 = v2 ? -E2[$2] / 2 + j2 + q2 + R2 + O2.mainAxis : F2 + q2 + R2 + O2.mainAxis, Q2 = e2.elements.arrow && Ne(e2.elements.arrow), X2 = Q2 ? "y" === y2 ? Q2.clientTop || 0 : Q2.clientLeft || 0 : 0, Y2 = null != (L2 = null == x2 ? void 0 : x2[y2]) ? L2 : 0, U2 = I2 + K2 - Y2, G2 = je(f2 ? Ae(N2, I2 + V2 - Y2 - X2) : N2, I2, f2 ? we(P2, U2) : P2);
        A2[y2] = G2, k2[y2] = G2 - I2;
      }
      if (a2) {
        var J2, Z2 = "x" === y2 ? qt : Qt, tt2 = "x" === y2 ? Vt : Kt, et2 = A2[w2], it2 = "y" === w2 ? "height" : "width", nt2 = et2 + g2[Z2], st2 = et2 - g2[tt2], ot2 = -1 !== [qt, Qt].indexOf(_2), rt2 = null != (J2 = null == x2 ? void 0 : x2[w2]) ? J2 : 0, at2 = ot2 ? nt2 : et2 - E2[it2] - T2[it2] - rt2 + O2.altAxis, lt2 = ot2 ? et2 + E2[it2] + T2[it2] - rt2 - O2.altAxis : st2, ct2 = f2 && ot2 ? function(t3, e3, i3) {
          var n3 = je(t3, e3, i3);
          return n3 > i3 ? i3 : n3;
        }(at2, et2, lt2) : je(f2 ? at2 : nt2, et2, f2 ? lt2 : st2);
        A2[w2] = ct2, k2[w2] = ct2 - et2;
      }
      e2.modifiersData[n2] = k2;
    }
  }, requiresIfExists: ["offset"] };
  function fi(t2, e2, i2) {
    void 0 === i2 && (i2 = false);
    var n2, s2, o2 = _e(e2), r2 = _e(e2) && function(t3) {
      var e3 = t3.getBoundingClientRect(), i3 = Ee(e3.width) / t3.offsetWidth || 1, n3 = Ee(e3.height) / t3.offsetHeight || 1;
      return 1 !== i3 || 1 !== n3;
    }(e2), a2 = De(e2), l2 = Oe(t2, r2, i2), c2 = { scrollLeft: 0, scrollTop: 0 }, h2 = { x: 0, y: 0 };
    return (o2 || !o2 && !i2) && (("body" !== pe(e2) || Je(a2)) && (c2 = (n2 = e2) !== me(n2) && _e(n2) ? { scrollLeft: (s2 = n2).scrollLeft, scrollTop: s2.scrollTop } : Ue(n2)), _e(e2) ? ((h2 = Oe(e2, true)).x += e2.clientLeft, h2.y += e2.clientTop) : a2 && (h2.x = Ge(a2))), { x: l2.left + c2.scrollLeft - h2.x, y: l2.top + c2.scrollTop - h2.y, width: l2.width, height: l2.height };
  }
  function pi(t2) {
    var e2 = /* @__PURE__ */ new Map(), i2 = /* @__PURE__ */ new Set(), n2 = [];
    function s2(t3) {
      i2.add(t3.name), [].concat(t3.requires || [], t3.requiresIfExists || []).forEach(function(t4) {
        if (!i2.has(t4)) {
          var n3 = e2.get(t4);
          n3 && s2(n3);
        }
      }), n2.push(t3);
    }
    return t2.forEach(function(t3) {
      e2.set(t3.name, t3);
    }), t2.forEach(function(t3) {
      i2.has(t3.name) || s2(t3);
    }), n2;
  }
  var mi = { placement: "bottom", modifiers: [], strategy: "absolute" };
  function gi() {
    for (var t2 = arguments.length, e2 = new Array(t2), i2 = 0; i2 < t2; i2++) e2[i2] = arguments[i2];
    return !e2.some(function(t3) {
      return !(t3 && "function" == typeof t3.getBoundingClientRect);
    });
  }
  function _i(t2) {
    void 0 === t2 && (t2 = {});
    var e2 = t2, i2 = e2.defaultModifiers, n2 = void 0 === i2 ? [] : i2, s2 = e2.defaultOptions, o2 = void 0 === s2 ? mi : s2;
    return function(t3, e3, i3) {
      void 0 === i3 && (i3 = o2);
      var s3, r2, a2 = { placement: "bottom", orderedModifiers: [], options: Object.assign({}, mi, o2), modifiersData: {}, elements: { reference: t3, popper: e3 }, attributes: {}, styles: {} }, l2 = [], c2 = false, h2 = { state: a2, setOptions: function(i4) {
        var s4 = "function" == typeof i4 ? i4(a2.options) : i4;
        d2(), a2.options = Object.assign({}, o2, a2.options, s4), a2.scrollParents = { reference: ge(t3) ? ti(t3) : t3.contextElement ? ti(t3.contextElement) : [], popper: ti(e3) };
        var r3, c3, u2 = function(t4) {
          var e4 = pi(t4);
          return fe.reduce(function(t5, i5) {
            return t5.concat(e4.filter(function(t6) {
              return t6.phase === i5;
            }));
          }, []);
        }((r3 = [].concat(n2, a2.options.modifiers), c3 = r3.reduce(function(t4, e4) {
          var i5 = t4[e4.name];
          return t4[e4.name] = i5 ? Object.assign({}, i5, e4, { options: Object.assign({}, i5.options, e4.options), data: Object.assign({}, i5.data, e4.data) }) : e4, t4;
        }, {}), Object.keys(c3).map(function(t4) {
          return c3[t4];
        })));
        return a2.orderedModifiers = u2.filter(function(t4) {
          return t4.enabled;
        }), a2.orderedModifiers.forEach(function(t4) {
          var e4 = t4.name, i5 = t4.options, n3 = void 0 === i5 ? {} : i5, s5 = t4.effect;
          if ("function" == typeof s5) {
            var o3 = s5({ state: a2, name: e4, instance: h2, options: n3 });
            l2.push(o3 || function() {
            });
          }
        }), h2.update();
      }, forceUpdate: function() {
        if (!c2) {
          var t4 = a2.elements, e4 = t4.reference, i4 = t4.popper;
          if (gi(e4, i4)) {
            a2.rects = { reference: fi(e4, Ne(i4), "fixed" === a2.options.strategy), popper: xe(i4) }, a2.reset = false, a2.placement = a2.options.placement, a2.orderedModifiers.forEach(function(t5) {
              return a2.modifiersData[t5.name] = Object.assign({}, t5.data);
            });
            for (var n3 = 0; n3 < a2.orderedModifiers.length; n3++) if (true !== a2.reset) {
              var s4 = a2.orderedModifiers[n3], o3 = s4.fn, r3 = s4.options, l3 = void 0 === r3 ? {} : r3, d3 = s4.name;
              "function" == typeof o3 && (a2 = o3({ state: a2, options: l3, name: d3, instance: h2 }) || a2);
            } else a2.reset = false, n3 = -1;
          }
        }
      }, update: (s3 = function() {
        return new Promise(function(t4) {
          h2.forceUpdate(), t4(a2);
        });
      }, function() {
        return r2 || (r2 = new Promise(function(t4) {
          Promise.resolve().then(function() {
            r2 = void 0, t4(s3());
          });
        })), r2;
      }), destroy: function() {
        d2(), c2 = true;
      } };
      if (!gi(t3, e3)) return h2;
      function d2() {
        l2.forEach(function(t4) {
          return t4();
        }), l2 = [];
      }
      return h2.setOptions(i3).then(function(t4) {
        !c2 && i3.onFirstUpdate && i3.onFirstUpdate(t4);
      }), h2;
    };
  }
  var bi = _i(), vi = _i({ defaultModifiers: [Ve, di, Re, ve] }), yi = _i({ defaultModifiers: [Ve, di, Re, ve, hi, ri, ui, He, ci] });
  const wi = Object.freeze(Object.defineProperty({ __proto__: null, afterMain: ce, afterRead: re, afterWrite: ue, applyStyles: ve, arrow: He, auto: Xt, basePlacements: Yt, beforeMain: ae, beforeRead: se, beforeWrite: he, bottom: Vt, clippingParents: Jt, computeStyles: Re, createPopper: yi, createPopperBase: bi, createPopperLite: vi, detectOverflow: si, end: Gt, eventListeners: Ve, flip: ri, hide: ci, left: Qt, main: le, modifierPhases: fe, offset: hi, placements: ne, popper: te, popperGenerator: _i, popperOffsets: di, preventOverflow: ui, read: oe, reference: ee, right: Kt, start: Ut, top: qt, variationPlacements: ie, viewport: Zt, write: de }, Symbol.toStringTag, { value: "Module" })), Ai = "dropdown", Ei = ".bs.dropdown", Ti = ".data-api", Ci = "ArrowUp", Oi = "ArrowDown", xi = `hide${Ei}`, ki = `hidden${Ei}`, Li = `show${Ei}`, Si = `shown${Ei}`, Di = `click${Ei}${Ti}`, $i = `keydown${Ei}${Ti}`, Ii = `keyup${Ei}${Ti}`, Ni = "show", Pi = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)', ji = `${Pi}.${Ni}`, Mi = ".dropdown-menu", Fi = p() ? "top-end" : "top-start", Hi = p() ? "top-start" : "top-end", Wi = p() ? "bottom-end" : "bottom-start", Bi = p() ? "bottom-start" : "bottom-end", zi = p() ? "left-start" : "right-start", Ri = p() ? "right-start" : "left-start", qi = { autoClose: true, boundary: "clippingParents", display: "dynamic", offset: [0, 2], popperConfig: null, reference: "toggle" }, Vi = { autoClose: "(boolean|string)", boundary: "(string|element)", display: "string", offset: "(array|string|function)", popperConfig: "(null|object|function)", reference: "(string|element|object)" };
  class Ki extends W {
    constructor(t2, e2) {
      super(t2, e2), this._popper = null, this._parent = this._element.parentNode, this._menu = z.next(this._element, Mi)[0] || z.prev(this._element, Mi)[0] || z.findOne(Mi, this._parent), this._inNavbar = this._detectNavbar();
    }
    static get Default() {
      return qi;
    }
    static get DefaultType() {
      return Vi;
    }
    static get NAME() {
      return Ai;
    }
    toggle() {
      return this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (l(this._element) || this._isShown()) return;
      const t2 = { relatedTarget: this._element };
      if (!N.trigger(this._element, Li, t2).defaultPrevented) {
        if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(".navbar-nav")) for (const t3 of [].concat(...document.body.children)) N.on(t3, "mouseover", h);
        this._element.focus(), this._element.setAttribute("aria-expanded", true), this._menu.classList.add(Ni), this._element.classList.add(Ni), N.trigger(this._element, Si, t2);
      }
    }
    hide() {
      if (l(this._element) || !this._isShown()) return;
      const t2 = { relatedTarget: this._element };
      this._completeHide(t2);
    }
    dispose() {
      this._popper && this._popper.destroy(), super.dispose();
    }
    update() {
      this._inNavbar = this._detectNavbar(), this._popper && this._popper.update();
    }
    _completeHide(t2) {
      if (!N.trigger(this._element, xi, t2).defaultPrevented) {
        if ("ontouchstart" in document.documentElement) for (const t3 of [].concat(...document.body.children)) N.off(t3, "mouseover", h);
        this._popper && this._popper.destroy(), this._menu.classList.remove(Ni), this._element.classList.remove(Ni), this._element.setAttribute("aria-expanded", "false"), F.removeDataAttribute(this._menu, "popper"), N.trigger(this._element, ki, t2);
      }
    }
    _getConfig(t2) {
      if ("object" == typeof (t2 = super._getConfig(t2)).reference && !o(t2.reference) && "function" != typeof t2.reference.getBoundingClientRect) throw new TypeError(`${Ai.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
      return t2;
    }
    _createPopper() {
      if (void 0 === wi) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)");
      let t2 = this._element;
      "parent" === this._config.reference ? t2 = this._parent : o(this._config.reference) ? t2 = r(this._config.reference) : "object" == typeof this._config.reference && (t2 = this._config.reference);
      const e2 = this._getPopperConfig();
      this._popper = yi(t2, this._menu, e2);
    }
    _isShown() {
      return this._menu.classList.contains(Ni);
    }
    _getPlacement() {
      const t2 = this._parent;
      if (t2.classList.contains("dropend")) return zi;
      if (t2.classList.contains("dropstart")) return Ri;
      if (t2.classList.contains("dropup-center")) return "top";
      if (t2.classList.contains("dropdown-center")) return "bottom";
      const e2 = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
      return t2.classList.contains("dropup") ? e2 ? Hi : Fi : e2 ? Bi : Wi;
    }
    _detectNavbar() {
      return null !== this._element.closest(".navbar");
    }
    _getOffset() {
      const { offset: t2 } = this._config;
      return "string" == typeof t2 ? t2.split(",").map((t3) => Number.parseInt(t3, 10)) : "function" == typeof t2 ? (e2) => t2(e2, this._element) : t2;
    }
    _getPopperConfig() {
      const t2 = { placement: this._getPlacement(), modifiers: [{ name: "preventOverflow", options: { boundary: this._config.boundary } }, { name: "offset", options: { offset: this._getOffset() } }] };
      return (this._inNavbar || "static" === this._config.display) && (F.setDataAttribute(this._menu, "popper", "static"), t2.modifiers = [{ name: "applyStyles", enabled: false }]), { ...t2, ...g(this._config.popperConfig, [void 0, t2]) };
    }
    _selectMenuItem({ key: t2, target: e2 }) {
      const i2 = z.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter((t3) => a(t3));
      i2.length && b(i2, e2, t2 === Oi, !i2.includes(e2)).focus();
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Ki.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
    static clearMenus(t2) {
      if (2 === t2.button || "keyup" === t2.type && "Tab" !== t2.key) return;
      const e2 = z.find(ji);
      for (const i2 of e2) {
        const e3 = Ki.getInstance(i2);
        if (!e3 || false === e3._config.autoClose) continue;
        const n2 = t2.composedPath(), s2 = n2.includes(e3._menu);
        if (n2.includes(e3._element) || "inside" === e3._config.autoClose && !s2 || "outside" === e3._config.autoClose && s2) continue;
        if (e3._menu.contains(t2.target) && ("keyup" === t2.type && "Tab" === t2.key || /input|select|option|textarea|form/i.test(t2.target.tagName))) continue;
        const o2 = { relatedTarget: e3._element };
        "click" === t2.type && (o2.clickEvent = t2), e3._completeHide(o2);
      }
    }
    static dataApiKeydownHandler(t2) {
      const e2 = /input|textarea/i.test(t2.target.tagName), i2 = "Escape" === t2.key, n2 = [Ci, Oi].includes(t2.key);
      if (!n2 && !i2) return;
      if (e2 && !i2) return;
      t2.preventDefault();
      const s2 = this.matches(Pi) ? this : z.prev(this, Pi)[0] || z.next(this, Pi)[0] || z.findOne(Pi, t2.delegateTarget.parentNode), o2 = Ki.getOrCreateInstance(s2);
      if (n2) return t2.stopPropagation(), o2.show(), void o2._selectMenuItem(t2);
      o2._isShown() && (t2.stopPropagation(), o2.hide(), s2.focus());
    }
  }
  N.on(document, $i, Pi, Ki.dataApiKeydownHandler), N.on(document, $i, Mi, Ki.dataApiKeydownHandler), N.on(document, Di, Ki.clearMenus), N.on(document, Ii, Ki.clearMenus), N.on(document, Di, Pi, function(t2) {
    t2.preventDefault(), Ki.getOrCreateInstance(this).toggle();
  }), m(Ki);
  const Qi = "backdrop", Xi = "show", Yi = `mousedown.bs.${Qi}`, Ui = { className: "modal-backdrop", clickCallback: null, isAnimated: false, isVisible: true, rootElement: "body" }, Gi = { className: "string", clickCallback: "(function|null)", isAnimated: "boolean", isVisible: "boolean", rootElement: "(element|string)" };
  class Ji extends H {
    constructor(t2) {
      super(), this._config = this._getConfig(t2), this._isAppended = false, this._element = null;
    }
    static get Default() {
      return Ui;
    }
    static get DefaultType() {
      return Gi;
    }
    static get NAME() {
      return Qi;
    }
    show(t2) {
      if (!this._config.isVisible) return void g(t2);
      this._append();
      const e2 = this._getElement();
      this._config.isAnimated && d(e2), e2.classList.add(Xi), this._emulateAnimation(() => {
        g(t2);
      });
    }
    hide(t2) {
      this._config.isVisible ? (this._getElement().classList.remove(Xi), this._emulateAnimation(() => {
        this.dispose(), g(t2);
      })) : g(t2);
    }
    dispose() {
      this._isAppended && (N.off(this._element, Yi), this._element.remove(), this._isAppended = false);
    }
    _getElement() {
      if (!this._element) {
        const t2 = document.createElement("div");
        t2.className = this._config.className, this._config.isAnimated && t2.classList.add("fade"), this._element = t2;
      }
      return this._element;
    }
    _configAfterMerge(t2) {
      return t2.rootElement = r(t2.rootElement), t2;
    }
    _append() {
      if (this._isAppended) return;
      const t2 = this._getElement();
      this._config.rootElement.append(t2), N.on(t2, Yi, () => {
        g(this._config.clickCallback);
      }), this._isAppended = true;
    }
    _emulateAnimation(t2) {
      _(t2, this._getElement(), this._config.isAnimated);
    }
  }
  const Zi = ".bs.focustrap", tn = `focusin${Zi}`, en = `keydown.tab${Zi}`, nn = "backward", sn = { autofocus: true, trapElement: null }, on = { autofocus: "boolean", trapElement: "element" };
  class rn extends H {
    constructor(t2) {
      super(), this._config = this._getConfig(t2), this._isActive = false, this._lastTabNavDirection = null;
    }
    static get Default() {
      return sn;
    }
    static get DefaultType() {
      return on;
    }
    static get NAME() {
      return "focustrap";
    }
    activate() {
      this._isActive || (this._config.autofocus && this._config.trapElement.focus(), N.off(document, Zi), N.on(document, tn, (t2) => this._handleFocusin(t2)), N.on(document, en, (t2) => this._handleKeydown(t2)), this._isActive = true);
    }
    deactivate() {
      this._isActive && (this._isActive = false, N.off(document, Zi));
    }
    _handleFocusin(t2) {
      const { trapElement: e2 } = this._config;
      if (t2.target === document || t2.target === e2 || e2.contains(t2.target)) return;
      const i2 = z.focusableChildren(e2);
      0 === i2.length ? e2.focus() : this._lastTabNavDirection === nn ? i2[i2.length - 1].focus() : i2[0].focus();
    }
    _handleKeydown(t2) {
      "Tab" === t2.key && (this._lastTabNavDirection = t2.shiftKey ? nn : "forward");
    }
  }
  const an = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", ln = ".sticky-top", cn = "padding-right", hn = "margin-right";
  class dn {
    constructor() {
      this._element = document.body;
    }
    getWidth() {
      const t2 = document.documentElement.clientWidth;
      return Math.abs(window.innerWidth - t2);
    }
    hide() {
      const t2 = this.getWidth();
      this._disableOverFlow(), this._setElementAttributes(this._element, cn, (e2) => e2 + t2), this._setElementAttributes(an, cn, (e2) => e2 + t2), this._setElementAttributes(ln, hn, (e2) => e2 - t2);
    }
    reset() {
      this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, cn), this._resetElementAttributes(an, cn), this._resetElementAttributes(ln, hn);
    }
    isOverflowing() {
      return this.getWidth() > 0;
    }
    _disableOverFlow() {
      this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden";
    }
    _setElementAttributes(t2, e2, i2) {
      const n2 = this.getWidth();
      this._applyManipulationCallback(t2, (t3) => {
        if (t3 !== this._element && window.innerWidth > t3.clientWidth + n2) return;
        this._saveInitialAttribute(t3, e2);
        const s2 = window.getComputedStyle(t3).getPropertyValue(e2);
        t3.style.setProperty(e2, `${i2(Number.parseFloat(s2))}px`);
      });
    }
    _saveInitialAttribute(t2, e2) {
      const i2 = t2.style.getPropertyValue(e2);
      i2 && F.setDataAttribute(t2, e2, i2);
    }
    _resetElementAttributes(t2, e2) {
      this._applyManipulationCallback(t2, (t3) => {
        const i2 = F.getDataAttribute(t3, e2);
        null !== i2 ? (F.removeDataAttribute(t3, e2), t3.style.setProperty(e2, i2)) : t3.style.removeProperty(e2);
      });
    }
    _applyManipulationCallback(t2, e2) {
      if (o(t2)) e2(t2);
      else for (const i2 of z.find(t2, this._element)) e2(i2);
    }
  }
  const un = ".bs.modal", fn = `hide${un}`, pn = `hidePrevented${un}`, mn = `hidden${un}`, gn = `show${un}`, _n = `shown${un}`, bn = `resize${un}`, vn = `click.dismiss${un}`, yn = `mousedown.dismiss${un}`, wn = `keydown.dismiss${un}`, An = `click${un}.data-api`, En = "modal-open", Tn = "show", Cn = "modal-static", On = { backdrop: true, focus: true, keyboard: true }, xn = { backdrop: "(boolean|string)", focus: "boolean", keyboard: "boolean" };
  class kn extends W {
    constructor(t2, e2) {
      super(t2, e2), this._dialog = z.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = false, this._isTransitioning = false, this._scrollBar = new dn(), this._addEventListeners();
    }
    static get Default() {
      return On;
    }
    static get DefaultType() {
      return xn;
    }
    static get NAME() {
      return "modal";
    }
    toggle(t2) {
      return this._isShown ? this.hide() : this.show(t2);
    }
    show(t2) {
      this._isShown || this._isTransitioning || N.trigger(this._element, gn, { relatedTarget: t2 }).defaultPrevented || (this._isShown = true, this._isTransitioning = true, this._scrollBar.hide(), document.body.classList.add(En), this._adjustDialog(), this._backdrop.show(() => this._showElement(t2)));
    }
    hide() {
      this._isShown && !this._isTransitioning && (N.trigger(this._element, fn).defaultPrevented || (this._isShown = false, this._isTransitioning = true, this._focustrap.deactivate(), this._element.classList.remove(Tn), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated())));
    }
    dispose() {
      N.off(window, un), N.off(this._dialog, un), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    handleUpdate() {
      this._adjustDialog();
    }
    _initializeBackDrop() {
      return new Ji({ isVisible: Boolean(this._config.backdrop), isAnimated: this._isAnimated() });
    }
    _initializeFocusTrap() {
      return new rn({ trapElement: this._element });
    }
    _showElement(t2) {
      document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", true), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
      const e2 = z.findOne(".modal-body", this._dialog);
      e2 && (e2.scrollTop = 0), d(this._element), this._element.classList.add(Tn), this._queueCallback(() => {
        this._config.focus && this._focustrap.activate(), this._isTransitioning = false, N.trigger(this._element, _n, { relatedTarget: t2 });
      }, this._dialog, this._isAnimated());
    }
    _addEventListeners() {
      N.on(this._element, wn, (t2) => {
        "Escape" === t2.key && (this._config.keyboard ? this.hide() : this._triggerBackdropTransition());
      }), N.on(window, bn, () => {
        this._isShown && !this._isTransitioning && this._adjustDialog();
      }), N.on(this._element, yn, (t2) => {
        N.one(this._element, vn, (e2) => {
          this._element === t2.target && this._element === e2.target && ("static" !== this._config.backdrop ? this._config.backdrop && this.hide() : this._triggerBackdropTransition());
        });
      });
    }
    _hideModal() {
      this._element.style.display = "none", this._element.setAttribute("aria-hidden", true), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = false, this._backdrop.hide(() => {
        document.body.classList.remove(En), this._resetAdjustments(), this._scrollBar.reset(), N.trigger(this._element, mn);
      });
    }
    _isAnimated() {
      return this._element.classList.contains("fade");
    }
    _triggerBackdropTransition() {
      if (N.trigger(this._element, pn).defaultPrevented) return;
      const t2 = this._element.scrollHeight > document.documentElement.clientHeight, e2 = this._element.style.overflowY;
      "hidden" === e2 || this._element.classList.contains(Cn) || (t2 || (this._element.style.overflowY = "hidden"), this._element.classList.add(Cn), this._queueCallback(() => {
        this._element.classList.remove(Cn), this._queueCallback(() => {
          this._element.style.overflowY = e2;
        }, this._dialog);
      }, this._dialog), this._element.focus());
    }
    _adjustDialog() {
      const t2 = this._element.scrollHeight > document.documentElement.clientHeight, e2 = this._scrollBar.getWidth(), i2 = e2 > 0;
      if (i2 && !t2) {
        const t3 = p() ? "paddingLeft" : "paddingRight";
        this._element.style[t3] = `${e2}px`;
      }
      if (!i2 && t2) {
        const t3 = p() ? "paddingRight" : "paddingLeft";
        this._element.style[t3] = `${e2}px`;
      }
    }
    _resetAdjustments() {
      this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
    }
    static jQueryInterface(t2, e2) {
      return this.each(function() {
        const i2 = kn.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === i2[t2]) throw new TypeError(`No method named "${t2}"`);
          i2[t2](e2);
        }
      });
    }
  }
  N.on(document, An, '[data-bs-toggle="modal"]', function(t2) {
    const e2 = z.getElementFromSelector(this);
    ["A", "AREA"].includes(this.tagName) && t2.preventDefault(), N.one(e2, gn, (t3) => {
      t3.defaultPrevented || N.one(e2, mn, () => {
        a(this) && this.focus();
      });
    });
    const i2 = z.findOne(".modal.show");
    i2 && kn.getInstance(i2).hide(), kn.getOrCreateInstance(e2).toggle(this);
  }), R(kn), m(kn);
  const Ln = ".bs.offcanvas", Sn = ".data-api", Dn = `load${Ln}${Sn}`, $n = "show", In = "showing", Nn = "hiding", Pn = ".offcanvas.show", jn = `show${Ln}`, Mn = `shown${Ln}`, Fn = `hide${Ln}`, Hn = `hidePrevented${Ln}`, Wn = `hidden${Ln}`, Bn = `resize${Ln}`, zn = `click${Ln}${Sn}`, Rn = `keydown.dismiss${Ln}`, qn = { backdrop: true, keyboard: true, scroll: false }, Vn = { backdrop: "(boolean|string)", keyboard: "boolean", scroll: "boolean" };
  class Kn extends W {
    constructor(t2, e2) {
      super(t2, e2), this._isShown = false, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners();
    }
    static get Default() {
      return qn;
    }
    static get DefaultType() {
      return Vn;
    }
    static get NAME() {
      return "offcanvas";
    }
    toggle(t2) {
      return this._isShown ? this.hide() : this.show(t2);
    }
    show(t2) {
      this._isShown || N.trigger(this._element, jn, { relatedTarget: t2 }).defaultPrevented || (this._isShown = true, this._backdrop.show(), this._config.scroll || new dn().hide(), this._element.setAttribute("aria-modal", true), this._element.setAttribute("role", "dialog"), this._element.classList.add(In), this._queueCallback(() => {
        this._config.scroll && !this._config.backdrop || this._focustrap.activate(), this._element.classList.add($n), this._element.classList.remove(In), N.trigger(this._element, Mn, { relatedTarget: t2 });
      }, this._element, true));
    }
    hide() {
      this._isShown && (N.trigger(this._element, Fn).defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = false, this._element.classList.add(Nn), this._backdrop.hide(), this._queueCallback(() => {
        this._element.classList.remove($n, Nn), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || new dn().reset(), N.trigger(this._element, Wn);
      }, this._element, true)));
    }
    dispose() {
      this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    _initializeBackDrop() {
      const t2 = Boolean(this._config.backdrop);
      return new Ji({ className: "offcanvas-backdrop", isVisible: t2, isAnimated: true, rootElement: this._element.parentNode, clickCallback: t2 ? () => {
        "static" !== this._config.backdrop ? this.hide() : N.trigger(this._element, Hn);
      } : null });
    }
    _initializeFocusTrap() {
      return new rn({ trapElement: this._element });
    }
    _addEventListeners() {
      N.on(this._element, Rn, (t2) => {
        "Escape" === t2.key && (this._config.keyboard ? this.hide() : N.trigger(this._element, Hn));
      });
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Kn.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  N.on(document, zn, '[data-bs-toggle="offcanvas"]', function(t2) {
    const e2 = z.getElementFromSelector(this);
    if (["A", "AREA"].includes(this.tagName) && t2.preventDefault(), l(this)) return;
    N.one(e2, Wn, () => {
      a(this) && this.focus();
    });
    const i2 = z.findOne(Pn);
    i2 && i2 !== e2 && Kn.getInstance(i2).hide(), Kn.getOrCreateInstance(e2).toggle(this);
  }), N.on(window, Dn, () => {
    for (const t2 of z.find(Pn)) Kn.getOrCreateInstance(t2).show();
  }), N.on(window, Bn, () => {
    for (const t2 of z.find("[aria-modal][class*=show][class*=offcanvas-]")) "fixed" !== getComputedStyle(t2).position && Kn.getOrCreateInstance(t2).hide();
  }), R(Kn), m(Kn);
  const Qn = { "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i], a: ["target", "href", "title", "rel"], area: [], b: [], br: [], col: [], code: [], dd: [], div: [], dl: [], dt: [], em: [], hr: [], h1: [], h2: [], h3: [], h4: [], h5: [], h6: [], i: [], img: ["src", "srcset", "alt", "title", "width", "height"], li: [], ol: [], p: [], pre: [], s: [], small: [], span: [], sub: [], sup: [], strong: [], u: [], ul: [] }, Xn = /* @__PURE__ */ new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]), Yn = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i, Un = (t2, e2) => {
    const i2 = t2.nodeName.toLowerCase();
    return e2.includes(i2) ? !Xn.has(i2) || Boolean(Yn.test(t2.nodeValue)) : e2.filter((t3) => t3 instanceof RegExp).some((t3) => t3.test(i2));
  }, Gn = { allowList: Qn, content: {}, extraClass: "", html: false, sanitize: true, sanitizeFn: null, template: "<div></div>" }, Jn = { allowList: "object", content: "object", extraClass: "(string|function)", html: "boolean", sanitize: "boolean", sanitizeFn: "(null|function)", template: "string" }, Zn = { entry: "(string|element|function|null)", selector: "(string|element)" };
  class ts extends H {
    constructor(t2) {
      super(), this._config = this._getConfig(t2);
    }
    static get Default() {
      return Gn;
    }
    static get DefaultType() {
      return Jn;
    }
    static get NAME() {
      return "TemplateFactory";
    }
    getContent() {
      return Object.values(this._config.content).map((t2) => this._resolvePossibleFunction(t2)).filter(Boolean);
    }
    hasContent() {
      return this.getContent().length > 0;
    }
    changeContent(t2) {
      return this._checkContent(t2), this._config.content = { ...this._config.content, ...t2 }, this;
    }
    toHtml() {
      const t2 = document.createElement("div");
      t2.innerHTML = this._maybeSanitize(this._config.template);
      for (const [e3, i3] of Object.entries(this._config.content)) this._setContent(t2, i3, e3);
      const e2 = t2.children[0], i2 = this._resolvePossibleFunction(this._config.extraClass);
      return i2 && e2.classList.add(...i2.split(" ")), e2;
    }
    _typeCheckConfig(t2) {
      super._typeCheckConfig(t2), this._checkContent(t2.content);
    }
    _checkContent(t2) {
      for (const [e2, i2] of Object.entries(t2)) super._typeCheckConfig({ selector: e2, entry: i2 }, Zn);
    }
    _setContent(t2, e2, i2) {
      const n2 = z.findOne(i2, t2);
      n2 && ((e2 = this._resolvePossibleFunction(e2)) ? o(e2) ? this._putElementInTemplate(r(e2), n2) : this._config.html ? n2.innerHTML = this._maybeSanitize(e2) : n2.textContent = e2 : n2.remove());
    }
    _maybeSanitize(t2) {
      return this._config.sanitize ? function(t3, e2, i2) {
        if (!t3.length) return t3;
        if (i2 && "function" == typeof i2) return i2(t3);
        const n2 = new window.DOMParser().parseFromString(t3, "text/html"), s2 = [].concat(...n2.body.querySelectorAll("*"));
        for (const t4 of s2) {
          const i3 = t4.nodeName.toLowerCase();
          if (!Object.keys(e2).includes(i3)) {
            t4.remove();
            continue;
          }
          const n3 = [].concat(...t4.attributes), s3 = [].concat(e2["*"] || [], e2[i3] || []);
          for (const e3 of n3) Un(e3, s3) || t4.removeAttribute(e3.nodeName);
        }
        return n2.body.innerHTML;
      }(t2, this._config.allowList, this._config.sanitizeFn) : t2;
    }
    _resolvePossibleFunction(t2) {
      return g(t2, [void 0, this]);
    }
    _putElementInTemplate(t2, e2) {
      if (this._config.html) return e2.innerHTML = "", void e2.append(t2);
      e2.textContent = t2.textContent;
    }
  }
  const es = /* @__PURE__ */ new Set(["sanitize", "allowList", "sanitizeFn"]), is = "fade", ns = "show", ss = ".tooltip-inner", os = ".modal", rs = "hide.bs.modal", as = "hover", ls = "focus", cs = { AUTO: "auto", TOP: "top", RIGHT: p() ? "left" : "right", BOTTOM: "bottom", LEFT: p() ? "right" : "left" }, hs = { allowList: Qn, animation: true, boundary: "clippingParents", container: false, customClass: "", delay: 0, fallbackPlacements: ["top", "right", "bottom", "left"], html: false, offset: [0, 6], placement: "top", popperConfig: null, sanitize: true, sanitizeFn: null, selector: false, template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>', title: "", trigger: "hover focus" }, ds = { allowList: "object", animation: "boolean", boundary: "(string|element)", container: "(string|element|boolean)", customClass: "(string|function)", delay: "(number|object)", fallbackPlacements: "array", html: "boolean", offset: "(array|string|function)", placement: "(string|function)", popperConfig: "(null|object|function)", sanitize: "boolean", sanitizeFn: "(null|function)", selector: "(string|boolean)", template: "string", title: "(string|element|function)", trigger: "string" };
  class us extends W {
    constructor(t2, e2) {
      if (void 0 === wi) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)");
      super(t2, e2), this._isEnabled = true, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle();
    }
    static get Default() {
      return hs;
    }
    static get DefaultType() {
      return ds;
    }
    static get NAME() {
      return "tooltip";
    }
    enable() {
      this._isEnabled = true;
    }
    disable() {
      this._isEnabled = false;
    }
    toggleEnabled() {
      this._isEnabled = !this._isEnabled;
    }
    toggle() {
      this._isEnabled && (this._isShown() ? this._leave() : this._enter());
    }
    dispose() {
      clearTimeout(this._timeout), N.off(this._element.closest(os), rs, this._hideModalHandler), this._element.getAttribute("data-bs-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-bs-original-title")), this._disposePopper(), super.dispose();
    }
    show() {
      if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
      if (!this._isWithContent() || !this._isEnabled) return;
      const t2 = N.trigger(this._element, this.constructor.eventName("show")), e2 = (c(this._element) || this._element.ownerDocument.documentElement).contains(this._element);
      if (t2.defaultPrevented || !e2) return;
      this._disposePopper();
      const i2 = this._getTipElement();
      this._element.setAttribute("aria-describedby", i2.getAttribute("id"));
      const { container: n2 } = this._config;
      if (this._element.ownerDocument.documentElement.contains(this.tip) || (n2.append(i2), N.trigger(this._element, this.constructor.eventName("inserted"))), this._popper = this._createPopper(i2), i2.classList.add(ns), "ontouchstart" in document.documentElement) for (const t3 of [].concat(...document.body.children)) N.on(t3, "mouseover", h);
      this._queueCallback(() => {
        N.trigger(this._element, this.constructor.eventName("shown")), false === this._isHovered && this._leave(), this._isHovered = false;
      }, this.tip, this._isAnimated());
    }
    hide() {
      if (this._isShown() && !N.trigger(this._element, this.constructor.eventName("hide")).defaultPrevented) {
        if (this._getTipElement().classList.remove(ns), "ontouchstart" in document.documentElement) for (const t2 of [].concat(...document.body.children)) N.off(t2, "mouseover", h);
        this._activeTrigger.click = false, this._activeTrigger[ls] = false, this._activeTrigger[as] = false, this._isHovered = null, this._queueCallback(() => {
          this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), N.trigger(this._element, this.constructor.eventName("hidden")));
        }, this.tip, this._isAnimated());
      }
    }
    update() {
      this._popper && this._popper.update();
    }
    _isWithContent() {
      return Boolean(this._getTitle());
    }
    _getTipElement() {
      return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip;
    }
    _createTipElement(t2) {
      const e2 = this._getTemplateFactory(t2).toHtml();
      if (!e2) return null;
      e2.classList.remove(is, ns), e2.classList.add(`bs-${this.constructor.NAME}-auto`);
      const i2 = ((t3) => {
        do {
          t3 += Math.floor(1e6 * Math.random());
        } while (document.getElementById(t3));
        return t3;
      })(this.constructor.NAME).toString();
      return e2.setAttribute("id", i2), this._isAnimated() && e2.classList.add(is), e2;
    }
    setContent(t2) {
      this._newContent = t2, this._isShown() && (this._disposePopper(), this.show());
    }
    _getTemplateFactory(t2) {
      return this._templateFactory ? this._templateFactory.changeContent(t2) : this._templateFactory = new ts({ ...this._config, content: t2, extraClass: this._resolvePossibleFunction(this._config.customClass) }), this._templateFactory;
    }
    _getContentForTemplate() {
      return { [ss]: this._getTitle() };
    }
    _getTitle() {
      return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-bs-original-title");
    }
    _initializeOnDelegatedTarget(t2) {
      return this.constructor.getOrCreateInstance(t2.delegateTarget, this._getDelegateConfig());
    }
    _isAnimated() {
      return this._config.animation || this.tip && this.tip.classList.contains(is);
    }
    _isShown() {
      return this.tip && this.tip.classList.contains(ns);
    }
    _createPopper(t2) {
      const e2 = g(this._config.placement, [this, t2, this._element]), i2 = cs[e2.toUpperCase()];
      return yi(this._element, t2, this._getPopperConfig(i2));
    }
    _getOffset() {
      const { offset: t2 } = this._config;
      return "string" == typeof t2 ? t2.split(",").map((t3) => Number.parseInt(t3, 10)) : "function" == typeof t2 ? (e2) => t2(e2, this._element) : t2;
    }
    _resolvePossibleFunction(t2) {
      return g(t2, [this._element, this._element]);
    }
    _getPopperConfig(t2) {
      const e2 = { placement: t2, modifiers: [{ name: "flip", options: { fallbackPlacements: this._config.fallbackPlacements } }, { name: "offset", options: { offset: this._getOffset() } }, { name: "preventOverflow", options: { boundary: this._config.boundary } }, { name: "arrow", options: { element: `.${this.constructor.NAME}-arrow` } }, { name: "preSetPlacement", enabled: true, phase: "beforeMain", fn: (t3) => {
        this._getTipElement().setAttribute("data-popper-placement", t3.state.placement);
      } }] };
      return { ...e2, ...g(this._config.popperConfig, [void 0, e2]) };
    }
    _setListeners() {
      const t2 = this._config.trigger.split(" ");
      for (const e2 of t2) if ("click" === e2) N.on(this._element, this.constructor.eventName("click"), this._config.selector, (t3) => {
        this._initializeOnDelegatedTarget(t3).toggle();
      });
      else if ("manual" !== e2) {
        const t3 = e2 === as ? this.constructor.eventName("mouseenter") : this.constructor.eventName("focusin"), i2 = e2 === as ? this.constructor.eventName("mouseleave") : this.constructor.eventName("focusout");
        N.on(this._element, t3, this._config.selector, (t4) => {
          const e3 = this._initializeOnDelegatedTarget(t4);
          e3._activeTrigger["focusin" === t4.type ? ls : as] = true, e3._enter();
        }), N.on(this._element, i2, this._config.selector, (t4) => {
          const e3 = this._initializeOnDelegatedTarget(t4);
          e3._activeTrigger["focusout" === t4.type ? ls : as] = e3._element.contains(t4.relatedTarget), e3._leave();
        });
      }
      this._hideModalHandler = () => {
        this._element && this.hide();
      }, N.on(this._element.closest(os), rs, this._hideModalHandler);
    }
    _fixTitle() {
      const t2 = this._element.getAttribute("title");
      t2 && (this._element.getAttribute("aria-label") || this._element.textContent.trim() || this._element.setAttribute("aria-label", t2), this._element.setAttribute("data-bs-original-title", t2), this._element.removeAttribute("title"));
    }
    _enter() {
      this._isShown() || this._isHovered ? this._isHovered = true : (this._isHovered = true, this._setTimeout(() => {
        this._isHovered && this.show();
      }, this._config.delay.show));
    }
    _leave() {
      this._isWithActiveTrigger() || (this._isHovered = false, this._setTimeout(() => {
        this._isHovered || this.hide();
      }, this._config.delay.hide));
    }
    _setTimeout(t2, e2) {
      clearTimeout(this._timeout), this._timeout = setTimeout(t2, e2);
    }
    _isWithActiveTrigger() {
      return Object.values(this._activeTrigger).includes(true);
    }
    _getConfig(t2) {
      const e2 = F.getDataAttributes(this._element);
      for (const t3 of Object.keys(e2)) es.has(t3) && delete e2[t3];
      return t2 = { ...e2, ..."object" == typeof t2 && t2 ? t2 : {} }, t2 = this._mergeConfigObj(t2), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    _configAfterMerge(t2) {
      return t2.container = false === t2.container ? document.body : r(t2.container), "number" == typeof t2.delay && (t2.delay = { show: t2.delay, hide: t2.delay }), "number" == typeof t2.title && (t2.title = t2.title.toString()), "number" == typeof t2.content && (t2.content = t2.content.toString()), t2;
    }
    _getDelegateConfig() {
      const t2 = {};
      for (const [e2, i2] of Object.entries(this._config)) this.constructor.Default[e2] !== i2 && (t2[e2] = i2);
      return t2.selector = false, t2.trigger = "manual", t2;
    }
    _disposePopper() {
      this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = us.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  m(us);
  const fs = ".popover-header", ps = ".popover-body", ms = { ...us.Default, content: "", offset: [0, 8], placement: "right", template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>', trigger: "click" }, gs = { ...us.DefaultType, content: "(null|string|element|function)" };
  class _s extends us {
    static get Default() {
      return ms;
    }
    static get DefaultType() {
      return gs;
    }
    static get NAME() {
      return "popover";
    }
    _isWithContent() {
      return this._getTitle() || this._getContent();
    }
    _getContentForTemplate() {
      return { [fs]: this._getTitle(), [ps]: this._getContent() };
    }
    _getContent() {
      return this._resolvePossibleFunction(this._config.content);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = _s.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  m(_s);
  const bs = ".bs.scrollspy", vs = `activate${bs}`, ys = `click${bs}`, ws = `load${bs}.data-api`, As = "active", Es = "[href]", Ts = ".nav-link", Cs = `${Ts}, .nav-item > ${Ts}, .list-group-item`, Os = { offset: null, rootMargin: "0px 0px -25%", smoothScroll: false, target: null, threshold: [0.1, 0.5, 1] }, xs = { offset: "(number|null)", rootMargin: "string", smoothScroll: "boolean", target: "element", threshold: "array" };
  class ks extends W {
    constructor(t2, e2) {
      super(t2, e2), this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map(), this._rootElement = "visible" === getComputedStyle(this._element).overflowY ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = { visibleEntryTop: 0, parentScrollTop: 0 }, this.refresh();
    }
    static get Default() {
      return Os;
    }
    static get DefaultType() {
      return xs;
    }
    static get NAME() {
      return "scrollspy";
    }
    refresh() {
      this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
      for (const t2 of this._observableSections.values()) this._observer.observe(t2);
    }
    dispose() {
      this._observer.disconnect(), super.dispose();
    }
    _configAfterMerge(t2) {
      return t2.target = r(t2.target) || document.body, t2.rootMargin = t2.offset ? `${t2.offset}px 0px -30%` : t2.rootMargin, "string" == typeof t2.threshold && (t2.threshold = t2.threshold.split(",").map((t3) => Number.parseFloat(t3))), t2;
    }
    _maybeEnableSmoothScroll() {
      this._config.smoothScroll && (N.off(this._config.target, ys), N.on(this._config.target, ys, Es, (t2) => {
        const e2 = this._observableSections.get(t2.target.hash);
        if (e2) {
          t2.preventDefault();
          const i2 = this._rootElement || window, n2 = e2.offsetTop - this._element.offsetTop;
          if (i2.scrollTo) return void i2.scrollTo({ top: n2, behavior: "smooth" });
          i2.scrollTop = n2;
        }
      }));
    }
    _getNewObserver() {
      const t2 = { root: this._rootElement, threshold: this._config.threshold, rootMargin: this._config.rootMargin };
      return new IntersectionObserver((t3) => this._observerCallback(t3), t2);
    }
    _observerCallback(t2) {
      const e2 = (t3) => this._targetLinks.get(`#${t3.target.id}`), i2 = (t3) => {
        this._previousScrollData.visibleEntryTop = t3.target.offsetTop, this._process(e2(t3));
      }, n2 = (this._rootElement || document.documentElement).scrollTop, s2 = n2 >= this._previousScrollData.parentScrollTop;
      this._previousScrollData.parentScrollTop = n2;
      for (const o2 of t2) {
        if (!o2.isIntersecting) {
          this._activeTarget = null, this._clearActiveClass(e2(o2));
          continue;
        }
        const t3 = o2.target.offsetTop >= this._previousScrollData.visibleEntryTop;
        if (s2 && t3) {
          if (i2(o2), !n2) return;
        } else s2 || t3 || i2(o2);
      }
    }
    _initializeTargetsAndObservables() {
      this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map();
      const t2 = z.find(Es, this._config.target);
      for (const e2 of t2) {
        if (!e2.hash || l(e2)) continue;
        const t3 = z.findOne(decodeURI(e2.hash), this._element);
        a(t3) && (this._targetLinks.set(decodeURI(e2.hash), e2), this._observableSections.set(e2.hash, t3));
      }
    }
    _process(t2) {
      this._activeTarget !== t2 && (this._clearActiveClass(this._config.target), this._activeTarget = t2, t2.classList.add(As), this._activateParents(t2), N.trigger(this._element, vs, { relatedTarget: t2 }));
    }
    _activateParents(t2) {
      if (t2.classList.contains("dropdown-item")) z.findOne(".dropdown-toggle", t2.closest(".dropdown")).classList.add(As);
      else for (const e2 of z.parents(t2, ".nav, .list-group")) for (const t3 of z.prev(e2, Cs)) t3.classList.add(As);
    }
    _clearActiveClass(t2) {
      t2.classList.remove(As);
      const e2 = z.find(`${Es}.${As}`, t2);
      for (const t3 of e2) t3.classList.remove(As);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = ks.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  N.on(window, ws, () => {
    for (const t2 of z.find('[data-bs-spy="scroll"]')) ks.getOrCreateInstance(t2);
  }), m(ks);
  const Ls = ".bs.tab", Ss = `hide${Ls}`, Ds = `hidden${Ls}`, $s = `show${Ls}`, Is = `shown${Ls}`, Ns = `click${Ls}`, Ps = `keydown${Ls}`, js = `load${Ls}`, Ms = "ArrowLeft", Fs = "ArrowRight", Hs = "ArrowUp", Ws = "ArrowDown", Bs = "Home", zs = "End", Rs = "active", qs = "fade", Vs = "show", Ks = ".dropdown-toggle", Qs = `:not(${Ks})`, Xs = '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', Ys = `.nav-link${Qs}, .list-group-item${Qs}, [role="tab"]${Qs}, ${Xs}`, Us = `.${Rs}[data-bs-toggle="tab"], .${Rs}[data-bs-toggle="pill"], .${Rs}[data-bs-toggle="list"]`;
  class Gs extends W {
    constructor(t2) {
      super(t2), this._parent = this._element.closest('.list-group, .nav, [role="tablist"]'), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), N.on(this._element, Ps, (t3) => this._keydown(t3)));
    }
    static get NAME() {
      return "tab";
    }
    show() {
      const t2 = this._element;
      if (this._elemIsActive(t2)) return;
      const e2 = this._getActiveElem(), i2 = e2 ? N.trigger(e2, Ss, { relatedTarget: t2 }) : null;
      N.trigger(t2, $s, { relatedTarget: e2 }).defaultPrevented || i2 && i2.defaultPrevented || (this._deactivate(e2, t2), this._activate(t2, e2));
    }
    _activate(t2, e2) {
      t2 && (t2.classList.add(Rs), this._activate(z.getElementFromSelector(t2)), this._queueCallback(() => {
        "tab" === t2.getAttribute("role") ? (t2.removeAttribute("tabindex"), t2.setAttribute("aria-selected", true), this._toggleDropDown(t2, true), N.trigger(t2, Is, { relatedTarget: e2 })) : t2.classList.add(Vs);
      }, t2, t2.classList.contains(qs)));
    }
    _deactivate(t2, e2) {
      t2 && (t2.classList.remove(Rs), t2.blur(), this._deactivate(z.getElementFromSelector(t2)), this._queueCallback(() => {
        "tab" === t2.getAttribute("role") ? (t2.setAttribute("aria-selected", false), t2.setAttribute("tabindex", "-1"), this._toggleDropDown(t2, false), N.trigger(t2, Ds, { relatedTarget: e2 })) : t2.classList.remove(Vs);
      }, t2, t2.classList.contains(qs)));
    }
    _keydown(t2) {
      if (![Ms, Fs, Hs, Ws, Bs, zs].includes(t2.key)) return;
      t2.stopPropagation(), t2.preventDefault();
      const e2 = this._getChildren().filter((t3) => !l(t3));
      let i2;
      if ([Bs, zs].includes(t2.key)) i2 = e2[t2.key === Bs ? 0 : e2.length - 1];
      else {
        const n2 = [Fs, Ws].includes(t2.key);
        i2 = b(e2, t2.target, n2, true);
      }
      i2 && (i2.focus({ preventScroll: true }), Gs.getOrCreateInstance(i2).show());
    }
    _getChildren() {
      return z.find(Ys, this._parent);
    }
    _getActiveElem() {
      return this._getChildren().find((t2) => this._elemIsActive(t2)) || null;
    }
    _setInitialAttributes(t2, e2) {
      this._setAttributeIfNotExists(t2, "role", "tablist");
      for (const t3 of e2) this._setInitialAttributesOnChild(t3);
    }
    _setInitialAttributesOnChild(t2) {
      t2 = this._getInnerElement(t2);
      const e2 = this._elemIsActive(t2), i2 = this._getOuterElement(t2);
      t2.setAttribute("aria-selected", e2), i2 !== t2 && this._setAttributeIfNotExists(i2, "role", "presentation"), e2 || t2.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t2, "role", "tab"), this._setInitialAttributesOnTargetPanel(t2);
    }
    _setInitialAttributesOnTargetPanel(t2) {
      const e2 = z.getElementFromSelector(t2);
      e2 && (this._setAttributeIfNotExists(e2, "role", "tabpanel"), t2.id && this._setAttributeIfNotExists(e2, "aria-labelledby", `${t2.id}`));
    }
    _toggleDropDown(t2, e2) {
      const i2 = this._getOuterElement(t2);
      if (!i2.classList.contains("dropdown")) return;
      const n2 = (t3, n3) => {
        const s2 = z.findOne(t3, i2);
        s2 && s2.classList.toggle(n3, e2);
      };
      n2(Ks, Rs), n2(".dropdown-menu", Vs), i2.setAttribute("aria-expanded", e2);
    }
    _setAttributeIfNotExists(t2, e2, i2) {
      t2.hasAttribute(e2) || t2.setAttribute(e2, i2);
    }
    _elemIsActive(t2) {
      return t2.classList.contains(Rs);
    }
    _getInnerElement(t2) {
      return t2.matches(Ys) ? t2 : z.findOne(Ys, t2);
    }
    _getOuterElement(t2) {
      return t2.closest(".nav-item, .list-group-item") || t2;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Gs.getOrCreateInstance(this);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  N.on(document, Ns, Xs, function(t2) {
    ["A", "AREA"].includes(this.tagName) && t2.preventDefault(), l(this) || Gs.getOrCreateInstance(this).show();
  }), N.on(window, js, () => {
    for (const t2 of z.find(Us)) Gs.getOrCreateInstance(t2);
  }), m(Gs);
  const Js = ".bs.toast", Zs = `mouseover${Js}`, to = `mouseout${Js}`, eo = `focusin${Js}`, io = `focusout${Js}`, no = `hide${Js}`, so = `hidden${Js}`, oo = `show${Js}`, ro = `shown${Js}`, ao = "hide", lo = "show", co = "showing", ho = { animation: "boolean", autohide: "boolean", delay: "number" }, uo = { animation: true, autohide: true, delay: 5e3 };
  class fo extends W {
    constructor(t2, e2) {
      super(t2, e2), this._timeout = null, this._hasMouseInteraction = false, this._hasKeyboardInteraction = false, this._setListeners();
    }
    static get Default() {
      return uo;
    }
    static get DefaultType() {
      return ho;
    }
    static get NAME() {
      return "toast";
    }
    show() {
      N.trigger(this._element, oo).defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(ao), d(this._element), this._element.classList.add(lo, co), this._queueCallback(() => {
        this._element.classList.remove(co), N.trigger(this._element, ro), this._maybeScheduleHide();
      }, this._element, this._config.animation));
    }
    hide() {
      this.isShown() && (N.trigger(this._element, no).defaultPrevented || (this._element.classList.add(co), this._queueCallback(() => {
        this._element.classList.add(ao), this._element.classList.remove(co, lo), N.trigger(this._element, so);
      }, this._element, this._config.animation)));
    }
    dispose() {
      this._clearTimeout(), this.isShown() && this._element.classList.remove(lo), super.dispose();
    }
    isShown() {
      return this._element.classList.contains(lo);
    }
    _maybeScheduleHide() {
      this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
        this.hide();
      }, this._config.delay)));
    }
    _onInteraction(t2, e2) {
      switch (t2.type) {
        case "mouseover":
        case "mouseout":
          this._hasMouseInteraction = e2;
          break;
        case "focusin":
        case "focusout":
          this._hasKeyboardInteraction = e2;
      }
      if (e2) return void this._clearTimeout();
      const i2 = t2.relatedTarget;
      this._element === i2 || this._element.contains(i2) || this._maybeScheduleHide();
    }
    _setListeners() {
      N.on(this._element, Zs, (t2) => this._onInteraction(t2, true)), N.on(this._element, to, (t2) => this._onInteraction(t2, false)), N.on(this._element, eo, (t2) => this._onInteraction(t2, true)), N.on(this._element, io, (t2) => this._onInteraction(t2, false));
    }
    _clearTimeout() {
      clearTimeout(this._timeout), this._timeout = null;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = fo.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  return R(fo), m(fo), { Alert: Q, Button: Y, Carousel: Lt, Collapse: Rt, Dropdown: Ki, Modal: kn, Offcanvas: Kn, Popover: _s, ScrollSpy: ks, Tab: Gs, Toast: fo, Tooltip: us };
});


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmlwdHMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gICogQm9vdHN0cmFwIHY1LjMuNSAoaHR0cHM6Ly9nZXRib290c3RyYXAuY29tLylcbiAgKiBDb3B5cmlnaHQgMjAxMS0yMDI1IFRoZSBCb290c3RyYXAgQXV0aG9ycyAoaHR0cHM6Ly9naXRodWIuY29tL3R3YnMvYm9vdHN0cmFwL2dyYXBocy9jb250cmlidXRvcnMpXG4gICogTGljZW5zZWQgdW5kZXIgTUlUIChodHRwczovL2dpdGh1Yi5jb20vdHdicy9ib290c3RyYXAvYmxvYi9tYWluL0xJQ0VOU0UpXG4gICovXG4hZnVuY3Rpb24odCxlKXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz1lKCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShlKToodD1cInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsVGhpcz9nbG9iYWxUaGlzOnR8fHNlbGYpLmJvb3RzdHJhcD1lKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7Y29uc3QgdD1uZXcgTWFwLGU9e3NldChlLGksbil7dC5oYXMoZSl8fHQuc2V0KGUsbmV3IE1hcCk7Y29uc3Qgcz10LmdldChlKTtzLmhhcyhpKXx8MD09PXMuc2l6ZT9zLnNldChpLG4pOmNvbnNvbGUuZXJyb3IoYEJvb3RzdHJhcCBkb2Vzbid0IGFsbG93IG1vcmUgdGhhbiBvbmUgaW5zdGFuY2UgcGVyIGVsZW1lbnQuIEJvdW5kIGluc3RhbmNlOiAke0FycmF5LmZyb20ocy5rZXlzKCkpWzBdfS5gKX0sZ2V0OihlLGkpPT50LmhhcyhlKSYmdC5nZXQoZSkuZ2V0KGkpfHxudWxsLHJlbW92ZShlLGkpe2lmKCF0LmhhcyhlKSlyZXR1cm47Y29uc3Qgbj10LmdldChlKTtuLmRlbGV0ZShpKSwwPT09bi5zaXplJiZ0LmRlbGV0ZShlKX19LGk9XCJ0cmFuc2l0aW9uZW5kXCIsbj10PT4odCYmd2luZG93LkNTUyYmd2luZG93LkNTUy5lc2NhcGUmJih0PXQucmVwbGFjZSgvIyhbXlxcc1wiIyddKykvZywoKHQsZSk9PmAjJHtDU1MuZXNjYXBlKGUpfWApKSksdCkscz10PT57dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChpKSl9LG89dD0+ISghdHx8XCJvYmplY3RcIiE9dHlwZW9mIHQpJiYodm9pZCAwIT09dC5qcXVlcnkmJih0PXRbMF0pLHZvaWQgMCE9PXQubm9kZVR5cGUpLHI9dD0+byh0KT90LmpxdWVyeT90WzBdOnQ6XCJzdHJpbmdcIj09dHlwZW9mIHQmJnQubGVuZ3RoPjA/ZG9jdW1lbnQucXVlcnlTZWxlY3RvcihuKHQpKTpudWxsLGE9dD0+e2lmKCFvKHQpfHwwPT09dC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aClyZXR1cm4hMTtjb25zdCBlPVwidmlzaWJsZVwiPT09Z2V0Q29tcHV0ZWRTdHlsZSh0KS5nZXRQcm9wZXJ0eVZhbHVlKFwidmlzaWJpbGl0eVwiKSxpPXQuY2xvc2VzdChcImRldGFpbHM6bm90KFtvcGVuXSlcIik7aWYoIWkpcmV0dXJuIGU7aWYoaSE9PXQpe2NvbnN0IGU9dC5jbG9zZXN0KFwic3VtbWFyeVwiKTtpZihlJiZlLnBhcmVudE5vZGUhPT1pKXJldHVybiExO2lmKG51bGw9PT1lKXJldHVybiExfXJldHVybiBlfSxsPXQ9PiF0fHx0Lm5vZGVUeXBlIT09Tm9kZS5FTEVNRU5UX05PREV8fCEhdC5jbGFzc0xpc3QuY29udGFpbnMoXCJkaXNhYmxlZFwiKXx8KHZvaWQgMCE9PXQuZGlzYWJsZWQ/dC5kaXNhYmxlZDp0Lmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpJiZcImZhbHNlXCIhPT10LmdldEF0dHJpYnV0ZShcImRpc2FibGVkXCIpKSxjPXQ9PntpZighZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmF0dGFjaFNoYWRvdylyZXR1cm4gbnVsbDtpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiB0LmdldFJvb3ROb2RlKXtjb25zdCBlPXQuZ2V0Um9vdE5vZGUoKTtyZXR1cm4gZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3Q/ZTpudWxsfXJldHVybiB0IGluc3RhbmNlb2YgU2hhZG93Um9vdD90OnQucGFyZW50Tm9kZT9jKHQucGFyZW50Tm9kZSk6bnVsbH0saD0oKT0+e30sZD10PT57dC5vZmZzZXRIZWlnaHR9LHU9KCk9PndpbmRvdy5qUXVlcnkmJiFkb2N1bWVudC5ib2R5Lmhhc0F0dHJpYnV0ZShcImRhdGEtYnMtbm8tanF1ZXJ5XCIpP3dpbmRvdy5qUXVlcnk6bnVsbCxmPVtdLHA9KCk9PlwicnRsXCI9PT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGlyLG09dD0+e3ZhciBlO2U9KCk9Pntjb25zdCBlPXUoKTtpZihlKXtjb25zdCBpPXQuTkFNRSxuPWUuZm5baV07ZS5mbltpXT10LmpRdWVyeUludGVyZmFjZSxlLmZuW2ldLkNvbnN0cnVjdG9yPXQsZS5mbltpXS5ub0NvbmZsaWN0PSgpPT4oZS5mbltpXT1uLHQualF1ZXJ5SW50ZXJmYWNlKX19LFwibG9hZGluZ1wiPT09ZG9jdW1lbnQucmVhZHlTdGF0ZT8oZi5sZW5ndGh8fGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsKCgpPT57Zm9yKGNvbnN0IHQgb2YgZil0KCl9KSksZi5wdXNoKGUpKTplKCl9LGc9KHQsZT1bXSxpPXQpPT5cImZ1bmN0aW9uXCI9PXR5cGVvZiB0P3QuY2FsbCguLi5lKTppLF89KHQsZSxuPSEwKT0+e2lmKCFuKXJldHVybiB2b2lkIGcodCk7Y29uc3Qgbz0odD0+e2lmKCF0KXJldHVybiAwO2xldHt0cmFuc2l0aW9uRHVyYXRpb246ZSx0cmFuc2l0aW9uRGVsYXk6aX09d2luZG93LmdldENvbXB1dGVkU3R5bGUodCk7Y29uc3Qgbj1OdW1iZXIucGFyc2VGbG9hdChlKSxzPU51bWJlci5wYXJzZUZsb2F0KGkpO3JldHVybiBufHxzPyhlPWUuc3BsaXQoXCIsXCIpWzBdLGk9aS5zcGxpdChcIixcIilbMF0sMWUzKihOdW1iZXIucGFyc2VGbG9hdChlKStOdW1iZXIucGFyc2VGbG9hdChpKSkpOjB9KShlKSs1O2xldCByPSExO2NvbnN0IGE9KHt0YXJnZXQ6bn0pPT57bj09PWUmJihyPSEwLGUucmVtb3ZlRXZlbnRMaXN0ZW5lcihpLGEpLGcodCkpfTtlLmFkZEV2ZW50TGlzdGVuZXIoaSxhKSxzZXRUaW1lb3V0KCgoKT0+e3J8fHMoZSl9KSxvKX0sYj0odCxlLGksbik9Pntjb25zdCBzPXQubGVuZ3RoO2xldCBvPXQuaW5kZXhPZihlKTtyZXR1cm4tMT09PW8/IWkmJm4/dFtzLTFdOnRbMF06KG8rPWk/MTotMSxuJiYobz0obytzKSVzKSx0W01hdGgubWF4KDAsTWF0aC5taW4obyxzLTEpKV0pfSx2PS9bXi5dKig/PVxcLi4qKVxcLnwuKi8seT0vXFwuLiovLHc9Lzo6XFxkKyQvLEE9e307bGV0IEU9MTtjb25zdCBUPXttb3VzZWVudGVyOlwibW91c2VvdmVyXCIsbW91c2VsZWF2ZTpcIm1vdXNlb3V0XCJ9LEM9bmV3IFNldChbXCJjbGlja1wiLFwiZGJsY2xpY2tcIixcIm1vdXNldXBcIixcIm1vdXNlZG93blwiLFwiY29udGV4dG1lbnVcIixcIm1vdXNld2hlZWxcIixcIkRPTU1vdXNlU2Nyb2xsXCIsXCJtb3VzZW92ZXJcIixcIm1vdXNlb3V0XCIsXCJtb3VzZW1vdmVcIixcInNlbGVjdHN0YXJ0XCIsXCJzZWxlY3RlbmRcIixcImtleWRvd25cIixcImtleXByZXNzXCIsXCJrZXl1cFwiLFwib3JpZW50YXRpb25jaGFuZ2VcIixcInRvdWNoc3RhcnRcIixcInRvdWNobW92ZVwiLFwidG91Y2hlbmRcIixcInRvdWNoY2FuY2VsXCIsXCJwb2ludGVyZG93blwiLFwicG9pbnRlcm1vdmVcIixcInBvaW50ZXJ1cFwiLFwicG9pbnRlcmxlYXZlXCIsXCJwb2ludGVyY2FuY2VsXCIsXCJnZXN0dXJlc3RhcnRcIixcImdlc3R1cmVjaGFuZ2VcIixcImdlc3R1cmVlbmRcIixcImZvY3VzXCIsXCJibHVyXCIsXCJjaGFuZ2VcIixcInJlc2V0XCIsXCJzZWxlY3RcIixcInN1Ym1pdFwiLFwiZm9jdXNpblwiLFwiZm9jdXNvdXRcIixcImxvYWRcIixcInVubG9hZFwiLFwiYmVmb3JldW5sb2FkXCIsXCJyZXNpemVcIixcIm1vdmVcIixcIkRPTUNvbnRlbnRMb2FkZWRcIixcInJlYWR5c3RhdGVjaGFuZ2VcIixcImVycm9yXCIsXCJhYm9ydFwiLFwic2Nyb2xsXCJdKTtmdW5jdGlvbiBPKHQsZSl7cmV0dXJuIGUmJmAke2V9Ojoke0UrK31gfHx0LnVpZEV2ZW50fHxFKyt9ZnVuY3Rpb24geCh0KXtjb25zdCBlPU8odCk7cmV0dXJuIHQudWlkRXZlbnQ9ZSxBW2VdPUFbZV18fHt9LEFbZV19ZnVuY3Rpb24gayh0LGUsaT1udWxsKXtyZXR1cm4gT2JqZWN0LnZhbHVlcyh0KS5maW5kKCh0PT50LmNhbGxhYmxlPT09ZSYmdC5kZWxlZ2F0aW9uU2VsZWN0b3I9PT1pKSl9ZnVuY3Rpb24gTCh0LGUsaSl7Y29uc3Qgbj1cInN0cmluZ1wiPT10eXBlb2YgZSxzPW4/aTplfHxpO2xldCBvPUkodCk7cmV0dXJuIEMuaGFzKG8pfHwobz10KSxbbixzLG9dfWZ1bmN0aW9uIFModCxlLGksbixzKXtpZihcInN0cmluZ1wiIT10eXBlb2YgZXx8IXQpcmV0dXJuO2xldFtvLHIsYV09TChlLGksbik7aWYoZSBpbiBUKXtjb25zdCB0PXQ9PmZ1bmN0aW9uKGUpe2lmKCFlLnJlbGF0ZWRUYXJnZXR8fGUucmVsYXRlZFRhcmdldCE9PWUuZGVsZWdhdGVUYXJnZXQmJiFlLmRlbGVnYXRlVGFyZ2V0LmNvbnRhaW5zKGUucmVsYXRlZFRhcmdldCkpcmV0dXJuIHQuY2FsbCh0aGlzLGUpfTtyPXQocil9Y29uc3QgbD14KHQpLGM9bFthXXx8KGxbYV09e30pLGg9ayhjLHIsbz9pOm51bGwpO2lmKGgpcmV0dXJuIHZvaWQoaC5vbmVPZmY9aC5vbmVPZmYmJnMpO2NvbnN0IGQ9TyhyLGUucmVwbGFjZSh2LFwiXCIpKSx1PW8/ZnVuY3Rpb24odCxlLGkpe3JldHVybiBmdW5jdGlvbiBuKHMpe2NvbnN0IG89dC5xdWVyeVNlbGVjdG9yQWxsKGUpO2ZvcihsZXR7dGFyZ2V0OnJ9PXM7ciYmciE9PXRoaXM7cj1yLnBhcmVudE5vZGUpZm9yKGNvbnN0IGEgb2YgbylpZihhPT09cilyZXR1cm4gUChzLHtkZWxlZ2F0ZVRhcmdldDpyfSksbi5vbmVPZmYmJk4ub2ZmKHQscy50eXBlLGUsaSksaS5hcHBseShyLFtzXSl9fSh0LGkscik6ZnVuY3Rpb24odCxlKXtyZXR1cm4gZnVuY3Rpb24gaShuKXtyZXR1cm4gUChuLHtkZWxlZ2F0ZVRhcmdldDp0fSksaS5vbmVPZmYmJk4ub2ZmKHQsbi50eXBlLGUpLGUuYXBwbHkodCxbbl0pfX0odCxyKTt1LmRlbGVnYXRpb25TZWxlY3Rvcj1vP2k6bnVsbCx1LmNhbGxhYmxlPXIsdS5vbmVPZmY9cyx1LnVpZEV2ZW50PWQsY1tkXT11LHQuYWRkRXZlbnRMaXN0ZW5lcihhLHUsbyl9ZnVuY3Rpb24gRCh0LGUsaSxuLHMpe2NvbnN0IG89ayhlW2ldLG4scyk7byYmKHQucmVtb3ZlRXZlbnRMaXN0ZW5lcihpLG8sQm9vbGVhbihzKSksZGVsZXRlIGVbaV1bby51aWRFdmVudF0pfWZ1bmN0aW9uICQodCxlLGksbil7Y29uc3Qgcz1lW2ldfHx7fTtmb3IoY29uc3RbbyxyXW9mIE9iamVjdC5lbnRyaWVzKHMpKW8uaW5jbHVkZXMobikmJkQodCxlLGksci5jYWxsYWJsZSxyLmRlbGVnYXRpb25TZWxlY3Rvcil9ZnVuY3Rpb24gSSh0KXtyZXR1cm4gdD10LnJlcGxhY2UoeSxcIlwiKSxUW3RdfHx0fWNvbnN0IE49e29uKHQsZSxpLG4pe1ModCxlLGksbiwhMSl9LG9uZSh0LGUsaSxuKXtTKHQsZSxpLG4sITApfSxvZmYodCxlLGksbil7aWYoXCJzdHJpbmdcIiE9dHlwZW9mIGV8fCF0KXJldHVybjtjb25zdFtzLG8scl09TChlLGksbiksYT1yIT09ZSxsPXgodCksYz1sW3JdfHx7fSxoPWUuc3RhcnRzV2l0aChcIi5cIik7aWYodm9pZCAwPT09byl7aWYoaClmb3IoY29uc3QgaSBvZiBPYmplY3Qua2V5cyhsKSkkKHQsbCxpLGUuc2xpY2UoMSkpO2Zvcihjb25zdFtpLG5db2YgT2JqZWN0LmVudHJpZXMoYykpe2NvbnN0IHM9aS5yZXBsYWNlKHcsXCJcIik7YSYmIWUuaW5jbHVkZXMocyl8fEQodCxsLHIsbi5jYWxsYWJsZSxuLmRlbGVnYXRpb25TZWxlY3Rvcil9fWVsc2V7aWYoIU9iamVjdC5rZXlzKGMpLmxlbmd0aClyZXR1cm47RCh0LGwscixvLHM/aTpudWxsKX19LHRyaWdnZXIodCxlLGkpe2lmKFwic3RyaW5nXCIhPXR5cGVvZiBlfHwhdClyZXR1cm4gbnVsbDtjb25zdCBuPXUoKTtsZXQgcz1udWxsLG89ITAscj0hMCxhPSExO2UhPT1JKGUpJiZuJiYocz1uLkV2ZW50KGUsaSksbih0KS50cmlnZ2VyKHMpLG89IXMuaXNQcm9wYWdhdGlvblN0b3BwZWQoKSxyPSFzLmlzSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkKCksYT1zLmlzRGVmYXVsdFByZXZlbnRlZCgpKTtjb25zdCBsPVAobmV3IEV2ZW50KGUse2J1YmJsZXM6byxjYW5jZWxhYmxlOiEwfSksaSk7cmV0dXJuIGEmJmwucHJldmVudERlZmF1bHQoKSxyJiZ0LmRpc3BhdGNoRXZlbnQobCksbC5kZWZhdWx0UHJldmVudGVkJiZzJiZzLnByZXZlbnREZWZhdWx0KCksbH19O2Z1bmN0aW9uIFAodCxlPXt9KXtmb3IoY29uc3RbaSxuXW9mIE9iamVjdC5lbnRyaWVzKGUpKXRyeXt0W2ldPW59Y2F0Y2goZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsaSx7Y29uZmlndXJhYmxlOiEwLGdldDooKT0+bn0pfXJldHVybiB0fWZ1bmN0aW9uIGoodCl7aWYoXCJ0cnVlXCI9PT10KXJldHVybiEwO2lmKFwiZmFsc2VcIj09PXQpcmV0dXJuITE7aWYodD09PU51bWJlcih0KS50b1N0cmluZygpKXJldHVybiBOdW1iZXIodCk7aWYoXCJcIj09PXR8fFwibnVsbFwiPT09dClyZXR1cm4gbnVsbDtpZihcInN0cmluZ1wiIT10eXBlb2YgdClyZXR1cm4gdDt0cnl7cmV0dXJuIEpTT04ucGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KHQpKX1jYXRjaChlKXtyZXR1cm4gdH19ZnVuY3Rpb24gTSh0KXtyZXR1cm4gdC5yZXBsYWNlKC9bQS1aXS9nLCh0PT5gLSR7dC50b0xvd2VyQ2FzZSgpfWApKX1jb25zdCBGPXtzZXREYXRhQXR0cmlidXRlKHQsZSxpKXt0LnNldEF0dHJpYnV0ZShgZGF0YS1icy0ke00oZSl9YCxpKX0scmVtb3ZlRGF0YUF0dHJpYnV0ZSh0LGUpe3QucmVtb3ZlQXR0cmlidXRlKGBkYXRhLWJzLSR7TShlKX1gKX0sZ2V0RGF0YUF0dHJpYnV0ZXModCl7aWYoIXQpcmV0dXJue307Y29uc3QgZT17fSxpPU9iamVjdC5rZXlzKHQuZGF0YXNldCkuZmlsdGVyKCh0PT50LnN0YXJ0c1dpdGgoXCJic1wiKSYmIXQuc3RhcnRzV2l0aChcImJzQ29uZmlnXCIpKSk7Zm9yKGNvbnN0IG4gb2YgaSl7bGV0IGk9bi5yZXBsYWNlKC9eYnMvLFwiXCIpO2k9aS5jaGFyQXQoMCkudG9Mb3dlckNhc2UoKStpLnNsaWNlKDEpLGVbaV09aih0LmRhdGFzZXRbbl0pfXJldHVybiBlfSxnZXREYXRhQXR0cmlidXRlOih0LGUpPT5qKHQuZ2V0QXR0cmlidXRlKGBkYXRhLWJzLSR7TShlKX1gKSl9O2NsYXNzIEh7c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJue319c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybnt9fXN0YXRpYyBnZXQgTkFNRSgpe3Rocm93IG5ldyBFcnJvcignWW91IGhhdmUgdG8gaW1wbGVtZW50IHRoZSBzdGF0aWMgbWV0aG9kIFwiTkFNRVwiLCBmb3IgZWFjaCBjb21wb25lbnQhJyl9X2dldENvbmZpZyh0KXtyZXR1cm4gdD10aGlzLl9tZXJnZUNvbmZpZ09iaih0KSx0PXRoaXMuX2NvbmZpZ0FmdGVyTWVyZ2UodCksdGhpcy5fdHlwZUNoZWNrQ29uZmlnKHQpLHR9X2NvbmZpZ0FmdGVyTWVyZ2UodCl7cmV0dXJuIHR9X21lcmdlQ29uZmlnT2JqKHQsZSl7Y29uc3QgaT1vKGUpP0YuZ2V0RGF0YUF0dHJpYnV0ZShlLFwiY29uZmlnXCIpOnt9O3JldHVybnsuLi50aGlzLmNvbnN0cnVjdG9yLkRlZmF1bHQsLi4uXCJvYmplY3RcIj09dHlwZW9mIGk/aTp7fSwuLi5vKGUpP0YuZ2V0RGF0YUF0dHJpYnV0ZXMoZSk6e30sLi4uXCJvYmplY3RcIj09dHlwZW9mIHQ/dDp7fX19X3R5cGVDaGVja0NvbmZpZyh0LGU9dGhpcy5jb25zdHJ1Y3Rvci5EZWZhdWx0VHlwZSl7Zm9yKGNvbnN0W24sc11vZiBPYmplY3QuZW50cmllcyhlKSl7Y29uc3QgZT10W25dLHI9byhlKT9cImVsZW1lbnRcIjpudWxsPT0oaT1lKT9gJHtpfWA6T2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGkpLm1hdGNoKC9cXHMoW2Etel0rKS9pKVsxXS50b0xvd2VyQ2FzZSgpO2lmKCFuZXcgUmVnRXhwKHMpLnRlc3QocikpdGhyb3cgbmV3IFR5cGVFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLk5BTUUudG9VcHBlckNhc2UoKX06IE9wdGlvbiBcIiR7bn1cIiBwcm92aWRlZCB0eXBlIFwiJHtyfVwiIGJ1dCBleHBlY3RlZCB0eXBlIFwiJHtzfVwiLmApfXZhciBpfX1jbGFzcyBXIGV4dGVuZHMgSHtjb25zdHJ1Y3Rvcih0LGkpe3N1cGVyKCksKHQ9cih0KSkmJih0aGlzLl9lbGVtZW50PXQsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhpKSxlLnNldCh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVksdGhpcykpfWRpc3Bvc2UoKXtlLnJlbW92ZSh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVkpLE4ub2ZmKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5FVkVOVF9LRVkpO2Zvcihjb25zdCB0IG9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKXRoaXNbdF09bnVsbH1fcXVldWVDYWxsYmFjayh0LGUsaT0hMCl7Xyh0LGUsaSl9X2dldENvbmZpZyh0KXtyZXR1cm4gdD10aGlzLl9tZXJnZUNvbmZpZ09iaih0LHRoaXMuX2VsZW1lbnQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1zdGF0aWMgZ2V0SW5zdGFuY2UodCl7cmV0dXJuIGUuZ2V0KHIodCksdGhpcy5EQVRBX0tFWSl9c3RhdGljIGdldE9yQ3JlYXRlSW5zdGFuY2UodCxlPXt9KXtyZXR1cm4gdGhpcy5nZXRJbnN0YW5jZSh0KXx8bmV3IHRoaXModCxcIm9iamVjdFwiPT10eXBlb2YgZT9lOm51bGwpfXN0YXRpYyBnZXQgVkVSU0lPTigpe3JldHVyblwiNS4zLjVcIn1zdGF0aWMgZ2V0IERBVEFfS0VZKCl7cmV0dXJuYGJzLiR7dGhpcy5OQU1FfWB9c3RhdGljIGdldCBFVkVOVF9LRVkoKXtyZXR1cm5gLiR7dGhpcy5EQVRBX0tFWX1gfXN0YXRpYyBldmVudE5hbWUodCl7cmV0dXJuYCR7dH0ke3RoaXMuRVZFTlRfS0VZfWB9fWNvbnN0IEI9dD0+e2xldCBlPXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy10YXJnZXRcIik7aWYoIWV8fFwiI1wiPT09ZSl7bGV0IGk9dC5nZXRBdHRyaWJ1dGUoXCJocmVmXCIpO2lmKCFpfHwhaS5pbmNsdWRlcyhcIiNcIikmJiFpLnN0YXJ0c1dpdGgoXCIuXCIpKXJldHVybiBudWxsO2kuaW5jbHVkZXMoXCIjXCIpJiYhaS5zdGFydHNXaXRoKFwiI1wiKSYmKGk9YCMke2kuc3BsaXQoXCIjXCIpWzFdfWApLGU9aSYmXCIjXCIhPT1pP2kudHJpbSgpOm51bGx9cmV0dXJuIGU/ZS5zcGxpdChcIixcIikubWFwKCh0PT5uKHQpKSkuam9pbihcIixcIik6bnVsbH0sej17ZmluZDoodCxlPWRvY3VtZW50LmRvY3VtZW50RWxlbWVudCk9PltdLmNvbmNhdCguLi5FbGVtZW50LnByb3RvdHlwZS5xdWVyeVNlbGVjdG9yQWxsLmNhbGwoZSx0KSksZmluZE9uZToodCxlPWRvY3VtZW50LmRvY3VtZW50RWxlbWVudCk9PkVsZW1lbnQucHJvdG90eXBlLnF1ZXJ5U2VsZWN0b3IuY2FsbChlLHQpLGNoaWxkcmVuOih0LGUpPT5bXS5jb25jYXQoLi4udC5jaGlsZHJlbikuZmlsdGVyKCh0PT50Lm1hdGNoZXMoZSkpKSxwYXJlbnRzKHQsZSl7Y29uc3QgaT1bXTtsZXQgbj10LnBhcmVudE5vZGUuY2xvc2VzdChlKTtmb3IoO247KWkucHVzaChuKSxuPW4ucGFyZW50Tm9kZS5jbG9zZXN0KGUpO3JldHVybiBpfSxwcmV2KHQsZSl7bGV0IGk9dC5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO2Zvcig7aTspe2lmKGkubWF0Y2hlcyhlKSlyZXR1cm5baV07aT1pLnByZXZpb3VzRWxlbWVudFNpYmxpbmd9cmV0dXJuW119LG5leHQodCxlKXtsZXQgaT10Lm5leHRFbGVtZW50U2libGluZztmb3IoO2k7KXtpZihpLm1hdGNoZXMoZSkpcmV0dXJuW2ldO2k9aS5uZXh0RWxlbWVudFNpYmxpbmd9cmV0dXJuW119LGZvY3VzYWJsZUNoaWxkcmVuKHQpe2NvbnN0IGU9W1wiYVwiLFwiYnV0dG9uXCIsXCJpbnB1dFwiLFwidGV4dGFyZWFcIixcInNlbGVjdFwiLFwiZGV0YWlsc1wiLFwiW3RhYmluZGV4XVwiLCdbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXSddLm1hcCgodD0+YCR7dH06bm90KFt0YWJpbmRleF49XCItXCJdKWApKS5qb2luKFwiLFwiKTtyZXR1cm4gdGhpcy5maW5kKGUsdCkuZmlsdGVyKCh0PT4hbCh0KSYmYSh0KSkpfSxnZXRTZWxlY3RvckZyb21FbGVtZW50KHQpe2NvbnN0IGU9Qih0KTtyZXR1cm4gZSYmei5maW5kT25lKGUpP2U6bnVsbH0sZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0KXtjb25zdCBlPUIodCk7cmV0dXJuIGU/ei5maW5kT25lKGUpOm51bGx9LGdldE11bHRpcGxlRWxlbWVudHNGcm9tU2VsZWN0b3IodCl7Y29uc3QgZT1CKHQpO3JldHVybiBlP3ouZmluZChlKTpbXX19LFI9KHQsZT1cImhpZGVcIik9Pntjb25zdCBpPWBjbGljay5kaXNtaXNzJHt0LkVWRU5UX0tFWX1gLG49dC5OQU1FO04ub24oZG9jdW1lbnQsaSxgW2RhdGEtYnMtZGlzbWlzcz1cIiR7bn1cIl1gLChmdW5jdGlvbihpKXtpZihbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJmkucHJldmVudERlZmF1bHQoKSxsKHRoaXMpKXJldHVybjtjb25zdCBzPXouZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKXx8dGhpcy5jbG9zZXN0KGAuJHtufWApO3QuZ2V0T3JDcmVhdGVJbnN0YW5jZShzKVtlXSgpfSkpfSxxPVwiLmJzLmFsZXJ0XCIsVj1gY2xvc2Uke3F9YCxLPWBjbG9zZWQke3F9YDtjbGFzcyBRIGV4dGVuZHMgV3tzdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cImFsZXJ0XCJ9Y2xvc2UoKXtpZihOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxWKS5kZWZhdWx0UHJldmVudGVkKXJldHVybjt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoXCJzaG93XCIpO2NvbnN0IHQ9dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJmYWRlXCIpO3RoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT50aGlzLl9kZXN0cm95RWxlbWVudCgpKSx0aGlzLl9lbGVtZW50LHQpfV9kZXN0cm95RWxlbWVudCgpe3RoaXMuX2VsZW1lbnQucmVtb3ZlKCksTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsSyksdGhpcy5kaXNwb3NlKCl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGU9US5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdfHx0LnN0YXJ0c1dpdGgoXCJfXCIpfHxcImNvbnN0cnVjdG9yXCI9PT10KXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0odGhpcyl9fSkpfX1SKFEsXCJjbG9zZVwiKSxtKFEpO2NvbnN0IFg9J1tkYXRhLWJzLXRvZ2dsZT1cImJ1dHRvblwiXSc7Y2xhc3MgWSBleHRlbmRzIFd7c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJidXR0b25cIn10b2dnbGUoKXt0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtcHJlc3NlZFwiLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnRvZ2dsZShcImFjdGl2ZVwiKSl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGU9WS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpO1widG9nZ2xlXCI9PT10JiZlW3RdKCl9KSl9fU4ub24oZG9jdW1lbnQsXCJjbGljay5icy5idXR0b24uZGF0YS1hcGlcIixYLCh0PT57dC5wcmV2ZW50RGVmYXVsdCgpO2NvbnN0IGU9dC50YXJnZXQuY2xvc2VzdChYKTtZLmdldE9yQ3JlYXRlSW5zdGFuY2UoZSkudG9nZ2xlKCl9KSksbShZKTtjb25zdCBVPVwiLmJzLnN3aXBlXCIsRz1gdG91Y2hzdGFydCR7VX1gLEo9YHRvdWNobW92ZSR7VX1gLFo9YHRvdWNoZW5kJHtVfWAsdHQ9YHBvaW50ZXJkb3duJHtVfWAsZXQ9YHBvaW50ZXJ1cCR7VX1gLGl0PXtlbmRDYWxsYmFjazpudWxsLGxlZnRDYWxsYmFjazpudWxsLHJpZ2h0Q2FsbGJhY2s6bnVsbH0sbnQ9e2VuZENhbGxiYWNrOlwiKGZ1bmN0aW9ufG51bGwpXCIsbGVmdENhbGxiYWNrOlwiKGZ1bmN0aW9ufG51bGwpXCIscmlnaHRDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwifTtjbGFzcyBzdCBleHRlbmRzIEh7Y29uc3RydWN0b3IodCxlKXtzdXBlcigpLHRoaXMuX2VsZW1lbnQ9dCx0JiZzdC5pc1N1cHBvcnRlZCgpJiYodGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhlKSx0aGlzLl9kZWx0YVg9MCx0aGlzLl9zdXBwb3J0UG9pbnRlckV2ZW50cz1Cb29sZWFuKHdpbmRvdy5Qb2ludGVyRXZlbnQpLHRoaXMuX2luaXRFdmVudHMoKSl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIGl0fXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gbnR9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJzd2lwZVwifWRpc3Bvc2UoKXtOLm9mZih0aGlzLl9lbGVtZW50LFUpfV9zdGFydCh0KXt0aGlzLl9zdXBwb3J0UG9pbnRlckV2ZW50cz90aGlzLl9ldmVudElzUG9pbnRlclBlblRvdWNoKHQpJiYodGhpcy5fZGVsdGFYPXQuY2xpZW50WCk6dGhpcy5fZGVsdGFYPXQudG91Y2hlc1swXS5jbGllbnRYfV9lbmQodCl7dGhpcy5fZXZlbnRJc1BvaW50ZXJQZW5Ub3VjaCh0KSYmKHRoaXMuX2RlbHRhWD10LmNsaWVudFgtdGhpcy5fZGVsdGFYKSx0aGlzLl9oYW5kbGVTd2lwZSgpLGcodGhpcy5fY29uZmlnLmVuZENhbGxiYWNrKX1fbW92ZSh0KXt0aGlzLl9kZWx0YVg9dC50b3VjaGVzJiZ0LnRvdWNoZXMubGVuZ3RoPjE/MDp0LnRvdWNoZXNbMF0uY2xpZW50WC10aGlzLl9kZWx0YVh9X2hhbmRsZVN3aXBlKCl7Y29uc3QgdD1NYXRoLmFicyh0aGlzLl9kZWx0YVgpO2lmKHQ8PTQwKXJldHVybjtjb25zdCBlPXQvdGhpcy5fZGVsdGFYO3RoaXMuX2RlbHRhWD0wLGUmJmcoZT4wP3RoaXMuX2NvbmZpZy5yaWdodENhbGxiYWNrOnRoaXMuX2NvbmZpZy5sZWZ0Q2FsbGJhY2spfV9pbml0RXZlbnRzKCl7dGhpcy5fc3VwcG9ydFBvaW50ZXJFdmVudHM/KE4ub24odGhpcy5fZWxlbWVudCx0dCwodD0+dGhpcy5fc3RhcnQodCkpKSxOLm9uKHRoaXMuX2VsZW1lbnQsZXQsKHQ9PnRoaXMuX2VuZCh0KSkpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChcInBvaW50ZXItZXZlbnRcIikpOihOLm9uKHRoaXMuX2VsZW1lbnQsRywodD0+dGhpcy5fc3RhcnQodCkpKSxOLm9uKHRoaXMuX2VsZW1lbnQsSiwodD0+dGhpcy5fbW92ZSh0KSkpLE4ub24odGhpcy5fZWxlbWVudCxaLCh0PT50aGlzLl9lbmQodCkpKSl9X2V2ZW50SXNQb2ludGVyUGVuVG91Y2godCl7cmV0dXJuIHRoaXMuX3N1cHBvcnRQb2ludGVyRXZlbnRzJiYoXCJwZW5cIj09PXQucG9pbnRlclR5cGV8fFwidG91Y2hcIj09PXQucG9pbnRlclR5cGUpfXN0YXRpYyBpc1N1cHBvcnRlZCgpe3JldHVyblwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnR8fG5hdmlnYXRvci5tYXhUb3VjaFBvaW50cz4wfX1jb25zdCBvdD1cIi5icy5jYXJvdXNlbFwiLHJ0PVwiLmRhdGEtYXBpXCIsYXQ9XCJBcnJvd0xlZnRcIixsdD1cIkFycm93UmlnaHRcIixjdD1cIm5leHRcIixodD1cInByZXZcIixkdD1cImxlZnRcIix1dD1cInJpZ2h0XCIsZnQ9YHNsaWRlJHtvdH1gLHB0PWBzbGlkJHtvdH1gLG10PWBrZXlkb3duJHtvdH1gLGd0PWBtb3VzZWVudGVyJHtvdH1gLF90PWBtb3VzZWxlYXZlJHtvdH1gLGJ0PWBkcmFnc3RhcnQke290fWAsdnQ9YGxvYWQke290fSR7cnR9YCx5dD1gY2xpY2ske290fSR7cnR9YCx3dD1cImNhcm91c2VsXCIsQXQ9XCJhY3RpdmVcIixFdD1cIi5hY3RpdmVcIixUdD1cIi5jYXJvdXNlbC1pdGVtXCIsQ3Q9RXQrVHQsT3Q9e1thdF06dXQsW2x0XTpkdH0seHQ9e2ludGVydmFsOjVlMyxrZXlib2FyZDohMCxwYXVzZTpcImhvdmVyXCIscmlkZTohMSx0b3VjaDohMCx3cmFwOiEwfSxrdD17aW50ZXJ2YWw6XCIobnVtYmVyfGJvb2xlYW4pXCIsa2V5Ym9hcmQ6XCJib29sZWFuXCIscGF1c2U6XCIoc3RyaW5nfGJvb2xlYW4pXCIscmlkZTpcIihib29sZWFufHN0cmluZylcIix0b3VjaDpcImJvb2xlYW5cIix3cmFwOlwiYm9vbGVhblwifTtjbGFzcyBMdCBleHRlbmRzIFd7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX2ludGVydmFsPW51bGwsdGhpcy5fYWN0aXZlRWxlbWVudD1udWxsLHRoaXMuX2lzU2xpZGluZz0hMSx0aGlzLnRvdWNoVGltZW91dD1udWxsLHRoaXMuX3N3aXBlSGVscGVyPW51bGwsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQ9ei5maW5kT25lKFwiLmNhcm91c2VsLWluZGljYXRvcnNcIix0aGlzLl9lbGVtZW50KSx0aGlzLl9hZGRFdmVudExpc3RlbmVycygpLHRoaXMuX2NvbmZpZy5yaWRlPT09d3QmJnRoaXMuY3ljbGUoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4geHR9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBrdH1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cImNhcm91c2VsXCJ9bmV4dCgpe3RoaXMuX3NsaWRlKGN0KX1uZXh0V2hlblZpc2libGUoKXshZG9jdW1lbnQuaGlkZGVuJiZhKHRoaXMuX2VsZW1lbnQpJiZ0aGlzLm5leHQoKX1wcmV2KCl7dGhpcy5fc2xpZGUoaHQpfXBhdXNlKCl7dGhpcy5faXNTbGlkaW5nJiZzKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2NsZWFySW50ZXJ2YWwoKX1jeWNsZSgpe3RoaXMuX2NsZWFySW50ZXJ2YWwoKSx0aGlzLl91cGRhdGVJbnRlcnZhbCgpLHRoaXMuX2ludGVydmFsPXNldEludGVydmFsKCgoKT0+dGhpcy5uZXh0V2hlblZpc2libGUoKSksdGhpcy5fY29uZmlnLmludGVydmFsKX1fbWF5YmVFbmFibGVDeWNsZSgpe3RoaXMuX2NvbmZpZy5yaWRlJiYodGhpcy5faXNTbGlkaW5nP04ub25lKHRoaXMuX2VsZW1lbnQscHQsKCgpPT50aGlzLmN5Y2xlKCkpKTp0aGlzLmN5Y2xlKCkpfXRvKHQpe2NvbnN0IGU9dGhpcy5fZ2V0SXRlbXMoKTtpZih0PmUubGVuZ3RoLTF8fHQ8MClyZXR1cm47aWYodGhpcy5faXNTbGlkaW5nKXJldHVybiB2b2lkIE4ub25lKHRoaXMuX2VsZW1lbnQscHQsKCgpPT50aGlzLnRvKHQpKSk7Y29uc3QgaT10aGlzLl9nZXRJdGVtSW5kZXgodGhpcy5fZ2V0QWN0aXZlKCkpO2lmKGk9PT10KXJldHVybjtjb25zdCBuPXQ+aT9jdDpodDt0aGlzLl9zbGlkZShuLGVbdF0pfWRpc3Bvc2UoKXt0aGlzLl9zd2lwZUhlbHBlciYmdGhpcy5fc3dpcGVIZWxwZXIuZGlzcG9zZSgpLHN1cGVyLmRpc3Bvc2UoKX1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC5kZWZhdWx0SW50ZXJ2YWw9dC5pbnRlcnZhbCx0fV9hZGRFdmVudExpc3RlbmVycygpe3RoaXMuX2NvbmZpZy5rZXlib2FyZCYmTi5vbih0aGlzLl9lbGVtZW50LG10LCh0PT50aGlzLl9rZXlkb3duKHQpKSksXCJob3ZlclwiPT09dGhpcy5fY29uZmlnLnBhdXNlJiYoTi5vbih0aGlzLl9lbGVtZW50LGd0LCgoKT0+dGhpcy5wYXVzZSgpKSksTi5vbih0aGlzLl9lbGVtZW50LF90LCgoKT0+dGhpcy5fbWF5YmVFbmFibGVDeWNsZSgpKSkpLHRoaXMuX2NvbmZpZy50b3VjaCYmc3QuaXNTdXBwb3J0ZWQoKSYmdGhpcy5fYWRkVG91Y2hFdmVudExpc3RlbmVycygpfV9hZGRUb3VjaEV2ZW50TGlzdGVuZXJzKCl7Zm9yKGNvbnN0IHQgb2Ygei5maW5kKFwiLmNhcm91c2VsLWl0ZW0gaW1nXCIsdGhpcy5fZWxlbWVudCkpTi5vbih0LGJ0LCh0PT50LnByZXZlbnREZWZhdWx0KCkpKTtjb25zdCB0PXtsZWZ0Q2FsbGJhY2s6KCk9PnRoaXMuX3NsaWRlKHRoaXMuX2RpcmVjdGlvblRvT3JkZXIoZHQpKSxyaWdodENhbGxiYWNrOigpPT50aGlzLl9zbGlkZSh0aGlzLl9kaXJlY3Rpb25Ub09yZGVyKHV0KSksZW5kQ2FsbGJhY2s6KCk9PntcImhvdmVyXCI9PT10aGlzLl9jb25maWcucGF1c2UmJih0aGlzLnBhdXNlKCksdGhpcy50b3VjaFRpbWVvdXQmJmNsZWFyVGltZW91dCh0aGlzLnRvdWNoVGltZW91dCksdGhpcy50b3VjaFRpbWVvdXQ9c2V0VGltZW91dCgoKCk9PnRoaXMuX21heWJlRW5hYmxlQ3ljbGUoKSksNTAwK3RoaXMuX2NvbmZpZy5pbnRlcnZhbCkpfX07dGhpcy5fc3dpcGVIZWxwZXI9bmV3IHN0KHRoaXMuX2VsZW1lbnQsdCl9X2tleWRvd24odCl7aWYoL2lucHV0fHRleHRhcmVhL2kudGVzdCh0LnRhcmdldC50YWdOYW1lKSlyZXR1cm47Y29uc3QgZT1PdFt0LmtleV07ZSYmKHQucHJldmVudERlZmF1bHQoKSx0aGlzLl9zbGlkZSh0aGlzLl9kaXJlY3Rpb25Ub09yZGVyKGUpKSl9X2dldEl0ZW1JbmRleCh0KXtyZXR1cm4gdGhpcy5fZ2V0SXRlbXMoKS5pbmRleE9mKHQpfV9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50KHQpe2lmKCF0aGlzLl9pbmRpY2F0b3JzRWxlbWVudClyZXR1cm47Y29uc3QgZT16LmZpbmRPbmUoRXQsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQpO2UuY2xhc3NMaXN0LnJlbW92ZShBdCksZS5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWN1cnJlbnRcIik7Y29uc3QgaT16LmZpbmRPbmUoYFtkYXRhLWJzLXNsaWRlLXRvPVwiJHt0fVwiXWAsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQpO2kmJihpLmNsYXNzTGlzdC5hZGQoQXQpLGkuc2V0QXR0cmlidXRlKFwiYXJpYS1jdXJyZW50XCIsXCJ0cnVlXCIpKX1fdXBkYXRlSW50ZXJ2YWwoKXtjb25zdCB0PXRoaXMuX2FjdGl2ZUVsZW1lbnR8fHRoaXMuX2dldEFjdGl2ZSgpO2lmKCF0KXJldHVybjtjb25zdCBlPU51bWJlci5wYXJzZUludCh0LmdldEF0dHJpYnV0ZShcImRhdGEtYnMtaW50ZXJ2YWxcIiksMTApO3RoaXMuX2NvbmZpZy5pbnRlcnZhbD1lfHx0aGlzLl9jb25maWcuZGVmYXVsdEludGVydmFsfV9zbGlkZSh0LGU9bnVsbCl7aWYodGhpcy5faXNTbGlkaW5nKXJldHVybjtjb25zdCBpPXRoaXMuX2dldEFjdGl2ZSgpLG49dD09PWN0LHM9ZXx8Yih0aGlzLl9nZXRJdGVtcygpLGksbix0aGlzLl9jb25maWcud3JhcCk7aWYocz09PWkpcmV0dXJuO2NvbnN0IG89dGhpcy5fZ2V0SXRlbUluZGV4KHMpLHI9ZT0+Ti50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsZSx7cmVsYXRlZFRhcmdldDpzLGRpcmVjdGlvbjp0aGlzLl9vcmRlclRvRGlyZWN0aW9uKHQpLGZyb206dGhpcy5fZ2V0SXRlbUluZGV4KGkpLHRvOm99KTtpZihyKGZ0KS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtpZighaXx8IXMpcmV0dXJuO2NvbnN0IGE9Qm9vbGVhbih0aGlzLl9pbnRlcnZhbCk7dGhpcy5wYXVzZSgpLHRoaXMuX2lzU2xpZGluZz0hMCx0aGlzLl9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50KG8pLHRoaXMuX2FjdGl2ZUVsZW1lbnQ9cztjb25zdCBsPW4/XCJjYXJvdXNlbC1pdGVtLXN0YXJ0XCI6XCJjYXJvdXNlbC1pdGVtLWVuZFwiLGM9bj9cImNhcm91c2VsLWl0ZW0tbmV4dFwiOlwiY2Fyb3VzZWwtaXRlbS1wcmV2XCI7cy5jbGFzc0xpc3QuYWRkKGMpLGQocyksaS5jbGFzc0xpc3QuYWRkKGwpLHMuY2xhc3NMaXN0LmFkZChsKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgoKT0+e3MuY2xhc3NMaXN0LnJlbW92ZShsLGMpLHMuY2xhc3NMaXN0LmFkZChBdCksaS5jbGFzc0xpc3QucmVtb3ZlKEF0LGMsbCksdGhpcy5faXNTbGlkaW5nPSExLHIocHQpfSksaSx0aGlzLl9pc0FuaW1hdGVkKCkpLGEmJnRoaXMuY3ljbGUoKX1faXNBbmltYXRlZCgpe3JldHVybiB0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcInNsaWRlXCIpfV9nZXRBY3RpdmUoKXtyZXR1cm4gei5maW5kT25lKEN0LHRoaXMuX2VsZW1lbnQpfV9nZXRJdGVtcygpe3JldHVybiB6LmZpbmQoVHQsdGhpcy5fZWxlbWVudCl9X2NsZWFySW50ZXJ2YWwoKXt0aGlzLl9pbnRlcnZhbCYmKGNsZWFySW50ZXJ2YWwodGhpcy5faW50ZXJ2YWwpLHRoaXMuX2ludGVydmFsPW51bGwpfV9kaXJlY3Rpb25Ub09yZGVyKHQpe3JldHVybiBwKCk/dD09PWR0P2h0OmN0OnQ9PT1kdD9jdDpodH1fb3JkZXJUb0RpcmVjdGlvbih0KXtyZXR1cm4gcCgpP3Q9PT1odD9kdDp1dDp0PT09aHQ/dXQ6ZHR9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGU9THQuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwibnVtYmVyXCIhPXR5cGVvZiB0KXtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fWVsc2UgZS50byh0KX0pKX19Ti5vbihkb2N1bWVudCx5dCxcIltkYXRhLWJzLXNsaWRlXSwgW2RhdGEtYnMtc2xpZGUtdG9dXCIsKGZ1bmN0aW9uKHQpe2NvbnN0IGU9ei5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHRoaXMpO2lmKCFlfHwhZS5jbGFzc0xpc3QuY29udGFpbnMod3QpKXJldHVybjt0LnByZXZlbnREZWZhdWx0KCk7Y29uc3QgaT1MdC5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLG49dGhpcy5nZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLXNsaWRlLXRvXCIpO3JldHVybiBuPyhpLnRvKG4pLHZvaWQgaS5fbWF5YmVFbmFibGVDeWNsZSgpKTpcIm5leHRcIj09PUYuZ2V0RGF0YUF0dHJpYnV0ZSh0aGlzLFwic2xpZGVcIik/KGkubmV4dCgpLHZvaWQgaS5fbWF5YmVFbmFibGVDeWNsZSgpKTooaS5wcmV2KCksdm9pZCBpLl9tYXliZUVuYWJsZUN5Y2xlKCkpfSkpLE4ub24od2luZG93LHZ0LCgoKT0+e2NvbnN0IHQ9ei5maW5kKCdbZGF0YS1icy1yaWRlPVwiY2Fyb3VzZWxcIl0nKTtmb3IoY29uc3QgZSBvZiB0KUx0LmdldE9yQ3JlYXRlSW5zdGFuY2UoZSl9KSksbShMdCk7Y29uc3QgU3Q9XCIuYnMuY29sbGFwc2VcIixEdD1gc2hvdyR7U3R9YCwkdD1gc2hvd24ke1N0fWAsSXQ9YGhpZGUke1N0fWAsTnQ9YGhpZGRlbiR7U3R9YCxQdD1gY2xpY2ske1N0fS5kYXRhLWFwaWAsanQ9XCJzaG93XCIsTXQ9XCJjb2xsYXBzZVwiLEZ0PVwiY29sbGFwc2luZ1wiLEh0PWA6c2NvcGUgLiR7TXR9IC4ke010fWAsV3Q9J1tkYXRhLWJzLXRvZ2dsZT1cImNvbGxhcHNlXCJdJyxCdD17cGFyZW50Om51bGwsdG9nZ2xlOiEwfSx6dD17cGFyZW50OlwiKG51bGx8ZWxlbWVudClcIix0b2dnbGU6XCJib29sZWFuXCJ9O2NsYXNzIFJ0IGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX3RyaWdnZXJBcnJheT1bXTtjb25zdCBpPXouZmluZChXdCk7Zm9yKGNvbnN0IHQgb2YgaSl7Y29uc3QgZT16LmdldFNlbGVjdG9yRnJvbUVsZW1lbnQodCksaT16LmZpbmQoZSkuZmlsdGVyKCh0PT50PT09dGhpcy5fZWxlbWVudCkpO251bGwhPT1lJiZpLmxlbmd0aCYmdGhpcy5fdHJpZ2dlckFycmF5LnB1c2godCl9dGhpcy5faW5pdGlhbGl6ZUNoaWxkcmVuKCksdGhpcy5fY29uZmlnLnBhcmVudHx8dGhpcy5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKHRoaXMuX3RyaWdnZXJBcnJheSx0aGlzLl9pc1Nob3duKCkpLHRoaXMuX2NvbmZpZy50b2dnbGUmJnRoaXMudG9nZ2xlKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIEJ0fXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4genR9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJjb2xsYXBzZVwifXRvZ2dsZSgpe3RoaXMuX2lzU2hvd24oKT90aGlzLmhpZGUoKTp0aGlzLnNob3coKX1zaG93KCl7aWYodGhpcy5faXNUcmFuc2l0aW9uaW5nfHx0aGlzLl9pc1Nob3duKCkpcmV0dXJuO2xldCB0PVtdO2lmKHRoaXMuX2NvbmZpZy5wYXJlbnQmJih0PXRoaXMuX2dldEZpcnN0TGV2ZWxDaGlsZHJlbihcIi5jb2xsYXBzZS5zaG93LCAuY29sbGFwc2UuY29sbGFwc2luZ1wiKS5maWx0ZXIoKHQ9PnQhPT10aGlzLl9lbGVtZW50KSkubWFwKCh0PT5SdC5nZXRPckNyZWF0ZUluc3RhbmNlKHQse3RvZ2dsZTohMX0pKSkpLHQubGVuZ3RoJiZ0WzBdLl9pc1RyYW5zaXRpb25pbmcpcmV0dXJuO2lmKE4udHJpZ2dlcih0aGlzLl9lbGVtZW50LER0KS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtmb3IoY29uc3QgZSBvZiB0KWUuaGlkZSgpO2NvbnN0IGU9dGhpcy5fZ2V0RGltZW5zaW9uKCk7dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKE10KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoRnQpLHRoaXMuX2VsZW1lbnQuc3R5bGVbZV09MCx0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3ModGhpcy5fdHJpZ2dlckFycmF5LCEwKSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITA7Y29uc3QgaT1gc2Nyb2xsJHtlWzBdLnRvVXBwZXJDYXNlKCkrZS5zbGljZSgxKX1gO3RoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57dGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShGdCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKE10LGp0KSx0aGlzLl9lbGVtZW50LnN0eWxlW2VdPVwiXCIsTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsJHQpfSksdGhpcy5fZWxlbWVudCwhMCksdGhpcy5fZWxlbWVudC5zdHlsZVtlXT1gJHt0aGlzLl9lbGVtZW50W2ldfXB4YH1oaWRlKCl7aWYodGhpcy5faXNUcmFuc2l0aW9uaW5nfHwhdGhpcy5faXNTaG93bigpKXJldHVybjtpZihOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxJdCkuZGVmYXVsdFByZXZlbnRlZClyZXR1cm47Y29uc3QgdD10aGlzLl9nZXREaW1lbnNpb24oKTt0aGlzLl9lbGVtZW50LnN0eWxlW3RdPWAke3RoaXMuX2VsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClbdF19cHhgLGQodGhpcy5fZWxlbWVudCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKEZ0KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoTXQsanQpO2Zvcihjb25zdCB0IG9mIHRoaXMuX3RyaWdnZXJBcnJheSl7Y29uc3QgZT16LmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCk7ZSYmIXRoaXMuX2lzU2hvd24oZSkmJnRoaXMuX2FkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyhbdF0sITEpfXRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMCx0aGlzLl9lbGVtZW50LnN0eWxlW3RdPVwiXCIsdGhpcy5fcXVldWVDYWxsYmFjaygoKCk9Pnt0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKEZ0KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoTXQpLE4udHJpZ2dlcih0aGlzLl9lbGVtZW50LE50KX0pLHRoaXMuX2VsZW1lbnQsITApfV9pc1Nob3duKHQ9dGhpcy5fZWxlbWVudCl7cmV0dXJuIHQuY2xhc3NMaXN0LmNvbnRhaW5zKGp0KX1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC50b2dnbGU9Qm9vbGVhbih0LnRvZ2dsZSksdC5wYXJlbnQ9cih0LnBhcmVudCksdH1fZ2V0RGltZW5zaW9uKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiY29sbGFwc2UtaG9yaXpvbnRhbFwiKT9cIndpZHRoXCI6XCJoZWlnaHRcIn1faW5pdGlhbGl6ZUNoaWxkcmVuKCl7aWYoIXRoaXMuX2NvbmZpZy5wYXJlbnQpcmV0dXJuO2NvbnN0IHQ9dGhpcy5fZ2V0Rmlyc3RMZXZlbENoaWxkcmVuKFd0KTtmb3IoY29uc3QgZSBvZiB0KXtjb25zdCB0PXouZ2V0RWxlbWVudEZyb21TZWxlY3RvcihlKTt0JiZ0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3MoW2VdLHRoaXMuX2lzU2hvd24odCkpfX1fZ2V0Rmlyc3RMZXZlbENoaWxkcmVuKHQpe2NvbnN0IGU9ei5maW5kKEh0LHRoaXMuX2NvbmZpZy5wYXJlbnQpO3JldHVybiB6LmZpbmQodCx0aGlzLl9jb25maWcucGFyZW50KS5maWx0ZXIoKHQ9PiFlLmluY2x1ZGVzKHQpKSl9X2FkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyh0LGUpe2lmKHQubGVuZ3RoKWZvcihjb25zdCBpIG9mIHQpaS5jbGFzc0xpc3QudG9nZ2xlKFwiY29sbGFwc2VkXCIsIWUpLGkuc2V0QXR0cmlidXRlKFwiYXJpYS1leHBhbmRlZFwiLGUpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7Y29uc3QgZT17fTtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdCYmL3Nob3d8aGlkZS8udGVzdCh0KSYmKGUudG9nZ2xlPSExKSx0aGlzLmVhY2goKGZ1bmN0aW9uKCl7Y29uc3QgaT1SdC5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsZSk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWlbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7aVt0XSgpfX0pKX19Ti5vbihkb2N1bWVudCxQdCxXdCwoZnVuY3Rpb24odCl7KFwiQVwiPT09dC50YXJnZXQudGFnTmFtZXx8dC5kZWxlZ2F0ZVRhcmdldCYmXCJBXCI9PT10LmRlbGVnYXRlVGFyZ2V0LnRhZ05hbWUpJiZ0LnByZXZlbnREZWZhdWx0KCk7Zm9yKGNvbnN0IHQgb2Ygei5nZXRNdWx0aXBsZUVsZW1lbnRzRnJvbVNlbGVjdG9yKHRoaXMpKVJ0LmdldE9yQ3JlYXRlSW5zdGFuY2UodCx7dG9nZ2xlOiExfSkudG9nZ2xlKCl9KSksbShSdCk7dmFyIHF0PVwidG9wXCIsVnQ9XCJib3R0b21cIixLdD1cInJpZ2h0XCIsUXQ9XCJsZWZ0XCIsWHQ9XCJhdXRvXCIsWXQ9W3F0LFZ0LEt0LFF0XSxVdD1cInN0YXJ0XCIsR3Q9XCJlbmRcIixKdD1cImNsaXBwaW5nUGFyZW50c1wiLFp0PVwidmlld3BvcnRcIix0ZT1cInBvcHBlclwiLGVlPVwicmVmZXJlbmNlXCIsaWU9WXQucmVkdWNlKChmdW5jdGlvbih0LGUpe3JldHVybiB0LmNvbmNhdChbZStcIi1cIitVdCxlK1wiLVwiK0d0XSl9KSxbXSksbmU9W10uY29uY2F0KFl0LFtYdF0pLnJlZHVjZSgoZnVuY3Rpb24odCxlKXtyZXR1cm4gdC5jb25jYXQoW2UsZStcIi1cIitVdCxlK1wiLVwiK0d0XSl9KSxbXSksc2U9XCJiZWZvcmVSZWFkXCIsb2U9XCJyZWFkXCIscmU9XCJhZnRlclJlYWRcIixhZT1cImJlZm9yZU1haW5cIixsZT1cIm1haW5cIixjZT1cImFmdGVyTWFpblwiLGhlPVwiYmVmb3JlV3JpdGVcIixkZT1cIndyaXRlXCIsdWU9XCJhZnRlcldyaXRlXCIsZmU9W3NlLG9lLHJlLGFlLGxlLGNlLGhlLGRlLHVlXTtmdW5jdGlvbiBwZSh0KXtyZXR1cm4gdD8odC5ub2RlTmFtZXx8XCJcIikudG9Mb3dlckNhc2UoKTpudWxsfWZ1bmN0aW9uIG1lKHQpe2lmKG51bGw9PXQpcmV0dXJuIHdpbmRvdztpZihcIltvYmplY3QgV2luZG93XVwiIT09dC50b1N0cmluZygpKXt2YXIgZT10Lm93bmVyRG9jdW1lbnQ7cmV0dXJuIGUmJmUuZGVmYXVsdFZpZXd8fHdpbmRvd31yZXR1cm4gdH1mdW5jdGlvbiBnZSh0KXtyZXR1cm4gdCBpbnN0YW5jZW9mIG1lKHQpLkVsZW1lbnR8fHQgaW5zdGFuY2VvZiBFbGVtZW50fWZ1bmN0aW9uIF9lKHQpe3JldHVybiB0IGluc3RhbmNlb2YgbWUodCkuSFRNTEVsZW1lbnR8fHQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudH1mdW5jdGlvbiBiZSh0KXtyZXR1cm5cInVuZGVmaW5lZFwiIT10eXBlb2YgU2hhZG93Um9vdCYmKHQgaW5zdGFuY2VvZiBtZSh0KS5TaGFkb3dSb290fHx0IGluc3RhbmNlb2YgU2hhZG93Um9vdCl9Y29uc3QgdmU9e25hbWU6XCJhcHBseVN0eWxlc1wiLGVuYWJsZWQ6ITAscGhhc2U6XCJ3cml0ZVwiLGZuOmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGU7T2JqZWN0LmtleXMoZS5lbGVtZW50cykuZm9yRWFjaCgoZnVuY3Rpb24odCl7dmFyIGk9ZS5zdHlsZXNbdF18fHt9LG49ZS5hdHRyaWJ1dGVzW3RdfHx7fSxzPWUuZWxlbWVudHNbdF07X2UocykmJnBlKHMpJiYoT2JqZWN0LmFzc2lnbihzLnN0eWxlLGkpLE9iamVjdC5rZXlzKG4pLmZvckVhY2goKGZ1bmN0aW9uKHQpe3ZhciBlPW5bdF07ITE9PT1lP3MucmVtb3ZlQXR0cmlidXRlKHQpOnMuc2V0QXR0cmlidXRlKHQsITA9PT1lP1wiXCI6ZSl9KSkpfSkpfSxlZmZlY3Q6ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXtwb3BwZXI6e3Bvc2l0aW9uOmUub3B0aW9ucy5zdHJhdGVneSxsZWZ0OlwiMFwiLHRvcDpcIjBcIixtYXJnaW46XCIwXCJ9LGFycm93Ontwb3NpdGlvbjpcImFic29sdXRlXCJ9LHJlZmVyZW5jZTp7fX07cmV0dXJuIE9iamVjdC5hc3NpZ24oZS5lbGVtZW50cy5wb3BwZXIuc3R5bGUsaS5wb3BwZXIpLGUuc3R5bGVzPWksZS5lbGVtZW50cy5hcnJvdyYmT2JqZWN0LmFzc2lnbihlLmVsZW1lbnRzLmFycm93LnN0eWxlLGkuYXJyb3cpLGZ1bmN0aW9uKCl7T2JqZWN0LmtleXMoZS5lbGVtZW50cykuZm9yRWFjaCgoZnVuY3Rpb24odCl7dmFyIG49ZS5lbGVtZW50c1t0XSxzPWUuYXR0cmlidXRlc1t0XXx8e30sbz1PYmplY3Qua2V5cyhlLnN0eWxlcy5oYXNPd25Qcm9wZXJ0eSh0KT9lLnN0eWxlc1t0XTppW3RdKS5yZWR1Y2UoKGZ1bmN0aW9uKHQsZSl7cmV0dXJuIHRbZV09XCJcIix0fSkse30pO19lKG4pJiZwZShuKSYmKE9iamVjdC5hc3NpZ24obi5zdHlsZSxvKSxPYmplY3Qua2V5cyhzKS5mb3JFYWNoKChmdW5jdGlvbih0KXtuLnJlbW92ZUF0dHJpYnV0ZSh0KX0pKSl9KSl9fSxyZXF1aXJlczpbXCJjb21wdXRlU3R5bGVzXCJdfTtmdW5jdGlvbiB5ZSh0KXtyZXR1cm4gdC5zcGxpdChcIi1cIilbMF19dmFyIHdlPU1hdGgubWF4LEFlPU1hdGgubWluLEVlPU1hdGgucm91bmQ7ZnVuY3Rpb24gVGUoKXt2YXIgdD1uYXZpZ2F0b3IudXNlckFnZW50RGF0YTtyZXR1cm4gbnVsbCE9dCYmdC5icmFuZHMmJkFycmF5LmlzQXJyYXkodC5icmFuZHMpP3QuYnJhbmRzLm1hcCgoZnVuY3Rpb24odCl7cmV0dXJuIHQuYnJhbmQrXCIvXCIrdC52ZXJzaW9ufSkpLmpvaW4oXCIgXCIpOm5hdmlnYXRvci51c2VyQWdlbnR9ZnVuY3Rpb24gQ2UoKXtyZXR1cm4hL14oKD8hY2hyb21lfGFuZHJvaWQpLikqc2FmYXJpL2kudGVzdChUZSgpKX1mdW5jdGlvbiBPZSh0LGUsaSl7dm9pZCAwPT09ZSYmKGU9ITEpLHZvaWQgMD09PWkmJihpPSExKTt2YXIgbj10LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLHM9MSxvPTE7ZSYmX2UodCkmJihzPXQub2Zmc2V0V2lkdGg+MCYmRWUobi53aWR0aCkvdC5vZmZzZXRXaWR0aHx8MSxvPXQub2Zmc2V0SGVpZ2h0PjAmJkVlKG4uaGVpZ2h0KS90Lm9mZnNldEhlaWdodHx8MSk7dmFyIHI9KGdlKHQpP21lKHQpOndpbmRvdykudmlzdWFsVmlld3BvcnQsYT0hQ2UoKSYmaSxsPShuLmxlZnQrKGEmJnI/ci5vZmZzZXRMZWZ0OjApKS9zLGM9KG4udG9wKyhhJiZyP3Iub2Zmc2V0VG9wOjApKS9vLGg9bi53aWR0aC9zLGQ9bi5oZWlnaHQvbztyZXR1cm57d2lkdGg6aCxoZWlnaHQ6ZCx0b3A6YyxyaWdodDpsK2gsYm90dG9tOmMrZCxsZWZ0OmwseDpsLHk6Y319ZnVuY3Rpb24geGUodCl7dmFyIGU9T2UodCksaT10Lm9mZnNldFdpZHRoLG49dC5vZmZzZXRIZWlnaHQ7cmV0dXJuIE1hdGguYWJzKGUud2lkdGgtaSk8PTEmJihpPWUud2lkdGgpLE1hdGguYWJzKGUuaGVpZ2h0LW4pPD0xJiYobj1lLmhlaWdodCkse3g6dC5vZmZzZXRMZWZ0LHk6dC5vZmZzZXRUb3Asd2lkdGg6aSxoZWlnaHQ6bn19ZnVuY3Rpb24ga2UodCxlKXt2YXIgaT1lLmdldFJvb3ROb2RlJiZlLmdldFJvb3ROb2RlKCk7aWYodC5jb250YWlucyhlKSlyZXR1cm4hMDtpZihpJiZiZShpKSl7dmFyIG49ZTtkb3tpZihuJiZ0LmlzU2FtZU5vZGUobikpcmV0dXJuITA7bj1uLnBhcmVudE5vZGV8fG4uaG9zdH13aGlsZShuKX1yZXR1cm4hMX1mdW5jdGlvbiBMZSh0KXtyZXR1cm4gbWUodCkuZ2V0Q29tcHV0ZWRTdHlsZSh0KX1mdW5jdGlvbiBTZSh0KXtyZXR1cm5bXCJ0YWJsZVwiLFwidGRcIixcInRoXCJdLmluZGV4T2YocGUodCkpPj0wfWZ1bmN0aW9uIERlKHQpe3JldHVybigoZ2UodCk/dC5vd25lckRvY3VtZW50OnQuZG9jdW1lbnQpfHx3aW5kb3cuZG9jdW1lbnQpLmRvY3VtZW50RWxlbWVudH1mdW5jdGlvbiAkZSh0KXtyZXR1cm5cImh0bWxcIj09PXBlKHQpP3Q6dC5hc3NpZ25lZFNsb3R8fHQucGFyZW50Tm9kZXx8KGJlKHQpP3QuaG9zdDpudWxsKXx8RGUodCl9ZnVuY3Rpb24gSWUodCl7cmV0dXJuIF9lKHQpJiZcImZpeGVkXCIhPT1MZSh0KS5wb3NpdGlvbj90Lm9mZnNldFBhcmVudDpudWxsfWZ1bmN0aW9uIE5lKHQpe2Zvcih2YXIgZT1tZSh0KSxpPUllKHQpO2kmJlNlKGkpJiZcInN0YXRpY1wiPT09TGUoaSkucG9zaXRpb247KWk9SWUoaSk7cmV0dXJuIGkmJihcImh0bWxcIj09PXBlKGkpfHxcImJvZHlcIj09PXBlKGkpJiZcInN0YXRpY1wiPT09TGUoaSkucG9zaXRpb24pP2U6aXx8ZnVuY3Rpb24odCl7dmFyIGU9L2ZpcmVmb3gvaS50ZXN0KFRlKCkpO2lmKC9UcmlkZW50L2kudGVzdChUZSgpKSYmX2UodCkmJlwiZml4ZWRcIj09PUxlKHQpLnBvc2l0aW9uKXJldHVybiBudWxsO3ZhciBpPSRlKHQpO2ZvcihiZShpKSYmKGk9aS5ob3N0KTtfZShpKSYmW1wiaHRtbFwiLFwiYm9keVwiXS5pbmRleE9mKHBlKGkpKTwwOyl7dmFyIG49TGUoaSk7aWYoXCJub25lXCIhPT1uLnRyYW5zZm9ybXx8XCJub25lXCIhPT1uLnBlcnNwZWN0aXZlfHxcInBhaW50XCI9PT1uLmNvbnRhaW58fC0xIT09W1widHJhbnNmb3JtXCIsXCJwZXJzcGVjdGl2ZVwiXS5pbmRleE9mKG4ud2lsbENoYW5nZSl8fGUmJlwiZmlsdGVyXCI9PT1uLndpbGxDaGFuZ2V8fGUmJm4uZmlsdGVyJiZcIm5vbmVcIiE9PW4uZmlsdGVyKXJldHVybiBpO2k9aS5wYXJlbnROb2RlfXJldHVybiBudWxsfSh0KXx8ZX1mdW5jdGlvbiBQZSh0KXtyZXR1cm5bXCJ0b3BcIixcImJvdHRvbVwiXS5pbmRleE9mKHQpPj0wP1wieFwiOlwieVwifWZ1bmN0aW9uIGplKHQsZSxpKXtyZXR1cm4gd2UodCxBZShlLGkpKX1mdW5jdGlvbiBNZSh0KXtyZXR1cm4gT2JqZWN0LmFzc2lnbih7fSx7dG9wOjAscmlnaHQ6MCxib3R0b206MCxsZWZ0OjB9LHQpfWZ1bmN0aW9uIEZlKHQsZSl7cmV0dXJuIGUucmVkdWNlKChmdW5jdGlvbihlLGkpe3JldHVybiBlW2ldPXQsZX0pLHt9KX1jb25zdCBIZT17bmFtZTpcImFycm93XCIsZW5hYmxlZDohMCxwaGFzZTpcIm1haW5cIixmbjpmdW5jdGlvbih0KXt2YXIgZSxpPXQuc3RhdGUsbj10Lm5hbWUscz10Lm9wdGlvbnMsbz1pLmVsZW1lbnRzLmFycm93LHI9aS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMsYT15ZShpLnBsYWNlbWVudCksbD1QZShhKSxjPVtRdCxLdF0uaW5kZXhPZihhKT49MD9cImhlaWdodFwiOlwid2lkdGhcIjtpZihvJiZyKXt2YXIgaD1mdW5jdGlvbih0LGUpe3JldHVybiBNZShcIm51bWJlclwiIT10eXBlb2YodD1cImZ1bmN0aW9uXCI9PXR5cGVvZiB0P3QoT2JqZWN0LmFzc2lnbih7fSxlLnJlY3RzLHtwbGFjZW1lbnQ6ZS5wbGFjZW1lbnR9KSk6dCk/dDpGZSh0LFl0KSl9KHMucGFkZGluZyxpKSxkPXhlKG8pLHU9XCJ5XCI9PT1sP3F0OlF0LGY9XCJ5XCI9PT1sP1Z0Okt0LHA9aS5yZWN0cy5yZWZlcmVuY2VbY10raS5yZWN0cy5yZWZlcmVuY2VbbF0tcltsXS1pLnJlY3RzLnBvcHBlcltjXSxtPXJbbF0taS5yZWN0cy5yZWZlcmVuY2VbbF0sZz1OZShvKSxfPWc/XCJ5XCI9PT1sP2cuY2xpZW50SGVpZ2h0fHwwOmcuY2xpZW50V2lkdGh8fDA6MCxiPXAvMi1tLzIsdj1oW3VdLHk9Xy1kW2NdLWhbZl0sdz1fLzItZFtjXS8yK2IsQT1qZSh2LHcseSksRT1sO2kubW9kaWZpZXJzRGF0YVtuXT0oKGU9e30pW0VdPUEsZS5jZW50ZXJPZmZzZXQ9QS13LGUpfX0sZWZmZWN0OmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGUsaT10Lm9wdGlvbnMuZWxlbWVudCxuPXZvaWQgMD09PWk/XCJbZGF0YS1wb3BwZXItYXJyb3ddXCI6aTtudWxsIT1uJiYoXCJzdHJpbmdcIiE9dHlwZW9mIG58fChuPWUuZWxlbWVudHMucG9wcGVyLnF1ZXJ5U2VsZWN0b3IobikpKSYma2UoZS5lbGVtZW50cy5wb3BwZXIsbikmJihlLmVsZW1lbnRzLmFycm93PW4pfSxyZXF1aXJlczpbXCJwb3BwZXJPZmZzZXRzXCJdLHJlcXVpcmVzSWZFeGlzdHM6W1wicHJldmVudE92ZXJmbG93XCJdfTtmdW5jdGlvbiBXZSh0KXtyZXR1cm4gdC5zcGxpdChcIi1cIilbMV19dmFyIEJlPXt0b3A6XCJhdXRvXCIscmlnaHQ6XCJhdXRvXCIsYm90dG9tOlwiYXV0b1wiLGxlZnQ6XCJhdXRvXCJ9O2Z1bmN0aW9uIHplKHQpe3ZhciBlLGk9dC5wb3BwZXIsbj10LnBvcHBlclJlY3Qscz10LnBsYWNlbWVudCxvPXQudmFyaWF0aW9uLHI9dC5vZmZzZXRzLGE9dC5wb3NpdGlvbixsPXQuZ3B1QWNjZWxlcmF0aW9uLGM9dC5hZGFwdGl2ZSxoPXQucm91bmRPZmZzZXRzLGQ9dC5pc0ZpeGVkLHU9ci54LGY9dm9pZCAwPT09dT8wOnUscD1yLnksbT12b2lkIDA9PT1wPzA6cCxnPVwiZnVuY3Rpb25cIj09dHlwZW9mIGg/aCh7eDpmLHk6bX0pOnt4OmYseTptfTtmPWcueCxtPWcueTt2YXIgXz1yLmhhc093blByb3BlcnR5KFwieFwiKSxiPXIuaGFzT3duUHJvcGVydHkoXCJ5XCIpLHY9UXQseT1xdCx3PXdpbmRvdztpZihjKXt2YXIgQT1OZShpKSxFPVwiY2xpZW50SGVpZ2h0XCIsVD1cImNsaWVudFdpZHRoXCI7QT09PW1lKGkpJiZcInN0YXRpY1wiIT09TGUoQT1EZShpKSkucG9zaXRpb24mJlwiYWJzb2x1dGVcIj09PWEmJihFPVwic2Nyb2xsSGVpZ2h0XCIsVD1cInNjcm9sbFdpZHRoXCIpLChzPT09cXR8fChzPT09UXR8fHM9PT1LdCkmJm89PT1HdCkmJih5PVZ0LG0tPShkJiZBPT09dyYmdy52aXN1YWxWaWV3cG9ydD93LnZpc3VhbFZpZXdwb3J0LmhlaWdodDpBW0VdKS1uLmhlaWdodCxtKj1sPzE6LTEpLHMhPT1RdCYmKHMhPT1xdCYmcyE9PVZ0fHxvIT09R3QpfHwodj1LdCxmLT0oZCYmQT09PXcmJncudmlzdWFsVmlld3BvcnQ/dy52aXN1YWxWaWV3cG9ydC53aWR0aDpBW1RdKS1uLndpZHRoLGYqPWw/MTotMSl9dmFyIEMsTz1PYmplY3QuYXNzaWduKHtwb3NpdGlvbjphfSxjJiZCZSkseD0hMD09PWg/ZnVuY3Rpb24odCxlKXt2YXIgaT10Lngsbj10Lnkscz1lLmRldmljZVBpeGVsUmF0aW98fDE7cmV0dXJue3g6RWUoaSpzKS9zfHwwLHk6RWUobipzKS9zfHwwfX0oe3g6Zix5Om19LG1lKGkpKTp7eDpmLHk6bX07cmV0dXJuIGY9eC54LG09eC55LGw/T2JqZWN0LmFzc2lnbih7fSxPLCgoQz17fSlbeV09Yj9cIjBcIjpcIlwiLENbdl09Xz9cIjBcIjpcIlwiLEMudHJhbnNmb3JtPSh3LmRldmljZVBpeGVsUmF0aW98fDEpPD0xP1widHJhbnNsYXRlKFwiK2YrXCJweCwgXCIrbStcInB4KVwiOlwidHJhbnNsYXRlM2QoXCIrZitcInB4LCBcIittK1wicHgsIDApXCIsQykpOk9iamVjdC5hc3NpZ24oe30sTywoKGU9e30pW3ldPWI/bStcInB4XCI6XCJcIixlW3ZdPV8/ZitcInB4XCI6XCJcIixlLnRyYW5zZm9ybT1cIlwiLGUpKX1jb25zdCBSZT17bmFtZTpcImNvbXB1dGVTdHlsZXNcIixlbmFibGVkOiEwLHBoYXNlOlwiYmVmb3JlV3JpdGVcIixmbjpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5vcHRpb25zLG49aS5ncHVBY2NlbGVyYXRpb24scz12b2lkIDA9PT1ufHxuLG89aS5hZGFwdGl2ZSxyPXZvaWQgMD09PW98fG8sYT1pLnJvdW5kT2Zmc2V0cyxsPXZvaWQgMD09PWF8fGEsYz17cGxhY2VtZW50OnllKGUucGxhY2VtZW50KSx2YXJpYXRpb246V2UoZS5wbGFjZW1lbnQpLHBvcHBlcjplLmVsZW1lbnRzLnBvcHBlcixwb3BwZXJSZWN0OmUucmVjdHMucG9wcGVyLGdwdUFjY2VsZXJhdGlvbjpzLGlzRml4ZWQ6XCJmaXhlZFwiPT09ZS5vcHRpb25zLnN0cmF0ZWd5fTtudWxsIT1lLm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cyYmKGUuc3R5bGVzLnBvcHBlcj1PYmplY3QuYXNzaWduKHt9LGUuc3R5bGVzLnBvcHBlcix6ZShPYmplY3QuYXNzaWduKHt9LGMse29mZnNldHM6ZS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMscG9zaXRpb246ZS5vcHRpb25zLnN0cmF0ZWd5LGFkYXB0aXZlOnIscm91bmRPZmZzZXRzOmx9KSkpKSxudWxsIT1lLm1vZGlmaWVyc0RhdGEuYXJyb3cmJihlLnN0eWxlcy5hcnJvdz1PYmplY3QuYXNzaWduKHt9LGUuc3R5bGVzLmFycm93LHplKE9iamVjdC5hc3NpZ24oe30sYyx7b2Zmc2V0czplLm1vZGlmaWVyc0RhdGEuYXJyb3cscG9zaXRpb246XCJhYnNvbHV0ZVwiLGFkYXB0aXZlOiExLHJvdW5kT2Zmc2V0czpsfSkpKSksZS5hdHRyaWJ1dGVzLnBvcHBlcj1PYmplY3QuYXNzaWduKHt9LGUuYXR0cmlidXRlcy5wb3BwZXIse1wiZGF0YS1wb3BwZXItcGxhY2VtZW50XCI6ZS5wbGFjZW1lbnR9KX0sZGF0YTp7fX07dmFyIHFlPXtwYXNzaXZlOiEwfTtjb25zdCBWZT17bmFtZTpcImV2ZW50TGlzdGVuZXJzXCIsZW5hYmxlZDohMCxwaGFzZTpcIndyaXRlXCIsZm46ZnVuY3Rpb24oKXt9LGVmZmVjdDpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5pbnN0YW5jZSxuPXQub3B0aW9ucyxzPW4uc2Nyb2xsLG89dm9pZCAwPT09c3x8cyxyPW4ucmVzaXplLGE9dm9pZCAwPT09cnx8cixsPW1lKGUuZWxlbWVudHMucG9wcGVyKSxjPVtdLmNvbmNhdChlLnNjcm9sbFBhcmVudHMucmVmZXJlbmNlLGUuc2Nyb2xsUGFyZW50cy5wb3BwZXIpO3JldHVybiBvJiZjLmZvckVhY2goKGZ1bmN0aW9uKHQpe3QuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLGkudXBkYXRlLHFlKX0pKSxhJiZsLmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIixpLnVwZGF0ZSxxZSksZnVuY3Rpb24oKXtvJiZjLmZvckVhY2goKGZ1bmN0aW9uKHQpe3QucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLGkudXBkYXRlLHFlKX0pKSxhJiZsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIixpLnVwZGF0ZSxxZSl9fSxkYXRhOnt9fTt2YXIgS2U9e2xlZnQ6XCJyaWdodFwiLHJpZ2h0OlwibGVmdFwiLGJvdHRvbTpcInRvcFwiLHRvcDpcImJvdHRvbVwifTtmdW5jdGlvbiBRZSh0KXtyZXR1cm4gdC5yZXBsYWNlKC9sZWZ0fHJpZ2h0fGJvdHRvbXx0b3AvZywoZnVuY3Rpb24odCl7cmV0dXJuIEtlW3RdfSkpfXZhciBYZT17c3RhcnQ6XCJlbmRcIixlbmQ6XCJzdGFydFwifTtmdW5jdGlvbiBZZSh0KXtyZXR1cm4gdC5yZXBsYWNlKC9zdGFydHxlbmQvZywoZnVuY3Rpb24odCl7cmV0dXJuIFhlW3RdfSkpfWZ1bmN0aW9uIFVlKHQpe3ZhciBlPW1lKHQpO3JldHVybntzY3JvbGxMZWZ0OmUucGFnZVhPZmZzZXQsc2Nyb2xsVG9wOmUucGFnZVlPZmZzZXR9fWZ1bmN0aW9uIEdlKHQpe3JldHVybiBPZShEZSh0KSkubGVmdCtVZSh0KS5zY3JvbGxMZWZ0fWZ1bmN0aW9uIEplKHQpe3ZhciBlPUxlKHQpLGk9ZS5vdmVyZmxvdyxuPWUub3ZlcmZsb3dYLHM9ZS5vdmVyZmxvd1k7cmV0dXJuL2F1dG98c2Nyb2xsfG92ZXJsYXl8aGlkZGVuLy50ZXN0KGkrcytuKX1mdW5jdGlvbiBaZSh0KXtyZXR1cm5bXCJodG1sXCIsXCJib2R5XCIsXCIjZG9jdW1lbnRcIl0uaW5kZXhPZihwZSh0KSk+PTA/dC5vd25lckRvY3VtZW50LmJvZHk6X2UodCkmJkplKHQpP3Q6WmUoJGUodCkpfWZ1bmN0aW9uIHRpKHQsZSl7dmFyIGk7dm9pZCAwPT09ZSYmKGU9W10pO3ZhciBuPVplKHQpLHM9bj09PShudWxsPT0oaT10Lm93bmVyRG9jdW1lbnQpP3ZvaWQgMDppLmJvZHkpLG89bWUobikscj1zP1tvXS5jb25jYXQoby52aXN1YWxWaWV3cG9ydHx8W10sSmUobik/bjpbXSk6bixhPWUuY29uY2F0KHIpO3JldHVybiBzP2E6YS5jb25jYXQodGkoJGUocikpKX1mdW5jdGlvbiBlaSh0KXtyZXR1cm4gT2JqZWN0LmFzc2lnbih7fSx0LHtsZWZ0OnQueCx0b3A6dC55LHJpZ2h0OnQueCt0LndpZHRoLGJvdHRvbTp0LnkrdC5oZWlnaHR9KX1mdW5jdGlvbiBpaSh0LGUsaSl7cmV0dXJuIGU9PT1adD9laShmdW5jdGlvbih0LGUpe3ZhciBpPW1lKHQpLG49RGUodCkscz1pLnZpc3VhbFZpZXdwb3J0LG89bi5jbGllbnRXaWR0aCxyPW4uY2xpZW50SGVpZ2h0LGE9MCxsPTA7aWYocyl7bz1zLndpZHRoLHI9cy5oZWlnaHQ7dmFyIGM9Q2UoKTsoY3x8IWMmJlwiZml4ZWRcIj09PWUpJiYoYT1zLm9mZnNldExlZnQsbD1zLm9mZnNldFRvcCl9cmV0dXJue3dpZHRoOm8saGVpZ2h0OnIseDphK0dlKHQpLHk6bH19KHQsaSkpOmdlKGUpP2Z1bmN0aW9uKHQsZSl7dmFyIGk9T2UodCwhMSxcImZpeGVkXCI9PT1lKTtyZXR1cm4gaS50b3A9aS50b3ArdC5jbGllbnRUb3AsaS5sZWZ0PWkubGVmdCt0LmNsaWVudExlZnQsaS5ib3R0b209aS50b3ArdC5jbGllbnRIZWlnaHQsaS5yaWdodD1pLmxlZnQrdC5jbGllbnRXaWR0aCxpLndpZHRoPXQuY2xpZW50V2lkdGgsaS5oZWlnaHQ9dC5jbGllbnRIZWlnaHQsaS54PWkubGVmdCxpLnk9aS50b3AsaX0oZSxpKTplaShmdW5jdGlvbih0KXt2YXIgZSxpPURlKHQpLG49VWUodCkscz1udWxsPT0oZT10Lm93bmVyRG9jdW1lbnQpP3ZvaWQgMDplLmJvZHksbz13ZShpLnNjcm9sbFdpZHRoLGkuY2xpZW50V2lkdGgscz9zLnNjcm9sbFdpZHRoOjAscz9zLmNsaWVudFdpZHRoOjApLHI9d2UoaS5zY3JvbGxIZWlnaHQsaS5jbGllbnRIZWlnaHQscz9zLnNjcm9sbEhlaWdodDowLHM/cy5jbGllbnRIZWlnaHQ6MCksYT0tbi5zY3JvbGxMZWZ0K0dlKHQpLGw9LW4uc2Nyb2xsVG9wO3JldHVyblwicnRsXCI9PT1MZShzfHxpKS5kaXJlY3Rpb24mJihhKz13ZShpLmNsaWVudFdpZHRoLHM/cy5jbGllbnRXaWR0aDowKS1vKSx7d2lkdGg6byxoZWlnaHQ6cix4OmEseTpsfX0oRGUodCkpKX1mdW5jdGlvbiBuaSh0KXt2YXIgZSxpPXQucmVmZXJlbmNlLG49dC5lbGVtZW50LHM9dC5wbGFjZW1lbnQsbz1zP3llKHMpOm51bGwscj1zP1dlKHMpOm51bGwsYT1pLngraS53aWR0aC8yLW4ud2lkdGgvMixsPWkueStpLmhlaWdodC8yLW4uaGVpZ2h0LzI7c3dpdGNoKG8pe2Nhc2UgcXQ6ZT17eDphLHk6aS55LW4uaGVpZ2h0fTticmVhaztjYXNlIFZ0OmU9e3g6YSx5OmkueStpLmhlaWdodH07YnJlYWs7Y2FzZSBLdDplPXt4OmkueCtpLndpZHRoLHk6bH07YnJlYWs7Y2FzZSBRdDplPXt4OmkueC1uLndpZHRoLHk6bH07YnJlYWs7ZGVmYXVsdDplPXt4OmkueCx5OmkueX19dmFyIGM9bz9QZShvKTpudWxsO2lmKG51bGwhPWMpe3ZhciBoPVwieVwiPT09Yz9cImhlaWdodFwiOlwid2lkdGhcIjtzd2l0Y2gocil7Y2FzZSBVdDplW2NdPWVbY10tKGlbaF0vMi1uW2hdLzIpO2JyZWFrO2Nhc2UgR3Q6ZVtjXT1lW2NdKyhpW2hdLzItbltoXS8yKX19cmV0dXJuIGV9ZnVuY3Rpb24gc2kodCxlKXt2b2lkIDA9PT1lJiYoZT17fSk7dmFyIGk9ZSxuPWkucGxhY2VtZW50LHM9dm9pZCAwPT09bj90LnBsYWNlbWVudDpuLG89aS5zdHJhdGVneSxyPXZvaWQgMD09PW8/dC5zdHJhdGVneTpvLGE9aS5ib3VuZGFyeSxsPXZvaWQgMD09PWE/SnQ6YSxjPWkucm9vdEJvdW5kYXJ5LGg9dm9pZCAwPT09Yz9adDpjLGQ9aS5lbGVtZW50Q29udGV4dCx1PXZvaWQgMD09PWQ/dGU6ZCxmPWkuYWx0Qm91bmRhcnkscD12b2lkIDAhPT1mJiZmLG09aS5wYWRkaW5nLGc9dm9pZCAwPT09bT8wOm0sXz1NZShcIm51bWJlclwiIT10eXBlb2YgZz9nOkZlKGcsWXQpKSxiPXU9PT10ZT9lZTp0ZSx2PXQucmVjdHMucG9wcGVyLHk9dC5lbGVtZW50c1twP2I6dV0sdz1mdW5jdGlvbih0LGUsaSxuKXt2YXIgcz1cImNsaXBwaW5nUGFyZW50c1wiPT09ZT9mdW5jdGlvbih0KXt2YXIgZT10aSgkZSh0KSksaT1bXCJhYnNvbHV0ZVwiLFwiZml4ZWRcIl0uaW5kZXhPZihMZSh0KS5wb3NpdGlvbik+PTAmJl9lKHQpP05lKHQpOnQ7cmV0dXJuIGdlKGkpP2UuZmlsdGVyKChmdW5jdGlvbih0KXtyZXR1cm4gZ2UodCkmJmtlKHQsaSkmJlwiYm9keVwiIT09cGUodCl9KSk6W119KHQpOltdLmNvbmNhdChlKSxvPVtdLmNvbmNhdChzLFtpXSkscj1vWzBdLGE9by5yZWR1Y2UoKGZ1bmN0aW9uKGUsaSl7dmFyIHM9aWkodCxpLG4pO3JldHVybiBlLnRvcD13ZShzLnRvcCxlLnRvcCksZS5yaWdodD1BZShzLnJpZ2h0LGUucmlnaHQpLGUuYm90dG9tPUFlKHMuYm90dG9tLGUuYm90dG9tKSxlLmxlZnQ9d2Uocy5sZWZ0LGUubGVmdCksZX0pLGlpKHQscixuKSk7cmV0dXJuIGEud2lkdGg9YS5yaWdodC1hLmxlZnQsYS5oZWlnaHQ9YS5ib3R0b20tYS50b3AsYS54PWEubGVmdCxhLnk9YS50b3AsYX0oZ2UoeSk/eTp5LmNvbnRleHRFbGVtZW50fHxEZSh0LmVsZW1lbnRzLnBvcHBlciksbCxoLHIpLEE9T2UodC5lbGVtZW50cy5yZWZlcmVuY2UpLEU9bmkoe3JlZmVyZW5jZTpBLGVsZW1lbnQ6dixwbGFjZW1lbnQ6c30pLFQ9ZWkoT2JqZWN0LmFzc2lnbih7fSx2LEUpKSxDPXU9PT10ZT9UOkEsTz17dG9wOncudG9wLUMudG9wK18udG9wLGJvdHRvbTpDLmJvdHRvbS13LmJvdHRvbStfLmJvdHRvbSxsZWZ0OncubGVmdC1DLmxlZnQrXy5sZWZ0LHJpZ2h0OkMucmlnaHQtdy5yaWdodCtfLnJpZ2h0fSx4PXQubW9kaWZpZXJzRGF0YS5vZmZzZXQ7aWYodT09PXRlJiZ4KXt2YXIgaz14W3NdO09iamVjdC5rZXlzKE8pLmZvckVhY2goKGZ1bmN0aW9uKHQpe3ZhciBlPVtLdCxWdF0uaW5kZXhPZih0KT49MD8xOi0xLGk9W3F0LFZ0XS5pbmRleE9mKHQpPj0wP1wieVwiOlwieFwiO09bdF0rPWtbaV0qZX0pKX1yZXR1cm4gT31mdW5jdGlvbiBvaSh0LGUpe3ZvaWQgMD09PWUmJihlPXt9KTt2YXIgaT1lLG49aS5wbGFjZW1lbnQscz1pLmJvdW5kYXJ5LG89aS5yb290Qm91bmRhcnkscj1pLnBhZGRpbmcsYT1pLmZsaXBWYXJpYXRpb25zLGw9aS5hbGxvd2VkQXV0b1BsYWNlbWVudHMsYz12b2lkIDA9PT1sP25lOmwsaD1XZShuKSxkPWg/YT9pZTppZS5maWx0ZXIoKGZ1bmN0aW9uKHQpe3JldHVybiBXZSh0KT09PWh9KSk6WXQsdT1kLmZpbHRlcigoZnVuY3Rpb24odCl7cmV0dXJuIGMuaW5kZXhPZih0KT49MH0pKTswPT09dS5sZW5ndGgmJih1PWQpO3ZhciBmPXUucmVkdWNlKChmdW5jdGlvbihlLGkpe3JldHVybiBlW2ldPXNpKHQse3BsYWNlbWVudDppLGJvdW5kYXJ5OnMscm9vdEJvdW5kYXJ5Om8scGFkZGluZzpyfSlbeWUoaSldLGV9KSx7fSk7cmV0dXJuIE9iamVjdC5rZXlzKGYpLnNvcnQoKGZ1bmN0aW9uKHQsZSl7cmV0dXJuIGZbdF0tZltlXX0pKX1jb25zdCByaT17bmFtZTpcImZsaXBcIixlbmFibGVkOiEwLHBoYXNlOlwibWFpblwiLGZuOmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGUsaT10Lm9wdGlvbnMsbj10Lm5hbWU7aWYoIWUubW9kaWZpZXJzRGF0YVtuXS5fc2tpcCl7Zm9yKHZhciBzPWkubWFpbkF4aXMsbz12b2lkIDA9PT1zfHxzLHI9aS5hbHRBeGlzLGE9dm9pZCAwPT09cnx8cixsPWkuZmFsbGJhY2tQbGFjZW1lbnRzLGM9aS5wYWRkaW5nLGg9aS5ib3VuZGFyeSxkPWkucm9vdEJvdW5kYXJ5LHU9aS5hbHRCb3VuZGFyeSxmPWkuZmxpcFZhcmlhdGlvbnMscD12b2lkIDA9PT1mfHxmLG09aS5hbGxvd2VkQXV0b1BsYWNlbWVudHMsZz1lLm9wdGlvbnMucGxhY2VtZW50LF89eWUoZyksYj1sfHwoXyE9PWcmJnA/ZnVuY3Rpb24odCl7aWYoeWUodCk9PT1YdClyZXR1cm5bXTt2YXIgZT1RZSh0KTtyZXR1cm5bWWUodCksZSxZZShlKV19KGcpOltRZShnKV0pLHY9W2ddLmNvbmNhdChiKS5yZWR1Y2UoKGZ1bmN0aW9uKHQsaSl7cmV0dXJuIHQuY29uY2F0KHllKGkpPT09WHQ/b2koZSx7cGxhY2VtZW50OmksYm91bmRhcnk6aCxyb290Qm91bmRhcnk6ZCxwYWRkaW5nOmMsZmxpcFZhcmlhdGlvbnM6cCxhbGxvd2VkQXV0b1BsYWNlbWVudHM6bX0pOmkpfSksW10pLHk9ZS5yZWN0cy5yZWZlcmVuY2Usdz1lLnJlY3RzLnBvcHBlcixBPW5ldyBNYXAsRT0hMCxUPXZbMF0sQz0wO0M8di5sZW5ndGg7QysrKXt2YXIgTz12W0NdLHg9eWUoTyksaz1XZShPKT09PVV0LEw9W3F0LFZ0XS5pbmRleE9mKHgpPj0wLFM9TD9cIndpZHRoXCI6XCJoZWlnaHRcIixEPXNpKGUse3BsYWNlbWVudDpPLGJvdW5kYXJ5Omgscm9vdEJvdW5kYXJ5OmQsYWx0Qm91bmRhcnk6dSxwYWRkaW5nOmN9KSwkPUw/az9LdDpRdDprP1Z0OnF0O3lbU10+d1tTXSYmKCQ9UWUoJCkpO3ZhciBJPVFlKCQpLE49W107aWYobyYmTi5wdXNoKERbeF08PTApLGEmJk4ucHVzaChEWyRdPD0wLERbSV08PTApLE4uZXZlcnkoKGZ1bmN0aW9uKHQpe3JldHVybiB0fSkpKXtUPU8sRT0hMTticmVha31BLnNldChPLE4pfWlmKEUpZm9yKHZhciBQPWZ1bmN0aW9uKHQpe3ZhciBlPXYuZmluZCgoZnVuY3Rpb24oZSl7dmFyIGk9QS5nZXQoZSk7aWYoaSlyZXR1cm4gaS5zbGljZSgwLHQpLmV2ZXJ5KChmdW5jdGlvbih0KXtyZXR1cm4gdH0pKX0pKTtpZihlKXJldHVybiBUPWUsXCJicmVha1wifSxqPXA/MzoxO2o+MCYmXCJicmVha1wiIT09UChqKTtqLS0pO2UucGxhY2VtZW50IT09VCYmKGUubW9kaWZpZXJzRGF0YVtuXS5fc2tpcD0hMCxlLnBsYWNlbWVudD1ULGUucmVzZXQ9ITApfX0scmVxdWlyZXNJZkV4aXN0czpbXCJvZmZzZXRcIl0sZGF0YTp7X3NraXA6ITF9fTtmdW5jdGlvbiBhaSh0LGUsaSl7cmV0dXJuIHZvaWQgMD09PWkmJihpPXt4OjAseTowfSkse3RvcDp0LnRvcC1lLmhlaWdodC1pLnkscmlnaHQ6dC5yaWdodC1lLndpZHRoK2kueCxib3R0b206dC5ib3R0b20tZS5oZWlnaHQraS55LGxlZnQ6dC5sZWZ0LWUud2lkdGgtaS54fX1mdW5jdGlvbiBsaSh0KXtyZXR1cm5bcXQsS3QsVnQsUXRdLnNvbWUoKGZ1bmN0aW9uKGUpe3JldHVybiB0W2VdPj0wfSkpfWNvbnN0IGNpPXtuYW1lOlwiaGlkZVwiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIscmVxdWlyZXNJZkV4aXN0czpbXCJwcmV2ZW50T3ZlcmZsb3dcIl0sZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXQubmFtZSxuPWUucmVjdHMucmVmZXJlbmNlLHM9ZS5yZWN0cy5wb3BwZXIsbz1lLm1vZGlmaWVyc0RhdGEucHJldmVudE92ZXJmbG93LHI9c2koZSx7ZWxlbWVudENvbnRleHQ6XCJyZWZlcmVuY2VcIn0pLGE9c2koZSx7YWx0Qm91bmRhcnk6ITB9KSxsPWFpKHIsbiksYz1haShhLHMsbyksaD1saShsKSxkPWxpKGMpO2UubW9kaWZpZXJzRGF0YVtpXT17cmVmZXJlbmNlQ2xpcHBpbmdPZmZzZXRzOmwscG9wcGVyRXNjYXBlT2Zmc2V0czpjLGlzUmVmZXJlbmNlSGlkZGVuOmgsaGFzUG9wcGVyRXNjYXBlZDpkfSxlLmF0dHJpYnV0ZXMucG9wcGVyPU9iamVjdC5hc3NpZ24oe30sZS5hdHRyaWJ1dGVzLnBvcHBlcix7XCJkYXRhLXBvcHBlci1yZWZlcmVuY2UtaGlkZGVuXCI6aCxcImRhdGEtcG9wcGVyLWVzY2FwZWRcIjpkfSl9fSxoaT17bmFtZTpcIm9mZnNldFwiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIscmVxdWlyZXM6W1wicG9wcGVyT2Zmc2V0c1wiXSxmbjpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5vcHRpb25zLG49dC5uYW1lLHM9aS5vZmZzZXQsbz12b2lkIDA9PT1zP1swLDBdOnMscj1uZS5yZWR1Y2UoKGZ1bmN0aW9uKHQsaSl7cmV0dXJuIHRbaV09ZnVuY3Rpb24odCxlLGkpe3ZhciBuPXllKHQpLHM9W1F0LHF0XS5pbmRleE9mKG4pPj0wPy0xOjEsbz1cImZ1bmN0aW9uXCI9PXR5cGVvZiBpP2koT2JqZWN0LmFzc2lnbih7fSxlLHtwbGFjZW1lbnQ6dH0pKTppLHI9b1swXSxhPW9bMV07cmV0dXJuIHI9cnx8MCxhPShhfHwwKSpzLFtRdCxLdF0uaW5kZXhPZihuKT49MD97eDphLHk6cn06e3g6cix5OmF9fShpLGUucmVjdHMsbyksdH0pLHt9KSxhPXJbZS5wbGFjZW1lbnRdLGw9YS54LGM9YS55O251bGwhPWUubW9kaWZpZXJzRGF0YS5wb3BwZXJPZmZzZXRzJiYoZS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMueCs9bCxlLm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cy55Kz1jKSxlLm1vZGlmaWVyc0RhdGFbbl09cn19LGRpPXtuYW1lOlwicG9wcGVyT2Zmc2V0c1wiLGVuYWJsZWQ6ITAscGhhc2U6XCJyZWFkXCIsZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXQubmFtZTtlLm1vZGlmaWVyc0RhdGFbaV09bmkoe3JlZmVyZW5jZTplLnJlY3RzLnJlZmVyZW5jZSxlbGVtZW50OmUucmVjdHMucG9wcGVyLHBsYWNlbWVudDplLnBsYWNlbWVudH0pfSxkYXRhOnt9fSx1aT17bmFtZTpcInByZXZlbnRPdmVyZmxvd1wiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIsZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXQub3B0aW9ucyxuPXQubmFtZSxzPWkubWFpbkF4aXMsbz12b2lkIDA9PT1zfHxzLHI9aS5hbHRBeGlzLGE9dm9pZCAwIT09ciYmcixsPWkuYm91bmRhcnksYz1pLnJvb3RCb3VuZGFyeSxoPWkuYWx0Qm91bmRhcnksZD1pLnBhZGRpbmcsdT1pLnRldGhlcixmPXZvaWQgMD09PXV8fHUscD1pLnRldGhlck9mZnNldCxtPXZvaWQgMD09PXA/MDpwLGc9c2koZSx7Ym91bmRhcnk6bCxyb290Qm91bmRhcnk6YyxwYWRkaW5nOmQsYWx0Qm91bmRhcnk6aH0pLF89eWUoZS5wbGFjZW1lbnQpLGI9V2UoZS5wbGFjZW1lbnQpLHY9IWIseT1QZShfKSx3PVwieFwiPT09eT9cInlcIjpcInhcIixBPWUubW9kaWZpZXJzRGF0YS5wb3BwZXJPZmZzZXRzLEU9ZS5yZWN0cy5yZWZlcmVuY2UsVD1lLnJlY3RzLnBvcHBlcixDPVwiZnVuY3Rpb25cIj09dHlwZW9mIG0/bShPYmplY3QuYXNzaWduKHt9LGUucmVjdHMse3BsYWNlbWVudDplLnBsYWNlbWVudH0pKTptLE89XCJudW1iZXJcIj09dHlwZW9mIEM/e21haW5BeGlzOkMsYWx0QXhpczpDfTpPYmplY3QuYXNzaWduKHttYWluQXhpczowLGFsdEF4aXM6MH0sQykseD1lLm1vZGlmaWVyc0RhdGEub2Zmc2V0P2UubW9kaWZpZXJzRGF0YS5vZmZzZXRbZS5wbGFjZW1lbnRdOm51bGwsaz17eDowLHk6MH07aWYoQSl7aWYobyl7dmFyIEwsUz1cInlcIj09PXk/cXQ6UXQsRD1cInlcIj09PXk/VnQ6S3QsJD1cInlcIj09PXk/XCJoZWlnaHRcIjpcIndpZHRoXCIsST1BW3ldLE49SStnW1NdLFA9SS1nW0RdLGo9Zj8tVFskXS8yOjAsTT1iPT09VXQ/RVskXTpUWyRdLEY9Yj09PVV0Py1UWyRdOi1FWyRdLEg9ZS5lbGVtZW50cy5hcnJvdyxXPWYmJkg/eGUoSCk6e3dpZHRoOjAsaGVpZ2h0OjB9LEI9ZS5tb2RpZmllcnNEYXRhW1wiYXJyb3cjcGVyc2lzdGVudFwiXT9lLm1vZGlmaWVyc0RhdGFbXCJhcnJvdyNwZXJzaXN0ZW50XCJdLnBhZGRpbmc6e3RvcDowLHJpZ2h0OjAsYm90dG9tOjAsbGVmdDowfSx6PUJbU10sUj1CW0RdLHE9amUoMCxFWyRdLFdbJF0pLFY9dj9FWyRdLzItai1xLXotTy5tYWluQXhpczpNLXEtei1PLm1haW5BeGlzLEs9dj8tRVskXS8yK2orcStSK08ubWFpbkF4aXM6RitxK1IrTy5tYWluQXhpcyxRPWUuZWxlbWVudHMuYXJyb3cmJk5lKGUuZWxlbWVudHMuYXJyb3cpLFg9UT9cInlcIj09PXk/US5jbGllbnRUb3B8fDA6US5jbGllbnRMZWZ0fHwwOjAsWT1udWxsIT0oTD1udWxsPT14P3ZvaWQgMDp4W3ldKT9MOjAsVT1JK0stWSxHPWplKGY/QWUoTixJK1YtWS1YKTpOLEksZj93ZShQLFUpOlApO0FbeV09RyxrW3ldPUctSX1pZihhKXt2YXIgSixaPVwieFwiPT09eT9xdDpRdCx0dD1cInhcIj09PXk/VnQ6S3QsZXQ9QVt3XSxpdD1cInlcIj09PXc/XCJoZWlnaHRcIjpcIndpZHRoXCIsbnQ9ZXQrZ1taXSxzdD1ldC1nW3R0XSxvdD0tMSE9PVtxdCxRdF0uaW5kZXhPZihfKSxydD1udWxsIT0oSj1udWxsPT14P3ZvaWQgMDp4W3ddKT9KOjAsYXQ9b3Q/bnQ6ZXQtRVtpdF0tVFtpdF0tcnQrTy5hbHRBeGlzLGx0PW90P2V0K0VbaXRdK1RbaXRdLXJ0LU8uYWx0QXhpczpzdCxjdD1mJiZvdD9mdW5jdGlvbih0LGUsaSl7dmFyIG49amUodCxlLGkpO3JldHVybiBuPmk/aTpufShhdCxldCxsdCk6amUoZj9hdDpudCxldCxmP2x0OnN0KTtBW3ddPWN0LGtbd109Y3QtZXR9ZS5tb2RpZmllcnNEYXRhW25dPWt9fSxyZXF1aXJlc0lmRXhpc3RzOltcIm9mZnNldFwiXX07ZnVuY3Rpb24gZmkodCxlLGkpe3ZvaWQgMD09PWkmJihpPSExKTt2YXIgbixzLG89X2UoZSkscj1fZShlKSYmZnVuY3Rpb24odCl7dmFyIGU9dC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxpPUVlKGUud2lkdGgpL3Qub2Zmc2V0V2lkdGh8fDEsbj1FZShlLmhlaWdodCkvdC5vZmZzZXRIZWlnaHR8fDE7cmV0dXJuIDEhPT1pfHwxIT09bn0oZSksYT1EZShlKSxsPU9lKHQscixpKSxjPXtzY3JvbGxMZWZ0OjAsc2Nyb2xsVG9wOjB9LGg9e3g6MCx5OjB9O3JldHVybihvfHwhbyYmIWkpJiYoKFwiYm9keVwiIT09cGUoZSl8fEplKGEpKSYmKGM9KG49ZSkhPT1tZShuKSYmX2Uobik/e3Njcm9sbExlZnQ6KHM9bikuc2Nyb2xsTGVmdCxzY3JvbGxUb3A6cy5zY3JvbGxUb3B9OlVlKG4pKSxfZShlKT8oKGg9T2UoZSwhMCkpLngrPWUuY2xpZW50TGVmdCxoLnkrPWUuY2xpZW50VG9wKTphJiYoaC54PUdlKGEpKSkse3g6bC5sZWZ0K2Muc2Nyb2xsTGVmdC1oLngseTpsLnRvcCtjLnNjcm9sbFRvcC1oLnksd2lkdGg6bC53aWR0aCxoZWlnaHQ6bC5oZWlnaHR9fWZ1bmN0aW9uIHBpKHQpe3ZhciBlPW5ldyBNYXAsaT1uZXcgU2V0LG49W107ZnVuY3Rpb24gcyh0KXtpLmFkZCh0Lm5hbWUpLFtdLmNvbmNhdCh0LnJlcXVpcmVzfHxbXSx0LnJlcXVpcmVzSWZFeGlzdHN8fFtdKS5mb3JFYWNoKChmdW5jdGlvbih0KXtpZighaS5oYXModCkpe3ZhciBuPWUuZ2V0KHQpO24mJnMobil9fSkpLG4ucHVzaCh0KX1yZXR1cm4gdC5mb3JFYWNoKChmdW5jdGlvbih0KXtlLnNldCh0Lm5hbWUsdCl9KSksdC5mb3JFYWNoKChmdW5jdGlvbih0KXtpLmhhcyh0Lm5hbWUpfHxzKHQpfSkpLG59dmFyIG1pPXtwbGFjZW1lbnQ6XCJib3R0b21cIixtb2RpZmllcnM6W10sc3RyYXRlZ3k6XCJhYnNvbHV0ZVwifTtmdW5jdGlvbiBnaSgpe2Zvcih2YXIgdD1hcmd1bWVudHMubGVuZ3RoLGU9bmV3IEFycmF5KHQpLGk9MDtpPHQ7aSsrKWVbaV09YXJndW1lbnRzW2ldO3JldHVybiFlLnNvbWUoKGZ1bmN0aW9uKHQpe3JldHVybiEodCYmXCJmdW5jdGlvblwiPT10eXBlb2YgdC5nZXRCb3VuZGluZ0NsaWVudFJlY3QpfSkpfWZ1bmN0aW9uIF9pKHQpe3ZvaWQgMD09PXQmJih0PXt9KTt2YXIgZT10LGk9ZS5kZWZhdWx0TW9kaWZpZXJzLG49dm9pZCAwPT09aT9bXTppLHM9ZS5kZWZhdWx0T3B0aW9ucyxvPXZvaWQgMD09PXM/bWk6cztyZXR1cm4gZnVuY3Rpb24odCxlLGkpe3ZvaWQgMD09PWkmJihpPW8pO3ZhciBzLHIsYT17cGxhY2VtZW50OlwiYm90dG9tXCIsb3JkZXJlZE1vZGlmaWVyczpbXSxvcHRpb25zOk9iamVjdC5hc3NpZ24oe30sbWksbyksbW9kaWZpZXJzRGF0YTp7fSxlbGVtZW50czp7cmVmZXJlbmNlOnQscG9wcGVyOmV9LGF0dHJpYnV0ZXM6e30sc3R5bGVzOnt9fSxsPVtdLGM9ITEsaD17c3RhdGU6YSxzZXRPcHRpb25zOmZ1bmN0aW9uKGkpe3ZhciBzPVwiZnVuY3Rpb25cIj09dHlwZW9mIGk/aShhLm9wdGlvbnMpOmk7ZCgpLGEub3B0aW9ucz1PYmplY3QuYXNzaWduKHt9LG8sYS5vcHRpb25zLHMpLGEuc2Nyb2xsUGFyZW50cz17cmVmZXJlbmNlOmdlKHQpP3RpKHQpOnQuY29udGV4dEVsZW1lbnQ/dGkodC5jb250ZXh0RWxlbWVudCk6W10scG9wcGVyOnRpKGUpfTt2YXIgcixjLHU9ZnVuY3Rpb24odCl7dmFyIGU9cGkodCk7cmV0dXJuIGZlLnJlZHVjZSgoZnVuY3Rpb24odCxpKXtyZXR1cm4gdC5jb25jYXQoZS5maWx0ZXIoKGZ1bmN0aW9uKHQpe3JldHVybiB0LnBoYXNlPT09aX0pKSl9KSxbXSl9KChyPVtdLmNvbmNhdChuLGEub3B0aW9ucy5tb2RpZmllcnMpLGM9ci5yZWR1Y2UoKGZ1bmN0aW9uKHQsZSl7dmFyIGk9dFtlLm5hbWVdO3JldHVybiB0W2UubmFtZV09aT9PYmplY3QuYXNzaWduKHt9LGksZSx7b3B0aW9uczpPYmplY3QuYXNzaWduKHt9LGkub3B0aW9ucyxlLm9wdGlvbnMpLGRhdGE6T2JqZWN0LmFzc2lnbih7fSxpLmRhdGEsZS5kYXRhKX0pOmUsdH0pLHt9KSxPYmplY3Qua2V5cyhjKS5tYXAoKGZ1bmN0aW9uKHQpe3JldHVybiBjW3RdfSkpKSk7cmV0dXJuIGEub3JkZXJlZE1vZGlmaWVycz11LmZpbHRlcigoZnVuY3Rpb24odCl7cmV0dXJuIHQuZW5hYmxlZH0pKSxhLm9yZGVyZWRNb2RpZmllcnMuZm9yRWFjaCgoZnVuY3Rpb24odCl7dmFyIGU9dC5uYW1lLGk9dC5vcHRpb25zLG49dm9pZCAwPT09aT97fTppLHM9dC5lZmZlY3Q7aWYoXCJmdW5jdGlvblwiPT10eXBlb2Ygcyl7dmFyIG89cyh7c3RhdGU6YSxuYW1lOmUsaW5zdGFuY2U6aCxvcHRpb25zOm59KTtsLnB1c2gob3x8ZnVuY3Rpb24oKXt9KX19KSksaC51cGRhdGUoKX0sZm9yY2VVcGRhdGU6ZnVuY3Rpb24oKXtpZighYyl7dmFyIHQ9YS5lbGVtZW50cyxlPXQucmVmZXJlbmNlLGk9dC5wb3BwZXI7aWYoZ2koZSxpKSl7YS5yZWN0cz17cmVmZXJlbmNlOmZpKGUsTmUoaSksXCJmaXhlZFwiPT09YS5vcHRpb25zLnN0cmF0ZWd5KSxwb3BwZXI6eGUoaSl9LGEucmVzZXQ9ITEsYS5wbGFjZW1lbnQ9YS5vcHRpb25zLnBsYWNlbWVudCxhLm9yZGVyZWRNb2RpZmllcnMuZm9yRWFjaCgoZnVuY3Rpb24odCl7cmV0dXJuIGEubW9kaWZpZXJzRGF0YVt0Lm5hbWVdPU9iamVjdC5hc3NpZ24oe30sdC5kYXRhKX0pKTtmb3IodmFyIG49MDtuPGEub3JkZXJlZE1vZGlmaWVycy5sZW5ndGg7bisrKWlmKCEwIT09YS5yZXNldCl7dmFyIHM9YS5vcmRlcmVkTW9kaWZpZXJzW25dLG89cy5mbixyPXMub3B0aW9ucyxsPXZvaWQgMD09PXI/e306cixkPXMubmFtZTtcImZ1bmN0aW9uXCI9PXR5cGVvZiBvJiYoYT1vKHtzdGF0ZTphLG9wdGlvbnM6bCxuYW1lOmQsaW5zdGFuY2U6aH0pfHxhKX1lbHNlIGEucmVzZXQ9ITEsbj0tMX19fSx1cGRhdGU6KHM9ZnVuY3Rpb24oKXtyZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uKHQpe2guZm9yY2VVcGRhdGUoKSx0KGEpfSkpfSxmdW5jdGlvbigpe3JldHVybiByfHwocj1uZXcgUHJvbWlzZSgoZnVuY3Rpb24odCl7UHJvbWlzZS5yZXNvbHZlKCkudGhlbigoZnVuY3Rpb24oKXtyPXZvaWQgMCx0KHMoKSl9KSl9KSkpLHJ9KSxkZXN0cm95OmZ1bmN0aW9uKCl7ZCgpLGM9ITB9fTtpZighZ2kodCxlKSlyZXR1cm4gaDtmdW5jdGlvbiBkKCl7bC5mb3JFYWNoKChmdW5jdGlvbih0KXtyZXR1cm4gdCgpfSkpLGw9W119cmV0dXJuIGguc2V0T3B0aW9ucyhpKS50aGVuKChmdW5jdGlvbih0KXshYyYmaS5vbkZpcnN0VXBkYXRlJiZpLm9uRmlyc3RVcGRhdGUodCl9KSksaH19dmFyIGJpPV9pKCksdmk9X2koe2RlZmF1bHRNb2RpZmllcnM6W1ZlLGRpLFJlLHZlXX0pLHlpPV9pKHtkZWZhdWx0TW9kaWZpZXJzOltWZSxkaSxSZSx2ZSxoaSxyaSx1aSxIZSxjaV19KTtjb25zdCB3aT1PYmplY3QuZnJlZXplKE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7X19wcm90b19fOm51bGwsYWZ0ZXJNYWluOmNlLGFmdGVyUmVhZDpyZSxhZnRlcldyaXRlOnVlLGFwcGx5U3R5bGVzOnZlLGFycm93OkhlLGF1dG86WHQsYmFzZVBsYWNlbWVudHM6WXQsYmVmb3JlTWFpbjphZSxiZWZvcmVSZWFkOnNlLGJlZm9yZVdyaXRlOmhlLGJvdHRvbTpWdCxjbGlwcGluZ1BhcmVudHM6SnQsY29tcHV0ZVN0eWxlczpSZSxjcmVhdGVQb3BwZXI6eWksY3JlYXRlUG9wcGVyQmFzZTpiaSxjcmVhdGVQb3BwZXJMaXRlOnZpLGRldGVjdE92ZXJmbG93OnNpLGVuZDpHdCxldmVudExpc3RlbmVyczpWZSxmbGlwOnJpLGhpZGU6Y2ksbGVmdDpRdCxtYWluOmxlLG1vZGlmaWVyUGhhc2VzOmZlLG9mZnNldDpoaSxwbGFjZW1lbnRzOm5lLHBvcHBlcjp0ZSxwb3BwZXJHZW5lcmF0b3I6X2kscG9wcGVyT2Zmc2V0czpkaSxwcmV2ZW50T3ZlcmZsb3c6dWkscmVhZDpvZSxyZWZlcmVuY2U6ZWUscmlnaHQ6S3Qsc3RhcnQ6VXQsdG9wOnF0LHZhcmlhdGlvblBsYWNlbWVudHM6aWUsdmlld3BvcnQ6WnQsd3JpdGU6ZGV9LFN5bWJvbC50b1N0cmluZ1RhZyx7dmFsdWU6XCJNb2R1bGVcIn0pKSxBaT1cImRyb3Bkb3duXCIsRWk9XCIuYnMuZHJvcGRvd25cIixUaT1cIi5kYXRhLWFwaVwiLENpPVwiQXJyb3dVcFwiLE9pPVwiQXJyb3dEb3duXCIseGk9YGhpZGUke0VpfWAsa2k9YGhpZGRlbiR7RWl9YCxMaT1gc2hvdyR7RWl9YCxTaT1gc2hvd24ke0VpfWAsRGk9YGNsaWNrJHtFaX0ke1RpfWAsJGk9YGtleWRvd24ke0VpfSR7VGl9YCxJaT1ga2V5dXAke0VpfSR7VGl9YCxOaT1cInNob3dcIixQaT0nW2RhdGEtYnMtdG9nZ2xlPVwiZHJvcGRvd25cIl06bm90KC5kaXNhYmxlZCk6bm90KDpkaXNhYmxlZCknLGppPWAke1BpfS4ke05pfWAsTWk9XCIuZHJvcGRvd24tbWVudVwiLEZpPXAoKT9cInRvcC1lbmRcIjpcInRvcC1zdGFydFwiLEhpPXAoKT9cInRvcC1zdGFydFwiOlwidG9wLWVuZFwiLFdpPXAoKT9cImJvdHRvbS1lbmRcIjpcImJvdHRvbS1zdGFydFwiLEJpPXAoKT9cImJvdHRvbS1zdGFydFwiOlwiYm90dG9tLWVuZFwiLHppPXAoKT9cImxlZnQtc3RhcnRcIjpcInJpZ2h0LXN0YXJ0XCIsUmk9cCgpP1wicmlnaHQtc3RhcnRcIjpcImxlZnQtc3RhcnRcIixxaT17YXV0b0Nsb3NlOiEwLGJvdW5kYXJ5OlwiY2xpcHBpbmdQYXJlbnRzXCIsZGlzcGxheTpcImR5bmFtaWNcIixvZmZzZXQ6WzAsMl0scG9wcGVyQ29uZmlnOm51bGwscmVmZXJlbmNlOlwidG9nZ2xlXCJ9LFZpPXthdXRvQ2xvc2U6XCIoYm9vbGVhbnxzdHJpbmcpXCIsYm91bmRhcnk6XCIoc3RyaW5nfGVsZW1lbnQpXCIsZGlzcGxheTpcInN0cmluZ1wiLG9mZnNldDpcIihhcnJheXxzdHJpbmd8ZnVuY3Rpb24pXCIscG9wcGVyQ29uZmlnOlwiKG51bGx8b2JqZWN0fGZ1bmN0aW9uKVwiLHJlZmVyZW5jZTpcIihzdHJpbmd8ZWxlbWVudHxvYmplY3QpXCJ9O2NsYXNzIEtpIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fcG9wcGVyPW51bGwsdGhpcy5fcGFyZW50PXRoaXMuX2VsZW1lbnQucGFyZW50Tm9kZSx0aGlzLl9tZW51PXoubmV4dCh0aGlzLl9lbGVtZW50LE1pKVswXXx8ei5wcmV2KHRoaXMuX2VsZW1lbnQsTWkpWzBdfHx6LmZpbmRPbmUoTWksdGhpcy5fcGFyZW50KSx0aGlzLl9pbk5hdmJhcj10aGlzLl9kZXRlY3ROYXZiYXIoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gcWl9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBWaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm4gQWl9dG9nZ2xlKCl7cmV0dXJuIHRoaXMuX2lzU2hvd24oKT90aGlzLmhpZGUoKTp0aGlzLnNob3coKX1zaG93KCl7aWYobCh0aGlzLl9lbGVtZW50KXx8dGhpcy5faXNTaG93bigpKXJldHVybjtjb25zdCB0PXtyZWxhdGVkVGFyZ2V0OnRoaXMuX2VsZW1lbnR9O2lmKCFOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxMaSx0KS5kZWZhdWx0UHJldmVudGVkKXtpZih0aGlzLl9jcmVhdGVQb3BwZXIoKSxcIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50JiYhdGhpcy5fcGFyZW50LmNsb3Nlc3QoXCIubmF2YmFyLW5hdlwiKSlmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlOLm9uKHQsXCJtb3VzZW92ZXJcIixoKTt0aGlzLl9lbGVtZW50LmZvY3VzKCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsITApLHRoaXMuX21lbnUuY2xhc3NMaXN0LmFkZChOaSksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKE5pKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxTaSx0KX19aGlkZSgpe2lmKGwodGhpcy5fZWxlbWVudCl8fCF0aGlzLl9pc1Nob3duKCkpcmV0dXJuO2NvbnN0IHQ9e3JlbGF0ZWRUYXJnZXQ6dGhpcy5fZWxlbWVudH07dGhpcy5fY29tcGxldGVIaWRlKHQpfWRpc3Bvc2UoKXt0aGlzLl9wb3BwZXImJnRoaXMuX3BvcHBlci5kZXN0cm95KCksc3VwZXIuZGlzcG9zZSgpfXVwZGF0ZSgpe3RoaXMuX2luTmF2YmFyPXRoaXMuX2RldGVjdE5hdmJhcigpLHRoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLnVwZGF0ZSgpfV9jb21wbGV0ZUhpZGUodCl7aWYoIU4udHJpZ2dlcih0aGlzLl9lbGVtZW50LHhpLHQpLmRlZmF1bHRQcmV2ZW50ZWQpe2lmKFwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpZm9yKGNvbnN0IHQgb2ZbXS5jb25jYXQoLi4uZG9jdW1lbnQuYm9keS5jaGlsZHJlbikpTi5vZmYodCxcIm1vdXNlb3ZlclwiLGgpO3RoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLmRlc3Ryb3koKSx0aGlzLl9tZW51LmNsYXNzTGlzdC5yZW1vdmUoTmkpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShOaSksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsXCJmYWxzZVwiKSxGLnJlbW92ZURhdGFBdHRyaWJ1dGUodGhpcy5fbWVudSxcInBvcHBlclwiKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxraSx0KX19X2dldENvbmZpZyh0KXtpZihcIm9iamVjdFwiPT10eXBlb2YodD1zdXBlci5fZ2V0Q29uZmlnKHQpKS5yZWZlcmVuY2UmJiFvKHQucmVmZXJlbmNlKSYmXCJmdW5jdGlvblwiIT10eXBlb2YgdC5yZWZlcmVuY2UuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KXRocm93IG5ldyBUeXBlRXJyb3IoYCR7QWkudG9VcHBlckNhc2UoKX06IE9wdGlvbiBcInJlZmVyZW5jZVwiIHByb3ZpZGVkIHR5cGUgXCJvYmplY3RcIiB3aXRob3V0IGEgcmVxdWlyZWQgXCJnZXRCb3VuZGluZ0NsaWVudFJlY3RcIiBtZXRob2QuYCk7cmV0dXJuIHR9X2NyZWF0ZVBvcHBlcigpe2lmKHZvaWQgMD09PXdpKXRocm93IG5ldyBUeXBlRXJyb3IoXCJCb290c3RyYXAncyBkcm9wZG93bnMgcmVxdWlyZSBQb3BwZXIgKGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyLylcIik7bGV0IHQ9dGhpcy5fZWxlbWVudDtcInBhcmVudFwiPT09dGhpcy5fY29uZmlnLnJlZmVyZW5jZT90PXRoaXMuX3BhcmVudDpvKHRoaXMuX2NvbmZpZy5yZWZlcmVuY2UpP3Q9cih0aGlzLl9jb25maWcucmVmZXJlbmNlKTpcIm9iamVjdFwiPT10eXBlb2YgdGhpcy5fY29uZmlnLnJlZmVyZW5jZSYmKHQ9dGhpcy5fY29uZmlnLnJlZmVyZW5jZSk7Y29uc3QgZT10aGlzLl9nZXRQb3BwZXJDb25maWcoKTt0aGlzLl9wb3BwZXI9eWkodCx0aGlzLl9tZW51LGUpfV9pc1Nob3duKCl7cmV0dXJuIHRoaXMuX21lbnUuY2xhc3NMaXN0LmNvbnRhaW5zKE5pKX1fZ2V0UGxhY2VtZW50KCl7Y29uc3QgdD10aGlzLl9wYXJlbnQ7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZW5kXCIpKXJldHVybiB6aTtpZih0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3BzdGFydFwiKSlyZXR1cm4gUmk7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wdXAtY2VudGVyXCIpKXJldHVyblwidG9wXCI7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZG93bi1jZW50ZXJcIikpcmV0dXJuXCJib3R0b21cIjtjb25zdCBlPVwiZW5kXCI9PT1nZXRDb21wdXRlZFN0eWxlKHRoaXMuX21lbnUpLmdldFByb3BlcnR5VmFsdWUoXCItLWJzLXBvc2l0aW9uXCIpLnRyaW0oKTtyZXR1cm4gdC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wdXBcIik/ZT9IaTpGaTplP0JpOldpfV9kZXRlY3ROYXZiYXIoKXtyZXR1cm4gbnVsbCE9PXRoaXMuX2VsZW1lbnQuY2xvc2VzdChcIi5uYXZiYXJcIil9X2dldE9mZnNldCgpe2NvbnN0e29mZnNldDp0fT10aGlzLl9jb25maWc7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHQ/dC5zcGxpdChcIixcIikubWFwKCh0PT5OdW1iZXIucGFyc2VJbnQodCwxMCkpKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiB0P2U9PnQoZSx0aGlzLl9lbGVtZW50KTp0fV9nZXRQb3BwZXJDb25maWcoKXtjb25zdCB0PXtwbGFjZW1lbnQ6dGhpcy5fZ2V0UGxhY2VtZW50KCksbW9kaWZpZXJzOlt7bmFtZTpcInByZXZlbnRPdmVyZmxvd1wiLG9wdGlvbnM6e2JvdW5kYXJ5OnRoaXMuX2NvbmZpZy5ib3VuZGFyeX19LHtuYW1lOlwib2Zmc2V0XCIsb3B0aW9uczp7b2Zmc2V0OnRoaXMuX2dldE9mZnNldCgpfX1dfTtyZXR1cm4odGhpcy5faW5OYXZiYXJ8fFwic3RhdGljXCI9PT10aGlzLl9jb25maWcuZGlzcGxheSkmJihGLnNldERhdGFBdHRyaWJ1dGUodGhpcy5fbWVudSxcInBvcHBlclwiLFwic3RhdGljXCIpLHQubW9kaWZpZXJzPVt7bmFtZTpcImFwcGx5U3R5bGVzXCIsZW5hYmxlZDohMX1dKSx7Li4udCwuLi5nKHRoaXMuX2NvbmZpZy5wb3BwZXJDb25maWcsW3ZvaWQgMCx0XSl9fV9zZWxlY3RNZW51SXRlbSh7a2V5OnQsdGFyZ2V0OmV9KXtjb25zdCBpPXouZmluZChcIi5kcm9wZG93bi1tZW51IC5kcm9wZG93bi1pdGVtOm5vdCguZGlzYWJsZWQpOm5vdCg6ZGlzYWJsZWQpXCIsdGhpcy5fbWVudSkuZmlsdGVyKCh0PT5hKHQpKSk7aS5sZW5ndGgmJmIoaSxlLHQ9PT1PaSwhaS5pbmNsdWRlcyhlKSkuZm9jdXMoKX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goKGZ1bmN0aW9uKCl7Y29uc3QgZT1LaS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pKX1zdGF0aWMgY2xlYXJNZW51cyh0KXtpZigyPT09dC5idXR0b258fFwia2V5dXBcIj09PXQudHlwZSYmXCJUYWJcIiE9PXQua2V5KXJldHVybjtjb25zdCBlPXouZmluZChqaSk7Zm9yKGNvbnN0IGkgb2YgZSl7Y29uc3QgZT1LaS5nZXRJbnN0YW5jZShpKTtpZighZXx8ITE9PT1lLl9jb25maWcuYXV0b0Nsb3NlKWNvbnRpbnVlO2NvbnN0IG49dC5jb21wb3NlZFBhdGgoKSxzPW4uaW5jbHVkZXMoZS5fbWVudSk7aWYobi5pbmNsdWRlcyhlLl9lbGVtZW50KXx8XCJpbnNpZGVcIj09PWUuX2NvbmZpZy5hdXRvQ2xvc2UmJiFzfHxcIm91dHNpZGVcIj09PWUuX2NvbmZpZy5hdXRvQ2xvc2UmJnMpY29udGludWU7aWYoZS5fbWVudS5jb250YWlucyh0LnRhcmdldCkmJihcImtleXVwXCI9PT10LnR5cGUmJlwiVGFiXCI9PT10LmtleXx8L2lucHV0fHNlbGVjdHxvcHRpb258dGV4dGFyZWF8Zm9ybS9pLnRlc3QodC50YXJnZXQudGFnTmFtZSkpKWNvbnRpbnVlO2NvbnN0IG89e3JlbGF0ZWRUYXJnZXQ6ZS5fZWxlbWVudH07XCJjbGlja1wiPT09dC50eXBlJiYoby5jbGlja0V2ZW50PXQpLGUuX2NvbXBsZXRlSGlkZShvKX19c3RhdGljIGRhdGFBcGlLZXlkb3duSGFuZGxlcih0KXtjb25zdCBlPS9pbnB1dHx0ZXh0YXJlYS9pLnRlc3QodC50YXJnZXQudGFnTmFtZSksaT1cIkVzY2FwZVwiPT09dC5rZXksbj1bQ2ksT2ldLmluY2x1ZGVzKHQua2V5KTtpZighbiYmIWkpcmV0dXJuO2lmKGUmJiFpKXJldHVybjt0LnByZXZlbnREZWZhdWx0KCk7Y29uc3Qgcz10aGlzLm1hdGNoZXMoUGkpP3RoaXM6ei5wcmV2KHRoaXMsUGkpWzBdfHx6Lm5leHQodGhpcyxQaSlbMF18fHouZmluZE9uZShQaSx0LmRlbGVnYXRlVGFyZ2V0LnBhcmVudE5vZGUpLG89S2kuZ2V0T3JDcmVhdGVJbnN0YW5jZShzKTtpZihuKXJldHVybiB0LnN0b3BQcm9wYWdhdGlvbigpLG8uc2hvdygpLHZvaWQgby5fc2VsZWN0TWVudUl0ZW0odCk7by5faXNTaG93bigpJiYodC5zdG9wUHJvcGFnYXRpb24oKSxvLmhpZGUoKSxzLmZvY3VzKCkpfX1OLm9uKGRvY3VtZW50LCRpLFBpLEtpLmRhdGFBcGlLZXlkb3duSGFuZGxlciksTi5vbihkb2N1bWVudCwkaSxNaSxLaS5kYXRhQXBpS2V5ZG93bkhhbmRsZXIpLE4ub24oZG9jdW1lbnQsRGksS2kuY2xlYXJNZW51cyksTi5vbihkb2N1bWVudCxJaSxLaS5jbGVhck1lbnVzKSxOLm9uKGRvY3VtZW50LERpLFBpLChmdW5jdGlvbih0KXt0LnByZXZlbnREZWZhdWx0KCksS2kuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzKS50b2dnbGUoKX0pKSxtKEtpKTtjb25zdCBRaT1cImJhY2tkcm9wXCIsWGk9XCJzaG93XCIsWWk9YG1vdXNlZG93bi5icy4ke1FpfWAsVWk9e2NsYXNzTmFtZTpcIm1vZGFsLWJhY2tkcm9wXCIsY2xpY2tDYWxsYmFjazpudWxsLGlzQW5pbWF0ZWQ6ITEsaXNWaXNpYmxlOiEwLHJvb3RFbGVtZW50OlwiYm9keVwifSxHaT17Y2xhc3NOYW1lOlwic3RyaW5nXCIsY2xpY2tDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwiLGlzQW5pbWF0ZWQ6XCJib29sZWFuXCIsaXNWaXNpYmxlOlwiYm9vbGVhblwiLHJvb3RFbGVtZW50OlwiKGVsZW1lbnR8c3RyaW5nKVwifTtjbGFzcyBKaSBleHRlbmRzIEh7Y29uc3RydWN0b3IodCl7c3VwZXIoKSx0aGlzLl9jb25maWc9dGhpcy5fZ2V0Q29uZmlnKHQpLHRoaXMuX2lzQXBwZW5kZWQ9ITEsdGhpcy5fZWxlbWVudD1udWxsfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBVaX1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIEdpfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVybiBRaX1zaG93KHQpe2lmKCF0aGlzLl9jb25maWcuaXNWaXNpYmxlKXJldHVybiB2b2lkIGcodCk7dGhpcy5fYXBwZW5kKCk7Y29uc3QgZT10aGlzLl9nZXRFbGVtZW50KCk7dGhpcy5fY29uZmlnLmlzQW5pbWF0ZWQmJmQoZSksZS5jbGFzc0xpc3QuYWRkKFhpKSx0aGlzLl9lbXVsYXRlQW5pbWF0aW9uKCgoKT0+e2codCl9KSl9aGlkZSh0KXt0aGlzLl9jb25maWcuaXNWaXNpYmxlPyh0aGlzLl9nZXRFbGVtZW50KCkuY2xhc3NMaXN0LnJlbW92ZShYaSksdGhpcy5fZW11bGF0ZUFuaW1hdGlvbigoKCk9Pnt0aGlzLmRpc3Bvc2UoKSxnKHQpfSkpKTpnKHQpfWRpc3Bvc2UoKXt0aGlzLl9pc0FwcGVuZGVkJiYoTi5vZmYodGhpcy5fZWxlbWVudCxZaSksdGhpcy5fZWxlbWVudC5yZW1vdmUoKSx0aGlzLl9pc0FwcGVuZGVkPSExKX1fZ2V0RWxlbWVudCgpe2lmKCF0aGlzLl9lbGVtZW50KXtjb25zdCB0PWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7dC5jbGFzc05hbWU9dGhpcy5fY29uZmlnLmNsYXNzTmFtZSx0aGlzLl9jb25maWcuaXNBbmltYXRlZCYmdC5jbGFzc0xpc3QuYWRkKFwiZmFkZVwiKSx0aGlzLl9lbGVtZW50PXR9cmV0dXJuIHRoaXMuX2VsZW1lbnR9X2NvbmZpZ0FmdGVyTWVyZ2UodCl7cmV0dXJuIHQucm9vdEVsZW1lbnQ9cih0LnJvb3RFbGVtZW50KSx0fV9hcHBlbmQoKXtpZih0aGlzLl9pc0FwcGVuZGVkKXJldHVybjtjb25zdCB0PXRoaXMuX2dldEVsZW1lbnQoKTt0aGlzLl9jb25maWcucm9vdEVsZW1lbnQuYXBwZW5kKHQpLE4ub24odCxZaSwoKCk9PntnKHRoaXMuX2NvbmZpZy5jbGlja0NhbGxiYWNrKX0pKSx0aGlzLl9pc0FwcGVuZGVkPSEwfV9lbXVsYXRlQW5pbWF0aW9uKHQpe18odCx0aGlzLl9nZXRFbGVtZW50KCksdGhpcy5fY29uZmlnLmlzQW5pbWF0ZWQpfX1jb25zdCBaaT1cIi5icy5mb2N1c3RyYXBcIix0bj1gZm9jdXNpbiR7Wml9YCxlbj1ga2V5ZG93bi50YWIke1ppfWAsbm49XCJiYWNrd2FyZFwiLHNuPXthdXRvZm9jdXM6ITAsdHJhcEVsZW1lbnQ6bnVsbH0sb249e2F1dG9mb2N1czpcImJvb2xlYW5cIix0cmFwRWxlbWVudDpcImVsZW1lbnRcIn07Y2xhc3Mgcm4gZXh0ZW5kcyBIe2NvbnN0cnVjdG9yKHQpe3N1cGVyKCksdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyh0KSx0aGlzLl9pc0FjdGl2ZT0hMSx0aGlzLl9sYXN0VGFiTmF2RGlyZWN0aW9uPW51bGx9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIHNufXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gb259c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJmb2N1c3RyYXBcIn1hY3RpdmF0ZSgpe3RoaXMuX2lzQWN0aXZlfHwodGhpcy5fY29uZmlnLmF1dG9mb2N1cyYmdGhpcy5fY29uZmlnLnRyYXBFbGVtZW50LmZvY3VzKCksTi5vZmYoZG9jdW1lbnQsWmkpLE4ub24oZG9jdW1lbnQsdG4sKHQ9PnRoaXMuX2hhbmRsZUZvY3VzaW4odCkpKSxOLm9uKGRvY3VtZW50LGVuLCh0PT50aGlzLl9oYW5kbGVLZXlkb3duKHQpKSksdGhpcy5faXNBY3RpdmU9ITApfWRlYWN0aXZhdGUoKXt0aGlzLl9pc0FjdGl2ZSYmKHRoaXMuX2lzQWN0aXZlPSExLE4ub2ZmKGRvY3VtZW50LFppKSl9X2hhbmRsZUZvY3VzaW4odCl7Y29uc3R7dHJhcEVsZW1lbnQ6ZX09dGhpcy5fY29uZmlnO2lmKHQudGFyZ2V0PT09ZG9jdW1lbnR8fHQudGFyZ2V0PT09ZXx8ZS5jb250YWlucyh0LnRhcmdldCkpcmV0dXJuO2NvbnN0IGk9ei5mb2N1c2FibGVDaGlsZHJlbihlKTswPT09aS5sZW5ndGg/ZS5mb2N1cygpOnRoaXMuX2xhc3RUYWJOYXZEaXJlY3Rpb249PT1ubj9pW2kubGVuZ3RoLTFdLmZvY3VzKCk6aVswXS5mb2N1cygpfV9oYW5kbGVLZXlkb3duKHQpe1wiVGFiXCI9PT10LmtleSYmKHRoaXMuX2xhc3RUYWJOYXZEaXJlY3Rpb249dC5zaGlmdEtleT9ubjpcImZvcndhcmRcIil9fWNvbnN0IGFuPVwiLmZpeGVkLXRvcCwgLmZpeGVkLWJvdHRvbSwgLmlzLWZpeGVkLCAuc3RpY2t5LXRvcFwiLGxuPVwiLnN0aWNreS10b3BcIixjbj1cInBhZGRpbmctcmlnaHRcIixobj1cIm1hcmdpbi1yaWdodFwiO2NsYXNzIGRue2NvbnN0cnVjdG9yKCl7dGhpcy5fZWxlbWVudD1kb2N1bWVudC5ib2R5fWdldFdpZHRoKCl7Y29uc3QgdD1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7cmV0dXJuIE1hdGguYWJzKHdpbmRvdy5pbm5lcldpZHRoLXQpfWhpZGUoKXtjb25zdCB0PXRoaXMuZ2V0V2lkdGgoKTt0aGlzLl9kaXNhYmxlT3ZlckZsb3coKSx0aGlzLl9zZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LGNuLChlPT5lK3QpKSx0aGlzLl9zZXRFbGVtZW50QXR0cmlidXRlcyhhbixjbiwoZT0+ZSt0KSksdGhpcy5fc2V0RWxlbWVudEF0dHJpYnV0ZXMobG4saG4sKGU9PmUtdCkpfXJlc2V0KCl7dGhpcy5fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LFwib3ZlcmZsb3dcIiksdGhpcy5fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LGNuKSx0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKGFuLGNuKSx0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKGxuLGhuKX1pc092ZXJmbG93aW5nKCl7cmV0dXJuIHRoaXMuZ2V0V2lkdGgoKT4wfV9kaXNhYmxlT3ZlckZsb3coKXt0aGlzLl9zYXZlSW5pdGlhbEF0dHJpYnV0ZSh0aGlzLl9lbGVtZW50LFwib3ZlcmZsb3dcIiksdGhpcy5fZWxlbWVudC5zdHlsZS5vdmVyZmxvdz1cImhpZGRlblwifV9zZXRFbGVtZW50QXR0cmlidXRlcyh0LGUsaSl7Y29uc3Qgbj10aGlzLmdldFdpZHRoKCk7dGhpcy5fYXBwbHlNYW5pcHVsYXRpb25DYWxsYmFjayh0LCh0PT57aWYodCE9PXRoaXMuX2VsZW1lbnQmJndpbmRvdy5pbm5lcldpZHRoPnQuY2xpZW50V2lkdGgrbilyZXR1cm47dGhpcy5fc2F2ZUluaXRpYWxBdHRyaWJ1dGUodCxlKTtjb25zdCBzPXdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHQpLmdldFByb3BlcnR5VmFsdWUoZSk7dC5zdHlsZS5zZXRQcm9wZXJ0eShlLGAke2koTnVtYmVyLnBhcnNlRmxvYXQocykpfXB4YCl9KSl9X3NhdmVJbml0aWFsQXR0cmlidXRlKHQsZSl7Y29uc3QgaT10LnN0eWxlLmdldFByb3BlcnR5VmFsdWUoZSk7aSYmRi5zZXREYXRhQXR0cmlidXRlKHQsZSxpKX1fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0LGUpe3RoaXMuX2FwcGx5TWFuaXB1bGF0aW9uQ2FsbGJhY2sodCwodD0+e2NvbnN0IGk9Ri5nZXREYXRhQXR0cmlidXRlKHQsZSk7bnVsbCE9PWk/KEYucmVtb3ZlRGF0YUF0dHJpYnV0ZSh0LGUpLHQuc3R5bGUuc2V0UHJvcGVydHkoZSxpKSk6dC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShlKX0pKX1fYXBwbHlNYW5pcHVsYXRpb25DYWxsYmFjayh0LGUpe2lmKG8odCkpZSh0KTtlbHNlIGZvcihjb25zdCBpIG9mIHouZmluZCh0LHRoaXMuX2VsZW1lbnQpKWUoaSl9fWNvbnN0IHVuPVwiLmJzLm1vZGFsXCIsZm49YGhpZGUke3VufWAscG49YGhpZGVQcmV2ZW50ZWQke3VufWAsbW49YGhpZGRlbiR7dW59YCxnbj1gc2hvdyR7dW59YCxfbj1gc2hvd24ke3VufWAsYm49YHJlc2l6ZSR7dW59YCx2bj1gY2xpY2suZGlzbWlzcyR7dW59YCx5bj1gbW91c2Vkb3duLmRpc21pc3Mke3VufWAsd249YGtleWRvd24uZGlzbWlzcyR7dW59YCxBbj1gY2xpY2ske3VufS5kYXRhLWFwaWAsRW49XCJtb2RhbC1vcGVuXCIsVG49XCJzaG93XCIsQ249XCJtb2RhbC1zdGF0aWNcIixPbj17YmFja2Ryb3A6ITAsZm9jdXM6ITAsa2V5Ym9hcmQ6ITB9LHhuPXtiYWNrZHJvcDpcIihib29sZWFufHN0cmluZylcIixmb2N1czpcImJvb2xlYW5cIixrZXlib2FyZDpcImJvb2xlYW5cIn07Y2xhc3Mga24gZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQsZSl7c3VwZXIodCxlKSx0aGlzLl9kaWFsb2c9ei5maW5kT25lKFwiLm1vZGFsLWRpYWxvZ1wiLHRoaXMuX2VsZW1lbnQpLHRoaXMuX2JhY2tkcm9wPXRoaXMuX2luaXRpYWxpemVCYWNrRHJvcCgpLHRoaXMuX2ZvY3VzdHJhcD10aGlzLl9pbml0aWFsaXplRm9jdXNUcmFwKCksdGhpcy5faXNTaG93bj0hMSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsdGhpcy5fc2Nyb2xsQmFyPW5ldyBkbix0aGlzLl9hZGRFdmVudExpc3RlbmVycygpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBPbn1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIHhufXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwibW9kYWxcIn10b2dnbGUodCl7cmV0dXJuIHRoaXMuX2lzU2hvd24/dGhpcy5oaWRlKCk6dGhpcy5zaG93KHQpfXNob3codCl7dGhpcy5faXNTaG93bnx8dGhpcy5faXNUcmFuc2l0aW9uaW5nfHxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxnbix7cmVsYXRlZFRhcmdldDp0fSkuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2lzU2hvd249ITAsdGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwLHRoaXMuX3Njcm9sbEJhci5oaWRlKCksZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKEVuKSx0aGlzLl9hZGp1c3REaWFsb2coKSx0aGlzLl9iYWNrZHJvcC5zaG93KCgoKT0+dGhpcy5fc2hvd0VsZW1lbnQodCkpKSl9aGlkZSgpe3RoaXMuX2lzU2hvd24mJiF0aGlzLl9pc1RyYW5zaXRpb25pbmcmJihOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxmbikuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2lzU2hvd249ITEsdGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwLHRoaXMuX2ZvY3VzdHJhcC5kZWFjdGl2YXRlKCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFRuKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgoKT0+dGhpcy5faGlkZU1vZGFsKCkpLHRoaXMuX2VsZW1lbnQsdGhpcy5faXNBbmltYXRlZCgpKSkpfWRpc3Bvc2UoKXtOLm9mZih3aW5kb3csdW4pLE4ub2ZmKHRoaXMuX2RpYWxvZyx1biksdGhpcy5fYmFja2Ryb3AuZGlzcG9zZSgpLHRoaXMuX2ZvY3VzdHJhcC5kZWFjdGl2YXRlKCksc3VwZXIuZGlzcG9zZSgpfWhhbmRsZVVwZGF0ZSgpe3RoaXMuX2FkanVzdERpYWxvZygpfV9pbml0aWFsaXplQmFja0Ryb3AoKXtyZXR1cm4gbmV3IEppKHtpc1Zpc2libGU6Qm9vbGVhbih0aGlzLl9jb25maWcuYmFja2Ryb3ApLGlzQW5pbWF0ZWQ6dGhpcy5faXNBbmltYXRlZCgpfSl9X2luaXRpYWxpemVGb2N1c1RyYXAoKXtyZXR1cm4gbmV3IHJuKHt0cmFwRWxlbWVudDp0aGlzLl9lbGVtZW50fSl9X3Nob3dFbGVtZW50KHQpe2RvY3VtZW50LmJvZHkuY29udGFpbnModGhpcy5fZWxlbWVudCl8fGRvY3VtZW50LmJvZHkuYXBwZW5kKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheT1cImJsb2NrXCIsdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiKSx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtbW9kYWxcIiwhMCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsXCJkaWFsb2dcIiksdGhpcy5fZWxlbWVudC5zY3JvbGxUb3A9MDtjb25zdCBlPXouZmluZE9uZShcIi5tb2RhbC1ib2R5XCIsdGhpcy5fZGlhbG9nKTtlJiYoZS5zY3JvbGxUb3A9MCksZCh0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoVG4pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57dGhpcy5fY29uZmlnLmZvY3VzJiZ0aGlzLl9mb2N1c3RyYXAuYWN0aXZhdGUoKSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsX24se3JlbGF0ZWRUYXJnZXQ6dH0pfSksdGhpcy5fZGlhbG9nLHRoaXMuX2lzQW5pbWF0ZWQoKSl9X2FkZEV2ZW50TGlzdGVuZXJzKCl7Ti5vbih0aGlzLl9lbGVtZW50LHduLCh0PT57XCJFc2NhcGVcIj09PXQua2V5JiYodGhpcy5fY29uZmlnLmtleWJvYXJkP3RoaXMuaGlkZSgpOnRoaXMuX3RyaWdnZXJCYWNrZHJvcFRyYW5zaXRpb24oKSl9KSksTi5vbih3aW5kb3csYm4sKCgpPT57dGhpcy5faXNTaG93biYmIXRoaXMuX2lzVHJhbnNpdGlvbmluZyYmdGhpcy5fYWRqdXN0RGlhbG9nKCl9KSksTi5vbih0aGlzLl9lbGVtZW50LHluLCh0PT57Ti5vbmUodGhpcy5fZWxlbWVudCx2biwoZT0+e3RoaXMuX2VsZW1lbnQ9PT10LnRhcmdldCYmdGhpcy5fZWxlbWVudD09PWUudGFyZ2V0JiYoXCJzdGF0aWNcIiE9PXRoaXMuX2NvbmZpZy5iYWNrZHJvcD90aGlzLl9jb25maWcuYmFja2Ryb3AmJnRoaXMuaGlkZSgpOnRoaXMuX3RyaWdnZXJCYWNrZHJvcFRyYW5zaXRpb24oKSl9KSl9KSl9X2hpZGVNb2RhbCgpe3RoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheT1cIm5vbmVcIix0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsITApLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1tb2RhbFwiKSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcInJvbGVcIiksdGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX2JhY2tkcm9wLmhpZGUoKCgpPT57ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKEVuKSx0aGlzLl9yZXNldEFkanVzdG1lbnRzKCksdGhpcy5fc2Nyb2xsQmFyLnJlc2V0KCksTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsbW4pfSkpfV9pc0FuaW1hdGVkKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFkZVwiKX1fdHJpZ2dlckJhY2tkcm9wVHJhbnNpdGlvbigpe2lmKE4udHJpZ2dlcih0aGlzLl9lbGVtZW50LHBuKS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtjb25zdCB0PXRoaXMuX2VsZW1lbnQuc2Nyb2xsSGVpZ2h0PmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQsZT10aGlzLl9lbGVtZW50LnN0eWxlLm92ZXJmbG93WTtcImhpZGRlblwiPT09ZXx8dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoQ24pfHwodHx8KHRoaXMuX2VsZW1lbnQuc3R5bGUub3ZlcmZsb3dZPVwiaGlkZGVuXCIpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChDbiksdGhpcy5fcXVldWVDYWxsYmFjaygoKCk9Pnt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoQ24pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57dGhpcy5fZWxlbWVudC5zdHlsZS5vdmVyZmxvd1k9ZX0pLHRoaXMuX2RpYWxvZyl9KSx0aGlzLl9kaWFsb2cpLHRoaXMuX2VsZW1lbnQuZm9jdXMoKSl9X2FkanVzdERpYWxvZygpe2NvbnN0IHQ9dGhpcy5fZWxlbWVudC5zY3JvbGxIZWlnaHQ+ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudEhlaWdodCxlPXRoaXMuX3Njcm9sbEJhci5nZXRXaWR0aCgpLGk9ZT4wO2lmKGkmJiF0KXtjb25zdCB0PXAoKT9cInBhZGRpbmdMZWZ0XCI6XCJwYWRkaW5nUmlnaHRcIjt0aGlzLl9lbGVtZW50LnN0eWxlW3RdPWAke2V9cHhgfWlmKCFpJiZ0KXtjb25zdCB0PXAoKT9cInBhZGRpbmdSaWdodFwiOlwicGFkZGluZ0xlZnRcIjt0aGlzLl9lbGVtZW50LnN0eWxlW3RdPWAke2V9cHhgfX1fcmVzZXRBZGp1c3RtZW50cygpe3RoaXMuX2VsZW1lbnQuc3R5bGUucGFkZGluZ0xlZnQ9XCJcIix0aGlzLl9lbGVtZW50LnN0eWxlLnBhZGRpbmdSaWdodD1cIlwifXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCxlKXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGk9a24uZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1pW3RdKXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2lbdF0oZSl9fSkpfX1OLm9uKGRvY3VtZW50LEFuLCdbZGF0YS1icy10b2dnbGU9XCJtb2RhbFwiXScsKGZ1bmN0aW9uKHQpe2NvbnN0IGU9ei5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHRoaXMpO1tcIkFcIixcIkFSRUFcIl0uaW5jbHVkZXModGhpcy50YWdOYW1lKSYmdC5wcmV2ZW50RGVmYXVsdCgpLE4ub25lKGUsZ24sKHQ9Pnt0LmRlZmF1bHRQcmV2ZW50ZWR8fE4ub25lKGUsbW4sKCgpPT57YSh0aGlzKSYmdGhpcy5mb2N1cygpfSkpfSkpO2NvbnN0IGk9ei5maW5kT25lKFwiLm1vZGFsLnNob3dcIik7aSYma24uZ2V0SW5zdGFuY2UoaSkuaGlkZSgpLGtuLmdldE9yQ3JlYXRlSW5zdGFuY2UoZSkudG9nZ2xlKHRoaXMpfSkpLFIoa24pLG0oa24pO2NvbnN0IExuPVwiLmJzLm9mZmNhbnZhc1wiLFNuPVwiLmRhdGEtYXBpXCIsRG49YGxvYWQke0xufSR7U259YCwkbj1cInNob3dcIixJbj1cInNob3dpbmdcIixObj1cImhpZGluZ1wiLFBuPVwiLm9mZmNhbnZhcy5zaG93XCIsam49YHNob3cke0xufWAsTW49YHNob3duJHtMbn1gLEZuPWBoaWRlJHtMbn1gLEhuPWBoaWRlUHJldmVudGVkJHtMbn1gLFduPWBoaWRkZW4ke0xufWAsQm49YHJlc2l6ZSR7TG59YCx6bj1gY2xpY2ske0xufSR7U259YCxSbj1ga2V5ZG93bi5kaXNtaXNzJHtMbn1gLHFuPXtiYWNrZHJvcDohMCxrZXlib2FyZDohMCxzY3JvbGw6ITF9LFZuPXtiYWNrZHJvcDpcIihib29sZWFufHN0cmluZylcIixrZXlib2FyZDpcImJvb2xlYW5cIixzY3JvbGw6XCJib29sZWFuXCJ9O2NsYXNzIEtuIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5faXNTaG93bj0hMSx0aGlzLl9iYWNrZHJvcD10aGlzLl9pbml0aWFsaXplQmFja0Ryb3AoKSx0aGlzLl9mb2N1c3RyYXA9dGhpcy5faW5pdGlhbGl6ZUZvY3VzVHJhcCgpLHRoaXMuX2FkZEV2ZW50TGlzdGVuZXJzKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIHFufXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gVm59c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJvZmZjYW52YXNcIn10b2dnbGUodCl7cmV0dXJuIHRoaXMuX2lzU2hvd24/dGhpcy5oaWRlKCk6dGhpcy5zaG93KHQpfXNob3codCl7dGhpcy5faXNTaG93bnx8Ti50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsam4se3JlbGF0ZWRUYXJnZXQ6dH0pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9pc1Nob3duPSEwLHRoaXMuX2JhY2tkcm9wLnNob3coKSx0aGlzLl9jb25maWcuc2Nyb2xsfHwobmV3IGRuKS5oaWRlKCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLW1vZGFsXCIsITApLHRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwicm9sZVwiLFwiZGlhbG9nXCIpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChJbiksdGhpcy5fcXVldWVDYWxsYmFjaygoKCk9Pnt0aGlzLl9jb25maWcuc2Nyb2xsJiYhdGhpcy5fY29uZmlnLmJhY2tkcm9wfHx0aGlzLl9mb2N1c3RyYXAuYWN0aXZhdGUoKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoJG4pLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShJbiksTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsTW4se3JlbGF0ZWRUYXJnZXQ6dH0pfSksdGhpcy5fZWxlbWVudCwhMCkpfWhpZGUoKXt0aGlzLl9pc1Nob3duJiYoTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsRm4pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9mb2N1c3RyYXAuZGVhY3RpdmF0ZSgpLHRoaXMuX2VsZW1lbnQuYmx1cigpLHRoaXMuX2lzU2hvd249ITEsdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKE5uKSx0aGlzLl9iYWNrZHJvcC5oaWRlKCksdGhpcy5fcXVldWVDYWxsYmFjaygoKCk9Pnt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJG4sTm4pLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1tb2RhbFwiKSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcInJvbGVcIiksdGhpcy5fY29uZmlnLnNjcm9sbHx8KG5ldyBkbikucmVzZXQoKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxXbil9KSx0aGlzLl9lbGVtZW50LCEwKSkpfWRpc3Bvc2UoKXt0aGlzLl9iYWNrZHJvcC5kaXNwb3NlKCksdGhpcy5fZm9jdXN0cmFwLmRlYWN0aXZhdGUoKSxzdXBlci5kaXNwb3NlKCl9X2luaXRpYWxpemVCYWNrRHJvcCgpe2NvbnN0IHQ9Qm9vbGVhbih0aGlzLl9jb25maWcuYmFja2Ryb3ApO3JldHVybiBuZXcgSmkoe2NsYXNzTmFtZTpcIm9mZmNhbnZhcy1iYWNrZHJvcFwiLGlzVmlzaWJsZTp0LGlzQW5pbWF0ZWQ6ITAscm9vdEVsZW1lbnQ6dGhpcy5fZWxlbWVudC5wYXJlbnROb2RlLGNsaWNrQ2FsbGJhY2s6dD8oKT0+e1wic3RhdGljXCIhPT10aGlzLl9jb25maWcuYmFja2Ryb3A/dGhpcy5oaWRlKCk6Ti50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsSG4pfTpudWxsfSl9X2luaXRpYWxpemVGb2N1c1RyYXAoKXtyZXR1cm4gbmV3IHJuKHt0cmFwRWxlbWVudDp0aGlzLl9lbGVtZW50fSl9X2FkZEV2ZW50TGlzdGVuZXJzKCl7Ti5vbih0aGlzLl9lbGVtZW50LFJuLCh0PT57XCJFc2NhcGVcIj09PXQua2V5JiYodGhpcy5fY29uZmlnLmtleWJvYXJkP3RoaXMuaGlkZSgpOk4udHJpZ2dlcih0aGlzLl9lbGVtZW50LEhuKSl9KSl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGU9S24uZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdfHx0LnN0YXJ0c1dpdGgoXCJfXCIpfHxcImNvbnN0cnVjdG9yXCI9PT10KXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0odGhpcyl9fSkpfX1OLm9uKGRvY3VtZW50LHpuLCdbZGF0YS1icy10b2dnbGU9XCJvZmZjYW52YXNcIl0nLChmdW5jdGlvbih0KXtjb25zdCBlPXouZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKTtpZihbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJnQucHJldmVudERlZmF1bHQoKSxsKHRoaXMpKXJldHVybjtOLm9uZShlLFduLCgoKT0+e2EodGhpcykmJnRoaXMuZm9jdXMoKX0pKTtjb25zdCBpPXouZmluZE9uZShQbik7aSYmaSE9PWUmJktuLmdldEluc3RhbmNlKGkpLmhpZGUoKSxLbi5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLnRvZ2dsZSh0aGlzKX0pKSxOLm9uKHdpbmRvdyxEbiwoKCk9Pntmb3IoY29uc3QgdCBvZiB6LmZpbmQoUG4pKUtuLmdldE9yQ3JlYXRlSW5zdGFuY2UodCkuc2hvdygpfSkpLE4ub24od2luZG93LEJuLCgoKT0+e2Zvcihjb25zdCB0IG9mIHouZmluZChcIlthcmlhLW1vZGFsXVtjbGFzcyo9c2hvd11bY2xhc3MqPW9mZmNhbnZhcy1dXCIpKVwiZml4ZWRcIiE9PWdldENvbXB1dGVkU3R5bGUodCkucG9zaXRpb24mJktuLmdldE9yQ3JlYXRlSW5zdGFuY2UodCkuaGlkZSgpfSkpLFIoS24pLG0oS24pO2NvbnN0IFFuPXtcIipcIjpbXCJjbGFzc1wiLFwiZGlyXCIsXCJpZFwiLFwibGFuZ1wiLFwicm9sZVwiLC9eYXJpYS1bXFx3LV0qJC9pXSxhOltcInRhcmdldFwiLFwiaHJlZlwiLFwidGl0bGVcIixcInJlbFwiXSxhcmVhOltdLGI6W10sYnI6W10sY29sOltdLGNvZGU6W10sZGQ6W10sZGl2OltdLGRsOltdLGR0OltdLGVtOltdLGhyOltdLGgxOltdLGgyOltdLGgzOltdLGg0OltdLGg1OltdLGg2OltdLGk6W10saW1nOltcInNyY1wiLFwic3Jjc2V0XCIsXCJhbHRcIixcInRpdGxlXCIsXCJ3aWR0aFwiLFwiaGVpZ2h0XCJdLGxpOltdLG9sOltdLHA6W10scHJlOltdLHM6W10sc21hbGw6W10sc3BhbjpbXSxzdWI6W10sc3VwOltdLHN0cm9uZzpbXSx1OltdLHVsOltdfSxYbj1uZXcgU2V0KFtcImJhY2tncm91bmRcIixcImNpdGVcIixcImhyZWZcIixcIml0ZW10eXBlXCIsXCJsb25nZGVzY1wiLFwicG9zdGVyXCIsXCJzcmNcIixcInhsaW5rOmhyZWZcIl0pLFluPS9eKD8hamF2YXNjcmlwdDopKD86W2EtejAtOSsuLV0rOnxbXiY6Lz8jXSooPzpbLz8jXXwkKSkvaSxVbj0odCxlKT0+e2NvbnN0IGk9dC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpO3JldHVybiBlLmluY2x1ZGVzKGkpPyFYbi5oYXMoaSl8fEJvb2xlYW4oWW4udGVzdCh0Lm5vZGVWYWx1ZSkpOmUuZmlsdGVyKCh0PT50IGluc3RhbmNlb2YgUmVnRXhwKSkuc29tZSgodD0+dC50ZXN0KGkpKSl9LEduPXthbGxvd0xpc3Q6UW4sY29udGVudDp7fSxleHRyYUNsYXNzOlwiXCIsaHRtbDohMSxzYW5pdGl6ZTohMCxzYW5pdGl6ZUZuOm51bGwsdGVtcGxhdGU6XCI8ZGl2PjwvZGl2PlwifSxKbj17YWxsb3dMaXN0Olwib2JqZWN0XCIsY29udGVudDpcIm9iamVjdFwiLGV4dHJhQ2xhc3M6XCIoc3RyaW5nfGZ1bmN0aW9uKVwiLGh0bWw6XCJib29sZWFuXCIsc2FuaXRpemU6XCJib29sZWFuXCIsc2FuaXRpemVGbjpcIihudWxsfGZ1bmN0aW9uKVwiLHRlbXBsYXRlOlwic3RyaW5nXCJ9LFpuPXtlbnRyeTpcIihzdHJpbmd8ZWxlbWVudHxmdW5jdGlvbnxudWxsKVwiLHNlbGVjdG9yOlwiKHN0cmluZ3xlbGVtZW50KVwifTtjbGFzcyB0cyBleHRlbmRzIEh7Y29uc3RydWN0b3IodCl7c3VwZXIoKSx0aGlzLl9jb25maWc9dGhpcy5fZ2V0Q29uZmlnKHQpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBHbn1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIEpufXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiVGVtcGxhdGVGYWN0b3J5XCJ9Z2V0Q29udGVudCgpe3JldHVybiBPYmplY3QudmFsdWVzKHRoaXMuX2NvbmZpZy5jb250ZW50KS5tYXAoKHQ9PnRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHQpKSkuZmlsdGVyKEJvb2xlYW4pfWhhc0NvbnRlbnQoKXtyZXR1cm4gdGhpcy5nZXRDb250ZW50KCkubGVuZ3RoPjB9Y2hhbmdlQ29udGVudCh0KXtyZXR1cm4gdGhpcy5fY2hlY2tDb250ZW50KHQpLHRoaXMuX2NvbmZpZy5jb250ZW50PXsuLi50aGlzLl9jb25maWcuY29udGVudCwuLi50fSx0aGlzfXRvSHRtbCgpe2NvbnN0IHQ9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTt0LmlubmVySFRNTD10aGlzLl9tYXliZVNhbml0aXplKHRoaXMuX2NvbmZpZy50ZW1wbGF0ZSk7Zm9yKGNvbnN0W2UsaV1vZiBPYmplY3QuZW50cmllcyh0aGlzLl9jb25maWcuY29udGVudCkpdGhpcy5fc2V0Q29udGVudCh0LGksZSk7Y29uc3QgZT10LmNoaWxkcmVuWzBdLGk9dGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odGhpcy5fY29uZmlnLmV4dHJhQ2xhc3MpO3JldHVybiBpJiZlLmNsYXNzTGlzdC5hZGQoLi4uaS5zcGxpdChcIiBcIikpLGV9X3R5cGVDaGVja0NvbmZpZyh0KXtzdXBlci5fdHlwZUNoZWNrQ29uZmlnKHQpLHRoaXMuX2NoZWNrQ29udGVudCh0LmNvbnRlbnQpfV9jaGVja0NvbnRlbnQodCl7Zm9yKGNvbnN0W2UsaV1vZiBPYmplY3QuZW50cmllcyh0KSlzdXBlci5fdHlwZUNoZWNrQ29uZmlnKHtzZWxlY3RvcjplLGVudHJ5Oml9LFpuKX1fc2V0Q29udGVudCh0LGUsaSl7Y29uc3Qgbj16LmZpbmRPbmUoaSx0KTtuJiYoKGU9dGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24oZSkpP28oZSk/dGhpcy5fcHV0RWxlbWVudEluVGVtcGxhdGUocihlKSxuKTp0aGlzLl9jb25maWcuaHRtbD9uLmlubmVySFRNTD10aGlzLl9tYXliZVNhbml0aXplKGUpOm4udGV4dENvbnRlbnQ9ZTpuLnJlbW92ZSgpKX1fbWF5YmVTYW5pdGl6ZSh0KXtyZXR1cm4gdGhpcy5fY29uZmlnLnNhbml0aXplP2Z1bmN0aW9uKHQsZSxpKXtpZighdC5sZW5ndGgpcmV0dXJuIHQ7aWYoaSYmXCJmdW5jdGlvblwiPT10eXBlb2YgaSlyZXR1cm4gaSh0KTtjb25zdCBuPShuZXcgd2luZG93LkRPTVBhcnNlcikucGFyc2VGcm9tU3RyaW5nKHQsXCJ0ZXh0L2h0bWxcIikscz1bXS5jb25jYXQoLi4ubi5ib2R5LnF1ZXJ5U2VsZWN0b3JBbGwoXCIqXCIpKTtmb3IoY29uc3QgdCBvZiBzKXtjb25zdCBpPXQubm9kZU5hbWUudG9Mb3dlckNhc2UoKTtpZighT2JqZWN0LmtleXMoZSkuaW5jbHVkZXMoaSkpe3QucmVtb3ZlKCk7Y29udGludWV9Y29uc3Qgbj1bXS5jb25jYXQoLi4udC5hdHRyaWJ1dGVzKSxzPVtdLmNvbmNhdChlW1wiKlwiXXx8W10sZVtpXXx8W10pO2Zvcihjb25zdCBlIG9mIG4pVW4oZSxzKXx8dC5yZW1vdmVBdHRyaWJ1dGUoZS5ub2RlTmFtZSl9cmV0dXJuIG4uYm9keS5pbm5lckhUTUx9KHQsdGhpcy5fY29uZmlnLmFsbG93TGlzdCx0aGlzLl9jb25maWcuc2FuaXRpemVGbik6dH1fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odCl7cmV0dXJuIGcodCxbdm9pZCAwLHRoaXNdKX1fcHV0RWxlbWVudEluVGVtcGxhdGUodCxlKXtpZih0aGlzLl9jb25maWcuaHRtbClyZXR1cm4gZS5pbm5lckhUTUw9XCJcIix2b2lkIGUuYXBwZW5kKHQpO2UudGV4dENvbnRlbnQ9dC50ZXh0Q29udGVudH19Y29uc3QgZXM9bmV3IFNldChbXCJzYW5pdGl6ZVwiLFwiYWxsb3dMaXN0XCIsXCJzYW5pdGl6ZUZuXCJdKSxpcz1cImZhZGVcIixucz1cInNob3dcIixzcz1cIi50b29sdGlwLWlubmVyXCIsb3M9XCIubW9kYWxcIixycz1cImhpZGUuYnMubW9kYWxcIixhcz1cImhvdmVyXCIsbHM9XCJmb2N1c1wiLGNzPXtBVVRPOlwiYXV0b1wiLFRPUDpcInRvcFwiLFJJR0hUOnAoKT9cImxlZnRcIjpcInJpZ2h0XCIsQk9UVE9NOlwiYm90dG9tXCIsTEVGVDpwKCk/XCJyaWdodFwiOlwibGVmdFwifSxocz17YWxsb3dMaXN0OlFuLGFuaW1hdGlvbjohMCxib3VuZGFyeTpcImNsaXBwaW5nUGFyZW50c1wiLGNvbnRhaW5lcjohMSxjdXN0b21DbGFzczpcIlwiLGRlbGF5OjAsZmFsbGJhY2tQbGFjZW1lbnRzOltcInRvcFwiLFwicmlnaHRcIixcImJvdHRvbVwiLFwibGVmdFwiXSxodG1sOiExLG9mZnNldDpbMCw2XSxwbGFjZW1lbnQ6XCJ0b3BcIixwb3BwZXJDb25maWc6bnVsbCxzYW5pdGl6ZTohMCxzYW5pdGl6ZUZuOm51bGwsc2VsZWN0b3I6ITEsdGVtcGxhdGU6JzxkaXYgY2xhc3M9XCJ0b29sdGlwXCIgcm9sZT1cInRvb2x0aXBcIj48ZGl2IGNsYXNzPVwidG9vbHRpcC1hcnJvd1wiPjwvZGl2PjxkaXYgY2xhc3M9XCJ0b29sdGlwLWlubmVyXCI+PC9kaXY+PC9kaXY+Jyx0aXRsZTpcIlwiLHRyaWdnZXI6XCJob3ZlciBmb2N1c1wifSxkcz17YWxsb3dMaXN0Olwib2JqZWN0XCIsYW5pbWF0aW9uOlwiYm9vbGVhblwiLGJvdW5kYXJ5OlwiKHN0cmluZ3xlbGVtZW50KVwiLGNvbnRhaW5lcjpcIihzdHJpbmd8ZWxlbWVudHxib29sZWFuKVwiLGN1c3RvbUNsYXNzOlwiKHN0cmluZ3xmdW5jdGlvbilcIixkZWxheTpcIihudW1iZXJ8b2JqZWN0KVwiLGZhbGxiYWNrUGxhY2VtZW50czpcImFycmF5XCIsaHRtbDpcImJvb2xlYW5cIixvZmZzZXQ6XCIoYXJyYXl8c3RyaW5nfGZ1bmN0aW9uKVwiLHBsYWNlbWVudDpcIihzdHJpbmd8ZnVuY3Rpb24pXCIscG9wcGVyQ29uZmlnOlwiKG51bGx8b2JqZWN0fGZ1bmN0aW9uKVwiLHNhbml0aXplOlwiYm9vbGVhblwiLHNhbml0aXplRm46XCIobnVsbHxmdW5jdGlvbilcIixzZWxlY3RvcjpcIihzdHJpbmd8Ym9vbGVhbilcIix0ZW1wbGF0ZTpcInN0cmluZ1wiLHRpdGxlOlwiKHN0cmluZ3xlbGVtZW50fGZ1bmN0aW9uKVwiLHRyaWdnZXI6XCJzdHJpbmdcIn07Y2xhc3MgdXMgZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQsZSl7aWYodm9pZCAwPT09d2kpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkJvb3RzdHJhcCdzIHRvb2x0aXBzIHJlcXVpcmUgUG9wcGVyIChodHRwczovL3BvcHBlci5qcy5vcmcvZG9jcy92Mi8pXCIpO3N1cGVyKHQsZSksdGhpcy5faXNFbmFibGVkPSEwLHRoaXMuX3RpbWVvdXQ9MCx0aGlzLl9pc0hvdmVyZWQ9bnVsbCx0aGlzLl9hY3RpdmVUcmlnZ2VyPXt9LHRoaXMuX3BvcHBlcj1udWxsLHRoaXMuX3RlbXBsYXRlRmFjdG9yeT1udWxsLHRoaXMuX25ld0NvbnRlbnQ9bnVsbCx0aGlzLnRpcD1udWxsLHRoaXMuX3NldExpc3RlbmVycygpLHRoaXMuX2NvbmZpZy5zZWxlY3Rvcnx8dGhpcy5fZml4VGl0bGUoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gaHN9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBkc31zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInRvb2x0aXBcIn1lbmFibGUoKXt0aGlzLl9pc0VuYWJsZWQ9ITB9ZGlzYWJsZSgpe3RoaXMuX2lzRW5hYmxlZD0hMX10b2dnbGVFbmFibGVkKCl7dGhpcy5faXNFbmFibGVkPSF0aGlzLl9pc0VuYWJsZWR9dG9nZ2xlKCl7dGhpcy5faXNFbmFibGVkJiYodGhpcy5faXNTaG93bigpP3RoaXMuX2xlYXZlKCk6dGhpcy5fZW50ZXIoKSl9ZGlzcG9zZSgpe2NsZWFyVGltZW91dCh0aGlzLl90aW1lb3V0KSxOLm9mZih0aGlzLl9lbGVtZW50LmNsb3Nlc3Qob3MpLHJzLHRoaXMuX2hpZGVNb2RhbEhhbmRsZXIpLHRoaXMuX2VsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy1vcmlnaW5hbC10aXRsZVwiKSYmdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiLHRoaXMuX2VsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy1vcmlnaW5hbC10aXRsZVwiKSksdGhpcy5fZGlzcG9zZVBvcHBlcigpLHN1cGVyLmRpc3Bvc2UoKX1zaG93KCl7aWYoXCJub25lXCI9PT10aGlzLl9lbGVtZW50LnN0eWxlLmRpc3BsYXkpdGhyb3cgbmV3IEVycm9yKFwiUGxlYXNlIHVzZSBzaG93IG9uIHZpc2libGUgZWxlbWVudHNcIik7aWYoIXRoaXMuX2lzV2l0aENvbnRlbnQoKXx8IXRoaXMuX2lzRW5hYmxlZClyZXR1cm47Y29uc3QgdD1OLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcInNob3dcIikpLGU9KGModGhpcy5fZWxlbWVudCl8fHRoaXMuX2VsZW1lbnQub3duZXJEb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLmNvbnRhaW5zKHRoaXMuX2VsZW1lbnQpO2lmKHQuZGVmYXVsdFByZXZlbnRlZHx8IWUpcmV0dXJuO3RoaXMuX2Rpc3Bvc2VQb3BwZXIoKTtjb25zdCBpPXRoaXMuX2dldFRpcEVsZW1lbnQoKTt0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtZGVzY3JpYmVkYnlcIixpLmdldEF0dHJpYnV0ZShcImlkXCIpKTtjb25zdHtjb250YWluZXI6bn09dGhpcy5fY29uZmlnO2lmKHRoaXMuX2VsZW1lbnQub3duZXJEb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY29udGFpbnModGhpcy50aXApfHwobi5hcHBlbmQoaSksTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJpbnNlcnRlZFwiKSkpLHRoaXMuX3BvcHBlcj10aGlzLl9jcmVhdGVQb3BwZXIoaSksaS5jbGFzc0xpc3QuYWRkKG5zKSxcIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KWZvcihjb25zdCB0IG9mW10uY29uY2F0KC4uLmRvY3VtZW50LmJvZHkuY2hpbGRyZW4pKU4ub24odCxcIm1vdXNlb3ZlclwiLGgpO3RoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57Ti50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJzaG93blwiKSksITE9PT10aGlzLl9pc0hvdmVyZWQmJnRoaXMuX2xlYXZlKCksdGhpcy5faXNIb3ZlcmVkPSExfSksdGhpcy50aXAsdGhpcy5faXNBbmltYXRlZCgpKX1oaWRlKCl7aWYodGhpcy5faXNTaG93bigpJiYhTi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJoaWRlXCIpKS5kZWZhdWx0UHJldmVudGVkKXtpZih0aGlzLl9nZXRUaXBFbGVtZW50KCkuY2xhc3NMaXN0LnJlbW92ZShucyksXCJvbnRvdWNoc3RhcnRcImluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudClmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlOLm9mZih0LFwibW91c2VvdmVyXCIsaCk7dGhpcy5fYWN0aXZlVHJpZ2dlci5jbGljaz0hMSx0aGlzLl9hY3RpdmVUcmlnZ2VyW2xzXT0hMSx0aGlzLl9hY3RpdmVUcmlnZ2VyW2FzXT0hMSx0aGlzLl9pc0hvdmVyZWQ9bnVsbCx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgoKT0+e3RoaXMuX2lzV2l0aEFjdGl2ZVRyaWdnZXIoKXx8KHRoaXMuX2lzSG92ZXJlZHx8dGhpcy5fZGlzcG9zZVBvcHBlcigpLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1kZXNjcmliZWRieVwiKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImhpZGRlblwiKSkpfSksdGhpcy50aXAsdGhpcy5faXNBbmltYXRlZCgpKX19dXBkYXRlKCl7dGhpcy5fcG9wcGVyJiZ0aGlzLl9wb3BwZXIudXBkYXRlKCl9X2lzV2l0aENvbnRlbnQoKXtyZXR1cm4gQm9vbGVhbih0aGlzLl9nZXRUaXRsZSgpKX1fZ2V0VGlwRWxlbWVudCgpe3JldHVybiB0aGlzLnRpcHx8KHRoaXMudGlwPXRoaXMuX2NyZWF0ZVRpcEVsZW1lbnQodGhpcy5fbmV3Q29udGVudHx8dGhpcy5fZ2V0Q29udGVudEZvclRlbXBsYXRlKCkpKSx0aGlzLnRpcH1fY3JlYXRlVGlwRWxlbWVudCh0KXtjb25zdCBlPXRoaXMuX2dldFRlbXBsYXRlRmFjdG9yeSh0KS50b0h0bWwoKTtpZighZSlyZXR1cm4gbnVsbDtlLmNsYXNzTGlzdC5yZW1vdmUoaXMsbnMpLGUuY2xhc3NMaXN0LmFkZChgYnMtJHt0aGlzLmNvbnN0cnVjdG9yLk5BTUV9LWF1dG9gKTtjb25zdCBpPSh0PT57ZG97dCs9TWF0aC5mbG9vcigxZTYqTWF0aC5yYW5kb20oKSl9d2hpbGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQodCkpO3JldHVybiB0fSkodGhpcy5jb25zdHJ1Y3Rvci5OQU1FKS50b1N0cmluZygpO3JldHVybiBlLnNldEF0dHJpYnV0ZShcImlkXCIsaSksdGhpcy5faXNBbmltYXRlZCgpJiZlLmNsYXNzTGlzdC5hZGQoaXMpLGV9c2V0Q29udGVudCh0KXt0aGlzLl9uZXdDb250ZW50PXQsdGhpcy5faXNTaG93bigpJiYodGhpcy5fZGlzcG9zZVBvcHBlcigpLHRoaXMuc2hvdygpKX1fZ2V0VGVtcGxhdGVGYWN0b3J5KHQpe3JldHVybiB0aGlzLl90ZW1wbGF0ZUZhY3Rvcnk/dGhpcy5fdGVtcGxhdGVGYWN0b3J5LmNoYW5nZUNvbnRlbnQodCk6dGhpcy5fdGVtcGxhdGVGYWN0b3J5PW5ldyB0cyh7Li4udGhpcy5fY29uZmlnLGNvbnRlbnQ6dCxleHRyYUNsYXNzOnRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHRoaXMuX2NvbmZpZy5jdXN0b21DbGFzcyl9KSx0aGlzLl90ZW1wbGF0ZUZhY3Rvcnl9X2dldENvbnRlbnRGb3JUZW1wbGF0ZSgpe3JldHVybntbc3NdOnRoaXMuX2dldFRpdGxlKCl9fV9nZXRUaXRsZSgpe3JldHVybiB0aGlzLl9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0aGlzLl9jb25maWcudGl0bGUpfHx0aGlzLl9lbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtYnMtb3JpZ2luYWwtdGl0bGVcIil9X2luaXRpYWxpemVPbkRlbGVnYXRlZFRhcmdldCh0KXtyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5nZXRPckNyZWF0ZUluc3RhbmNlKHQuZGVsZWdhdGVUYXJnZXQsdGhpcy5fZ2V0RGVsZWdhdGVDb25maWcoKSl9X2lzQW5pbWF0ZWQoKXtyZXR1cm4gdGhpcy5fY29uZmlnLmFuaW1hdGlvbnx8dGhpcy50aXAmJnRoaXMudGlwLmNsYXNzTGlzdC5jb250YWlucyhpcyl9X2lzU2hvd24oKXtyZXR1cm4gdGhpcy50aXAmJnRoaXMudGlwLmNsYXNzTGlzdC5jb250YWlucyhucyl9X2NyZWF0ZVBvcHBlcih0KXtjb25zdCBlPWcodGhpcy5fY29uZmlnLnBsYWNlbWVudCxbdGhpcyx0LHRoaXMuX2VsZW1lbnRdKSxpPWNzW2UudG9VcHBlckNhc2UoKV07cmV0dXJuIHlpKHRoaXMuX2VsZW1lbnQsdCx0aGlzLl9nZXRQb3BwZXJDb25maWcoaSkpfV9nZXRPZmZzZXQoKXtjb25zdHtvZmZzZXQ6dH09dGhpcy5fY29uZmlnO3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiB0P3Quc3BsaXQoXCIsXCIpLm1hcCgodD0+TnVtYmVyLnBhcnNlSW50KHQsMTApKSk6XCJmdW5jdGlvblwiPT10eXBlb2YgdD9lPT50KGUsdGhpcy5fZWxlbWVudCk6dH1fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odCl7cmV0dXJuIGcodCxbdGhpcy5fZWxlbWVudCx0aGlzLl9lbGVtZW50XSl9X2dldFBvcHBlckNvbmZpZyh0KXtjb25zdCBlPXtwbGFjZW1lbnQ6dCxtb2RpZmllcnM6W3tuYW1lOlwiZmxpcFwiLG9wdGlvbnM6e2ZhbGxiYWNrUGxhY2VtZW50czp0aGlzLl9jb25maWcuZmFsbGJhY2tQbGFjZW1lbnRzfX0se25hbWU6XCJvZmZzZXRcIixvcHRpb25zOntvZmZzZXQ6dGhpcy5fZ2V0T2Zmc2V0KCl9fSx7bmFtZTpcInByZXZlbnRPdmVyZmxvd1wiLG9wdGlvbnM6e2JvdW5kYXJ5OnRoaXMuX2NvbmZpZy5ib3VuZGFyeX19LHtuYW1lOlwiYXJyb3dcIixvcHRpb25zOntlbGVtZW50OmAuJHt0aGlzLmNvbnN0cnVjdG9yLk5BTUV9LWFycm93YH19LHtuYW1lOlwicHJlU2V0UGxhY2VtZW50XCIsZW5hYmxlZDohMCxwaGFzZTpcImJlZm9yZU1haW5cIixmbjp0PT57dGhpcy5fZ2V0VGlwRWxlbWVudCgpLnNldEF0dHJpYnV0ZShcImRhdGEtcG9wcGVyLXBsYWNlbWVudFwiLHQuc3RhdGUucGxhY2VtZW50KX19XX07cmV0dXJuey4uLmUsLi4uZyh0aGlzLl9jb25maWcucG9wcGVyQ29uZmlnLFt2b2lkIDAsZV0pfX1fc2V0TGlzdGVuZXJzKCl7Y29uc3QgdD10aGlzLl9jb25maWcudHJpZ2dlci5zcGxpdChcIiBcIik7Zm9yKGNvbnN0IGUgb2YgdClpZihcImNsaWNrXCI9PT1lKU4ub24odGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImNsaWNrXCIpLHRoaXMuX2NvbmZpZy5zZWxlY3RvciwodD0+e3RoaXMuX2luaXRpYWxpemVPbkRlbGVnYXRlZFRhcmdldCh0KS50b2dnbGUoKX0pKTtlbHNlIGlmKFwibWFudWFsXCIhPT1lKXtjb25zdCB0PWU9PT1hcz90aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcIm1vdXNlZW50ZXJcIik6dGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJmb2N1c2luXCIpLGk9ZT09PWFzP3RoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwibW91c2VsZWF2ZVwiKTp0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImZvY3Vzb3V0XCIpO04ub24odGhpcy5fZWxlbWVudCx0LHRoaXMuX2NvbmZpZy5zZWxlY3RvciwodD0+e2NvbnN0IGU9dGhpcy5faW5pdGlhbGl6ZU9uRGVsZWdhdGVkVGFyZ2V0KHQpO2UuX2FjdGl2ZVRyaWdnZXJbXCJmb2N1c2luXCI9PT10LnR5cGU/bHM6YXNdPSEwLGUuX2VudGVyKCl9KSksTi5vbih0aGlzLl9lbGVtZW50LGksdGhpcy5fY29uZmlnLnNlbGVjdG9yLCh0PT57Y29uc3QgZT10aGlzLl9pbml0aWFsaXplT25EZWxlZ2F0ZWRUYXJnZXQodCk7ZS5fYWN0aXZlVHJpZ2dlcltcImZvY3Vzb3V0XCI9PT10LnR5cGU/bHM6YXNdPWUuX2VsZW1lbnQuY29udGFpbnModC5yZWxhdGVkVGFyZ2V0KSxlLl9sZWF2ZSgpfSkpfXRoaXMuX2hpZGVNb2RhbEhhbmRsZXI9KCk9Pnt0aGlzLl9lbGVtZW50JiZ0aGlzLmhpZGUoKX0sTi5vbih0aGlzLl9lbGVtZW50LmNsb3Nlc3Qob3MpLHJzLHRoaXMuX2hpZGVNb2RhbEhhbmRsZXIpfV9maXhUaXRsZSgpe2NvbnN0IHQ9dGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKTt0JiYodGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpfHx0aGlzLl9lbGVtZW50LnRleHRDb250ZW50LnRyaW0oKXx8dGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsdCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLW9yaWdpbmFsLXRpdGxlXCIsdCksdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJ0aXRsZVwiKSl9X2VudGVyKCl7dGhpcy5faXNTaG93bigpfHx0aGlzLl9pc0hvdmVyZWQ/dGhpcy5faXNIb3ZlcmVkPSEwOih0aGlzLl9pc0hvdmVyZWQ9ITAsdGhpcy5fc2V0VGltZW91dCgoKCk9Pnt0aGlzLl9pc0hvdmVyZWQmJnRoaXMuc2hvdygpfSksdGhpcy5fY29uZmlnLmRlbGF5LnNob3cpKX1fbGVhdmUoKXt0aGlzLl9pc1dpdGhBY3RpdmVUcmlnZ2VyKCl8fCh0aGlzLl9pc0hvdmVyZWQ9ITEsdGhpcy5fc2V0VGltZW91dCgoKCk9Pnt0aGlzLl9pc0hvdmVyZWR8fHRoaXMuaGlkZSgpfSksdGhpcy5fY29uZmlnLmRlbGF5LmhpZGUpKX1fc2V0VGltZW91dCh0LGUpe2NsZWFyVGltZW91dCh0aGlzLl90aW1lb3V0KSx0aGlzLl90aW1lb3V0PXNldFRpbWVvdXQodCxlKX1faXNXaXRoQWN0aXZlVHJpZ2dlcigpe3JldHVybiBPYmplY3QudmFsdWVzKHRoaXMuX2FjdGl2ZVRyaWdnZXIpLmluY2x1ZGVzKCEwKX1fZ2V0Q29uZmlnKHQpe2NvbnN0IGU9Ri5nZXREYXRhQXR0cmlidXRlcyh0aGlzLl9lbGVtZW50KTtmb3IoY29uc3QgdCBvZiBPYmplY3Qua2V5cyhlKSllcy5oYXModCkmJmRlbGV0ZSBlW3RdO3JldHVybiB0PXsuLi5lLC4uLlwib2JqZWN0XCI9PXR5cGVvZiB0JiZ0P3Q6e319LHQ9dGhpcy5fbWVyZ2VDb25maWdPYmoodCksdD10aGlzLl9jb25maWdBZnRlck1lcmdlKHQpLHRoaXMuX3R5cGVDaGVja0NvbmZpZyh0KSx0fV9jb25maWdBZnRlck1lcmdlKHQpe3JldHVybiB0LmNvbnRhaW5lcj0hMT09PXQuY29udGFpbmVyP2RvY3VtZW50LmJvZHk6cih0LmNvbnRhaW5lciksXCJudW1iZXJcIj09dHlwZW9mIHQuZGVsYXkmJih0LmRlbGF5PXtzaG93OnQuZGVsYXksaGlkZTp0LmRlbGF5fSksXCJudW1iZXJcIj09dHlwZW9mIHQudGl0bGUmJih0LnRpdGxlPXQudGl0bGUudG9TdHJpbmcoKSksXCJudW1iZXJcIj09dHlwZW9mIHQuY29udGVudCYmKHQuY29udGVudD10LmNvbnRlbnQudG9TdHJpbmcoKSksdH1fZ2V0RGVsZWdhdGVDb25maWcoKXtjb25zdCB0PXt9O2Zvcihjb25zdFtlLGldb2YgT2JqZWN0LmVudHJpZXModGhpcy5fY29uZmlnKSl0aGlzLmNvbnN0cnVjdG9yLkRlZmF1bHRbZV0hPT1pJiYodFtlXT1pKTtyZXR1cm4gdC5zZWxlY3Rvcj0hMSx0LnRyaWdnZXI9XCJtYW51YWxcIix0fV9kaXNwb3NlUG9wcGVyKCl7dGhpcy5fcG9wcGVyJiYodGhpcy5fcG9wcGVyLmRlc3Ryb3koKSx0aGlzLl9wb3BwZXI9bnVsbCksdGhpcy50aXAmJih0aGlzLnRpcC5yZW1vdmUoKSx0aGlzLnRpcD1udWxsKX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goKGZ1bmN0aW9uKCl7Y29uc3QgZT11cy5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pKX19bSh1cyk7Y29uc3QgZnM9XCIucG9wb3Zlci1oZWFkZXJcIixwcz1cIi5wb3BvdmVyLWJvZHlcIixtcz17Li4udXMuRGVmYXVsdCxjb250ZW50OlwiXCIsb2Zmc2V0OlswLDhdLHBsYWNlbWVudDpcInJpZ2h0XCIsdGVtcGxhdGU6JzxkaXYgY2xhc3M9XCJwb3BvdmVyXCIgcm9sZT1cInRvb2x0aXBcIj48ZGl2IGNsYXNzPVwicG9wb3Zlci1hcnJvd1wiPjwvZGl2PjxoMyBjbGFzcz1cInBvcG92ZXItaGVhZGVyXCI+PC9oMz48ZGl2IGNsYXNzPVwicG9wb3Zlci1ib2R5XCI+PC9kaXY+PC9kaXY+Jyx0cmlnZ2VyOlwiY2xpY2tcIn0sZ3M9ey4uLnVzLkRlZmF1bHRUeXBlLGNvbnRlbnQ6XCIobnVsbHxzdHJpbmd8ZWxlbWVudHxmdW5jdGlvbilcIn07Y2xhc3MgX3MgZXh0ZW5kcyB1c3tzdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gbXN9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBnc31zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInBvcG92ZXJcIn1faXNXaXRoQ29udGVudCgpe3JldHVybiB0aGlzLl9nZXRUaXRsZSgpfHx0aGlzLl9nZXRDb250ZW50KCl9X2dldENvbnRlbnRGb3JUZW1wbGF0ZSgpe3JldHVybntbZnNdOnRoaXMuX2dldFRpdGxlKCksW3BzXTp0aGlzLl9nZXRDb250ZW50KCl9fV9nZXRDb250ZW50KCl7cmV0dXJuIHRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHRoaXMuX2NvbmZpZy5jb250ZW50KX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goKGZ1bmN0aW9uKCl7Y29uc3QgZT1fcy5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pKX19bShfcyk7Y29uc3QgYnM9XCIuYnMuc2Nyb2xsc3B5XCIsdnM9YGFjdGl2YXRlJHtic31gLHlzPWBjbGljayR7YnN9YCx3cz1gbG9hZCR7YnN9LmRhdGEtYXBpYCxBcz1cImFjdGl2ZVwiLEVzPVwiW2hyZWZdXCIsVHM9XCIubmF2LWxpbmtcIixDcz1gJHtUc30sIC5uYXYtaXRlbSA+ICR7VHN9LCAubGlzdC1ncm91cC1pdGVtYCxPcz17b2Zmc2V0Om51bGwscm9vdE1hcmdpbjpcIjBweCAwcHggLTI1JVwiLHNtb290aFNjcm9sbDohMSx0YXJnZXQ6bnVsbCx0aHJlc2hvbGQ6Wy4xLC41LDFdfSx4cz17b2Zmc2V0OlwiKG51bWJlcnxudWxsKVwiLHJvb3RNYXJnaW46XCJzdHJpbmdcIixzbW9vdGhTY3JvbGw6XCJib29sZWFuXCIsdGFyZ2V0OlwiZWxlbWVudFwiLHRocmVzaG9sZDpcImFycmF5XCJ9O2NsYXNzIGtzIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fdGFyZ2V0TGlua3M9bmV3IE1hcCx0aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnM9bmV3IE1hcCx0aGlzLl9yb290RWxlbWVudD1cInZpc2libGVcIj09PWdldENvbXB1dGVkU3R5bGUodGhpcy5fZWxlbWVudCkub3ZlcmZsb3dZP251bGw6dGhpcy5fZWxlbWVudCx0aGlzLl9hY3RpdmVUYXJnZXQ9bnVsbCx0aGlzLl9vYnNlcnZlcj1udWxsLHRoaXMuX3ByZXZpb3VzU2Nyb2xsRGF0YT17dmlzaWJsZUVudHJ5VG9wOjAscGFyZW50U2Nyb2xsVG9wOjB9LHRoaXMucmVmcmVzaCgpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBPc31zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIHhzfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwic2Nyb2xsc3B5XCJ9cmVmcmVzaCgpe3RoaXMuX2luaXRpYWxpemVUYXJnZXRzQW5kT2JzZXJ2YWJsZXMoKSx0aGlzLl9tYXliZUVuYWJsZVNtb290aFNjcm9sbCgpLHRoaXMuX29ic2VydmVyP3RoaXMuX29ic2VydmVyLmRpc2Nvbm5lY3QoKTp0aGlzLl9vYnNlcnZlcj10aGlzLl9nZXROZXdPYnNlcnZlcigpO2Zvcihjb25zdCB0IG9mIHRoaXMuX29ic2VydmFibGVTZWN0aW9ucy52YWx1ZXMoKSl0aGlzLl9vYnNlcnZlci5vYnNlcnZlKHQpfWRpc3Bvc2UoKXt0aGlzLl9vYnNlcnZlci5kaXNjb25uZWN0KCksc3VwZXIuZGlzcG9zZSgpfV9jb25maWdBZnRlck1lcmdlKHQpe3JldHVybiB0LnRhcmdldD1yKHQudGFyZ2V0KXx8ZG9jdW1lbnQuYm9keSx0LnJvb3RNYXJnaW49dC5vZmZzZXQ/YCR7dC5vZmZzZXR9cHggMHB4IC0zMCVgOnQucm9vdE1hcmdpbixcInN0cmluZ1wiPT10eXBlb2YgdC50aHJlc2hvbGQmJih0LnRocmVzaG9sZD10LnRocmVzaG9sZC5zcGxpdChcIixcIikubWFwKCh0PT5OdW1iZXIucGFyc2VGbG9hdCh0KSkpKSx0fV9tYXliZUVuYWJsZVNtb290aFNjcm9sbCgpe3RoaXMuX2NvbmZpZy5zbW9vdGhTY3JvbGwmJihOLm9mZih0aGlzLl9jb25maWcudGFyZ2V0LHlzKSxOLm9uKHRoaXMuX2NvbmZpZy50YXJnZXQseXMsRXMsKHQ9Pntjb25zdCBlPXRoaXMuX29ic2VydmFibGVTZWN0aW9ucy5nZXQodC50YXJnZXQuaGFzaCk7aWYoZSl7dC5wcmV2ZW50RGVmYXVsdCgpO2NvbnN0IGk9dGhpcy5fcm9vdEVsZW1lbnR8fHdpbmRvdyxuPWUub2Zmc2V0VG9wLXRoaXMuX2VsZW1lbnQub2Zmc2V0VG9wO2lmKGkuc2Nyb2xsVG8pcmV0dXJuIHZvaWQgaS5zY3JvbGxUbyh7dG9wOm4sYmVoYXZpb3I6XCJzbW9vdGhcIn0pO2kuc2Nyb2xsVG9wPW59fSkpKX1fZ2V0TmV3T2JzZXJ2ZXIoKXtjb25zdCB0PXtyb290OnRoaXMuX3Jvb3RFbGVtZW50LHRocmVzaG9sZDp0aGlzLl9jb25maWcudGhyZXNob2xkLHJvb3RNYXJnaW46dGhpcy5fY29uZmlnLnJvb3RNYXJnaW59O3JldHVybiBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKHQ9PnRoaXMuX29ic2VydmVyQ2FsbGJhY2sodCkpLHQpfV9vYnNlcnZlckNhbGxiYWNrKHQpe2NvbnN0IGU9dD0+dGhpcy5fdGFyZ2V0TGlua3MuZ2V0KGAjJHt0LnRhcmdldC5pZH1gKSxpPXQ9Pnt0aGlzLl9wcmV2aW91c1Njcm9sbERhdGEudmlzaWJsZUVudHJ5VG9wPXQudGFyZ2V0Lm9mZnNldFRvcCx0aGlzLl9wcm9jZXNzKGUodCkpfSxuPSh0aGlzLl9yb290RWxlbWVudHx8ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5zY3JvbGxUb3Ascz1uPj10aGlzLl9wcmV2aW91c1Njcm9sbERhdGEucGFyZW50U2Nyb2xsVG9wO3RoaXMuX3ByZXZpb3VzU2Nyb2xsRGF0YS5wYXJlbnRTY3JvbGxUb3A9bjtmb3IoY29uc3QgbyBvZiB0KXtpZighby5pc0ludGVyc2VjdGluZyl7dGhpcy5fYWN0aXZlVGFyZ2V0PW51bGwsdGhpcy5fY2xlYXJBY3RpdmVDbGFzcyhlKG8pKTtjb250aW51ZX1jb25zdCB0PW8udGFyZ2V0Lm9mZnNldFRvcD49dGhpcy5fcHJldmlvdXNTY3JvbGxEYXRhLnZpc2libGVFbnRyeVRvcDtpZihzJiZ0KXtpZihpKG8pLCFuKXJldHVybn1lbHNlIHN8fHR8fGkobyl9fV9pbml0aWFsaXplVGFyZ2V0c0FuZE9ic2VydmFibGVzKCl7dGhpcy5fdGFyZ2V0TGlua3M9bmV3IE1hcCx0aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnM9bmV3IE1hcDtjb25zdCB0PXouZmluZChFcyx0aGlzLl9jb25maWcudGFyZ2V0KTtmb3IoY29uc3QgZSBvZiB0KXtpZighZS5oYXNofHxsKGUpKWNvbnRpbnVlO2NvbnN0IHQ9ei5maW5kT25lKGRlY29kZVVSSShlLmhhc2gpLHRoaXMuX2VsZW1lbnQpO2EodCkmJih0aGlzLl90YXJnZXRMaW5rcy5zZXQoZGVjb2RlVVJJKGUuaGFzaCksZSksdGhpcy5fb2JzZXJ2YWJsZVNlY3Rpb25zLnNldChlLmhhc2gsdCkpfX1fcHJvY2Vzcyh0KXt0aGlzLl9hY3RpdmVUYXJnZXQhPT10JiYodGhpcy5fY2xlYXJBY3RpdmVDbGFzcyh0aGlzLl9jb25maWcudGFyZ2V0KSx0aGlzLl9hY3RpdmVUYXJnZXQ9dCx0LmNsYXNzTGlzdC5hZGQoQXMpLHRoaXMuX2FjdGl2YXRlUGFyZW50cyh0KSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCx2cyx7cmVsYXRlZFRhcmdldDp0fSkpfV9hY3RpdmF0ZVBhcmVudHModCl7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZG93bi1pdGVtXCIpKXouZmluZE9uZShcIi5kcm9wZG93bi10b2dnbGVcIix0LmNsb3Nlc3QoXCIuZHJvcGRvd25cIikpLmNsYXNzTGlzdC5hZGQoQXMpO2Vsc2UgZm9yKGNvbnN0IGUgb2Ygei5wYXJlbnRzKHQsXCIubmF2LCAubGlzdC1ncm91cFwiKSlmb3IoY29uc3QgdCBvZiB6LnByZXYoZSxDcykpdC5jbGFzc0xpc3QuYWRkKEFzKX1fY2xlYXJBY3RpdmVDbGFzcyh0KXt0LmNsYXNzTGlzdC5yZW1vdmUoQXMpO2NvbnN0IGU9ei5maW5kKGAke0VzfS4ke0FzfWAsdCk7Zm9yKGNvbnN0IHQgb2YgZSl0LmNsYXNzTGlzdC5yZW1vdmUoQXMpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaCgoZnVuY3Rpb24oKXtjb25zdCBlPWtzLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyx0KTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fSkpfX1OLm9uKHdpbmRvdyx3cywoKCk9Pntmb3IoY29uc3QgdCBvZiB6LmZpbmQoJ1tkYXRhLWJzLXNweT1cInNjcm9sbFwiXScpKWtzLmdldE9yQ3JlYXRlSW5zdGFuY2UodCl9KSksbShrcyk7Y29uc3QgTHM9XCIuYnMudGFiXCIsU3M9YGhpZGUke0xzfWAsRHM9YGhpZGRlbiR7THN9YCwkcz1gc2hvdyR7THN9YCxJcz1gc2hvd24ke0xzfWAsTnM9YGNsaWNrJHtMc31gLFBzPWBrZXlkb3duJHtMc31gLGpzPWBsb2FkJHtMc31gLE1zPVwiQXJyb3dMZWZ0XCIsRnM9XCJBcnJvd1JpZ2h0XCIsSHM9XCJBcnJvd1VwXCIsV3M9XCJBcnJvd0Rvd25cIixCcz1cIkhvbWVcIix6cz1cIkVuZFwiLFJzPVwiYWN0aXZlXCIscXM9XCJmYWRlXCIsVnM9XCJzaG93XCIsS3M9XCIuZHJvcGRvd24tdG9nZ2xlXCIsUXM9YDpub3QoJHtLc30pYCxYcz0nW2RhdGEtYnMtdG9nZ2xlPVwidGFiXCJdLCBbZGF0YS1icy10b2dnbGU9XCJwaWxsXCJdLCBbZGF0YS1icy10b2dnbGU9XCJsaXN0XCJdJyxZcz1gLm5hdi1saW5rJHtRc30sIC5saXN0LWdyb3VwLWl0ZW0ke1FzfSwgW3JvbGU9XCJ0YWJcIl0ke1FzfSwgJHtYc31gLFVzPWAuJHtSc31bZGF0YS1icy10b2dnbGU9XCJ0YWJcIl0sIC4ke1JzfVtkYXRhLWJzLXRvZ2dsZT1cInBpbGxcIl0sIC4ke1JzfVtkYXRhLWJzLXRvZ2dsZT1cImxpc3RcIl1gO2NsYXNzIEdzIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0KXtzdXBlcih0KSx0aGlzLl9wYXJlbnQ9dGhpcy5fZWxlbWVudC5jbG9zZXN0KCcubGlzdC1ncm91cCwgLm5hdiwgW3JvbGU9XCJ0YWJsaXN0XCJdJyksdGhpcy5fcGFyZW50JiYodGhpcy5fc2V0SW5pdGlhbEF0dHJpYnV0ZXModGhpcy5fcGFyZW50LHRoaXMuX2dldENoaWxkcmVuKCkpLE4ub24odGhpcy5fZWxlbWVudCxQcywodD0+dGhpcy5fa2V5ZG93bih0KSkpKX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInRhYlwifXNob3coKXtjb25zdCB0PXRoaXMuX2VsZW1lbnQ7aWYodGhpcy5fZWxlbUlzQWN0aXZlKHQpKXJldHVybjtjb25zdCBlPXRoaXMuX2dldEFjdGl2ZUVsZW0oKSxpPWU/Ti50cmlnZ2VyKGUsU3Mse3JlbGF0ZWRUYXJnZXQ6dH0pOm51bGw7Ti50cmlnZ2VyKHQsJHMse3JlbGF0ZWRUYXJnZXQ6ZX0pLmRlZmF1bHRQcmV2ZW50ZWR8fGkmJmkuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2RlYWN0aXZhdGUoZSx0KSx0aGlzLl9hY3RpdmF0ZSh0LGUpKX1fYWN0aXZhdGUodCxlKXt0JiYodC5jbGFzc0xpc3QuYWRkKFJzKSx0aGlzLl9hY3RpdmF0ZSh6LmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCkpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57XCJ0YWJcIj09PXQuZ2V0QXR0cmlidXRlKFwicm9sZVwiKT8odC5yZW1vdmVBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiKSx0LnNldEF0dHJpYnV0ZShcImFyaWEtc2VsZWN0ZWRcIiwhMCksdGhpcy5fdG9nZ2xlRHJvcERvd24odCwhMCksTi50cmlnZ2VyKHQsSXMse3JlbGF0ZWRUYXJnZXQ6ZX0pKTp0LmNsYXNzTGlzdC5hZGQoVnMpfSksdCx0LmNsYXNzTGlzdC5jb250YWlucyhxcykpKX1fZGVhY3RpdmF0ZSh0LGUpe3QmJih0LmNsYXNzTGlzdC5yZW1vdmUoUnMpLHQuYmx1cigpLHRoaXMuX2RlYWN0aXZhdGUoei5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHQpKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgoKT0+e1widGFiXCI9PT10LmdldEF0dHJpYnV0ZShcInJvbGVcIik/KHQuc2V0QXR0cmlidXRlKFwiYXJpYS1zZWxlY3RlZFwiLCExKSx0LnNldEF0dHJpYnV0ZShcInRhYmluZGV4XCIsXCItMVwiKSx0aGlzLl90b2dnbGVEcm9wRG93bih0LCExKSxOLnRyaWdnZXIodCxEcyx7cmVsYXRlZFRhcmdldDplfSkpOnQuY2xhc3NMaXN0LnJlbW92ZShWcyl9KSx0LHQuY2xhc3NMaXN0LmNvbnRhaW5zKHFzKSkpfV9rZXlkb3duKHQpe2lmKCFbTXMsRnMsSHMsV3MsQnMsenNdLmluY2x1ZGVzKHQua2V5KSlyZXR1cm47dC5zdG9wUHJvcGFnYXRpb24oKSx0LnByZXZlbnREZWZhdWx0KCk7Y29uc3QgZT10aGlzLl9nZXRDaGlsZHJlbigpLmZpbHRlcigodD0+IWwodCkpKTtsZXQgaTtpZihbQnMsenNdLmluY2x1ZGVzKHQua2V5KSlpPWVbdC5rZXk9PT1Ccz8wOmUubGVuZ3RoLTFdO2Vsc2V7Y29uc3Qgbj1bRnMsV3NdLmluY2x1ZGVzKHQua2V5KTtpPWIoZSx0LnRhcmdldCxuLCEwKX1pJiYoaS5mb2N1cyh7cHJldmVudFNjcm9sbDohMH0pLEdzLmdldE9yQ3JlYXRlSW5zdGFuY2UoaSkuc2hvdygpKX1fZ2V0Q2hpbGRyZW4oKXtyZXR1cm4gei5maW5kKFlzLHRoaXMuX3BhcmVudCl9X2dldEFjdGl2ZUVsZW0oKXtyZXR1cm4gdGhpcy5fZ2V0Q2hpbGRyZW4oKS5maW5kKCh0PT50aGlzLl9lbGVtSXNBY3RpdmUodCkpKXx8bnVsbH1fc2V0SW5pdGlhbEF0dHJpYnV0ZXModCxlKXt0aGlzLl9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyh0LFwicm9sZVwiLFwidGFibGlzdFwiKTtmb3IoY29uc3QgdCBvZiBlKXRoaXMuX3NldEluaXRpYWxBdHRyaWJ1dGVzT25DaGlsZCh0KX1fc2V0SW5pdGlhbEF0dHJpYnV0ZXNPbkNoaWxkKHQpe3Q9dGhpcy5fZ2V0SW5uZXJFbGVtZW50KHQpO2NvbnN0IGU9dGhpcy5fZWxlbUlzQWN0aXZlKHQpLGk9dGhpcy5fZ2V0T3V0ZXJFbGVtZW50KHQpO3Quc2V0QXR0cmlidXRlKFwiYXJpYS1zZWxlY3RlZFwiLGUpLGkhPT10JiZ0aGlzLl9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyhpLFwicm9sZVwiLFwicHJlc2VudGF0aW9uXCIpLGV8fHQuc2V0QXR0cmlidXRlKFwidGFiaW5kZXhcIixcIi0xXCIpLHRoaXMuX3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKHQsXCJyb2xlXCIsXCJ0YWJcIiksdGhpcy5fc2V0SW5pdGlhbEF0dHJpYnV0ZXNPblRhcmdldFBhbmVsKHQpfV9zZXRJbml0aWFsQXR0cmlidXRlc09uVGFyZ2V0UGFuZWwodCl7Y29uc3QgZT16LmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCk7ZSYmKHRoaXMuX3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKGUsXCJyb2xlXCIsXCJ0YWJwYW5lbFwiKSx0LmlkJiZ0aGlzLl9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyhlLFwiYXJpYS1sYWJlbGxlZGJ5XCIsYCR7dC5pZH1gKSl9X3RvZ2dsZURyb3BEb3duKHQsZSl7Y29uc3QgaT10aGlzLl9nZXRPdXRlckVsZW1lbnQodCk7aWYoIWkuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZHJvcGRvd25cIikpcmV0dXJuO2NvbnN0IG49KHQsbik9Pntjb25zdCBzPXouZmluZE9uZSh0LGkpO3MmJnMuY2xhc3NMaXN0LnRvZ2dsZShuLGUpfTtuKEtzLFJzKSxuKFwiLmRyb3Bkb3duLW1lbnVcIixWcyksaS5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsZSl9X3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKHQsZSxpKXt0Lmhhc0F0dHJpYnV0ZShlKXx8dC5zZXRBdHRyaWJ1dGUoZSxpKX1fZWxlbUlzQWN0aXZlKHQpe3JldHVybiB0LmNsYXNzTGlzdC5jb250YWlucyhScyl9X2dldElubmVyRWxlbWVudCh0KXtyZXR1cm4gdC5tYXRjaGVzKFlzKT90OnouZmluZE9uZShZcyx0KX1fZ2V0T3V0ZXJFbGVtZW50KHQpe3JldHVybiB0LmNsb3Nlc3QoXCIubmF2LWl0ZW0sIC5saXN0LWdyb3VwLWl0ZW1cIil8fHR9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKChmdW5jdGlvbigpe2NvbnN0IGU9R3MuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzKTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fSkpfX1OLm9uKGRvY3VtZW50LE5zLFhzLChmdW5jdGlvbih0KXtbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJnQucHJldmVudERlZmF1bHQoKSxsKHRoaXMpfHxHcy5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpLnNob3coKX0pKSxOLm9uKHdpbmRvdyxqcywoKCk9Pntmb3IoY29uc3QgdCBvZiB6LmZpbmQoVXMpKUdzLmdldE9yQ3JlYXRlSW5zdGFuY2UodCl9KSksbShHcyk7Y29uc3QgSnM9XCIuYnMudG9hc3RcIixacz1gbW91c2VvdmVyJHtKc31gLHRvPWBtb3VzZW91dCR7SnN9YCxlbz1gZm9jdXNpbiR7SnN9YCxpbz1gZm9jdXNvdXQke0pzfWAsbm89YGhpZGUke0pzfWAsc289YGhpZGRlbiR7SnN9YCxvbz1gc2hvdyR7SnN9YCxybz1gc2hvd24ke0pzfWAsYW89XCJoaWRlXCIsbG89XCJzaG93XCIsY289XCJzaG93aW5nXCIsaG89e2FuaW1hdGlvbjpcImJvb2xlYW5cIixhdXRvaGlkZTpcImJvb2xlYW5cIixkZWxheTpcIm51bWJlclwifSx1bz17YW5pbWF0aW9uOiEwLGF1dG9oaWRlOiEwLGRlbGF5OjVlM307Y2xhc3MgZm8gZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQsZSl7c3VwZXIodCxlKSx0aGlzLl90aW1lb3V0PW51bGwsdGhpcy5faGFzTW91c2VJbnRlcmFjdGlvbj0hMSx0aGlzLl9oYXNLZXlib2FyZEludGVyYWN0aW9uPSExLHRoaXMuX3NldExpc3RlbmVycygpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiB1b31zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIGhvfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwidG9hc3RcIn1zaG93KCl7Ti50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsb28pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9jbGVhclRpbWVvdXQoKSx0aGlzLl9jb25maWcuYW5pbWF0aW9uJiZ0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJmYWRlXCIpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShhbyksZCh0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQobG8sY28pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCgpPT57dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGNvKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxybyksdGhpcy5fbWF5YmVTY2hlZHVsZUhpZGUoKX0pLHRoaXMuX2VsZW1lbnQsdGhpcy5fY29uZmlnLmFuaW1hdGlvbikpfWhpZGUoKXt0aGlzLmlzU2hvd24oKSYmKE4udHJpZ2dlcih0aGlzLl9lbGVtZW50LG5vKS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKGNvKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgoKT0+e3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChhbyksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGNvLGxvKSxOLnRyaWdnZXIodGhpcy5fZWxlbWVudCxzbyl9KSx0aGlzLl9lbGVtZW50LHRoaXMuX2NvbmZpZy5hbmltYXRpb24pKSl9ZGlzcG9zZSgpe3RoaXMuX2NsZWFyVGltZW91dCgpLHRoaXMuaXNTaG93bigpJiZ0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUobG8pLHN1cGVyLmRpc3Bvc2UoKX1pc1Nob3duKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGxvKX1fbWF5YmVTY2hlZHVsZUhpZGUoKXt0aGlzLl9jb25maWcuYXV0b2hpZGUmJih0aGlzLl9oYXNNb3VzZUludGVyYWN0aW9ufHx0aGlzLl9oYXNLZXlib2FyZEludGVyYWN0aW9ufHwodGhpcy5fdGltZW91dD1zZXRUaW1lb3V0KCgoKT0+e3RoaXMuaGlkZSgpfSksdGhpcy5fY29uZmlnLmRlbGF5KSkpfV9vbkludGVyYWN0aW9uKHQsZSl7c3dpdGNoKHQudHlwZSl7Y2FzZVwibW91c2VvdmVyXCI6Y2FzZVwibW91c2VvdXRcIjp0aGlzLl9oYXNNb3VzZUludGVyYWN0aW9uPWU7YnJlYWs7Y2FzZVwiZm9jdXNpblwiOmNhc2VcImZvY3Vzb3V0XCI6dGhpcy5faGFzS2V5Ym9hcmRJbnRlcmFjdGlvbj1lfWlmKGUpcmV0dXJuIHZvaWQgdGhpcy5fY2xlYXJUaW1lb3V0KCk7Y29uc3QgaT10LnJlbGF0ZWRUYXJnZXQ7dGhpcy5fZWxlbWVudD09PWl8fHRoaXMuX2VsZW1lbnQuY29udGFpbnMoaSl8fHRoaXMuX21heWJlU2NoZWR1bGVIaWRlKCl9X3NldExpc3RlbmVycygpe04ub24odGhpcy5fZWxlbWVudCxacywodD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCEwKSkpLE4ub24odGhpcy5fZWxlbWVudCx0bywodD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCExKSkpLE4ub24odGhpcy5fZWxlbWVudCxlbywodD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCEwKSkpLE4ub24odGhpcy5fZWxlbWVudCxpbywodD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCExKSkpfV9jbGVhclRpbWVvdXQoKXtjbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksdGhpcy5fdGltZW91dD1udWxsfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaCgoZnVuY3Rpb24oKXtjb25zdCBlPWZvLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyx0KTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XSl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKHRoaXMpfX0pKX19cmV0dXJuIFIoZm8pLG0oZm8pLHtBbGVydDpRLEJ1dHRvbjpZLENhcm91c2VsOkx0LENvbGxhcHNlOlJ0LERyb3Bkb3duOktpLE1vZGFsOmtuLE9mZmNhbnZhczpLbixQb3BvdmVyOl9zLFNjcm9sbFNweTprcyxUYWI6R3MsVG9hc3Q6Zm8sVG9vbHRpcDp1c319KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ib290c3RyYXAuYnVuZGxlLm1pbi5qcy5tYXAiXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLQSxDQUFDLFNBQVMsR0FBRSxHQUFFO0FBQUMsY0FBVSxPQUFPLFdBQVMsZUFBYSxPQUFPLFNBQU8sT0FBTyxVQUFRLEVBQUUsSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLEtBQUcsSUFBRSxlQUFhLE9BQU8sYUFBVyxhQUFXLEtBQUcsTUFBTSxZQUFVLEVBQUU7QUFBQyxFQUFFLE1BQU0sV0FBVTtBQUFDO0FBQWEsUUFBTSxJQUFFLG9CQUFJLE9BQUksSUFBRSxFQUFDLElBQUlBLElBQUVDLElBQUVDLElBQUU7QUFBQyxNQUFFLElBQUlGLEVBQUMsS0FBRyxFQUFFLElBQUlBLElBQUUsb0JBQUksS0FBRztBQUFFLFVBQU1HLEtBQUUsRUFBRSxJQUFJSCxFQUFDO0FBQUUsSUFBQUcsR0FBRSxJQUFJRixFQUFDLEtBQUcsTUFBSUUsR0FBRSxPQUFLQSxHQUFFLElBQUlGLElBQUVDLEVBQUMsSUFBRSxRQUFRLE1BQU0sK0VBQStFLE1BQU0sS0FBS0MsR0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRztBQUFBLEVBQUMsR0FBRSxLQUFJLENBQUNILElBQUVDLE9BQUksRUFBRSxJQUFJRCxFQUFDLEtBQUcsRUFBRSxJQUFJQSxFQUFDLEVBQUUsSUFBSUMsRUFBQyxLQUFHLE1BQUssT0FBT0QsSUFBRUMsSUFBRTtBQUFDLFFBQUcsQ0FBQyxFQUFFLElBQUlELEVBQUMsRUFBRTtBQUFPLFVBQU1FLEtBQUUsRUFBRSxJQUFJRixFQUFDO0FBQUUsSUFBQUUsR0FBRSxPQUFPRCxFQUFDLEdBQUUsTUFBSUMsR0FBRSxRQUFNLEVBQUUsT0FBT0YsRUFBQztBQUFBLEVBQUMsRUFBQyxHQUFFLElBQUUsaUJBQWdCLElBQUUsQ0FBQUksUUFBSUEsTUFBRyxPQUFPLE9BQUssT0FBTyxJQUFJLFdBQVNBLEtBQUVBLEdBQUUsUUFBUSxpQkFBaUIsQ0FBQ0EsSUFBRUosT0FBSSxJQUFJLElBQUksT0FBT0EsRUFBQyxDQUFDLEVBQUcsSUFBR0ksS0FBRyxJQUFFLENBQUFBLE9BQUc7QUFBQyxJQUFBQSxHQUFFLGNBQWMsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQUMsR0FBRSxJQUFFLENBQUFBLE9BQUcsRUFBRSxDQUFDQSxNQUFHLFlBQVUsT0FBT0EsUUFBSyxXQUFTQSxHQUFFLFdBQVNBLEtBQUVBLEdBQUUsQ0FBQyxJQUFHLFdBQVNBLEdBQUUsV0FBVSxJQUFFLENBQUFBLE9BQUcsRUFBRUEsRUFBQyxJQUFFQSxHQUFFLFNBQU9BLEdBQUUsQ0FBQyxJQUFFQSxLQUFFLFlBQVUsT0FBT0EsTUFBR0EsR0FBRSxTQUFPLElBQUUsU0FBUyxjQUFjLEVBQUVBLEVBQUMsQ0FBQyxJQUFFLE1BQUssSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBRyxDQUFDLEVBQUVBLEVBQUMsS0FBRyxNQUFJQSxHQUFFLGVBQWUsRUFBRSxPQUFPLFFBQU07QUFBRyxVQUFNSixLQUFFLGNBQVksaUJBQWlCSSxFQUFDLEVBQUUsaUJBQWlCLFlBQVksR0FBRUgsS0FBRUcsR0FBRSxRQUFRLHFCQUFxQjtBQUFFLFFBQUcsQ0FBQ0gsR0FBRSxRQUFPRDtBQUFFLFFBQUdDLE9BQUlHLElBQUU7QUFBQyxZQUFNSixLQUFFSSxHQUFFLFFBQVEsU0FBUztBQUFFLFVBQUdKLE1BQUdBLEdBQUUsZUFBYUMsR0FBRSxRQUFNO0FBQUcsVUFBRyxTQUFPRCxHQUFFLFFBQU07QUFBQSxJQUFFO0FBQUMsV0FBT0E7QUFBQSxFQUFDLEdBQUUsSUFBRSxDQUFBSSxPQUFHLENBQUNBLE1BQUdBLEdBQUUsYUFBVyxLQUFLLGdCQUFjLENBQUMsQ0FBQ0EsR0FBRSxVQUFVLFNBQVMsVUFBVSxNQUFJLFdBQVNBLEdBQUUsV0FBU0EsR0FBRSxXQUFTQSxHQUFFLGFBQWEsVUFBVSxLQUFHLFlBQVVBLEdBQUUsYUFBYSxVQUFVLElBQUcsSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBRyxDQUFDLFNBQVMsZ0JBQWdCLGFBQWEsUUFBTztBQUFLLFFBQUcsY0FBWSxPQUFPQSxHQUFFLGFBQVk7QUFBQyxZQUFNSixLQUFFSSxHQUFFLFlBQVk7QUFBRSxhQUFPSixjQUFhLGFBQVdBLEtBQUU7QUFBQSxJQUFJO0FBQUMsV0FBT0ksY0FBYSxhQUFXQSxLQUFFQSxHQUFFLGFBQVcsRUFBRUEsR0FBRSxVQUFVLElBQUU7QUFBQSxFQUFJLEdBQUUsSUFBRSxNQUFJO0FBQUEsRUFBQyxHQUFFLElBQUUsQ0FBQUEsT0FBRztBQUFDLElBQUFBLEdBQUU7QUFBQSxFQUFZLEdBQUUsSUFBRSxNQUFJLE9BQU8sVUFBUSxDQUFDLFNBQVMsS0FBSyxhQUFhLG1CQUFtQixJQUFFLE9BQU8sU0FBTyxNQUFLLElBQUUsQ0FBQyxHQUFFLElBQUUsTUFBSSxVQUFRLFNBQVMsZ0JBQWdCLEtBQUksSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBSUo7QUFBRSxJQUFBQSxLQUFFLE1BQUk7QUFBQyxZQUFNQSxLQUFFLEVBQUU7QUFBRSxVQUFHQSxJQUFFO0FBQUMsY0FBTUMsS0FBRUcsR0FBRSxNQUFLRixLQUFFRixHQUFFLEdBQUdDLEVBQUM7QUFBRSxRQUFBRCxHQUFFLEdBQUdDLEVBQUMsSUFBRUcsR0FBRSxpQkFBZ0JKLEdBQUUsR0FBR0MsRUFBQyxFQUFFLGNBQVlHLElBQUVKLEdBQUUsR0FBR0MsRUFBQyxFQUFFLGFBQVcsT0FBS0QsR0FBRSxHQUFHQyxFQUFDLElBQUVDLElBQUVFLEdBQUU7QUFBQSxNQUFnQjtBQUFBLElBQUMsR0FBRSxjQUFZLFNBQVMsY0FBWSxFQUFFLFVBQVEsU0FBUyxpQkFBaUIsb0JBQW9CLE1BQUk7QUFBQyxpQkFBVUEsTUFBSyxFQUFFLENBQUFBLEdBQUU7QUFBQSxJQUFDLENBQUUsR0FBRSxFQUFFLEtBQUtKLEVBQUMsS0FBR0EsR0FBRTtBQUFBLEVBQUMsR0FBRSxJQUFFLENBQUNJLElBQUVKLEtBQUUsQ0FBQyxHQUFFQyxLQUFFRyxPQUFJLGNBQVksT0FBT0EsS0FBRUEsR0FBRSxLQUFLLEdBQUdKLEVBQUMsSUFBRUMsSUFBRSxJQUFFLENBQUNHLElBQUVKLElBQUVFLEtBQUUsU0FBSztBQUFDLFFBQUcsQ0FBQ0EsR0FBRSxRQUFPLEtBQUssRUFBRUUsRUFBQztBQUFFLFVBQU1DLE1BQUcsQ0FBQUQsT0FBRztBQUFDLFVBQUcsQ0FBQ0EsR0FBRSxRQUFPO0FBQUUsVUFBRyxFQUFDLG9CQUFtQkosSUFBRSxpQkFBZ0JDLEdBQUMsSUFBRSxPQUFPLGlCQUFpQkcsRUFBQztBQUFFLFlBQU1GLEtBQUUsT0FBTyxXQUFXRixFQUFDLEdBQUVHLEtBQUUsT0FBTyxXQUFXRixFQUFDO0FBQUUsYUFBT0MsTUFBR0MsTUFBR0gsS0FBRUEsR0FBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLEdBQUVDLEtBQUVBLEdBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFFLE9BQUssT0FBTyxXQUFXRCxFQUFDLElBQUUsT0FBTyxXQUFXQyxFQUFDLE1BQUk7QUFBQSxJQUFDLEdBQUdELEVBQUMsSUFBRTtBQUFFLFFBQUlNLEtBQUU7QUFBRyxVQUFNQyxLQUFFLENBQUMsRUFBQyxRQUFPTCxHQUFDLE1BQUk7QUFBQyxNQUFBQSxPQUFJRixPQUFJTSxLQUFFLE1BQUdOLEdBQUUsb0JBQW9CLEdBQUVPLEVBQUMsR0FBRSxFQUFFSCxFQUFDO0FBQUEsSUFBRTtBQUFFLElBQUFKLEdBQUUsaUJBQWlCLEdBQUVPLEVBQUMsR0FBRSxXQUFZLE1BQUk7QUFBQyxNQUFBRCxNQUFHLEVBQUVOLEVBQUM7QUFBQSxJQUFDLEdBQUdLLEVBQUM7QUFBQSxFQUFDLEdBQUUsSUFBRSxDQUFDRCxJQUFFSixJQUFFQyxJQUFFQyxPQUFJO0FBQUMsVUFBTUMsS0FBRUMsR0FBRTtBQUFPLFFBQUlDLEtBQUVELEdBQUUsUUFBUUosRUFBQztBQUFFLFdBQU0sT0FBS0ssS0FBRSxDQUFDSixNQUFHQyxLQUFFRSxHQUFFRCxLQUFFLENBQUMsSUFBRUMsR0FBRSxDQUFDLEtBQUdDLE1BQUdKLEtBQUUsSUFBRSxJQUFHQyxPQUFJRyxNQUFHQSxLQUFFRixNQUFHQSxLQUFHQyxHQUFFLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSUMsSUFBRUYsS0FBRSxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQUUsR0FBRSxJQUFFLHNCQUFxQixJQUFFLFFBQU8sSUFBRSxVQUFTLElBQUUsQ0FBQztBQUFFLE1BQUksSUFBRTtBQUFFLFFBQU0sSUFBRSxFQUFDLFlBQVcsYUFBWSxZQUFXLFdBQVUsR0FBRSxJQUFFLG9CQUFJLElBQUksQ0FBQyxTQUFRLFlBQVcsV0FBVSxhQUFZLGVBQWMsY0FBYSxrQkFBaUIsYUFBWSxZQUFXLGFBQVksZUFBYyxhQUFZLFdBQVUsWUFBVyxTQUFRLHFCQUFvQixjQUFhLGFBQVksWUFBVyxlQUFjLGVBQWMsZUFBYyxhQUFZLGdCQUFlLGlCQUFnQixnQkFBZSxpQkFBZ0IsY0FBYSxTQUFRLFFBQU8sVUFBUyxTQUFRLFVBQVMsVUFBUyxXQUFVLFlBQVcsUUFBTyxVQUFTLGdCQUFlLFVBQVMsUUFBTyxvQkFBbUIsb0JBQW1CLFNBQVEsU0FBUSxRQUFRLENBQUM7QUFBRSxXQUFTLEVBQUVDLElBQUVKLElBQUU7QUFBQyxXQUFPQSxNQUFHLEdBQUdBLEVBQUMsS0FBSyxHQUFHLE1BQUlJLEdBQUUsWUFBVTtBQUFBLEVBQUc7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxVQUFNSixLQUFFLEVBQUVJLEVBQUM7QUFBRSxXQUFPQSxHQUFFLFdBQVNKLElBQUUsRUFBRUEsRUFBQyxJQUFFLEVBQUVBLEVBQUMsS0FBRyxDQUFDLEdBQUUsRUFBRUEsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVJLElBQUVKLElBQUVDLEtBQUUsTUFBSztBQUFDLFdBQU8sT0FBTyxPQUFPRyxFQUFDLEVBQUUsS0FBTSxDQUFBQSxPQUFHQSxHQUFFLGFBQVdKLE1BQUdJLEdBQUUsdUJBQXFCSCxFQUFFO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUcsSUFBRUosSUFBRUMsSUFBRTtBQUFDLFVBQU1DLEtBQUUsWUFBVSxPQUFPRixJQUFFRyxLQUFFRCxLQUFFRCxLQUFFRCxNQUFHQztBQUFFLFFBQUlJLEtBQUUsRUFBRUQsRUFBQztBQUFFLFdBQU8sRUFBRSxJQUFJQyxFQUFDLE1BQUlBLEtBQUVELEtBQUcsQ0FBQ0YsSUFBRUMsSUFBRUUsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVELElBQUVKLElBQUVDLElBQUVDLElBQUVDLElBQUU7QUFBQyxRQUFHLFlBQVUsT0FBT0gsTUFBRyxDQUFDSSxHQUFFO0FBQU8sUUFBRyxDQUFDQyxJQUFFQyxJQUFFQyxFQUFDLElBQUUsRUFBRVAsSUFBRUMsSUFBRUMsRUFBQztBQUFFLFFBQUdGLE1BQUssR0FBRTtBQUFDLFlBQU1JLEtBQUUsQ0FBQUEsT0FBRyxTQUFTSixJQUFFO0FBQUMsWUFBRyxDQUFDQSxHQUFFLGlCQUFlQSxHQUFFLGtCQUFnQkEsR0FBRSxrQkFBZ0IsQ0FBQ0EsR0FBRSxlQUFlLFNBQVNBLEdBQUUsYUFBYSxFQUFFLFFBQU9JLEdBQUUsS0FBSyxNQUFLSixFQUFDO0FBQUEsTUFBQztBQUFFLE1BQUFNLEtBQUVGLEdBQUVFLEVBQUM7QUFBQSxJQUFDO0FBQUMsVUFBTUUsS0FBRSxFQUFFSixFQUFDLEdBQUVLLEtBQUVELEdBQUVELEVBQUMsTUFBSUMsR0FBRUQsRUFBQyxJQUFFLENBQUMsSUFBR0csS0FBRSxFQUFFRCxJQUFFSCxJQUFFRCxLQUFFSixLQUFFLElBQUk7QUFBRSxRQUFHUyxHQUFFLFFBQU8sTUFBS0EsR0FBRSxTQUFPQSxHQUFFLFVBQVFQO0FBQUcsVUFBTVEsS0FBRSxFQUFFTCxJQUFFTixHQUFFLFFBQVEsR0FBRSxFQUFFLENBQUMsR0FBRVksS0FBRVAsS0FBRSx5QkFBU0QsSUFBRUosSUFBRUMsSUFBRTtBQUFDLGFBQU8sU0FBU0MsR0FBRUMsSUFBRTtBQUFDLGNBQU1FLEtBQUVELEdBQUUsaUJBQWlCSixFQUFDO0FBQUUsaUJBQU8sRUFBQyxRQUFPTSxHQUFDLElBQUVILElBQUVHLE1BQUdBLE9BQUksTUFBS0EsS0FBRUEsR0FBRSxXQUFXLFlBQVVDLE1BQUtGLEdBQUUsS0FBR0UsT0FBSUQsR0FBRSxRQUFPLEVBQUVILElBQUUsRUFBQyxnQkFBZUcsR0FBQyxDQUFDLEdBQUVKLEdBQUUsVUFBUSxFQUFFLElBQUlFLElBQUVELEdBQUUsTUFBS0gsSUFBRUMsRUFBQyxHQUFFQSxHQUFFLE1BQU1LLElBQUUsQ0FBQ0gsRUFBQyxDQUFDO0FBQUEsTUFBQztBQUFBLElBQUMsRUFBRUMsSUFBRUgsSUFBRUssRUFBQyxJQUFFLHlCQUFTRixJQUFFSixJQUFFO0FBQUMsYUFBTyxTQUFTQyxHQUFFQyxJQUFFO0FBQUMsZUFBTyxFQUFFQSxJQUFFLEVBQUMsZ0JBQWVFLEdBQUMsQ0FBQyxHQUFFSCxHQUFFLFVBQVEsRUFBRSxJQUFJRyxJQUFFRixHQUFFLE1BQUtGLEVBQUMsR0FBRUEsR0FBRSxNQUFNSSxJQUFFLENBQUNGLEVBQUMsQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEVBQUVFLElBQUVFLEVBQUM7QUFBRSxJQUFBTSxHQUFFLHFCQUFtQlAsS0FBRUosS0FBRSxNQUFLVyxHQUFFLFdBQVNOLElBQUVNLEdBQUUsU0FBT1QsSUFBRVMsR0FBRSxXQUFTRCxJQUFFRixHQUFFRSxFQUFDLElBQUVDLElBQUVSLEdBQUUsaUJBQWlCRyxJQUFFSyxJQUFFUCxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUQsSUFBRUosSUFBRUMsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFVBQU1FLEtBQUUsRUFBRUwsR0FBRUMsRUFBQyxHQUFFQyxJQUFFQyxFQUFDO0FBQUUsSUFBQUUsT0FBSUQsR0FBRSxvQkFBb0JILElBQUVJLElBQUUsUUFBUUYsRUFBQyxDQUFDLEdBQUUsT0FBT0gsR0FBRUMsRUFBQyxFQUFFSSxHQUFFLFFBQVE7QUFBQSxFQUFFO0FBQUMsV0FBUyxFQUFFRCxJQUFFSixJQUFFQyxJQUFFQyxJQUFFO0FBQUMsVUFBTUMsS0FBRUgsR0FBRUMsRUFBQyxLQUFHLENBQUM7QUFBRSxlQUFTLENBQUNJLElBQUVDLEVBQUMsS0FBSSxPQUFPLFFBQVFILEVBQUMsRUFBRSxDQUFBRSxHQUFFLFNBQVNILEVBQUMsS0FBRyxFQUFFRSxJQUFFSixJQUFFQyxJQUFFSyxHQUFFLFVBQVNBLEdBQUUsa0JBQWtCO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUYsSUFBRTtBQUFDLFdBQU9BLEtBQUVBLEdBQUUsUUFBUSxHQUFFLEVBQUUsR0FBRSxFQUFFQSxFQUFDLEtBQUdBO0FBQUEsRUFBQztBQUFDLFFBQU0sSUFBRSxFQUFDLEdBQUdBLElBQUVKLElBQUVDLElBQUVDLElBQUU7QUFBQyxNQUFFRSxJQUFFSixJQUFFQyxJQUFFQyxJQUFFLEtBQUU7QUFBQSxFQUFDLEdBQUUsSUFBSUUsSUFBRUosSUFBRUMsSUFBRUMsSUFBRTtBQUFDLE1BQUVFLElBQUVKLElBQUVDLElBQUVDLElBQUUsSUFBRTtBQUFBLEVBQUMsR0FBRSxJQUFJRSxJQUFFSixJQUFFQyxJQUFFQyxJQUFFO0FBQUMsUUFBRyxZQUFVLE9BQU9GLE1BQUcsQ0FBQ0ksR0FBRTtBQUFPLFVBQUssQ0FBQ0QsSUFBRUUsSUFBRUMsRUFBQyxJQUFFLEVBQUVOLElBQUVDLElBQUVDLEVBQUMsR0FBRUssS0FBRUQsT0FBSU4sSUFBRVEsS0FBRSxFQUFFSixFQUFDLEdBQUVLLEtBQUVELEdBQUVGLEVBQUMsS0FBRyxDQUFDLEdBQUVJLEtBQUVWLEdBQUUsV0FBVyxHQUFHO0FBQUUsUUFBRyxXQUFTSyxJQUFFO0FBQUMsVUFBR0ssR0FBRSxZQUFVVCxNQUFLLE9BQU8sS0FBS08sRUFBQyxFQUFFLEdBQUVKLElBQUVJLElBQUVQLElBQUVELEdBQUUsTUFBTSxDQUFDLENBQUM7QUFBRSxpQkFBUyxDQUFDQyxJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRTyxFQUFDLEdBQUU7QUFBQyxjQUFNTixLQUFFRixHQUFFLFFBQVEsR0FBRSxFQUFFO0FBQUUsUUFBQU0sTUFBRyxDQUFDUCxHQUFFLFNBQVNHLEVBQUMsS0FBRyxFQUFFQyxJQUFFSSxJQUFFRixJQUFFSixHQUFFLFVBQVNBLEdBQUUsa0JBQWtCO0FBQUEsTUFBQztBQUFBLElBQUMsT0FBSztBQUFDLFVBQUcsQ0FBQyxPQUFPLEtBQUtPLEVBQUMsRUFBRSxPQUFPO0FBQU8sUUFBRUwsSUFBRUksSUFBRUYsSUFBRUQsSUFBRUYsS0FBRUYsS0FBRSxJQUFJO0FBQUEsSUFBQztBQUFBLEVBQUMsR0FBRSxRQUFRRyxJQUFFSixJQUFFQyxJQUFFO0FBQUMsUUFBRyxZQUFVLE9BQU9ELE1BQUcsQ0FBQ0ksR0FBRSxRQUFPO0FBQUssVUFBTUYsS0FBRSxFQUFFO0FBQUUsUUFBSUMsS0FBRSxNQUFLRSxLQUFFLE1BQUdDLEtBQUUsTUFBR0MsS0FBRTtBQUFHLElBQUFQLE9BQUksRUFBRUEsRUFBQyxLQUFHRSxPQUFJQyxLQUFFRCxHQUFFLE1BQU1GLElBQUVDLEVBQUMsR0FBRUMsR0FBRUUsRUFBQyxFQUFFLFFBQVFELEVBQUMsR0FBRUUsS0FBRSxDQUFDRixHQUFFLHFCQUFxQixHQUFFRyxLQUFFLENBQUNILEdBQUUsOEJBQThCLEdBQUVJLEtBQUVKLEdBQUUsbUJBQW1CO0FBQUcsVUFBTUssS0FBRSxFQUFFLElBQUksTUFBTVIsSUFBRSxFQUFDLFNBQVFLLElBQUUsWUFBVyxLQUFFLENBQUMsR0FBRUosRUFBQztBQUFFLFdBQU9NLE1BQUdDLEdBQUUsZUFBZSxHQUFFRixNQUFHRixHQUFFLGNBQWNJLEVBQUMsR0FBRUEsR0FBRSxvQkFBa0JMLE1BQUdBLEdBQUUsZUFBZSxHQUFFSztBQUFBLEVBQUMsRUFBQztBQUFFLFdBQVMsRUFBRUosSUFBRUosS0FBRSxDQUFDLEdBQUU7QUFBQyxlQUFTLENBQUNDLElBQUVDLEVBQUMsS0FBSSxPQUFPLFFBQVFGLEVBQUMsRUFBRSxLQUFHO0FBQUMsTUFBQUksR0FBRUgsRUFBQyxJQUFFQztBQUFBLElBQUMsU0FBT0YsSUFBRTtBQUFDLGFBQU8sZUFBZUksSUFBRUgsSUFBRSxFQUFDLGNBQWEsTUFBRyxLQUFJLE1BQUlDLEdBQUMsQ0FBQztBQUFBLElBQUM7QUFBQyxXQUFPRTtBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxRQUFHLFdBQVNBLEdBQUUsUUFBTTtBQUFHLFFBQUcsWUFBVUEsR0FBRSxRQUFNO0FBQUcsUUFBR0EsT0FBSSxPQUFPQSxFQUFDLEVBQUUsU0FBUyxFQUFFLFFBQU8sT0FBT0EsRUFBQztBQUFFLFFBQUcsT0FBS0EsTUFBRyxXQUFTQSxHQUFFLFFBQU87QUFBSyxRQUFHLFlBQVUsT0FBT0EsR0FBRSxRQUFPQTtBQUFFLFFBQUc7QUFBQyxhQUFPLEtBQUssTUFBTSxtQkFBbUJBLEVBQUMsQ0FBQztBQUFBLElBQUMsU0FBT0osSUFBRTtBQUFDLGFBQU9JO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxXQUFPQSxHQUFFLFFBQVEsVUFBVSxDQUFBQSxPQUFHLElBQUlBLEdBQUUsWUFBWSxDQUFDLEVBQUc7QUFBQSxFQUFDO0FBQUMsUUFBTSxJQUFFLEVBQUMsaUJBQWlCQSxJQUFFSixJQUFFQyxJQUFFO0FBQUMsSUFBQUcsR0FBRSxhQUFhLFdBQVcsRUFBRUosRUFBQyxDQUFDLElBQUdDLEVBQUM7QUFBQSxFQUFDLEdBQUUsb0JBQW9CRyxJQUFFSixJQUFFO0FBQUMsSUFBQUksR0FBRSxnQkFBZ0IsV0FBVyxFQUFFSixFQUFDLENBQUMsRUFBRTtBQUFBLEVBQUMsR0FBRSxrQkFBa0JJLElBQUU7QUFBQyxRQUFHLENBQUNBLEdBQUUsUUFBTSxDQUFDO0FBQUUsVUFBTUosS0FBRSxDQUFDLEdBQUVDLEtBQUUsT0FBTyxLQUFLRyxHQUFFLE9BQU8sRUFBRSxPQUFRLENBQUFBLE9BQUdBLEdBQUUsV0FBVyxJQUFJLEtBQUcsQ0FBQ0EsR0FBRSxXQUFXLFVBQVUsQ0FBRTtBQUFFLGVBQVVGLE1BQUtELElBQUU7QUFBQyxVQUFJQSxLQUFFQyxHQUFFLFFBQVEsT0FBTSxFQUFFO0FBQUUsTUFBQUQsS0FBRUEsR0FBRSxPQUFPLENBQUMsRUFBRSxZQUFZLElBQUVBLEdBQUUsTUFBTSxDQUFDLEdBQUVELEdBQUVDLEVBQUMsSUFBRSxFQUFFRyxHQUFFLFFBQVFGLEVBQUMsQ0FBQztBQUFBLElBQUM7QUFBQyxXQUFPRjtBQUFBLEVBQUMsR0FBRSxrQkFBaUIsQ0FBQ0ksSUFBRUosT0FBSSxFQUFFSSxHQUFFLGFBQWEsV0FBVyxFQUFFSixFQUFDLENBQUMsRUFBRSxDQUFDLEVBQUM7QUFBQSxFQUFFLE1BQU0sRUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsWUFBTSxJQUFJLE1BQU0scUVBQXFFO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBV0ksSUFBRTtBQUFDLGFBQU9BLEtBQUUsS0FBSyxnQkFBZ0JBLEVBQUMsR0FBRUEsS0FBRSxLQUFLLGtCQUFrQkEsRUFBQyxHQUFFLEtBQUssaUJBQWlCQSxFQUFDLEdBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0E7QUFBQSxJQUFDO0FBQUEsSUFBQyxnQkFBZ0JBLElBQUVKLElBQUU7QUFBQyxZQUFNQyxLQUFFLEVBQUVELEVBQUMsSUFBRSxFQUFFLGlCQUFpQkEsSUFBRSxRQUFRLElBQUUsQ0FBQztBQUFFLGFBQU0sRUFBQyxHQUFHLEtBQUssWUFBWSxTQUFRLEdBQUcsWUFBVSxPQUFPQyxLQUFFQSxLQUFFLENBQUMsR0FBRSxHQUFHLEVBQUVELEVBQUMsSUFBRSxFQUFFLGtCQUFrQkEsRUFBQyxJQUFFLENBQUMsR0FBRSxHQUFHLFlBQVUsT0FBT0ksS0FBRUEsS0FBRSxDQUFDLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJBLElBQUVKLEtBQUUsS0FBSyxZQUFZLGFBQVk7QUFBQyxpQkFBUyxDQUFDRSxJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRSCxFQUFDLEdBQUU7QUFBQyxjQUFNQSxLQUFFSSxHQUFFRixFQUFDLEdBQUVJLEtBQUUsRUFBRU4sRUFBQyxJQUFFLFlBQVUsU0FBT0MsS0FBRUQsTUFBRyxHQUFHQyxFQUFDLEtBQUcsT0FBTyxVQUFVLFNBQVMsS0FBS0EsRUFBQyxFQUFFLE1BQU0sYUFBYSxFQUFFLENBQUMsRUFBRSxZQUFZO0FBQUUsWUFBRyxDQUFDLElBQUksT0FBT0UsRUFBQyxFQUFFLEtBQUtHLEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxHQUFHLEtBQUssWUFBWSxLQUFLLFlBQVksQ0FBQyxhQUFhSixFQUFDLG9CQUFvQkksRUFBQyx3QkFBd0JILEVBQUMsSUFBSTtBQUFBLE1BQUM7QUFBQyxVQUFJRjtBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUEsRUFBQyxNQUFNLFVBQVUsRUFBQztBQUFBLElBQUMsWUFBWUcsSUFBRUgsSUFBRTtBQUFDLFlBQU0sSUFBR0csS0FBRSxFQUFFQSxFQUFDLE9BQUssS0FBSyxXQUFTQSxJQUFFLEtBQUssVUFBUSxLQUFLLFdBQVdILEVBQUMsR0FBRSxFQUFFLElBQUksS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFTLElBQUk7QUFBQSxJQUFFO0FBQUEsSUFBQyxVQUFTO0FBQUMsUUFBRSxPQUFPLEtBQUssVUFBUyxLQUFLLFlBQVksUUFBUSxHQUFFLEVBQUUsSUFBSSxLQUFLLFVBQVMsS0FBSyxZQUFZLFNBQVM7QUFBRSxpQkFBVUcsTUFBSyxPQUFPLG9CQUFvQixJQUFJLEVBQUUsTUFBS0EsRUFBQyxJQUFFO0FBQUEsSUFBSTtBQUFBLElBQUMsZUFBZUEsSUFBRUosSUFBRUMsS0FBRSxNQUFHO0FBQUMsUUFBRUcsSUFBRUosSUFBRUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVdHLElBQUU7QUFBQyxhQUFPQSxLQUFFLEtBQUssZ0JBQWdCQSxJQUFFLEtBQUssUUFBUSxHQUFFQSxLQUFFLEtBQUssa0JBQWtCQSxFQUFDLEdBQUUsS0FBSyxpQkFBaUJBLEVBQUMsR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLFlBQVlBLElBQUU7QUFBQyxhQUFPLEVBQUUsSUFBSSxFQUFFQSxFQUFDLEdBQUUsS0FBSyxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxvQkFBb0JBLElBQUVKLEtBQUUsQ0FBQyxHQUFFO0FBQUMsYUFBTyxLQUFLLFlBQVlJLEVBQUMsS0FBRyxJQUFJLEtBQUtBLElBQUUsWUFBVSxPQUFPSixLQUFFQSxLQUFFLElBQUk7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFNO0FBQUEsSUFBTztBQUFBLElBQUMsV0FBVyxXQUFVO0FBQUMsYUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsWUFBVztBQUFDLGFBQU0sSUFBSSxLQUFLLFFBQVE7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFPLFVBQVVJLElBQUU7QUFBQyxhQUFNLEdBQUdBLEVBQUMsR0FBRyxLQUFLLFNBQVM7QUFBQSxJQUFFO0FBQUEsRUFBQztBQUFDLFFBQU0sSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBSUosS0FBRUksR0FBRSxhQUFhLGdCQUFnQjtBQUFFLFFBQUcsQ0FBQ0osTUFBRyxRQUFNQSxJQUFFO0FBQUMsVUFBSUMsS0FBRUcsR0FBRSxhQUFhLE1BQU07QUFBRSxVQUFHLENBQUNILE1BQUcsQ0FBQ0EsR0FBRSxTQUFTLEdBQUcsS0FBRyxDQUFDQSxHQUFFLFdBQVcsR0FBRyxFQUFFLFFBQU87QUFBSyxNQUFBQSxHQUFFLFNBQVMsR0FBRyxLQUFHLENBQUNBLEdBQUUsV0FBVyxHQUFHLE1BQUlBLEtBQUUsSUFBSUEsR0FBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSUQsS0FBRUMsTUFBRyxRQUFNQSxLQUFFQSxHQUFFLEtBQUssSUFBRTtBQUFBLElBQUk7QUFBQyxXQUFPRCxLQUFFQSxHQUFFLE1BQU0sR0FBRyxFQUFFLElBQUssQ0FBQUksT0FBRyxFQUFFQSxFQUFDLENBQUUsRUFBRSxLQUFLLEdBQUcsSUFBRTtBQUFBLEVBQUksR0FBRSxJQUFFLEVBQUMsTUFBSyxDQUFDQSxJQUFFSixLQUFFLFNBQVMsb0JBQWtCLENBQUMsRUFBRSxPQUFPLEdBQUcsUUFBUSxVQUFVLGlCQUFpQixLQUFLQSxJQUFFSSxFQUFDLENBQUMsR0FBRSxTQUFRLENBQUNBLElBQUVKLEtBQUUsU0FBUyxvQkFBa0IsUUFBUSxVQUFVLGNBQWMsS0FBS0EsSUFBRUksRUFBQyxHQUFFLFVBQVMsQ0FBQ0EsSUFBRUosT0FBSSxDQUFDLEVBQUUsT0FBTyxHQUFHSSxHQUFFLFFBQVEsRUFBRSxPQUFRLENBQUFBLE9BQUdBLEdBQUUsUUFBUUosRUFBQyxDQUFFLEdBQUUsUUFBUUksSUFBRUosSUFBRTtBQUFDLFVBQU1DLEtBQUUsQ0FBQztBQUFFLFFBQUlDLEtBQUVFLEdBQUUsV0FBVyxRQUFRSixFQUFDO0FBQUUsV0FBS0UsS0FBRyxDQUFBRCxHQUFFLEtBQUtDLEVBQUMsR0FBRUEsS0FBRUEsR0FBRSxXQUFXLFFBQVFGLEVBQUM7QUFBRSxXQUFPQztBQUFBLEVBQUMsR0FBRSxLQUFLRyxJQUFFSixJQUFFO0FBQUMsUUFBSUMsS0FBRUcsR0FBRTtBQUF1QixXQUFLSCxNQUFHO0FBQUMsVUFBR0EsR0FBRSxRQUFRRCxFQUFDLEVBQUUsUUFBTSxDQUFDQyxFQUFDO0FBQUUsTUFBQUEsS0FBRUEsR0FBRTtBQUFBLElBQXNCO0FBQUMsV0FBTSxDQUFDO0FBQUEsRUFBQyxHQUFFLEtBQUtHLElBQUVKLElBQUU7QUFBQyxRQUFJQyxLQUFFRyxHQUFFO0FBQW1CLFdBQUtILE1BQUc7QUFBQyxVQUFHQSxHQUFFLFFBQVFELEVBQUMsRUFBRSxRQUFNLENBQUNDLEVBQUM7QUFBRSxNQUFBQSxLQUFFQSxHQUFFO0FBQUEsSUFBa0I7QUFBQyxXQUFNLENBQUM7QUFBQSxFQUFDLEdBQUUsa0JBQWtCRyxJQUFFO0FBQUMsVUFBTUosS0FBRSxDQUFDLEtBQUksVUFBUyxTQUFRLFlBQVcsVUFBUyxXQUFVLGNBQWEsMEJBQTBCLEVBQUUsSUFBSyxDQUFBSSxPQUFHLEdBQUdBLEVBQUMsdUJBQXdCLEVBQUUsS0FBSyxHQUFHO0FBQUUsV0FBTyxLQUFLLEtBQUtKLElBQUVJLEVBQUMsRUFBRSxPQUFRLENBQUFBLE9BQUcsQ0FBQyxFQUFFQSxFQUFDLEtBQUcsRUFBRUEsRUFBQyxDQUFFO0FBQUEsRUFBQyxHQUFFLHVCQUF1QkEsSUFBRTtBQUFDLFVBQU1KLEtBQUUsRUFBRUksRUFBQztBQUFFLFdBQU9KLE1BQUcsRUFBRSxRQUFRQSxFQUFDLElBQUVBLEtBQUU7QUFBQSxFQUFJLEdBQUUsdUJBQXVCSSxJQUFFO0FBQUMsVUFBTUosS0FBRSxFQUFFSSxFQUFDO0FBQUUsV0FBT0osS0FBRSxFQUFFLFFBQVFBLEVBQUMsSUFBRTtBQUFBLEVBQUksR0FBRSxnQ0FBZ0NJLElBQUU7QUFBQyxVQUFNSixLQUFFLEVBQUVJLEVBQUM7QUFBRSxXQUFPSixLQUFFLEVBQUUsS0FBS0EsRUFBQyxJQUFFLENBQUM7QUFBQSxFQUFDLEVBQUMsR0FBRSxJQUFFLENBQUNJLElBQUVKLEtBQUUsV0FBUztBQUFDLFVBQU1DLEtBQUUsZ0JBQWdCRyxHQUFFLFNBQVMsSUFBR0YsS0FBRUUsR0FBRTtBQUFLLE1BQUUsR0FBRyxVQUFTSCxJQUFFLHFCQUFxQkMsRUFBQyxNQUFNLFNBQVNELElBQUU7QUFBQyxVQUFHLENBQUMsS0FBSSxNQUFNLEVBQUUsU0FBUyxLQUFLLE9BQU8sS0FBR0EsR0FBRSxlQUFlLEdBQUUsRUFBRSxJQUFJLEVBQUU7QUFBTyxZQUFNRSxLQUFFLEVBQUUsdUJBQXVCLElBQUksS0FBRyxLQUFLLFFBQVEsSUFBSUQsRUFBQyxFQUFFO0FBQUUsTUFBQUUsR0FBRSxvQkFBb0JELEVBQUMsRUFBRUgsRUFBQyxFQUFFO0FBQUEsSUFBQyxDQUFFO0FBQUEsRUFBQyxHQUFFLElBQUUsYUFBWSxJQUFFLFFBQVEsQ0FBQyxJQUFHLElBQUUsU0FBUyxDQUFDO0FBQUEsRUFBRyxNQUFNLFVBQVUsRUFBQztBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQU87QUFBQSxJQUFDLFFBQU87QUFBQyxVQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsQ0FBQyxFQUFFLGlCQUFpQjtBQUFPLFdBQUssU0FBUyxVQUFVLE9BQU8sTUFBTTtBQUFFLFlBQU1JLEtBQUUsS0FBSyxTQUFTLFVBQVUsU0FBUyxNQUFNO0FBQUUsV0FBSyxlQUFnQixNQUFJLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxVQUFTQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWlCO0FBQUMsV0FBSyxTQUFTLE9BQU8sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLENBQUMsR0FBRSxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFNLFdBQVU7QUFBQyxjQUFNSixLQUFFLEVBQUUsb0JBQW9CLElBQUk7QUFBRSxZQUFHLFlBQVUsT0FBT0ksSUFBRTtBQUFDLGNBQUcsV0FBU0osR0FBRUksRUFBQyxLQUFHQSxHQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQkEsR0FBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFKLEdBQUVJLEVBQUMsRUFBRSxJQUFJO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsSUFBRSxHQUFFLE9BQU8sR0FBRSxFQUFFLENBQUM7QUFBRSxRQUFNLElBQUU7QUFBQSxFQUE0QixNQUFNLFVBQVUsRUFBQztBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQVE7QUFBQSxJQUFDLFNBQVE7QUFBQyxXQUFLLFNBQVMsYUFBYSxnQkFBZSxLQUFLLFNBQVMsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQU0sV0FBVTtBQUFDLGNBQU1KLEtBQUUsRUFBRSxvQkFBb0IsSUFBSTtBQUFFLHFCQUFXSSxNQUFHSixHQUFFSSxFQUFDLEVBQUU7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsR0FBRyxVQUFTLDRCQUEyQixHQUFHLENBQUFBLE9BQUc7QUFBQyxJQUFBQSxHQUFFLGVBQWU7QUFBRSxVQUFNSixLQUFFSSxHQUFFLE9BQU8sUUFBUSxDQUFDO0FBQUUsTUFBRSxvQkFBb0JKLEVBQUMsRUFBRSxPQUFPO0FBQUEsRUFBQyxDQUFFLEdBQUUsRUFBRSxDQUFDO0FBQUUsUUFBTSxJQUFFLGFBQVksSUFBRSxhQUFhLENBQUMsSUFBRyxJQUFFLFlBQVksQ0FBQyxJQUFHLElBQUUsV0FBVyxDQUFDLElBQUcsS0FBRyxjQUFjLENBQUMsSUFBRyxLQUFHLFlBQVksQ0FBQyxJQUFHLEtBQUcsRUFBQyxhQUFZLE1BQUssY0FBYSxNQUFLLGVBQWMsS0FBSSxHQUFFLEtBQUcsRUFBQyxhQUFZLG1CQUFrQixjQUFhLG1CQUFrQixlQUFjLGtCQUFpQjtBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlJLElBQUVKLElBQUU7QUFBQyxZQUFNLEdBQUUsS0FBSyxXQUFTSSxJQUFFQSxNQUFHLEdBQUcsWUFBWSxNQUFJLEtBQUssVUFBUSxLQUFLLFdBQVdKLEVBQUMsR0FBRSxLQUFLLFVBQVEsR0FBRSxLQUFLLHdCQUFzQixRQUFRLE9BQU8sWUFBWSxHQUFFLEtBQUssWUFBWTtBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQU87QUFBQSxJQUFDLFVBQVM7QUFBQyxRQUFFLElBQUksS0FBSyxVQUFTLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPSSxJQUFFO0FBQUMsV0FBSyx3QkFBc0IsS0FBSyx3QkFBd0JBLEVBQUMsTUFBSSxLQUFLLFVBQVFBLEdBQUUsV0FBUyxLQUFLLFVBQVFBLEdBQUUsUUFBUSxDQUFDLEVBQUU7QUFBQSxJQUFPO0FBQUEsSUFBQyxLQUFLQSxJQUFFO0FBQUMsV0FBSyx3QkFBd0JBLEVBQUMsTUFBSSxLQUFLLFVBQVFBLEdBQUUsVUFBUSxLQUFLLFVBQVMsS0FBSyxhQUFhLEdBQUUsRUFBRSxLQUFLLFFBQVEsV0FBVztBQUFBLElBQUM7QUFBQSxJQUFDLE1BQU1BLElBQUU7QUFBQyxXQUFLLFVBQVFBLEdBQUUsV0FBU0EsR0FBRSxRQUFRLFNBQU8sSUFBRSxJQUFFQSxHQUFFLFFBQVEsQ0FBQyxFQUFFLFVBQVEsS0FBSztBQUFBLElBQU87QUFBQSxJQUFDLGVBQWM7QUFBQyxZQUFNQSxLQUFFLEtBQUssSUFBSSxLQUFLLE9BQU87QUFBRSxVQUFHQSxNQUFHLEdBQUc7QUFBTyxZQUFNSixLQUFFSSxLQUFFLEtBQUs7QUFBUSxXQUFLLFVBQVEsR0FBRUosTUFBRyxFQUFFQSxLQUFFLElBQUUsS0FBSyxRQUFRLGdCQUFjLEtBQUssUUFBUSxZQUFZO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBYTtBQUFDLFdBQUsseUJBQXVCLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxDQUFBSSxPQUFHLEtBQUssT0FBT0EsRUFBQyxDQUFFLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFJLENBQUFBLE9BQUcsS0FBSyxLQUFLQSxFQUFDLENBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLGVBQWUsTUFBSSxFQUFFLEdBQUcsS0FBSyxVQUFTLEdBQUcsQ0FBQUEsT0FBRyxLQUFLLE9BQU9BLEVBQUMsQ0FBRSxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsR0FBRyxDQUFBQSxPQUFHLEtBQUssTUFBTUEsRUFBQyxDQUFFLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxHQUFHLENBQUFBLE9BQUcsS0FBSyxLQUFLQSxFQUFDLENBQUU7QUFBQSxJQUFFO0FBQUEsSUFBQyx3QkFBd0JBLElBQUU7QUFBQyxhQUFPLEtBQUssMEJBQXdCLFVBQVFBLEdBQUUsZUFBYSxZQUFVQSxHQUFFO0FBQUEsSUFBWTtBQUFBLElBQUMsT0FBTyxjQUFhO0FBQUMsYUFBTSxrQkFBaUIsU0FBUyxtQkFBaUIsVUFBVSxpQkFBZTtBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLGdCQUFlLEtBQUcsYUFBWSxLQUFHLGFBQVksS0FBRyxjQUFhLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRyxRQUFPLEtBQUcsU0FBUSxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxVQUFVLEVBQUUsSUFBRyxLQUFHLGFBQWEsRUFBRSxJQUFHLEtBQUcsYUFBYSxFQUFFLElBQUcsS0FBRyxZQUFZLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLFlBQVcsS0FBRyxVQUFTLEtBQUcsV0FBVSxLQUFHLGtCQUFpQixLQUFHLEtBQUcsSUFBRyxLQUFHLEVBQUMsQ0FBQyxFQUFFLEdBQUUsSUFBRyxDQUFDLEVBQUUsR0FBRSxHQUFFLEdBQUUsS0FBRyxFQUFDLFVBQVMsS0FBSSxVQUFTLE1BQUcsT0FBTSxTQUFRLE1BQUssT0FBRyxPQUFNLE1BQUcsTUFBSyxLQUFFLEdBQUUsS0FBRyxFQUFDLFVBQVMsb0JBQW1CLFVBQVMsV0FBVSxPQUFNLG9CQUFtQixNQUFLLG9CQUFtQixPQUFNLFdBQVUsTUFBSyxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUEsSUFBRUosSUFBRTtBQUFDLFlBQU1JLElBQUVKLEVBQUMsR0FBRSxLQUFLLFlBQVUsTUFBSyxLQUFLLGlCQUFlLE1BQUssS0FBSyxhQUFXLE9BQUcsS0FBSyxlQUFhLE1BQUssS0FBSyxlQUFhLE1BQUssS0FBSyxxQkFBbUIsRUFBRSxRQUFRLHdCQUF1QixLQUFLLFFBQVEsR0FBRSxLQUFLLG1CQUFtQixHQUFFLEtBQUssUUFBUSxTQUFPLE1BQUksS0FBSyxNQUFNO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBVTtBQUFBLElBQUMsT0FBTTtBQUFDLFdBQUssT0FBTyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWlCO0FBQUMsT0FBQyxTQUFTLFVBQVEsRUFBRSxLQUFLLFFBQVEsS0FBRyxLQUFLLEtBQUs7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFNO0FBQUMsV0FBSyxPQUFPLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxRQUFPO0FBQUMsV0FBSyxjQUFZLEVBQUUsS0FBSyxRQUFRLEdBQUUsS0FBSyxlQUFlO0FBQUEsSUFBQztBQUFBLElBQUMsUUFBTztBQUFDLFdBQUssZUFBZSxHQUFFLEtBQUssZ0JBQWdCLEdBQUUsS0FBSyxZQUFVLFlBQWEsTUFBSSxLQUFLLGdCQUFnQixHQUFHLEtBQUssUUFBUSxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsb0JBQW1CO0FBQUMsV0FBSyxRQUFRLFNBQU8sS0FBSyxhQUFXLEVBQUUsSUFBSSxLQUFLLFVBQVMsSUFBSSxNQUFJLEtBQUssTUFBTSxDQUFFLElBQUUsS0FBSyxNQUFNO0FBQUEsSUFBRTtBQUFBLElBQUMsR0FBR0ksSUFBRTtBQUFDLFlBQU1KLEtBQUUsS0FBSyxVQUFVO0FBQUUsVUFBR0ksS0FBRUosR0FBRSxTQUFPLEtBQUdJLEtBQUUsRUFBRTtBQUFPLFVBQUcsS0FBSyxXQUFXLFFBQU8sS0FBSyxFQUFFLElBQUksS0FBSyxVQUFTLElBQUksTUFBSSxLQUFLLEdBQUdBLEVBQUMsQ0FBRTtBQUFFLFlBQU1ILEtBQUUsS0FBSyxjQUFjLEtBQUssV0FBVyxDQUFDO0FBQUUsVUFBR0EsT0FBSUcsR0FBRTtBQUFPLFlBQU1GLEtBQUVFLEtBQUVILEtBQUUsS0FBRztBQUFHLFdBQUssT0FBT0MsSUFBRUYsR0FBRUksRUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssZ0JBQWMsS0FBSyxhQUFhLFFBQVEsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPQSxHQUFFLGtCQUFnQkEsR0FBRSxVQUFTQTtBQUFBLElBQUM7QUFBQSxJQUFDLHFCQUFvQjtBQUFDLFdBQUssUUFBUSxZQUFVLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxDQUFBQSxPQUFHLEtBQUssU0FBU0EsRUFBQyxDQUFFLEdBQUUsWUFBVSxLQUFLLFFBQVEsVUFBUSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUksTUFBSSxLQUFLLE1BQU0sQ0FBRSxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxNQUFJLEtBQUssa0JBQWtCLENBQUUsSUFBRyxLQUFLLFFBQVEsU0FBTyxHQUFHLFlBQVksS0FBRyxLQUFLLHdCQUF3QjtBQUFBLElBQUM7QUFBQSxJQUFDLDBCQUF5QjtBQUFDLGlCQUFVQSxNQUFLLEVBQUUsS0FBSyxzQkFBcUIsS0FBSyxRQUFRLEVBQUUsR0FBRSxHQUFHQSxJQUFFLElBQUksQ0FBQUEsT0FBR0EsR0FBRSxlQUFlLENBQUU7QUFBRSxZQUFNQSxLQUFFLEVBQUMsY0FBYSxNQUFJLEtBQUssT0FBTyxLQUFLLGtCQUFrQixFQUFFLENBQUMsR0FBRSxlQUFjLE1BQUksS0FBSyxPQUFPLEtBQUssa0JBQWtCLEVBQUUsQ0FBQyxHQUFFLGFBQVksTUFBSTtBQUFDLG9CQUFVLEtBQUssUUFBUSxVQUFRLEtBQUssTUFBTSxHQUFFLEtBQUssZ0JBQWMsYUFBYSxLQUFLLFlBQVksR0FBRSxLQUFLLGVBQWEsV0FBWSxNQUFJLEtBQUssa0JBQWtCLEdBQUcsTUFBSSxLQUFLLFFBQVEsUUFBUTtBQUFBLE1BQUUsRUFBQztBQUFFLFdBQUssZUFBYSxJQUFJLEdBQUcsS0FBSyxVQUFTQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsU0FBU0EsSUFBRTtBQUFDLFVBQUcsa0JBQWtCLEtBQUtBLEdBQUUsT0FBTyxPQUFPLEVBQUU7QUFBTyxZQUFNSixLQUFFLEdBQUdJLEdBQUUsR0FBRztBQUFFLE1BQUFKLE9BQUlJLEdBQUUsZUFBZSxHQUFFLEtBQUssT0FBTyxLQUFLLGtCQUFrQkosRUFBQyxDQUFDO0FBQUEsSUFBRTtBQUFBLElBQUMsY0FBY0ksSUFBRTtBQUFDLGFBQU8sS0FBSyxVQUFVLEVBQUUsUUFBUUEsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLDJCQUEyQkEsSUFBRTtBQUFDLFVBQUcsQ0FBQyxLQUFLLG1CQUFtQjtBQUFPLFlBQU1KLEtBQUUsRUFBRSxRQUFRLElBQUcsS0FBSyxrQkFBa0I7QUFBRSxNQUFBQSxHQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUVBLEdBQUUsZ0JBQWdCLGNBQWM7QUFBRSxZQUFNQyxLQUFFLEVBQUUsUUFBUSxzQkFBc0JHLEVBQUMsTUFBSyxLQUFLLGtCQUFrQjtBQUFFLE1BQUFILE9BQUlBLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRUEsR0FBRSxhQUFhLGdCQUFlLE1BQU07QUFBQSxJQUFFO0FBQUEsSUFBQyxrQkFBaUI7QUFBQyxZQUFNRyxLQUFFLEtBQUssa0JBQWdCLEtBQUssV0FBVztBQUFFLFVBQUcsQ0FBQ0EsR0FBRTtBQUFPLFlBQU1KLEtBQUUsT0FBTyxTQUFTSSxHQUFFLGFBQWEsa0JBQWtCLEdBQUUsRUFBRTtBQUFFLFdBQUssUUFBUSxXQUFTSixNQUFHLEtBQUssUUFBUTtBQUFBLElBQWU7QUFBQSxJQUFDLE9BQU9JLElBQUVKLEtBQUUsTUFBSztBQUFDLFVBQUcsS0FBSyxXQUFXO0FBQU8sWUFBTUMsS0FBRSxLQUFLLFdBQVcsR0FBRUMsS0FBRUUsT0FBSSxJQUFHRCxLQUFFSCxNQUFHLEVBQUUsS0FBSyxVQUFVLEdBQUVDLElBQUVDLElBQUUsS0FBSyxRQUFRLElBQUk7QUFBRSxVQUFHQyxPQUFJRixHQUFFO0FBQU8sWUFBTUksS0FBRSxLQUFLLGNBQWNGLEVBQUMsR0FBRUcsS0FBRSxDQUFBTixPQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVNBLElBQUUsRUFBQyxlQUFjRyxJQUFFLFdBQVUsS0FBSyxrQkFBa0JDLEVBQUMsR0FBRSxNQUFLLEtBQUssY0FBY0gsRUFBQyxHQUFFLElBQUdJLEdBQUMsQ0FBQztBQUFFLFVBQUdDLEdBQUUsRUFBRSxFQUFFLGlCQUFpQjtBQUFPLFVBQUcsQ0FBQ0wsTUFBRyxDQUFDRSxHQUFFO0FBQU8sWUFBTUksS0FBRSxRQUFRLEtBQUssU0FBUztBQUFFLFdBQUssTUFBTSxHQUFFLEtBQUssYUFBVyxNQUFHLEtBQUssMkJBQTJCRixFQUFDLEdBQUUsS0FBSyxpQkFBZUY7QUFBRSxZQUFNSyxLQUFFTixLQUFFLHdCQUFzQixxQkFBb0JPLEtBQUVQLEtBQUUsdUJBQXFCO0FBQXFCLE1BQUFDLEdBQUUsVUFBVSxJQUFJTSxFQUFDLEdBQUUsRUFBRU4sRUFBQyxHQUFFRixHQUFFLFVBQVUsSUFBSU8sRUFBQyxHQUFFTCxHQUFFLFVBQVUsSUFBSUssRUFBQyxHQUFFLEtBQUssZUFBZ0IsTUFBSTtBQUFDLFFBQUFMLEdBQUUsVUFBVSxPQUFPSyxJQUFFQyxFQUFDLEdBQUVOLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRUYsR0FBRSxVQUFVLE9BQU8sSUFBR1EsSUFBRUQsRUFBQyxHQUFFLEtBQUssYUFBVyxPQUFHRixHQUFFLEVBQUU7QUFBQSxNQUFDLEdBQUdMLElBQUUsS0FBSyxZQUFZLENBQUMsR0FBRU0sTUFBRyxLQUFLLE1BQU07QUFBQSxJQUFDO0FBQUEsSUFBQyxjQUFhO0FBQUMsYUFBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxhQUFZO0FBQUMsYUFBTyxFQUFFLFFBQVEsSUFBRyxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFXO0FBQUMsYUFBTyxFQUFFLEtBQUssSUFBRyxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBZ0I7QUFBQyxXQUFLLGNBQVksY0FBYyxLQUFLLFNBQVMsR0FBRSxLQUFLLFlBQVU7QUFBQSxJQUFLO0FBQUEsSUFBQyxrQkFBa0JILElBQUU7QUFBQyxhQUFPLEVBQUUsSUFBRUEsT0FBSSxLQUFHLEtBQUcsS0FBR0EsT0FBSSxLQUFHLEtBQUc7QUFBQSxJQUFFO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPLEVBQUUsSUFBRUEsT0FBSSxLQUFHLEtBQUcsS0FBR0EsT0FBSSxLQUFHLEtBQUc7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFNLFdBQVU7QUFBQyxjQUFNSixLQUFFLEdBQUcsb0JBQW9CLE1BQUtJLEVBQUM7QUFBRSxZQUFHLFlBQVUsT0FBT0EsSUFBRTtBQUFDLGNBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsZ0JBQUcsV0FBU0osR0FBRUksRUFBQyxLQUFHQSxHQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQkEsR0FBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFlBQUFKLEdBQUVJLEVBQUMsRUFBRTtBQUFBLFVBQUM7QUFBQSxRQUFDLE1BQU0sQ0FBQUosR0FBRSxHQUFHSSxFQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLHVDQUF1QyxTQUFTQSxJQUFFO0FBQUMsVUFBTUosS0FBRSxFQUFFLHVCQUF1QixJQUFJO0FBQUUsUUFBRyxDQUFDQSxNQUFHLENBQUNBLEdBQUUsVUFBVSxTQUFTLEVBQUUsRUFBRTtBQUFPLElBQUFJLEdBQUUsZUFBZTtBQUFFLFVBQU1ILEtBQUUsR0FBRyxvQkFBb0JELEVBQUMsR0FBRUUsS0FBRSxLQUFLLGFBQWEsa0JBQWtCO0FBQUUsV0FBT0EsTUFBR0QsR0FBRSxHQUFHQyxFQUFDLEdBQUUsS0FBS0QsR0FBRSxrQkFBa0IsS0FBRyxXQUFTLEVBQUUsaUJBQWlCLE1BQUssT0FBTyxLQUFHQSxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGtCQUFrQixNQUFJQSxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGtCQUFrQjtBQUFBLEVBQUUsQ0FBRSxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUksTUFBSTtBQUFDLFVBQU1HLEtBQUUsRUFBRSxLQUFLLDJCQUEyQjtBQUFFLGVBQVVKLE1BQUtJLEdBQUUsSUFBRyxvQkFBb0JKLEVBQUM7QUFBQSxFQUFDLENBQUUsR0FBRSxFQUFFLEVBQUU7QUFBRSxRQUFNLEtBQUcsZ0JBQWUsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxTQUFTLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxhQUFZLEtBQUcsUUFBTyxLQUFHLFlBQVcsS0FBRyxjQUFhLEtBQUcsV0FBVyxFQUFFLEtBQUssRUFBRSxJQUFHLEtBQUcsK0JBQThCLEtBQUcsRUFBQyxRQUFPLE1BQUssUUFBTyxLQUFFLEdBQUUsS0FBRyxFQUFDLFFBQU8sa0JBQWlCLFFBQU8sVUFBUztBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlJLElBQUVKLElBQUU7QUFBQyxZQUFNSSxJQUFFSixFQUFDLEdBQUUsS0FBSyxtQkFBaUIsT0FBRyxLQUFLLGdCQUFjLENBQUM7QUFBRSxZQUFNQyxLQUFFLEVBQUUsS0FBSyxFQUFFO0FBQUUsaUJBQVVHLE1BQUtILElBQUU7QUFBQyxjQUFNRCxLQUFFLEVBQUUsdUJBQXVCSSxFQUFDLEdBQUVILEtBQUUsRUFBRSxLQUFLRCxFQUFDLEVBQUUsT0FBUSxDQUFBSSxPQUFHQSxPQUFJLEtBQUssUUFBUztBQUFFLGlCQUFPSixNQUFHQyxHQUFFLFVBQVEsS0FBSyxjQUFjLEtBQUtHLEVBQUM7QUFBQSxNQUFDO0FBQUMsV0FBSyxvQkFBb0IsR0FBRSxLQUFLLFFBQVEsVUFBUSxLQUFLLDBCQUEwQixLQUFLLGVBQWMsS0FBSyxTQUFTLENBQUMsR0FBRSxLQUFLLFFBQVEsVUFBUSxLQUFLLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFVO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxTQUFTLElBQUUsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTTtBQUFDLFVBQUcsS0FBSyxvQkFBa0IsS0FBSyxTQUFTLEVBQUU7QUFBTyxVQUFJQSxLQUFFLENBQUM7QUFBRSxVQUFHLEtBQUssUUFBUSxXQUFTQSxLQUFFLEtBQUssdUJBQXVCLHNDQUFzQyxFQUFFLE9BQVEsQ0FBQUEsT0FBR0EsT0FBSSxLQUFLLFFBQVMsRUFBRSxJQUFLLENBQUFBLE9BQUcsR0FBRyxvQkFBb0JBLElBQUUsRUFBQyxRQUFPLE1BQUUsQ0FBQyxDQUFFLElBQUdBLEdBQUUsVUFBUUEsR0FBRSxDQUFDLEVBQUUsaUJBQWlCO0FBQU8sVUFBRyxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsRUFBRSxpQkFBaUI7QUFBTyxpQkFBVUosTUFBS0ksR0FBRSxDQUFBSixHQUFFLEtBQUs7QUFBRSxZQUFNQSxLQUFFLEtBQUssY0FBYztBQUFFLFdBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsR0FBRSxLQUFLLDBCQUEwQixLQUFLLGVBQWMsSUFBRSxHQUFFLEtBQUssbUJBQWlCO0FBQUcsWUFBTUMsS0FBRSxTQUFTRCxHQUFFLENBQUMsRUFBRSxZQUFZLElBQUVBLEdBQUUsTUFBTSxDQUFDLENBQUM7QUFBRyxXQUFLLGVBQWdCLE1BQUk7QUFBQyxhQUFLLG1CQUFpQixPQUFHLEtBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksSUFBRyxFQUFFLEdBQUUsS0FBSyxTQUFTLE1BQU1BLEVBQUMsSUFBRSxJQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtBQUFBLE1BQUMsR0FBRyxLQUFLLFVBQVMsSUFBRSxHQUFFLEtBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsR0FBRyxLQUFLLFNBQVNDLEVBQUMsQ0FBQztBQUFBLElBQUk7QUFBQSxJQUFDLE9BQU07QUFBQyxVQUFHLEtBQUssb0JBQWtCLENBQUMsS0FBSyxTQUFTLEVBQUU7QUFBTyxVQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxFQUFFLGlCQUFpQjtBQUFPLFlBQU1HLEtBQUUsS0FBSyxjQUFjO0FBQUUsV0FBSyxTQUFTLE1BQU1BLEVBQUMsSUFBRSxHQUFHLEtBQUssU0FBUyxzQkFBc0IsRUFBRUEsRUFBQyxDQUFDLE1BQUssRUFBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLElBQUcsRUFBRTtBQUFFLGlCQUFVQSxNQUFLLEtBQUssZUFBYztBQUFDLGNBQU1KLEtBQUUsRUFBRSx1QkFBdUJJLEVBQUM7QUFBRSxRQUFBSixNQUFHLENBQUMsS0FBSyxTQUFTQSxFQUFDLEtBQUcsS0FBSywwQkFBMEIsQ0FBQ0ksRUFBQyxHQUFFLEtBQUU7QUFBQSxNQUFDO0FBQUMsV0FBSyxtQkFBaUIsTUFBRyxLQUFLLFNBQVMsTUFBTUEsRUFBQyxJQUFFLElBQUcsS0FBSyxlQUFnQixNQUFJO0FBQUMsYUFBSyxtQkFBaUIsT0FBRyxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLEdBQUcsS0FBSyxVQUFTLElBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxTQUFTQSxLQUFFLEtBQUssVUFBUztBQUFDLGFBQU9BLEdBQUUsVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPQSxHQUFFLFNBQU8sUUFBUUEsR0FBRSxNQUFNLEdBQUVBLEdBQUUsU0FBTyxFQUFFQSxHQUFFLE1BQU0sR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxnQkFBZTtBQUFDLGFBQU8sS0FBSyxTQUFTLFVBQVUsU0FBUyxxQkFBcUIsSUFBRSxVQUFRO0FBQUEsSUFBUTtBQUFBLElBQUMsc0JBQXFCO0FBQUMsVUFBRyxDQUFDLEtBQUssUUFBUSxPQUFPO0FBQU8sWUFBTUEsS0FBRSxLQUFLLHVCQUF1QixFQUFFO0FBQUUsaUJBQVVKLE1BQUtJLElBQUU7QUFBQyxjQUFNQSxLQUFFLEVBQUUsdUJBQXVCSixFQUFDO0FBQUUsUUFBQUksTUFBRyxLQUFLLDBCQUEwQixDQUFDSixFQUFDLEdBQUUsS0FBSyxTQUFTSSxFQUFDLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsdUJBQXVCQSxJQUFFO0FBQUMsWUFBTUosS0FBRSxFQUFFLEtBQUssSUFBRyxLQUFLLFFBQVEsTUFBTTtBQUFFLGFBQU8sRUFBRSxLQUFLSSxJQUFFLEtBQUssUUFBUSxNQUFNLEVBQUUsT0FBUSxDQUFBQSxPQUFHLENBQUNKLEdBQUUsU0FBU0ksRUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsMEJBQTBCQSxJQUFFSixJQUFFO0FBQUMsVUFBR0ksR0FBRSxPQUFPLFlBQVVILE1BQUtHLEdBQUUsQ0FBQUgsR0FBRSxVQUFVLE9BQU8sYUFBWSxDQUFDRCxFQUFDLEdBQUVDLEdBQUUsYUFBYSxpQkFBZ0JELEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkksSUFBRTtBQUFDLFlBQU1KLEtBQUUsQ0FBQztBQUFFLGFBQU0sWUFBVSxPQUFPSSxNQUFHLFlBQVksS0FBS0EsRUFBQyxNQUFJSixHQUFFLFNBQU8sUUFBSSxLQUFLLEtBQU0sV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0QsRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPSSxJQUFFO0FBQUMsY0FBRyxXQUFTSCxHQUFFRyxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBSCxHQUFFRyxFQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLElBQUksU0FBU0EsSUFBRTtBQUFDLEtBQUMsUUFBTUEsR0FBRSxPQUFPLFdBQVNBLEdBQUUsa0JBQWdCLFFBQU1BLEdBQUUsZUFBZSxZQUFVQSxHQUFFLGVBQWU7QUFBRSxlQUFVQSxNQUFLLEVBQUUsZ0NBQWdDLElBQUksRUFBRSxJQUFHLG9CQUFvQkEsSUFBRSxFQUFDLFFBQU8sTUFBRSxDQUFDLEVBQUUsT0FBTztBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsRUFBRTtBQUFFLE1BQUksS0FBRyxPQUFNLEtBQUcsVUFBUyxLQUFHLFNBQVEsS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLENBQUMsSUFBRyxJQUFHLElBQUcsRUFBRSxHQUFFLEtBQUcsU0FBUSxLQUFHLE9BQU0sS0FBRyxtQkFBa0IsS0FBRyxZQUFXLEtBQUcsVUFBUyxLQUFHLGFBQVksS0FBRyxHQUFHLE9BQVEsU0FBU0EsSUFBRUosSUFBRTtBQUFDLFdBQU9JLEdBQUUsT0FBTyxDQUFDSixLQUFFLE1BQUksSUFBR0EsS0FBRSxNQUFJLEVBQUUsQ0FBQztBQUFBLEVBQUMsR0FBRyxDQUFDLENBQUMsR0FBRSxLQUFHLENBQUMsRUFBRSxPQUFPLElBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFRLFNBQVNJLElBQUVKLElBQUU7QUFBQyxXQUFPSSxHQUFFLE9BQU8sQ0FBQ0osSUFBRUEsS0FBRSxNQUFJLElBQUdBLEtBQUUsTUFBSSxFQUFFLENBQUM7QUFBQSxFQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUUsS0FBRyxjQUFhLEtBQUcsUUFBTyxLQUFHLGFBQVksS0FBRyxjQUFhLEtBQUcsUUFBTyxLQUFHLGFBQVksS0FBRyxlQUFjLEtBQUcsU0FBUSxLQUFHLGNBQWEsS0FBRyxDQUFDLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxFQUFFO0FBQUUsV0FBUyxHQUFHSSxJQUFFO0FBQUMsV0FBT0EsTUFBR0EsR0FBRSxZQUFVLElBQUksWUFBWSxJQUFFO0FBQUEsRUFBSTtBQUFDLFdBQVMsR0FBR0EsSUFBRTtBQUFDLFFBQUcsUUFBTUEsR0FBRSxRQUFPO0FBQU8sUUFBRyxzQkFBb0JBLEdBQUUsU0FBUyxHQUFFO0FBQUMsVUFBSUosS0FBRUksR0FBRTtBQUFjLGFBQU9KLE1BQUdBLEdBQUUsZUFBYTtBQUFBLElBQU07QUFBQyxXQUFPSTtBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxXQUFPQSxjQUFhLEdBQUdBLEVBQUMsRUFBRSxXQUFTQSxjQUFhO0FBQUEsRUFBTztBQUFDLFdBQVMsR0FBR0EsSUFBRTtBQUFDLFdBQU9BLGNBQWEsR0FBR0EsRUFBQyxFQUFFLGVBQWFBLGNBQWE7QUFBQSxFQUFXO0FBQUMsV0FBUyxHQUFHQSxJQUFFO0FBQUMsV0FBTSxlQUFhLE9BQU8sZUFBYUEsY0FBYSxHQUFHQSxFQUFDLEVBQUUsY0FBWUEsY0FBYTtBQUFBLEVBQVc7QUFBQyxRQUFNLEtBQUcsRUFBQyxNQUFLLGVBQWMsU0FBUSxNQUFHLE9BQU0sU0FBUSxJQUFHLFNBQVNBLElBQUU7QUFBQyxRQUFJSixLQUFFSSxHQUFFO0FBQU0sV0FBTyxLQUFLSixHQUFFLFFBQVEsRUFBRSxRQUFTLFNBQVNJLElBQUU7QUFBQyxVQUFJSCxLQUFFRCxHQUFFLE9BQU9JLEVBQUMsS0FBRyxDQUFDLEdBQUVGLEtBQUVGLEdBQUUsV0FBV0ksRUFBQyxLQUFHLENBQUMsR0FBRUQsS0FBRUgsR0FBRSxTQUFTSSxFQUFDO0FBQUUsU0FBR0QsRUFBQyxLQUFHLEdBQUdBLEVBQUMsTUFBSSxPQUFPLE9BQU9BLEdBQUUsT0FBTUYsRUFBQyxHQUFFLE9BQU8sS0FBS0MsRUFBQyxFQUFFLFFBQVMsU0FBU0UsSUFBRTtBQUFDLFlBQUlKLEtBQUVFLEdBQUVFLEVBQUM7QUFBRSxrQkFBS0osS0FBRUcsR0FBRSxnQkFBZ0JDLEVBQUMsSUFBRUQsR0FBRSxhQUFhQyxJQUFFLFNBQUtKLEtBQUUsS0FBR0EsRUFBQztBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUUsQ0FBRTtBQUFBLEVBQUMsR0FBRSxRQUFPLFNBQVNJLElBQUU7QUFBQyxRQUFJSixLQUFFSSxHQUFFLE9BQU1ILEtBQUUsRUFBQyxRQUFPLEVBQUMsVUFBU0QsR0FBRSxRQUFRLFVBQVMsTUFBSyxLQUFJLEtBQUksS0FBSSxRQUFPLElBQUcsR0FBRSxPQUFNLEVBQUMsVUFBUyxXQUFVLEdBQUUsV0FBVSxDQUFDLEVBQUM7QUFBRSxXQUFPLE9BQU8sT0FBT0EsR0FBRSxTQUFTLE9BQU8sT0FBTUMsR0FBRSxNQUFNLEdBQUVELEdBQUUsU0FBT0MsSUFBRUQsR0FBRSxTQUFTLFNBQU8sT0FBTyxPQUFPQSxHQUFFLFNBQVMsTUFBTSxPQUFNQyxHQUFFLEtBQUssR0FBRSxXQUFVO0FBQUMsYUFBTyxLQUFLRCxHQUFFLFFBQVEsRUFBRSxRQUFTLFNBQVNJLElBQUU7QUFBQyxZQUFJRixLQUFFRixHQUFFLFNBQVNJLEVBQUMsR0FBRUQsS0FBRUgsR0FBRSxXQUFXSSxFQUFDLEtBQUcsQ0FBQyxHQUFFQyxLQUFFLE9BQU8sS0FBS0wsR0FBRSxPQUFPLGVBQWVJLEVBQUMsSUFBRUosR0FBRSxPQUFPSSxFQUFDLElBQUVILEdBQUVHLEVBQUMsQ0FBQyxFQUFFLE9BQVEsU0FBU0EsSUFBRUosSUFBRTtBQUFDLGlCQUFPSSxHQUFFSixFQUFDLElBQUUsSUFBR0k7QUFBQSxRQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQUUsV0FBR0YsRUFBQyxLQUFHLEdBQUdBLEVBQUMsTUFBSSxPQUFPLE9BQU9BLEdBQUUsT0FBTUcsRUFBQyxHQUFFLE9BQU8sS0FBS0YsRUFBQyxFQUFFLFFBQVMsU0FBU0MsSUFBRTtBQUFDLFVBQUFGLEdBQUUsZ0JBQWdCRSxFQUFDO0FBQUEsUUFBQyxDQUFFO0FBQUEsTUFBRSxDQUFFO0FBQUEsSUFBQztBQUFBLEVBQUMsR0FBRSxVQUFTLENBQUMsZUFBZSxFQUFDO0FBQUUsV0FBUyxHQUFHQSxJQUFFO0FBQUMsV0FBT0EsR0FBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFBQztBQUFDLE1BQUksS0FBRyxLQUFLLEtBQUksS0FBRyxLQUFLLEtBQUksS0FBRyxLQUFLO0FBQU0sV0FBUyxLQUFJO0FBQUMsUUFBSUEsS0FBRSxVQUFVO0FBQWMsV0FBTyxRQUFNQSxNQUFHQSxHQUFFLFVBQVEsTUFBTSxRQUFRQSxHQUFFLE1BQU0sSUFBRUEsR0FBRSxPQUFPLElBQUssU0FBU0EsSUFBRTtBQUFDLGFBQU9BLEdBQUUsUUFBTSxNQUFJQSxHQUFFO0FBQUEsSUFBTyxDQUFFLEVBQUUsS0FBSyxHQUFHLElBQUUsVUFBVTtBQUFBLEVBQVM7QUFBQyxXQUFTLEtBQUk7QUFBQyxXQUFNLENBQUMsaUNBQWlDLEtBQUssR0FBRyxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0EsSUFBRUosSUFBRUMsSUFBRTtBQUFDLGVBQVNELE9BQUlBLEtBQUUsUUFBSSxXQUFTQyxPQUFJQSxLQUFFO0FBQUksUUFBSUMsS0FBRUUsR0FBRSxzQkFBc0IsR0FBRUQsS0FBRSxHQUFFRSxLQUFFO0FBQUUsSUFBQUwsTUFBRyxHQUFHSSxFQUFDLE1BQUlELEtBQUVDLEdBQUUsY0FBWSxLQUFHLEdBQUdGLEdBQUUsS0FBSyxJQUFFRSxHQUFFLGVBQWEsR0FBRUMsS0FBRUQsR0FBRSxlQUFhLEtBQUcsR0FBR0YsR0FBRSxNQUFNLElBQUVFLEdBQUUsZ0JBQWM7QUFBRyxRQUFJRSxNQUFHLEdBQUdGLEVBQUMsSUFBRSxHQUFHQSxFQUFDLElBQUUsUUFBUSxnQkFBZUcsS0FBRSxDQUFDLEdBQUcsS0FBR04sSUFBRU8sTUFBR04sR0FBRSxRQUFNSyxNQUFHRCxLQUFFQSxHQUFFLGFBQVcsTUFBSUgsSUFBRU0sTUFBR1AsR0FBRSxPQUFLSyxNQUFHRCxLQUFFQSxHQUFFLFlBQVUsTUFBSUQsSUFBRUssS0FBRVIsR0FBRSxRQUFNQyxJQUFFUSxLQUFFVCxHQUFFLFNBQU9HO0FBQUUsV0FBTSxFQUFDLE9BQU1LLElBQUUsUUFBT0MsSUFBRSxLQUFJRixJQUFFLE9BQU1ELEtBQUVFLElBQUUsUUFBT0QsS0FBRUUsSUFBRSxNQUFLSCxJQUFFLEdBQUVBLElBQUUsR0FBRUMsR0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdMLElBQUU7QUFBQyxRQUFJSixLQUFFLEdBQUdJLEVBQUMsR0FBRUgsS0FBRUcsR0FBRSxhQUFZRixLQUFFRSxHQUFFO0FBQWEsV0FBTyxLQUFLLElBQUlKLEdBQUUsUUFBTUMsRUFBQyxLQUFHLE1BQUlBLEtBQUVELEdBQUUsUUFBTyxLQUFLLElBQUlBLEdBQUUsU0FBT0UsRUFBQyxLQUFHLE1BQUlBLEtBQUVGLEdBQUUsU0FBUSxFQUFDLEdBQUVJLEdBQUUsWUFBVyxHQUFFQSxHQUFFLFdBQVUsT0FBTUgsSUFBRSxRQUFPQyxHQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0UsSUFBRUosSUFBRTtBQUFDLFFBQUlDLEtBQUVELEdBQUUsZUFBYUEsR0FBRSxZQUFZO0FBQUUsUUFBR0ksR0FBRSxTQUFTSixFQUFDLEVBQUUsUUFBTTtBQUFHLFFBQUdDLE1BQUcsR0FBR0EsRUFBQyxHQUFFO0FBQUMsVUFBSUMsS0FBRUY7QUFBRSxTQUFFO0FBQUMsWUFBR0UsTUFBR0UsR0FBRSxXQUFXRixFQUFDLEVBQUUsUUFBTTtBQUFHLFFBQUFBLEtBQUVBLEdBQUUsY0FBWUEsR0FBRTtBQUFBLE1BQUksU0FBT0E7QUFBQSxJQUFFO0FBQUMsV0FBTTtBQUFBLEVBQUU7QUFBQyxXQUFTLEdBQUdFLElBQUU7QUFBQyxXQUFPLEdBQUdBLEVBQUMsRUFBRSxpQkFBaUJBLEVBQUM7QUFBQSxFQUFDO0FBQUMsV0FBUyxHQUFHQSxJQUFFO0FBQUMsV0FBTSxDQUFDLFNBQVEsTUFBSyxJQUFJLEVBQUUsUUFBUSxHQUFHQSxFQUFDLENBQUMsS0FBRztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxhQUFRLEdBQUdBLEVBQUMsSUFBRUEsR0FBRSxnQkFBY0EsR0FBRSxhQUFXLE9BQU8sVUFBVTtBQUFBLEVBQWU7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxXQUFNLFdBQVMsR0FBR0EsRUFBQyxJQUFFQSxLQUFFQSxHQUFFLGdCQUFjQSxHQUFFLGVBQWEsR0FBR0EsRUFBQyxJQUFFQSxHQUFFLE9BQUssU0FBTyxHQUFHQSxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0EsSUFBRTtBQUFDLFdBQU8sR0FBR0EsRUFBQyxLQUFHLFlBQVUsR0FBR0EsRUFBQyxFQUFFLFdBQVNBLEdBQUUsZUFBYTtBQUFBLEVBQUk7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxhQUFRSixLQUFFLEdBQUdJLEVBQUMsR0FBRUgsS0FBRSxHQUFHRyxFQUFDLEdBQUVILE1BQUcsR0FBR0EsRUFBQyxLQUFHLGFBQVcsR0FBR0EsRUFBQyxFQUFFLFdBQVUsQ0FBQUEsS0FBRSxHQUFHQSxFQUFDO0FBQUUsV0FBT0EsT0FBSSxXQUFTLEdBQUdBLEVBQUMsS0FBRyxXQUFTLEdBQUdBLEVBQUMsS0FBRyxhQUFXLEdBQUdBLEVBQUMsRUFBRSxZQUFVRCxLQUFFQyxNQUFHLFNBQVNHLElBQUU7QUFBQyxVQUFJSixLQUFFLFdBQVcsS0FBSyxHQUFHLENBQUM7QUFBRSxVQUFHLFdBQVcsS0FBSyxHQUFHLENBQUMsS0FBRyxHQUFHSSxFQUFDLEtBQUcsWUFBVSxHQUFHQSxFQUFDLEVBQUUsU0FBUyxRQUFPO0FBQUssVUFBSUgsS0FBRSxHQUFHRyxFQUFDO0FBQUUsV0FBSSxHQUFHSCxFQUFDLE1BQUlBLEtBQUVBLEdBQUUsT0FBTSxHQUFHQSxFQUFDLEtBQUcsQ0FBQyxRQUFPLE1BQU0sRUFBRSxRQUFRLEdBQUdBLEVBQUMsQ0FBQyxJQUFFLEtBQUc7QUFBQyxZQUFJQyxLQUFFLEdBQUdELEVBQUM7QUFBRSxZQUFHLFdBQVNDLEdBQUUsYUFBVyxXQUFTQSxHQUFFLGVBQWEsWUFBVUEsR0FBRSxXQUFTLE9BQUssQ0FBQyxhQUFZLGFBQWEsRUFBRSxRQUFRQSxHQUFFLFVBQVUsS0FBR0YsTUFBRyxhQUFXRSxHQUFFLGNBQVlGLE1BQUdFLEdBQUUsVUFBUSxXQUFTQSxHQUFFLE9BQU8sUUFBT0Q7QUFBRSxRQUFBQSxLQUFFQSxHQUFFO0FBQUEsTUFBVTtBQUFDLGFBQU87QUFBQSxJQUFJLEVBQUVHLEVBQUMsS0FBR0o7QUFBQSxFQUFDO0FBQUMsV0FBUyxHQUFHSSxJQUFFO0FBQUMsV0FBTSxDQUFDLE9BQU0sUUFBUSxFQUFFLFFBQVFBLEVBQUMsS0FBRyxJQUFFLE1BQUk7QUFBQSxFQUFHO0FBQUMsV0FBUyxHQUFHQSxJQUFFSixJQUFFQyxJQUFFO0FBQUMsV0FBTyxHQUFHRyxJQUFFLEdBQUdKLElBQUVDLEVBQUMsQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdHLElBQUU7QUFBQyxXQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUUsRUFBQyxLQUFJLEdBQUUsT0FBTSxHQUFFLFFBQU8sR0FBRSxNQUFLLEVBQUMsR0FBRUEsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUVKLElBQUU7QUFBQyxXQUFPQSxHQUFFLE9BQVEsU0FBU0EsSUFBRUMsSUFBRTtBQUFDLGFBQU9ELEdBQUVDLEVBQUMsSUFBRUcsSUFBRUo7QUFBQSxJQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFBQztBQUFDLFFBQU0sS0FBRyxFQUFDLE1BQUssU0FBUSxTQUFRLE1BQUcsT0FBTSxRQUFPLElBQUcsU0FBU0ksSUFBRTtBQUFDLFFBQUlKLElBQUVDLEtBQUVHLEdBQUUsT0FBTUYsS0FBRUUsR0FBRSxNQUFLRCxLQUFFQyxHQUFFLFNBQVFDLEtBQUVKLEdBQUUsU0FBUyxPQUFNSyxLQUFFTCxHQUFFLGNBQWMsZUFBY00sS0FBRSxHQUFHTixHQUFFLFNBQVMsR0FBRU8sS0FBRSxHQUFHRCxFQUFDLEdBQUVFLEtBQUUsQ0FBQyxJQUFHLEVBQUUsRUFBRSxRQUFRRixFQUFDLEtBQUcsSUFBRSxXQUFTO0FBQVEsUUFBR0YsTUFBR0MsSUFBRTtBQUFDLFVBQUlJLEtBQUUsU0FBU04sSUFBRUosSUFBRTtBQUFDLGVBQU8sR0FBRyxZQUFVLFFBQU9JLEtBQUUsY0FBWSxPQUFPQSxLQUFFQSxHQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUVKLEdBQUUsT0FBTSxFQUFDLFdBQVVBLEdBQUUsVUFBUyxDQUFDLENBQUMsSUFBRUksTUFBR0EsS0FBRSxHQUFHQSxJQUFFLEVBQUUsQ0FBQztBQUFBLE1BQUMsRUFBRUQsR0FBRSxTQUFRRixFQUFDLEdBQUVVLEtBQUUsR0FBR04sRUFBQyxHQUFFTyxLQUFFLFFBQU1KLEtBQUUsS0FBRyxJQUFHSyxLQUFFLFFBQU1MLEtBQUUsS0FBRyxJQUFHTSxLQUFFYixHQUFFLE1BQU0sVUFBVVEsRUFBQyxJQUFFUixHQUFFLE1BQU0sVUFBVU8sRUFBQyxJQUFFRixHQUFFRSxFQUFDLElBQUVQLEdBQUUsTUFBTSxPQUFPUSxFQUFDLEdBQUVNLEtBQUVULEdBQUVFLEVBQUMsSUFBRVAsR0FBRSxNQUFNLFVBQVVPLEVBQUMsR0FBRVEsS0FBRSxHQUFHWCxFQUFDLEdBQUVZLEtBQUVELEtBQUUsUUFBTVIsS0FBRVEsR0FBRSxnQkFBYyxJQUFFQSxHQUFFLGVBQWEsSUFBRSxHQUFFRSxLQUFFSixLQUFFLElBQUVDLEtBQUUsR0FBRUksS0FBRVQsR0FBRUUsRUFBQyxHQUFFUSxLQUFFSCxLQUFFTixHQUFFRixFQUFDLElBQUVDLEdBQUVHLEVBQUMsR0FBRVEsS0FBRUosS0FBRSxJQUFFTixHQUFFRixFQUFDLElBQUUsSUFBRVMsSUFBRUksS0FBRSxHQUFHSCxJQUFFRSxJQUFFRCxFQUFDLEdBQUVHLEtBQUVmO0FBQUUsTUFBQVAsR0FBRSxjQUFjQyxFQUFDLE1BQUlGLEtBQUUsQ0FBQyxHQUFHdUIsRUFBQyxJQUFFRCxJQUFFdEIsR0FBRSxlQUFhc0IsS0FBRUQsSUFBRXJCO0FBQUEsSUFBRTtBQUFBLEVBQUMsR0FBRSxRQUFPLFNBQVNJLElBQUU7QUFBQyxRQUFJSixLQUFFSSxHQUFFLE9BQU1ILEtBQUVHLEdBQUUsUUFBUSxTQUFRRixLQUFFLFdBQVNELEtBQUUsd0JBQXNCQTtBQUFFLFlBQU1DLE9BQUksWUFBVSxPQUFPQSxPQUFJQSxLQUFFRixHQUFFLFNBQVMsT0FBTyxjQUFjRSxFQUFDLE9BQUssR0FBR0YsR0FBRSxTQUFTLFFBQU9FLEVBQUMsTUFBSUYsR0FBRSxTQUFTLFFBQU1FO0FBQUEsRUFBRSxHQUFFLFVBQVMsQ0FBQyxlQUFlLEdBQUUsa0JBQWlCLENBQUMsaUJBQWlCLEVBQUM7QUFBRSxXQUFTLEdBQUdFLElBQUU7QUFBQyxXQUFPQSxHQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUFDO0FBQUMsTUFBSSxLQUFHLEVBQUMsS0FBSSxRQUFPLE9BQU0sUUFBTyxRQUFPLFFBQU8sTUFBSyxPQUFNO0FBQUUsV0FBUyxHQUFHQSxJQUFFO0FBQUMsUUFBSUosSUFBRUMsS0FBRUcsR0FBRSxRQUFPRixLQUFFRSxHQUFFLFlBQVdELEtBQUVDLEdBQUUsV0FBVUMsS0FBRUQsR0FBRSxXQUFVRSxLQUFFRixHQUFFLFNBQVFHLEtBQUVILEdBQUUsVUFBU0ksS0FBRUosR0FBRSxpQkFBZ0JLLEtBQUVMLEdBQUUsVUFBU00sS0FBRU4sR0FBRSxjQUFhTyxLQUFFUCxHQUFFLFNBQVFRLEtBQUVOLEdBQUUsR0FBRU8sS0FBRSxXQUFTRCxLQUFFLElBQUVBLElBQUVFLEtBQUVSLEdBQUUsR0FBRVMsS0FBRSxXQUFTRCxLQUFFLElBQUVBLElBQUVFLEtBQUUsY0FBWSxPQUFPTixLQUFFQSxHQUFFLEVBQUMsR0FBRUcsSUFBRSxHQUFFRSxHQUFDLENBQUMsSUFBRSxFQUFDLEdBQUVGLElBQUUsR0FBRUUsR0FBQztBQUFFLElBQUFGLEtBQUVHLEdBQUUsR0FBRUQsS0FBRUMsR0FBRTtBQUFFLFFBQUlDLEtBQUVYLEdBQUUsZUFBZSxHQUFHLEdBQUVZLEtBQUVaLEdBQUUsZUFBZSxHQUFHLEdBQUVhLEtBQUUsSUFBR0MsS0FBRSxJQUFHQyxLQUFFO0FBQU8sUUFBR1osSUFBRTtBQUFDLFVBQUlhLEtBQUUsR0FBR3JCLEVBQUMsR0FBRXNCLEtBQUUsZ0JBQWVDLEtBQUU7QUFBYyxNQUFBRixPQUFJLEdBQUdyQixFQUFDLEtBQUcsYUFBVyxHQUFHcUIsS0FBRSxHQUFHckIsRUFBQyxDQUFDLEVBQUUsWUFBVSxlQUFhTSxPQUFJZ0IsS0FBRSxnQkFBZUMsS0FBRSxpQkFBZ0JyQixPQUFJLE9BQUtBLE9BQUksTUFBSUEsT0FBSSxPQUFLRSxPQUFJLFFBQU1lLEtBQUUsSUFBR0wsT0FBSUosTUFBR1csT0FBSUQsTUFBR0EsR0FBRSxpQkFBZUEsR0FBRSxlQUFlLFNBQU9DLEdBQUVDLEVBQUMsS0FBR3JCLEdBQUUsUUFBT2EsTUFBR1AsS0FBRSxJQUFFLEtBQUlMLE9BQUksT0FBS0EsT0FBSSxNQUFJQSxPQUFJLE1BQUlFLE9BQUksUUFBTWMsS0FBRSxJQUFHTixPQUFJRixNQUFHVyxPQUFJRCxNQUFHQSxHQUFFLGlCQUFlQSxHQUFFLGVBQWUsUUFBTUMsR0FBRUUsRUFBQyxLQUFHdEIsR0FBRSxPQUFNVyxNQUFHTCxLQUFFLElBQUU7QUFBQSxJQUFHO0FBQUMsUUFBSWlCLElBQUVDLEtBQUUsT0FBTyxPQUFPLEVBQUMsVUFBU25CLEdBQUMsR0FBRUUsTUFBRyxFQUFFLEdBQUVrQixLQUFFLFNBQUtqQixLQUFFLFNBQVNOLElBQUVKLElBQUU7QUFBQyxVQUFJQyxLQUFFRyxHQUFFLEdBQUVGLEtBQUVFLEdBQUUsR0FBRUQsS0FBRUgsR0FBRSxvQkFBa0I7QUFBRSxhQUFNLEVBQUMsR0FBRSxHQUFHQyxLQUFFRSxFQUFDLElBQUVBLE1BQUcsR0FBRSxHQUFFLEdBQUdELEtBQUVDLEVBQUMsSUFBRUEsTUFBRyxFQUFDO0FBQUEsSUFBQyxFQUFFLEVBQUMsR0FBRVUsSUFBRSxHQUFFRSxHQUFDLEdBQUUsR0FBR2QsRUFBQyxDQUFDLElBQUUsRUFBQyxHQUFFWSxJQUFFLEdBQUVFLEdBQUM7QUFBRSxXQUFPRixLQUFFYyxHQUFFLEdBQUVaLEtBQUVZLEdBQUUsR0FBRW5CLEtBQUUsT0FBTyxPQUFPLENBQUMsR0FBRWtCLE1BQUlELEtBQUUsQ0FBQyxHQUFHTCxFQUFDLElBQUVGLEtBQUUsTUFBSSxJQUFHTyxHQUFFTixFQUFDLElBQUVGLEtBQUUsTUFBSSxJQUFHUSxHQUFFLGFBQVdKLEdBQUUsb0JBQWtCLE1BQUksSUFBRSxlQUFhUixLQUFFLFNBQU9FLEtBQUUsUUFBTSxpQkFBZUYsS0FBRSxTQUFPRSxLQUFFLFVBQVNVLEdBQUUsSUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFQyxNQUFJMUIsS0FBRSxDQUFDLEdBQUdvQixFQUFDLElBQUVGLEtBQUVILEtBQUUsT0FBSyxJQUFHZixHQUFFbUIsRUFBQyxJQUFFRixLQUFFSixLQUFFLE9BQUssSUFBR2IsR0FBRSxZQUFVLElBQUdBLEdBQUU7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLEVBQUMsTUFBSyxpQkFBZ0IsU0FBUSxNQUFHLE9BQU0sZUFBYyxJQUFHLFNBQVNJLElBQUU7QUFBQyxRQUFJSixLQUFFSSxHQUFFLE9BQU1ILEtBQUVHLEdBQUUsU0FBUUYsS0FBRUQsR0FBRSxpQkFBZ0JFLEtBQUUsV0FBU0QsTUFBR0EsSUFBRUcsS0FBRUosR0FBRSxVQUFTSyxLQUFFLFdBQVNELE1BQUdBLElBQUVFLEtBQUVOLEdBQUUsY0FBYU8sS0FBRSxXQUFTRCxNQUFHQSxJQUFFRSxLQUFFLEVBQUMsV0FBVSxHQUFHVCxHQUFFLFNBQVMsR0FBRSxXQUFVLEdBQUdBLEdBQUUsU0FBUyxHQUFFLFFBQU9BLEdBQUUsU0FBUyxRQUFPLFlBQVdBLEdBQUUsTUFBTSxRQUFPLGlCQUFnQkcsSUFBRSxTQUFRLFlBQVVILEdBQUUsUUFBUSxTQUFRO0FBQUUsWUFBTUEsR0FBRSxjQUFjLGtCQUFnQkEsR0FBRSxPQUFPLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRUEsR0FBRSxPQUFPLFFBQU8sR0FBRyxPQUFPLE9BQU8sQ0FBQyxHQUFFUyxJQUFFLEVBQUMsU0FBUVQsR0FBRSxjQUFjLGVBQWMsVUFBU0EsR0FBRSxRQUFRLFVBQVMsVUFBU00sSUFBRSxjQUFhRSxHQUFDLENBQUMsQ0FBQyxDQUFDLElBQUcsUUFBTVIsR0FBRSxjQUFjLFVBQVFBLEdBQUUsT0FBTyxRQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUVBLEdBQUUsT0FBTyxPQUFNLEdBQUcsT0FBTyxPQUFPLENBQUMsR0FBRVMsSUFBRSxFQUFDLFNBQVFULEdBQUUsY0FBYyxPQUFNLFVBQVMsWUFBVyxVQUFTLE9BQUcsY0FBYVEsR0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFHUixHQUFFLFdBQVcsU0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxHQUFFLFdBQVcsUUFBTyxFQUFDLHlCQUF3QkEsR0FBRSxVQUFTLENBQUM7QUFBQSxFQUFDLEdBQUUsTUFBSyxDQUFDLEVBQUM7QUFBRSxNQUFJLEtBQUcsRUFBQyxTQUFRLEtBQUU7QUFBRSxRQUFNLEtBQUcsRUFBQyxNQUFLLGtCQUFpQixTQUFRLE1BQUcsT0FBTSxTQUFRLElBQUcsV0FBVTtBQUFBLEVBQUMsR0FBRSxRQUFPLFNBQVNJLElBQUU7QUFBQyxRQUFJSixLQUFFSSxHQUFFLE9BQU1ILEtBQUVHLEdBQUUsVUFBU0YsS0FBRUUsR0FBRSxTQUFRRCxLQUFFRCxHQUFFLFFBQU9HLEtBQUUsV0FBU0YsTUFBR0EsSUFBRUcsS0FBRUosR0FBRSxRQUFPSyxLQUFFLFdBQVNELE1BQUdBLElBQUVFLEtBQUUsR0FBR1IsR0FBRSxTQUFTLE1BQU0sR0FBRVMsS0FBRSxDQUFDLEVBQUUsT0FBT1QsR0FBRSxjQUFjLFdBQVVBLEdBQUUsY0FBYyxNQUFNO0FBQUUsV0FBT0ssTUFBR0ksR0FBRSxRQUFTLFNBQVNMLElBQUU7QUFBQyxNQUFBQSxHQUFFLGlCQUFpQixVQUFTSCxHQUFFLFFBQU8sRUFBRTtBQUFBLElBQUMsQ0FBRSxHQUFFTSxNQUFHQyxHQUFFLGlCQUFpQixVQUFTUCxHQUFFLFFBQU8sRUFBRSxHQUFFLFdBQVU7QUFBQyxNQUFBSSxNQUFHSSxHQUFFLFFBQVMsU0FBU0wsSUFBRTtBQUFDLFFBQUFBLEdBQUUsb0JBQW9CLFVBQVNILEdBQUUsUUFBTyxFQUFFO0FBQUEsTUFBQyxDQUFFLEdBQUVNLE1BQUdDLEdBQUUsb0JBQW9CLFVBQVNQLEdBQUUsUUFBTyxFQUFFO0FBQUEsSUFBQztBQUFBLEVBQUMsR0FBRSxNQUFLLENBQUMsRUFBQztBQUFFLE1BQUksS0FBRyxFQUFDLE1BQUssU0FBUSxPQUFNLFFBQU8sUUFBTyxPQUFNLEtBQUksU0FBUTtBQUFFLFdBQVMsR0FBR0csSUFBRTtBQUFDLFdBQU9BLEdBQUUsUUFBUSwwQkFBMEIsU0FBU0EsSUFBRTtBQUFDLGFBQU8sR0FBR0EsRUFBQztBQUFBLElBQUMsQ0FBRTtBQUFBLEVBQUM7QUFBQyxNQUFJLEtBQUcsRUFBQyxPQUFNLE9BQU0sS0FBSSxRQUFPO0FBQUUsV0FBUyxHQUFHQSxJQUFFO0FBQUMsV0FBT0EsR0FBRSxRQUFRLGNBQWMsU0FBU0EsSUFBRTtBQUFDLGFBQU8sR0FBR0EsRUFBQztBQUFBLElBQUMsQ0FBRTtBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxRQUFJSixLQUFFLEdBQUdJLEVBQUM7QUFBRSxXQUFNLEVBQUMsWUFBV0osR0FBRSxhQUFZLFdBQVVBLEdBQUUsWUFBVztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdJLElBQUU7QUFBQyxXQUFPLEdBQUcsR0FBR0EsRUFBQyxDQUFDLEVBQUUsT0FBSyxHQUFHQSxFQUFDLEVBQUU7QUFBQSxFQUFVO0FBQUMsV0FBUyxHQUFHQSxJQUFFO0FBQUMsUUFBSUosS0FBRSxHQUFHSSxFQUFDLEdBQUVILEtBQUVELEdBQUUsVUFBU0UsS0FBRUYsR0FBRSxXQUFVRyxLQUFFSCxHQUFFO0FBQVUsV0FBTSw2QkFBNkIsS0FBS0MsS0FBRUUsS0FBRUQsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdFLElBQUU7QUFBQyxXQUFNLENBQUMsUUFBTyxRQUFPLFdBQVcsRUFBRSxRQUFRLEdBQUdBLEVBQUMsQ0FBQyxLQUFHLElBQUVBLEdBQUUsY0FBYyxPQUFLLEdBQUdBLEVBQUMsS0FBRyxHQUFHQSxFQUFDLElBQUVBLEtBQUUsR0FBRyxHQUFHQSxFQUFDLENBQUM7QUFBQSxFQUFDO0FBQUMsV0FBUyxHQUFHQSxJQUFFSixJQUFFO0FBQUMsUUFBSUM7QUFBRSxlQUFTRCxPQUFJQSxLQUFFLENBQUM7QUFBRyxRQUFJRSxLQUFFLEdBQUdFLEVBQUMsR0FBRUQsS0FBRUQsUUFBSyxTQUFPRCxLQUFFRyxHQUFFLGlCQUFlLFNBQU9ILEdBQUUsT0FBTUksS0FBRSxHQUFHSCxFQUFDLEdBQUVJLEtBQUVILEtBQUUsQ0FBQ0UsRUFBQyxFQUFFLE9BQU9BLEdBQUUsa0JBQWdCLENBQUMsR0FBRSxHQUFHSCxFQUFDLElBQUVBLEtBQUUsQ0FBQyxDQUFDLElBQUVBLElBQUVLLEtBQUVQLEdBQUUsT0FBT00sRUFBQztBQUFFLFdBQU9ILEtBQUVJLEtBQUVBLEdBQUUsT0FBTyxHQUFHLEdBQUdELEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0YsSUFBRTtBQUFDLFdBQU8sT0FBTyxPQUFPLENBQUMsR0FBRUEsSUFBRSxFQUFDLE1BQUtBLEdBQUUsR0FBRSxLQUFJQSxHQUFFLEdBQUUsT0FBTUEsR0FBRSxJQUFFQSxHQUFFLE9BQU0sUUFBT0EsR0FBRSxJQUFFQSxHQUFFLE9BQU0sQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUVKLElBQUVDLElBQUU7QUFBQyxXQUFPRCxPQUFJLEtBQUcsR0FBRyxTQUFTSSxJQUFFSixJQUFFO0FBQUMsVUFBSUMsS0FBRSxHQUFHRyxFQUFDLEdBQUVGLEtBQUUsR0FBR0UsRUFBQyxHQUFFRCxLQUFFRixHQUFFLGdCQUFlSSxLQUFFSCxHQUFFLGFBQVlJLEtBQUVKLEdBQUUsY0FBYUssS0FBRSxHQUFFQyxLQUFFO0FBQUUsVUFBR0wsSUFBRTtBQUFDLFFBQUFFLEtBQUVGLEdBQUUsT0FBTUcsS0FBRUgsR0FBRTtBQUFPLFlBQUlNLEtBQUUsR0FBRztBQUFFLFNBQUNBLE1BQUcsQ0FBQ0EsTUFBRyxZQUFVVCxRQUFLTyxLQUFFSixHQUFFLFlBQVdLLEtBQUVMLEdBQUU7QUFBQSxNQUFVO0FBQUMsYUFBTSxFQUFDLE9BQU1FLElBQUUsUUFBT0MsSUFBRSxHQUFFQyxLQUFFLEdBQUdILEVBQUMsR0FBRSxHQUFFSSxHQUFDO0FBQUEsSUFBQyxFQUFFSixJQUFFSCxFQUFDLENBQUMsSUFBRSxHQUFHRCxFQUFDLElBQUUsU0FBU0ksSUFBRUosSUFBRTtBQUFDLFVBQUlDLEtBQUUsR0FBR0csSUFBRSxPQUFHLFlBQVVKLEVBQUM7QUFBRSxhQUFPQyxHQUFFLE1BQUlBLEdBQUUsTUFBSUcsR0FBRSxXQUFVSCxHQUFFLE9BQUtBLEdBQUUsT0FBS0csR0FBRSxZQUFXSCxHQUFFLFNBQU9BLEdBQUUsTUFBSUcsR0FBRSxjQUFhSCxHQUFFLFFBQU1BLEdBQUUsT0FBS0csR0FBRSxhQUFZSCxHQUFFLFFBQU1HLEdBQUUsYUFBWUgsR0FBRSxTQUFPRyxHQUFFLGNBQWFILEdBQUUsSUFBRUEsR0FBRSxNQUFLQSxHQUFFLElBQUVBLEdBQUUsS0FBSUE7QUFBQSxJQUFDLEVBQUVELElBQUVDLEVBQUMsSUFBRSxHQUFHLFNBQVNHLElBQUU7QUFBQyxVQUFJSixJQUFFQyxLQUFFLEdBQUdHLEVBQUMsR0FBRUYsS0FBRSxHQUFHRSxFQUFDLEdBQUVELEtBQUUsU0FBT0gsS0FBRUksR0FBRSxpQkFBZSxTQUFPSixHQUFFLE1BQUtLLEtBQUUsR0FBR0osR0FBRSxhQUFZQSxHQUFFLGFBQVlFLEtBQUVBLEdBQUUsY0FBWSxHQUFFQSxLQUFFQSxHQUFFLGNBQVksQ0FBQyxHQUFFRyxLQUFFLEdBQUdMLEdBQUUsY0FBYUEsR0FBRSxjQUFhRSxLQUFFQSxHQUFFLGVBQWEsR0FBRUEsS0FBRUEsR0FBRSxlQUFhLENBQUMsR0FBRUksS0FBRSxDQUFDTCxHQUFFLGFBQVcsR0FBR0UsRUFBQyxHQUFFSSxLQUFFLENBQUNOLEdBQUU7QUFBVSxhQUFNLFVBQVEsR0FBR0MsTUFBR0YsRUFBQyxFQUFFLGNBQVlNLE1BQUcsR0FBR04sR0FBRSxhQUFZRSxLQUFFQSxHQUFFLGNBQVksQ0FBQyxJQUFFRSxLQUFHLEVBQUMsT0FBTUEsSUFBRSxRQUFPQyxJQUFFLEdBQUVDLElBQUUsR0FBRUMsR0FBQztBQUFBLElBQUMsRUFBRSxHQUFHSixFQUFDLENBQUMsQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdBLElBQUU7QUFBQyxRQUFJSixJQUFFQyxLQUFFRyxHQUFFLFdBQVVGLEtBQUVFLEdBQUUsU0FBUUQsS0FBRUMsR0FBRSxXQUFVQyxLQUFFRixLQUFFLEdBQUdBLEVBQUMsSUFBRSxNQUFLRyxLQUFFSCxLQUFFLEdBQUdBLEVBQUMsSUFBRSxNQUFLSSxLQUFFTixHQUFFLElBQUVBLEdBQUUsUUFBTSxJQUFFQyxHQUFFLFFBQU0sR0FBRU0sS0FBRVAsR0FBRSxJQUFFQSxHQUFFLFNBQU8sSUFBRUMsR0FBRSxTQUFPO0FBQUUsWUFBT0csSUFBRTtBQUFBLE1BQUMsS0FBSztBQUFHLFFBQUFMLEtBQUUsRUFBQyxHQUFFTyxJQUFFLEdBQUVOLEdBQUUsSUFBRUMsR0FBRSxPQUFNO0FBQUU7QUFBQSxNQUFNLEtBQUs7QUFBRyxRQUFBRixLQUFFLEVBQUMsR0FBRU8sSUFBRSxHQUFFTixHQUFFLElBQUVBLEdBQUUsT0FBTTtBQUFFO0FBQUEsTUFBTSxLQUFLO0FBQUcsUUFBQUQsS0FBRSxFQUFDLEdBQUVDLEdBQUUsSUFBRUEsR0FBRSxPQUFNLEdBQUVPLEdBQUM7QUFBRTtBQUFBLE1BQU0sS0FBSztBQUFHLFFBQUFSLEtBQUUsRUFBQyxHQUFFQyxHQUFFLElBQUVDLEdBQUUsT0FBTSxHQUFFTSxHQUFDO0FBQUU7QUFBQSxNQUFNO0FBQVEsUUFBQVIsS0FBRSxFQUFDLEdBQUVDLEdBQUUsR0FBRSxHQUFFQSxHQUFFLEVBQUM7QUFBQSxJQUFDO0FBQUMsUUFBSVEsS0FBRUosS0FBRSxHQUFHQSxFQUFDLElBQUU7QUFBSyxRQUFHLFFBQU1JLElBQUU7QUFBQyxVQUFJQyxLQUFFLFFBQU1ELEtBQUUsV0FBUztBQUFRLGNBQU9ILElBQUU7QUFBQSxRQUFDLEtBQUs7QUFBRyxVQUFBTixHQUFFUyxFQUFDLElBQUVULEdBQUVTLEVBQUMsS0FBR1IsR0FBRVMsRUFBQyxJQUFFLElBQUVSLEdBQUVRLEVBQUMsSUFBRTtBQUFHO0FBQUEsUUFBTSxLQUFLO0FBQUcsVUFBQVYsR0FBRVMsRUFBQyxJQUFFVCxHQUFFUyxFQUFDLEtBQUdSLEdBQUVTLEVBQUMsSUFBRSxJQUFFUixHQUFFUSxFQUFDLElBQUU7QUFBQSxNQUFFO0FBQUEsSUFBQztBQUFDLFdBQU9WO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0ksSUFBRUosSUFBRTtBQUFDLGVBQVNBLE9BQUlBLEtBQUUsQ0FBQztBQUFHLFFBQUlDLEtBQUVELElBQUVFLEtBQUVELEdBQUUsV0FBVUUsS0FBRSxXQUFTRCxLQUFFRSxHQUFFLFlBQVVGLElBQUVHLEtBQUVKLEdBQUUsVUFBU0ssS0FBRSxXQUFTRCxLQUFFRCxHQUFFLFdBQVNDLElBQUVFLEtBQUVOLEdBQUUsVUFBU08sS0FBRSxXQUFTRCxLQUFFLEtBQUdBLElBQUVFLEtBQUVSLEdBQUUsY0FBYVMsS0FBRSxXQUFTRCxLQUFFLEtBQUdBLElBQUVFLEtBQUVWLEdBQUUsZ0JBQWVXLEtBQUUsV0FBU0QsS0FBRSxLQUFHQSxJQUFFRSxLQUFFWixHQUFFLGFBQVlhLEtBQUUsV0FBU0QsTUFBR0EsSUFBRUUsS0FBRWQsR0FBRSxTQUFRZSxLQUFFLFdBQVNELEtBQUUsSUFBRUEsSUFBRUUsS0FBRSxHQUFHLFlBQVUsT0FBT0QsS0FBRUEsS0FBRSxHQUFHQSxJQUFFLEVBQUUsQ0FBQyxHQUFFRSxLQUFFTixPQUFJLEtBQUcsS0FBRyxJQUFHTyxLQUFFZixHQUFFLE1BQU0sUUFBT2dCLEtBQUVoQixHQUFFLFNBQVNVLEtBQUVJLEtBQUVOLEVBQUMsR0FBRVMsS0FBRSxTQUFTakIsSUFBRUosSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFVBQUlDLEtBQUUsc0JBQW9CSCxLQUFFLFNBQVNJLElBQUU7QUFBQyxZQUFJSixLQUFFLEdBQUcsR0FBR0ksRUFBQyxDQUFDLEdBQUVILEtBQUUsQ0FBQyxZQUFXLE9BQU8sRUFBRSxRQUFRLEdBQUdHLEVBQUMsRUFBRSxRQUFRLEtBQUcsS0FBRyxHQUFHQSxFQUFDLElBQUUsR0FBR0EsRUFBQyxJQUFFQTtBQUFFLGVBQU8sR0FBR0gsRUFBQyxJQUFFRCxHQUFFLE9BQVEsU0FBU0ksSUFBRTtBQUFDLGlCQUFPLEdBQUdBLEVBQUMsS0FBRyxHQUFHQSxJQUFFSCxFQUFDLEtBQUcsV0FBUyxHQUFHRyxFQUFDO0FBQUEsUUFBQyxDQUFFLElBQUUsQ0FBQztBQUFBLE1BQUMsRUFBRUEsRUFBQyxJQUFFLENBQUMsRUFBRSxPQUFPSixFQUFDLEdBQUVLLEtBQUUsQ0FBQyxFQUFFLE9BQU9GLElBQUUsQ0FBQ0YsRUFBQyxDQUFDLEdBQUVLLEtBQUVELEdBQUUsQ0FBQyxHQUFFRSxLQUFFRixHQUFFLE9BQVEsU0FBU0wsSUFBRUMsSUFBRTtBQUFDLFlBQUlFLEtBQUUsR0FBR0MsSUFBRUgsSUFBRUMsRUFBQztBQUFFLGVBQU9GLEdBQUUsTUFBSSxHQUFHRyxHQUFFLEtBQUlILEdBQUUsR0FBRyxHQUFFQSxHQUFFLFFBQU0sR0FBR0csR0FBRSxPQUFNSCxHQUFFLEtBQUssR0FBRUEsR0FBRSxTQUFPLEdBQUdHLEdBQUUsUUFBT0gsR0FBRSxNQUFNLEdBQUVBLEdBQUUsT0FBSyxHQUFHRyxHQUFFLE1BQUtILEdBQUUsSUFBSSxHQUFFQTtBQUFBLE1BQUMsR0FBRyxHQUFHSSxJQUFFRSxJQUFFSixFQUFDLENBQUM7QUFBRSxhQUFPSyxHQUFFLFFBQU1BLEdBQUUsUUFBTUEsR0FBRSxNQUFLQSxHQUFFLFNBQU9BLEdBQUUsU0FBT0EsR0FBRSxLQUFJQSxHQUFFLElBQUVBLEdBQUUsTUFBS0EsR0FBRSxJQUFFQSxHQUFFLEtBQUlBO0FBQUEsSUFBQyxFQUFFLEdBQUdhLEVBQUMsSUFBRUEsS0FBRUEsR0FBRSxrQkFBZ0IsR0FBR2hCLEdBQUUsU0FBUyxNQUFNLEdBQUVJLElBQUVFLElBQUVKLEVBQUMsR0FBRWdCLEtBQUUsR0FBR2xCLEdBQUUsU0FBUyxTQUFTLEdBQUVtQixLQUFFLEdBQUcsRUFBQyxXQUFVRCxJQUFFLFNBQVFILElBQUUsV0FBVWhCLEdBQUMsQ0FBQyxHQUFFcUIsS0FBRSxHQUFHLE9BQU8sT0FBTyxDQUFDLEdBQUVMLElBQUVJLEVBQUMsQ0FBQyxHQUFFRSxLQUFFYixPQUFJLEtBQUdZLEtBQUVGLElBQUVJLEtBQUUsRUFBQyxLQUFJTCxHQUFFLE1BQUlJLEdBQUUsTUFBSVIsR0FBRSxLQUFJLFFBQU9RLEdBQUUsU0FBT0osR0FBRSxTQUFPSixHQUFFLFFBQU8sTUFBS0ksR0FBRSxPQUFLSSxHQUFFLE9BQUtSLEdBQUUsTUFBSyxPQUFNUSxHQUFFLFFBQU1KLEdBQUUsUUFBTUosR0FBRSxNQUFLLEdBQUVVLEtBQUV2QixHQUFFLGNBQWM7QUFBTyxRQUFHUSxPQUFJLE1BQUllLElBQUU7QUFBQyxVQUFJQyxLQUFFRCxHQUFFeEIsRUFBQztBQUFFLGFBQU8sS0FBS3VCLEVBQUMsRUFBRSxRQUFTLFNBQVN0QixJQUFFO0FBQUMsWUFBSUosS0FBRSxDQUFDLElBQUcsRUFBRSxFQUFFLFFBQVFJLEVBQUMsS0FBRyxJQUFFLElBQUUsSUFBR0gsS0FBRSxDQUFDLElBQUcsRUFBRSxFQUFFLFFBQVFHLEVBQUMsS0FBRyxJQUFFLE1BQUk7QUFBSSxRQUFBc0IsR0FBRXRCLEVBQUMsS0FBR3dCLEdBQUUzQixFQUFDLElBQUVEO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFDLFdBQU8wQjtBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUd0QixJQUFFSixJQUFFO0FBQUMsZUFBU0EsT0FBSUEsS0FBRSxDQUFDO0FBQUcsUUFBSUMsS0FBRUQsSUFBRUUsS0FBRUQsR0FBRSxXQUFVRSxLQUFFRixHQUFFLFVBQVNJLEtBQUVKLEdBQUUsY0FBYUssS0FBRUwsR0FBRSxTQUFRTSxLQUFFTixHQUFFLGdCQUFlTyxLQUFFUCxHQUFFLHVCQUFzQlEsS0FBRSxXQUFTRCxLQUFFLEtBQUdBLElBQUVFLEtBQUUsR0FBR1IsRUFBQyxHQUFFUyxLQUFFRCxLQUFFSCxLQUFFLEtBQUcsR0FBRyxPQUFRLFNBQVNILElBQUU7QUFBQyxhQUFPLEdBQUdBLEVBQUMsTUFBSU07QUFBQSxJQUFDLENBQUUsSUFBRSxJQUFHRSxLQUFFRCxHQUFFLE9BQVEsU0FBU1AsSUFBRTtBQUFDLGFBQU9LLEdBQUUsUUFBUUwsRUFBQyxLQUFHO0FBQUEsSUFBQyxDQUFFO0FBQUUsVUFBSVEsR0FBRSxXQUFTQSxLQUFFRDtBQUFHLFFBQUlFLEtBQUVELEdBQUUsT0FBUSxTQUFTWixJQUFFQyxJQUFFO0FBQUMsYUFBT0QsR0FBRUMsRUFBQyxJQUFFLEdBQUdHLElBQUUsRUFBQyxXQUFVSCxJQUFFLFVBQVNFLElBQUUsY0FBYUUsSUFBRSxTQUFRQyxHQUFDLENBQUMsRUFBRSxHQUFHTCxFQUFDLENBQUMsR0FBRUQ7QUFBQSxJQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQUUsV0FBTyxPQUFPLEtBQUthLEVBQUMsRUFBRSxLQUFNLFNBQVNULElBQUVKLElBQUU7QUFBQyxhQUFPYSxHQUFFVCxFQUFDLElBQUVTLEdBQUViLEVBQUM7QUFBQSxJQUFDLENBQUU7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLEVBQUMsTUFBSyxRQUFPLFNBQVEsTUFBRyxPQUFNLFFBQU8sSUFBRyxTQUFTSSxJQUFFO0FBQUMsUUFBSUosS0FBRUksR0FBRSxPQUFNSCxLQUFFRyxHQUFFLFNBQVFGLEtBQUVFLEdBQUU7QUFBSyxRQUFHLENBQUNKLEdBQUUsY0FBY0UsRUFBQyxFQUFFLE9BQU07QUFBQyxlQUFRQyxLQUFFRixHQUFFLFVBQVNJLEtBQUUsV0FBU0YsTUFBR0EsSUFBRUcsS0FBRUwsR0FBRSxTQUFRTSxLQUFFLFdBQVNELE1BQUdBLElBQUVFLEtBQUVQLEdBQUUsb0JBQW1CUSxLQUFFUixHQUFFLFNBQVFTLEtBQUVULEdBQUUsVUFBU1UsS0FBRVYsR0FBRSxjQUFhVyxLQUFFWCxHQUFFLGFBQVlZLEtBQUVaLEdBQUUsZ0JBQWVhLEtBQUUsV0FBU0QsTUFBR0EsSUFBRUUsS0FBRWQsR0FBRSx1QkFBc0JlLEtBQUVoQixHQUFFLFFBQVEsV0FBVWlCLEtBQUUsR0FBR0QsRUFBQyxHQUFFRSxLQUFFVixPQUFJUyxPQUFJRCxNQUFHRixLQUFFLFNBQVNWLElBQUU7QUFBQyxZQUFHLEdBQUdBLEVBQUMsTUFBSSxHQUFHLFFBQU0sQ0FBQztBQUFFLFlBQUlKLEtBQUUsR0FBR0ksRUFBQztBQUFFLGVBQU0sQ0FBQyxHQUFHQSxFQUFDLEdBQUVKLElBQUUsR0FBR0EsRUFBQyxDQUFDO0FBQUEsTUFBQyxFQUFFZ0IsRUFBQyxJQUFFLENBQUMsR0FBR0EsRUFBQyxDQUFDLElBQUdHLEtBQUUsQ0FBQ0gsRUFBQyxFQUFFLE9BQU9FLEVBQUMsRUFBRSxPQUFRLFNBQVNkLElBQUVILElBQUU7QUFBQyxlQUFPRyxHQUFFLE9BQU8sR0FBR0gsRUFBQyxNQUFJLEtBQUcsR0FBR0QsSUFBRSxFQUFDLFdBQVVDLElBQUUsVUFBU1MsSUFBRSxjQUFhQyxJQUFFLFNBQVFGLElBQUUsZ0JBQWVLLElBQUUsdUJBQXNCQyxHQUFDLENBQUMsSUFBRWQsRUFBQztBQUFBLE1BQUMsR0FBRyxDQUFDLENBQUMsR0FBRW1CLEtBQUVwQixHQUFFLE1BQU0sV0FBVXFCLEtBQUVyQixHQUFFLE1BQU0sUUFBT3NCLEtBQUUsb0JBQUksT0FBSUMsS0FBRSxNQUFHQyxLQUFFTCxHQUFFLENBQUMsR0FBRU0sS0FBRSxHQUFFQSxLQUFFTixHQUFFLFFBQU9NLE1BQUk7QUFBQyxZQUFJQyxLQUFFUCxHQUFFTSxFQUFDLEdBQUVFLEtBQUUsR0FBR0QsRUFBQyxHQUFFRSxLQUFFLEdBQUdGLEVBQUMsTUFBSSxJQUFHRyxLQUFFLENBQUMsSUFBRyxFQUFFLEVBQUUsUUFBUUYsRUFBQyxLQUFHLEdBQUVHLEtBQUVELEtBQUUsVUFBUSxVQUFTRSxLQUFFLEdBQUcvQixJQUFFLEVBQUMsV0FBVTBCLElBQUUsVUFBU2hCLElBQUUsY0FBYUMsSUFBRSxhQUFZQyxJQUFFLFNBQVFILEdBQUMsQ0FBQyxHQUFFdUIsS0FBRUgsS0FBRUQsS0FBRSxLQUFHLEtBQUdBLEtBQUUsS0FBRztBQUFHLFFBQUFSLEdBQUVVLEVBQUMsSUFBRVQsR0FBRVMsRUFBQyxNQUFJRSxLQUFFLEdBQUdBLEVBQUM7QUFBRyxZQUFJQyxLQUFFLEdBQUdELEVBQUMsR0FBRUUsS0FBRSxDQUFDO0FBQUUsWUFBRzdCLE1BQUc2QixHQUFFLEtBQUtILEdBQUVKLEVBQUMsS0FBRyxDQUFDLEdBQUVwQixNQUFHMkIsR0FBRSxLQUFLSCxHQUFFQyxFQUFDLEtBQUcsR0FBRUQsR0FBRUUsRUFBQyxLQUFHLENBQUMsR0FBRUMsR0FBRSxNQUFPLFNBQVM5QixJQUFFO0FBQUMsaUJBQU9BO0FBQUEsUUFBQyxDQUFFLEdBQUU7QUFBQyxVQUFBb0IsS0FBRUUsSUFBRUgsS0FBRTtBQUFHO0FBQUEsUUFBSztBQUFDLFFBQUFELEdBQUUsSUFBSUksSUFBRVEsRUFBQztBQUFBLE1BQUM7QUFBQyxVQUFHWCxHQUFFLFVBQVFZLEtBQUUsU0FBUy9CLElBQUU7QUFBQyxZQUFJSixLQUFFbUIsR0FBRSxLQUFNLFNBQVNuQixJQUFFO0FBQUMsY0FBSUMsS0FBRXFCLEdBQUUsSUFBSXRCLEVBQUM7QUFBRSxjQUFHQyxHQUFFLFFBQU9BLEdBQUUsTUFBTSxHQUFFRyxFQUFDLEVBQUUsTUFBTyxTQUFTQSxJQUFFO0FBQUMsbUJBQU9BO0FBQUEsVUFBQyxDQUFFO0FBQUEsUUFBQyxDQUFFO0FBQUUsWUFBR0osR0FBRSxRQUFPd0IsS0FBRXhCLElBQUU7QUFBQSxNQUFPLEdBQUVvQyxLQUFFdEIsS0FBRSxJQUFFLEdBQUVzQixLQUFFLEtBQUcsWUFBVUQsR0FBRUMsRUFBQyxHQUFFQSxLQUFJO0FBQUMsTUFBQXBDLEdBQUUsY0FBWXdCLE9BQUl4QixHQUFFLGNBQWNFLEVBQUMsRUFBRSxRQUFNLE1BQUdGLEdBQUUsWUFBVXdCLElBQUV4QixHQUFFLFFBQU07QUFBQSxJQUFHO0FBQUEsRUFBQyxHQUFFLGtCQUFpQixDQUFDLFFBQVEsR0FBRSxNQUFLLEVBQUMsT0FBTSxNQUFFLEVBQUM7QUFBRSxXQUFTLEdBQUdJLElBQUVKLElBQUVDLElBQUU7QUFBQyxXQUFPLFdBQVNBLE9BQUlBLEtBQUUsRUFBQyxHQUFFLEdBQUUsR0FBRSxFQUFDLElBQUcsRUFBQyxLQUFJRyxHQUFFLE1BQUlKLEdBQUUsU0FBT0MsR0FBRSxHQUFFLE9BQU1HLEdBQUUsUUFBTUosR0FBRSxRQUFNQyxHQUFFLEdBQUUsUUFBT0csR0FBRSxTQUFPSixHQUFFLFNBQU9DLEdBQUUsR0FBRSxNQUFLRyxHQUFFLE9BQUtKLEdBQUUsUUFBTUMsR0FBRSxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsR0FBR0csSUFBRTtBQUFDLFdBQU0sQ0FBQyxJQUFHLElBQUcsSUFBRyxFQUFFLEVBQUUsS0FBTSxTQUFTSixJQUFFO0FBQUMsYUFBT0ksR0FBRUosRUFBQyxLQUFHO0FBQUEsSUFBQyxDQUFFO0FBQUEsRUFBQztBQUFDLFFBQU0sS0FBRyxFQUFDLE1BQUssUUFBTyxTQUFRLE1BQUcsT0FBTSxRQUFPLGtCQUFpQixDQUFDLGlCQUFpQixHQUFFLElBQUcsU0FBU0ksSUFBRTtBQUFDLFFBQUlKLEtBQUVJLEdBQUUsT0FBTUgsS0FBRUcsR0FBRSxNQUFLRixLQUFFRixHQUFFLE1BQU0sV0FBVUcsS0FBRUgsR0FBRSxNQUFNLFFBQU9LLEtBQUVMLEdBQUUsY0FBYyxpQkFBZ0JNLEtBQUUsR0FBR04sSUFBRSxFQUFDLGdCQUFlLFlBQVcsQ0FBQyxHQUFFTyxLQUFFLEdBQUdQLElBQUUsRUFBQyxhQUFZLEtBQUUsQ0FBQyxHQUFFUSxLQUFFLEdBQUdGLElBQUVKLEVBQUMsR0FBRU8sS0FBRSxHQUFHRixJQUFFSixJQUFFRSxFQUFDLEdBQUVLLEtBQUUsR0FBR0YsRUFBQyxHQUFFRyxLQUFFLEdBQUdGLEVBQUM7QUFBRSxJQUFBVCxHQUFFLGNBQWNDLEVBQUMsSUFBRSxFQUFDLDBCQUF5Qk8sSUFBRSxxQkFBb0JDLElBQUUsbUJBQWtCQyxJQUFFLGtCQUFpQkMsR0FBQyxHQUFFWCxHQUFFLFdBQVcsU0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxHQUFFLFdBQVcsUUFBTyxFQUFDLGdDQUErQlUsSUFBRSx1QkFBc0JDLEdBQUMsQ0FBQztBQUFBLEVBQUMsRUFBQyxHQUFFLEtBQUcsRUFBQyxNQUFLLFVBQVMsU0FBUSxNQUFHLE9BQU0sUUFBTyxVQUFTLENBQUMsZUFBZSxHQUFFLElBQUcsU0FBU1AsSUFBRTtBQUFDLFFBQUlKLEtBQUVJLEdBQUUsT0FBTUgsS0FBRUcsR0FBRSxTQUFRRixLQUFFRSxHQUFFLE1BQUtELEtBQUVGLEdBQUUsUUFBT0ksS0FBRSxXQUFTRixLQUFFLENBQUMsR0FBRSxDQUFDLElBQUVBLElBQUVHLEtBQUUsR0FBRyxPQUFRLFNBQVNGLElBQUVILElBQUU7QUFBQyxhQUFPRyxHQUFFSCxFQUFDLElBQUUsU0FBU0csSUFBRUosSUFBRUMsSUFBRTtBQUFDLFlBQUlDLEtBQUUsR0FBR0UsRUFBQyxHQUFFRCxLQUFFLENBQUMsSUFBRyxFQUFFLEVBQUUsUUFBUUQsRUFBQyxLQUFHLElBQUUsS0FBRyxHQUFFRyxLQUFFLGNBQVksT0FBT0osS0FBRUEsR0FBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFRCxJQUFFLEVBQUMsV0FBVUksR0FBQyxDQUFDLENBQUMsSUFBRUgsSUFBRUssS0FBRUQsR0FBRSxDQUFDLEdBQUVFLEtBQUVGLEdBQUUsQ0FBQztBQUFFLGVBQU9DLEtBQUVBLE1BQUcsR0FBRUMsTUFBR0EsTUFBRyxLQUFHSixJQUFFLENBQUMsSUFBRyxFQUFFLEVBQUUsUUFBUUQsRUFBQyxLQUFHLElBQUUsRUFBQyxHQUFFSyxJQUFFLEdBQUVELEdBQUMsSUFBRSxFQUFDLEdBQUVBLElBQUUsR0FBRUMsR0FBQztBQUFBLE1BQUMsRUFBRU4sSUFBRUQsR0FBRSxPQUFNSyxFQUFDLEdBQUVEO0FBQUEsSUFBQyxHQUFHLENBQUMsQ0FBQyxHQUFFRyxLQUFFRCxHQUFFTixHQUFFLFNBQVMsR0FBRVEsS0FBRUQsR0FBRSxHQUFFRSxLQUFFRixHQUFFO0FBQUUsWUFBTVAsR0FBRSxjQUFjLGtCQUFnQkEsR0FBRSxjQUFjLGNBQWMsS0FBR1EsSUFBRVIsR0FBRSxjQUFjLGNBQWMsS0FBR1MsS0FBR1QsR0FBRSxjQUFjRSxFQUFDLElBQUVJO0FBQUEsRUFBQyxFQUFDLEdBQUUsS0FBRyxFQUFDLE1BQUssaUJBQWdCLFNBQVEsTUFBRyxPQUFNLFFBQU8sSUFBRyxTQUFTRixJQUFFO0FBQUMsUUFBSUosS0FBRUksR0FBRSxPQUFNSCxLQUFFRyxHQUFFO0FBQUssSUFBQUosR0FBRSxjQUFjQyxFQUFDLElBQUUsR0FBRyxFQUFDLFdBQVVELEdBQUUsTUFBTSxXQUFVLFNBQVFBLEdBQUUsTUFBTSxRQUFPLFdBQVVBLEdBQUUsVUFBUyxDQUFDO0FBQUEsRUFBQyxHQUFFLE1BQUssQ0FBQyxFQUFDLEdBQUUsS0FBRyxFQUFDLE1BQUssbUJBQWtCLFNBQVEsTUFBRyxPQUFNLFFBQU8sSUFBRyxTQUFTSSxJQUFFO0FBQUMsUUFBSUosS0FBRUksR0FBRSxPQUFNSCxLQUFFRyxHQUFFLFNBQVFGLEtBQUVFLEdBQUUsTUFBS0QsS0FBRUYsR0FBRSxVQUFTSSxLQUFFLFdBQVNGLE1BQUdBLElBQUVHLEtBQUVMLEdBQUUsU0FBUU0sS0FBRSxXQUFTRCxNQUFHQSxJQUFFRSxLQUFFUCxHQUFFLFVBQVNRLEtBQUVSLEdBQUUsY0FBYVMsS0FBRVQsR0FBRSxhQUFZVSxLQUFFVixHQUFFLFNBQVFXLEtBQUVYLEdBQUUsUUFBT1ksS0FBRSxXQUFTRCxNQUFHQSxJQUFFRSxLQUFFYixHQUFFLGNBQWFjLEtBQUUsV0FBU0QsS0FBRSxJQUFFQSxJQUFFRSxLQUFFLEdBQUdoQixJQUFFLEVBQUMsVUFBU1EsSUFBRSxjQUFhQyxJQUFFLFNBQVFFLElBQUUsYUFBWUQsR0FBQyxDQUFDLEdBQUVPLEtBQUUsR0FBR2pCLEdBQUUsU0FBUyxHQUFFa0IsS0FBRSxHQUFHbEIsR0FBRSxTQUFTLEdBQUVtQixLQUFFLENBQUNELElBQUVFLEtBQUUsR0FBR0gsRUFBQyxHQUFFSSxLQUFFLFFBQU1ELEtBQUUsTUFBSSxLQUFJRSxLQUFFdEIsR0FBRSxjQUFjLGVBQWN1QixLQUFFdkIsR0FBRSxNQUFNLFdBQVV3QixLQUFFeEIsR0FBRSxNQUFNLFFBQU95QixLQUFFLGNBQVksT0FBT1YsS0FBRUEsR0FBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFZixHQUFFLE9BQU0sRUFBQyxXQUFVQSxHQUFFLFVBQVMsQ0FBQyxDQUFDLElBQUVlLElBQUVXLEtBQUUsWUFBVSxPQUFPRCxLQUFFLEVBQUMsVUFBU0EsSUFBRSxTQUFRQSxHQUFDLElBQUUsT0FBTyxPQUFPLEVBQUMsVUFBUyxHQUFFLFNBQVEsRUFBQyxHQUFFQSxFQUFDLEdBQUVFLEtBQUUzQixHQUFFLGNBQWMsU0FBT0EsR0FBRSxjQUFjLE9BQU9BLEdBQUUsU0FBUyxJQUFFLE1BQUs0QixLQUFFLEVBQUMsR0FBRSxHQUFFLEdBQUUsRUFBQztBQUFFLFFBQUdOLElBQUU7QUFBQyxVQUFHakIsSUFBRTtBQUFDLFlBQUl3QixJQUFFQyxLQUFFLFFBQU1WLEtBQUUsS0FBRyxJQUFHVyxLQUFFLFFBQU1YLEtBQUUsS0FBRyxJQUFHWSxLQUFFLFFBQU1aLEtBQUUsV0FBUyxTQUFRYSxLQUFFWCxHQUFFRixFQUFDLEdBQUVjLEtBQUVELEtBQUVqQixHQUFFYyxFQUFDLEdBQUVLLEtBQUVGLEtBQUVqQixHQUFFZSxFQUFDLEdBQUVLLEtBQUV2QixLQUFFLENBQUNXLEdBQUVRLEVBQUMsSUFBRSxJQUFFLEdBQUVLLEtBQUVuQixPQUFJLEtBQUdLLEdBQUVTLEVBQUMsSUFBRVIsR0FBRVEsRUFBQyxHQUFFTSxLQUFFcEIsT0FBSSxLQUFHLENBQUNNLEdBQUVRLEVBQUMsSUFBRSxDQUFDVCxHQUFFUyxFQUFDLEdBQUVPLEtBQUV2QyxHQUFFLFNBQVMsT0FBTXdDLEtBQUUzQixNQUFHMEIsS0FBRSxHQUFHQSxFQUFDLElBQUUsRUFBQyxPQUFNLEdBQUUsUUFBTyxFQUFDLEdBQUVFLEtBQUV6QyxHQUFFLGNBQWMsa0JBQWtCLElBQUVBLEdBQUUsY0FBYyxrQkFBa0IsRUFBRSxVQUFRLEVBQUMsS0FBSSxHQUFFLE9BQU0sR0FBRSxRQUFPLEdBQUUsTUFBSyxFQUFDLEdBQUUwQyxLQUFFRCxHQUFFWCxFQUFDLEdBQUVhLEtBQUVGLEdBQUVWLEVBQUMsR0FBRWEsS0FBRSxHQUFHLEdBQUVyQixHQUFFUyxFQUFDLEdBQUVRLEdBQUVSLEVBQUMsQ0FBQyxHQUFFYSxLQUFFMUIsS0FBRUksR0FBRVMsRUFBQyxJQUFFLElBQUVJLEtBQUVRLEtBQUVGLEtBQUVoQixHQUFFLFdBQVNXLEtBQUVPLEtBQUVGLEtBQUVoQixHQUFFLFVBQVNvQixLQUFFM0IsS0FBRSxDQUFDSSxHQUFFUyxFQUFDLElBQUUsSUFBRUksS0FBRVEsS0FBRUQsS0FBRWpCLEdBQUUsV0FBU1ksS0FBRU0sS0FBRUQsS0FBRWpCLEdBQUUsVUFBU3FCLEtBQUUvQyxHQUFFLFNBQVMsU0FBTyxHQUFHQSxHQUFFLFNBQVMsS0FBSyxHQUFFZ0QsS0FBRUQsS0FBRSxRQUFNM0IsS0FBRTJCLEdBQUUsYUFBVyxJQUFFQSxHQUFFLGNBQVksSUFBRSxHQUFFRSxLQUFFLFNBQU9wQixLQUFFLFFBQU1GLEtBQUUsU0FBT0EsR0FBRVAsRUFBQyxLQUFHUyxLQUFFLEdBQUVxQixLQUFFakIsS0FBRWEsS0FBRUcsSUFBRUUsS0FBRSxHQUFHdEMsS0FBRSxHQUFHcUIsSUFBRUQsS0FBRVksS0FBRUksS0FBRUQsRUFBQyxJQUFFZCxJQUFFRCxJQUFFcEIsS0FBRSxHQUFHc0IsSUFBRWUsRUFBQyxJQUFFZixFQUFDO0FBQUUsUUFBQWIsR0FBRUYsRUFBQyxJQUFFK0IsSUFBRXZCLEdBQUVSLEVBQUMsSUFBRStCLEtBQUVsQjtBQUFBLE1BQUM7QUFBQyxVQUFHMUIsSUFBRTtBQUFDLFlBQUk2QyxJQUFFQyxLQUFFLFFBQU1qQyxLQUFFLEtBQUcsSUFBR2tDLE1BQUcsUUFBTWxDLEtBQUUsS0FBRyxJQUFHbUMsTUFBR2pDLEdBQUVELEVBQUMsR0FBRW1DLE1BQUcsUUFBTW5DLEtBQUUsV0FBUyxTQUFRb0MsTUFBR0YsTUFBR3ZDLEdBQUVxQyxFQUFDLEdBQUVLLE1BQUdILE1BQUd2QyxHQUFFc0MsR0FBRSxHQUFFSyxNQUFHLE9BQUssQ0FBQyxJQUFHLEVBQUUsRUFBRSxRQUFRMUMsRUFBQyxHQUFFMkMsTUFBRyxTQUFPUixLQUFFLFFBQU16QixLQUFFLFNBQU9BLEdBQUVOLEVBQUMsS0FBRytCLEtBQUUsR0FBRVMsTUFBR0YsTUFBR0YsTUFBR0YsTUFBR2hDLEdBQUVpQyxHQUFFLElBQUVoQyxHQUFFZ0MsR0FBRSxJQUFFSSxNQUFHbEMsR0FBRSxTQUFRb0MsTUFBR0gsTUFBR0osTUFBR2hDLEdBQUVpQyxHQUFFLElBQUVoQyxHQUFFZ0MsR0FBRSxJQUFFSSxNQUFHbEMsR0FBRSxVQUFRZ0MsS0FBR0ssTUFBR2xELE1BQUc4QyxNQUFHLFNBQVN2RCxJQUFFSixJQUFFQyxJQUFFO0FBQUMsY0FBSUMsS0FBRSxHQUFHRSxJQUFFSixJQUFFQyxFQUFDO0FBQUUsaUJBQU9DLEtBQUVELEtBQUVBLEtBQUVDO0FBQUEsUUFBQyxFQUFFMkQsS0FBR04sS0FBR08sR0FBRSxJQUFFLEdBQUdqRCxLQUFFZ0QsTUFBR0osS0FBR0YsS0FBRzFDLEtBQUVpRCxNQUFHSixHQUFFO0FBQUUsUUFBQXBDLEdBQUVELEVBQUMsSUFBRTBDLEtBQUduQyxHQUFFUCxFQUFDLElBQUUwQyxNQUFHUjtBQUFBLE1BQUU7QUFBQyxNQUFBdkQsR0FBRSxjQUFjRSxFQUFDLElBQUUwQjtBQUFBLElBQUM7QUFBQSxFQUFDLEdBQUUsa0JBQWlCLENBQUMsUUFBUSxFQUFDO0FBQUUsV0FBUyxHQUFHeEIsSUFBRUosSUFBRUMsSUFBRTtBQUFDLGVBQVNBLE9BQUlBLEtBQUU7QUFBSSxRQUFJQyxJQUFFQyxJQUFFRSxLQUFFLEdBQUdMLEVBQUMsR0FBRU0sS0FBRSxHQUFHTixFQUFDLEtBQUcsU0FBU0ksSUFBRTtBQUFDLFVBQUlKLEtBQUVJLEdBQUUsc0JBQXNCLEdBQUVILEtBQUUsR0FBR0QsR0FBRSxLQUFLLElBQUVJLEdBQUUsZUFBYSxHQUFFRixLQUFFLEdBQUdGLEdBQUUsTUFBTSxJQUFFSSxHQUFFLGdCQUFjO0FBQUUsYUFBTyxNQUFJSCxNQUFHLE1BQUlDO0FBQUEsSUFBQyxFQUFFRixFQUFDLEdBQUVPLEtBQUUsR0FBR1AsRUFBQyxHQUFFUSxLQUFFLEdBQUdKLElBQUVFLElBQUVMLEVBQUMsR0FBRVEsS0FBRSxFQUFDLFlBQVcsR0FBRSxXQUFVLEVBQUMsR0FBRUMsS0FBRSxFQUFDLEdBQUUsR0FBRSxHQUFFLEVBQUM7QUFBRSxZQUFPTCxNQUFHLENBQUNBLE1BQUcsQ0FBQ0osU0FBTSxXQUFTLEdBQUdELEVBQUMsS0FBRyxHQUFHTyxFQUFDLE9BQUtFLE1BQUdQLEtBQUVGLFFBQUssR0FBR0UsRUFBQyxLQUFHLEdBQUdBLEVBQUMsSUFBRSxFQUFDLGFBQVlDLEtBQUVELElBQUcsWUFBVyxXQUFVQyxHQUFFLFVBQVMsSUFBRSxHQUFHRCxFQUFDLElBQUcsR0FBR0YsRUFBQyxNQUFJVSxLQUFFLEdBQUdWLElBQUUsSUFBRSxHQUFHLEtBQUdBLEdBQUUsWUFBV1UsR0FBRSxLQUFHVixHQUFFLGFBQVdPLE9BQUlHLEdBQUUsSUFBRSxHQUFHSCxFQUFDLEtBQUksRUFBQyxHQUFFQyxHQUFFLE9BQUtDLEdBQUUsYUFBV0MsR0FBRSxHQUFFLEdBQUVGLEdBQUUsTUFBSUMsR0FBRSxZQUFVQyxHQUFFLEdBQUUsT0FBTUYsR0FBRSxPQUFNLFFBQU9BLEdBQUUsT0FBTTtBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdKLElBQUU7QUFBQyxRQUFJSixLQUFFLG9CQUFJLE9BQUlDLEtBQUUsb0JBQUksT0FBSUMsS0FBRSxDQUFDO0FBQUUsYUFBU0MsR0FBRUMsSUFBRTtBQUFDLE1BQUFILEdBQUUsSUFBSUcsR0FBRSxJQUFJLEdBQUUsQ0FBQyxFQUFFLE9BQU9BLEdBQUUsWUFBVSxDQUFDLEdBQUVBLEdBQUUsb0JBQWtCLENBQUMsQ0FBQyxFQUFFLFFBQVMsU0FBU0EsSUFBRTtBQUFDLFlBQUcsQ0FBQ0gsR0FBRSxJQUFJRyxFQUFDLEdBQUU7QUFBQyxjQUFJRixLQUFFRixHQUFFLElBQUlJLEVBQUM7QUFBRSxVQUFBRixNQUFHQyxHQUFFRCxFQUFDO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBRSxHQUFFQSxHQUFFLEtBQUtFLEVBQUM7QUFBQSxJQUFDO0FBQUMsV0FBT0EsR0FBRSxRQUFTLFNBQVNBLElBQUU7QUFBQyxNQUFBSixHQUFFLElBQUlJLEdBQUUsTUFBS0EsRUFBQztBQUFBLElBQUMsQ0FBRSxHQUFFQSxHQUFFLFFBQVMsU0FBU0EsSUFBRTtBQUFDLE1BQUFILEdBQUUsSUFBSUcsR0FBRSxJQUFJLEtBQUdELEdBQUVDLEVBQUM7QUFBQSxJQUFDLENBQUUsR0FBRUY7QUFBQSxFQUFDO0FBQUMsTUFBSSxLQUFHLEVBQUMsV0FBVSxVQUFTLFdBQVUsQ0FBQyxHQUFFLFVBQVMsV0FBVTtBQUFFLFdBQVMsS0FBSTtBQUFDLGFBQVFFLEtBQUUsVUFBVSxRQUFPSixLQUFFLElBQUksTUFBTUksRUFBQyxHQUFFSCxLQUFFLEdBQUVBLEtBQUVHLElBQUVILEtBQUksQ0FBQUQsR0FBRUMsRUFBQyxJQUFFLFVBQVVBLEVBQUM7QUFBRSxXQUFNLENBQUNELEdBQUUsS0FBTSxTQUFTSSxJQUFFO0FBQUMsYUFBTSxFQUFFQSxNQUFHLGNBQVksT0FBT0EsR0FBRTtBQUFBLElBQXNCLENBQUU7QUFBQSxFQUFDO0FBQUMsV0FBUyxHQUFHQSxJQUFFO0FBQUMsZUFBU0EsT0FBSUEsS0FBRSxDQUFDO0FBQUcsUUFBSUosS0FBRUksSUFBRUgsS0FBRUQsR0FBRSxrQkFBaUJFLEtBQUUsV0FBU0QsS0FBRSxDQUFDLElBQUVBLElBQUVFLEtBQUVILEdBQUUsZ0JBQWVLLEtBQUUsV0FBU0YsS0FBRSxLQUFHQTtBQUFFLFdBQU8sU0FBU0MsSUFBRUosSUFBRUMsSUFBRTtBQUFDLGlCQUFTQSxPQUFJQSxLQUFFSTtBQUFHLFVBQUlGLElBQUVHLElBQUVDLEtBQUUsRUFBQyxXQUFVLFVBQVMsa0JBQWlCLENBQUMsR0FBRSxTQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUUsSUFBR0YsRUFBQyxHQUFFLGVBQWMsQ0FBQyxHQUFFLFVBQVMsRUFBQyxXQUFVRCxJQUFFLFFBQU9KLEdBQUMsR0FBRSxZQUFXLENBQUMsR0FBRSxRQUFPLENBQUMsRUFBQyxHQUFFUSxLQUFFLENBQUMsR0FBRUMsS0FBRSxPQUFHQyxLQUFFLEVBQUMsT0FBTUgsSUFBRSxZQUFXLFNBQVNOLElBQUU7QUFBQyxZQUFJRSxLQUFFLGNBQVksT0FBT0YsS0FBRUEsR0FBRU0sR0FBRSxPQUFPLElBQUVOO0FBQUUsUUFBQVUsR0FBRSxHQUFFSixHQUFFLFVBQVEsT0FBTyxPQUFPLENBQUMsR0FBRUYsSUFBRUUsR0FBRSxTQUFRSixFQUFDLEdBQUVJLEdBQUUsZ0JBQWMsRUFBQyxXQUFVLEdBQUdILEVBQUMsSUFBRSxHQUFHQSxFQUFDLElBQUVBLEdBQUUsaUJBQWUsR0FBR0EsR0FBRSxjQUFjLElBQUUsQ0FBQyxHQUFFLFFBQU8sR0FBR0osRUFBQyxFQUFDO0FBQUUsWUFBSU0sSUFBRUcsSUFBRUcsS0FBRSxTQUFTUixJQUFFO0FBQUMsY0FBSUosS0FBRSxHQUFHSSxFQUFDO0FBQUUsaUJBQU8sR0FBRyxPQUFRLFNBQVNBLElBQUVILElBQUU7QUFBQyxtQkFBT0csR0FBRSxPQUFPSixHQUFFLE9BQVEsU0FBU0ksSUFBRTtBQUFDLHFCQUFPQSxHQUFFLFVBQVFIO0FBQUEsWUFBQyxDQUFFLENBQUM7QUFBQSxVQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQUEsUUFBQyxHQUFHSyxLQUFFLENBQUMsRUFBRSxPQUFPSixJQUFFSyxHQUFFLFFBQVEsU0FBUyxHQUFFRSxLQUFFSCxHQUFFLE9BQVEsU0FBU0YsSUFBRUosSUFBRTtBQUFDLGNBQUlDLEtBQUVHLEdBQUVKLEdBQUUsSUFBSTtBQUFFLGlCQUFPSSxHQUFFSixHQUFFLElBQUksSUFBRUMsS0FBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxJQUFFRCxJQUFFLEVBQUMsU0FBUSxPQUFPLE9BQU8sQ0FBQyxHQUFFQyxHQUFFLFNBQVFELEdBQUUsT0FBTyxHQUFFLE1BQUssT0FBTyxPQUFPLENBQUMsR0FBRUMsR0FBRSxNQUFLRCxHQUFFLElBQUksRUFBQyxDQUFDLElBQUVBLElBQUVJO0FBQUEsUUFBQyxHQUFHLENBQUMsQ0FBQyxHQUFFLE9BQU8sS0FBS0ssRUFBQyxFQUFFLElBQUssU0FBU0wsSUFBRTtBQUFDLGlCQUFPSyxHQUFFTCxFQUFDO0FBQUEsUUFBQyxDQUFFLEVBQUU7QUFBRSxlQUFPRyxHQUFFLG1CQUFpQkssR0FBRSxPQUFRLFNBQVNSLElBQUU7QUFBQyxpQkFBT0EsR0FBRTtBQUFBLFFBQU8sQ0FBRSxHQUFFRyxHQUFFLGlCQUFpQixRQUFTLFNBQVNILElBQUU7QUFBQyxjQUFJSixLQUFFSSxHQUFFLE1BQUtILEtBQUVHLEdBQUUsU0FBUUYsS0FBRSxXQUFTRCxLQUFFLENBQUMsSUFBRUEsSUFBRUUsS0FBRUMsR0FBRTtBQUFPLGNBQUcsY0FBWSxPQUFPRCxJQUFFO0FBQUMsZ0JBQUlFLEtBQUVGLEdBQUUsRUFBQyxPQUFNSSxJQUFFLE1BQUtQLElBQUUsVUFBU1UsSUFBRSxTQUFRUixHQUFDLENBQUM7QUFBRSxZQUFBTSxHQUFFLEtBQUtILE1BQUcsV0FBVTtBQUFBLFlBQUMsQ0FBQztBQUFBLFVBQUM7QUFBQSxRQUFDLENBQUUsR0FBRUssR0FBRSxPQUFPO0FBQUEsTUFBQyxHQUFFLGFBQVksV0FBVTtBQUFDLFlBQUcsQ0FBQ0QsSUFBRTtBQUFDLGNBQUlMLEtBQUVHLEdBQUUsVUFBU1AsS0FBRUksR0FBRSxXQUFVSCxLQUFFRyxHQUFFO0FBQU8sY0FBRyxHQUFHSixJQUFFQyxFQUFDLEdBQUU7QUFBQyxZQUFBTSxHQUFFLFFBQU0sRUFBQyxXQUFVLEdBQUdQLElBQUUsR0FBR0MsRUFBQyxHQUFFLFlBQVVNLEdBQUUsUUFBUSxRQUFRLEdBQUUsUUFBTyxHQUFHTixFQUFDLEVBQUMsR0FBRU0sR0FBRSxRQUFNLE9BQUdBLEdBQUUsWUFBVUEsR0FBRSxRQUFRLFdBQVVBLEdBQUUsaUJBQWlCLFFBQVMsU0FBU0gsSUFBRTtBQUFDLHFCQUFPRyxHQUFFLGNBQWNILEdBQUUsSUFBSSxJQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUVBLEdBQUUsSUFBSTtBQUFBLFlBQUMsQ0FBRTtBQUFFLHFCQUFRRixLQUFFLEdBQUVBLEtBQUVLLEdBQUUsaUJBQWlCLFFBQU9MLEtBQUksS0FBRyxTQUFLSyxHQUFFLE9BQU07QUFBQyxrQkFBSUosS0FBRUksR0FBRSxpQkFBaUJMLEVBQUMsR0FBRUcsS0FBRUYsR0FBRSxJQUFHRyxLQUFFSCxHQUFFLFNBQVFLLEtBQUUsV0FBU0YsS0FBRSxDQUFDLElBQUVBLElBQUVLLEtBQUVSLEdBQUU7QUFBSyw0QkFBWSxPQUFPRSxPQUFJRSxLQUFFRixHQUFFLEVBQUMsT0FBTUUsSUFBRSxTQUFRQyxJQUFFLE1BQUtHLElBQUUsVUFBU0QsR0FBQyxDQUFDLEtBQUdIO0FBQUEsWUFBRSxNQUFNLENBQUFBLEdBQUUsUUFBTSxPQUFHTCxLQUFFO0FBQUEsVUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDLEdBQUUsU0FBUUMsS0FBRSxXQUFVO0FBQUMsZUFBTyxJQUFJLFFBQVMsU0FBU0MsSUFBRTtBQUFDLFVBQUFNLEdBQUUsWUFBWSxHQUFFTixHQUFFRyxFQUFDO0FBQUEsUUFBQyxDQUFFO0FBQUEsTUFBQyxHQUFFLFdBQVU7QUFBQyxlQUFPRCxPQUFJQSxLQUFFLElBQUksUUFBUyxTQUFTRixJQUFFO0FBQUMsa0JBQVEsUUFBUSxFQUFFLEtBQU0sV0FBVTtBQUFDLFlBQUFFLEtBQUUsUUFBT0YsR0FBRUQsR0FBRSxDQUFDO0FBQUEsVUFBQyxDQUFFO0FBQUEsUUFBQyxDQUFFLElBQUdHO0FBQUEsTUFBQyxJQUFHLFNBQVEsV0FBVTtBQUFDLFFBQUFLLEdBQUUsR0FBRUYsS0FBRTtBQUFBLE1BQUUsRUFBQztBQUFFLFVBQUcsQ0FBQyxHQUFHTCxJQUFFSixFQUFDLEVBQUUsUUFBT1U7QUFBRSxlQUFTQyxLQUFHO0FBQUMsUUFBQUgsR0FBRSxRQUFTLFNBQVNKLElBQUU7QUFBQyxpQkFBT0EsR0FBRTtBQUFBLFFBQUMsQ0FBRSxHQUFFSSxLQUFFLENBQUM7QUFBQSxNQUFDO0FBQUMsYUFBT0UsR0FBRSxXQUFXVCxFQUFDLEVBQUUsS0FBTSxTQUFTRyxJQUFFO0FBQUMsU0FBQ0ssTUFBR1IsR0FBRSxpQkFBZUEsR0FBRSxjQUFjRyxFQUFDO0FBQUEsTUFBQyxDQUFFLEdBQUVNO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxNQUFJLEtBQUcsR0FBRyxHQUFFLEtBQUcsR0FBRyxFQUFDLGtCQUFpQixDQUFDLElBQUcsSUFBRyxJQUFHLEVBQUUsRUFBQyxDQUFDLEdBQUUsS0FBRyxHQUFHLEVBQUMsa0JBQWlCLENBQUMsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLEVBQUUsRUFBQyxDQUFDO0FBQUUsUUFBTSxLQUFHLE9BQU8sT0FBTyxPQUFPLGVBQWUsRUFBQyxXQUFVLE1BQUssV0FBVSxJQUFHLFdBQVUsSUFBRyxZQUFXLElBQUcsYUFBWSxJQUFHLE9BQU0sSUFBRyxNQUFLLElBQUcsZ0JBQWUsSUFBRyxZQUFXLElBQUcsWUFBVyxJQUFHLGFBQVksSUFBRyxRQUFPLElBQUcsaUJBQWdCLElBQUcsZUFBYyxJQUFHLGNBQWEsSUFBRyxrQkFBaUIsSUFBRyxrQkFBaUIsSUFBRyxnQkFBZSxJQUFHLEtBQUksSUFBRyxnQkFBZSxJQUFHLE1BQUssSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLE1BQUssSUFBRyxnQkFBZSxJQUFHLFFBQU8sSUFBRyxZQUFXLElBQUcsUUFBTyxJQUFHLGlCQUFnQixJQUFHLGVBQWMsSUFBRyxpQkFBZ0IsSUFBRyxNQUFLLElBQUcsV0FBVSxJQUFHLE9BQU0sSUFBRyxPQUFNLElBQUcsS0FBSSxJQUFHLHFCQUFvQixJQUFHLFVBQVMsSUFBRyxPQUFNLEdBQUUsR0FBRSxPQUFPLGFBQVksRUFBQyxPQUFNLFNBQVEsQ0FBQyxDQUFDLEdBQUUsS0FBRyxZQUFXLEtBQUcsZ0JBQWUsS0FBRyxhQUFZLEtBQUcsV0FBVSxLQUFHLGFBQVksS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLFFBQU8sS0FBRyw2REFBNEQsS0FBRyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUcsS0FBRyxrQkFBaUIsS0FBRyxFQUFFLElBQUUsWUFBVSxhQUFZLEtBQUcsRUFBRSxJQUFFLGNBQVksV0FBVSxLQUFHLEVBQUUsSUFBRSxlQUFhLGdCQUFlLEtBQUcsRUFBRSxJQUFFLGlCQUFlLGNBQWEsS0FBRyxFQUFFLElBQUUsZUFBYSxlQUFjLEtBQUcsRUFBRSxJQUFFLGdCQUFjLGNBQWEsS0FBRyxFQUFDLFdBQVUsTUFBRyxVQUFTLG1CQUFrQixTQUFRLFdBQVUsUUFBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFLGNBQWEsTUFBSyxXQUFVLFNBQVEsR0FBRSxLQUFHLEVBQUMsV0FBVSxvQkFBbUIsVUFBUyxvQkFBbUIsU0FBUSxVQUFTLFFBQU8sMkJBQTBCLGNBQWEsMEJBQXlCLFdBQVUsMEJBQXlCO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWU4sSUFBRUosSUFBRTtBQUFDLFlBQU1JLElBQUVKLEVBQUMsR0FBRSxLQUFLLFVBQVEsTUFBSyxLQUFLLFVBQVEsS0FBSyxTQUFTLFlBQVcsS0FBSyxRQUFNLEVBQUUsS0FBSyxLQUFLLFVBQVMsRUFBRSxFQUFFLENBQUMsS0FBRyxFQUFFLEtBQUssS0FBSyxVQUFTLEVBQUUsRUFBRSxDQUFDLEtBQUcsRUFBRSxRQUFRLElBQUcsS0FBSyxPQUFPLEdBQUUsS0FBSyxZQUFVLEtBQUssY0FBYztBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFNBQVE7QUFBQyxhQUFPLEtBQUssU0FBUyxJQUFFLEtBQUssS0FBSyxJQUFFLEtBQUssS0FBSztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxVQUFHLEVBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxTQUFTLEVBQUU7QUFBTyxZQUFNSSxLQUFFLEVBQUMsZUFBYyxLQUFLLFNBQVE7QUFBRSxVQUFHLENBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHQSxFQUFDLEVBQUUsa0JBQWlCO0FBQUMsWUFBRyxLQUFLLGNBQWMsR0FBRSxrQkFBaUIsU0FBUyxtQkFBaUIsQ0FBQyxLQUFLLFFBQVEsUUFBUSxhQUFhLEVBQUUsWUFBVUEsTUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLFNBQVMsS0FBSyxRQUFRLEVBQUUsR0FBRSxHQUFHQSxJQUFFLGFBQVksQ0FBQztBQUFFLGFBQUssU0FBUyxNQUFNLEdBQUUsS0FBSyxTQUFTLGFBQWEsaUJBQWdCLElBQUUsR0FBRSxLQUFLLE1BQU0sVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUdBLEVBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTTtBQUFDLFVBQUcsRUFBRSxLQUFLLFFBQVEsS0FBRyxDQUFDLEtBQUssU0FBUyxFQUFFO0FBQU8sWUFBTUEsS0FBRSxFQUFDLGVBQWMsS0FBSyxTQUFRO0FBQUUsV0FBSyxjQUFjQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssV0FBUyxLQUFLLFFBQVEsUUFBUSxHQUFFLE1BQU0sUUFBUTtBQUFBLElBQUM7QUFBQSxJQUFDLFNBQVE7QUFBQyxXQUFLLFlBQVUsS0FBSyxjQUFjLEdBQUUsS0FBSyxXQUFTLEtBQUssUUFBUSxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBY0EsSUFBRTtBQUFDLFVBQUcsQ0FBQyxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUdBLEVBQUMsRUFBRSxrQkFBaUI7QUFBQyxZQUFHLGtCQUFpQixTQUFTLGdCQUFnQixZQUFVQSxNQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsU0FBUyxLQUFLLFFBQVEsRUFBRSxHQUFFLElBQUlBLElBQUUsYUFBWSxDQUFDO0FBQUUsYUFBSyxXQUFTLEtBQUssUUFBUSxRQUFRLEdBQUUsS0FBSyxNQUFNLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLGFBQWEsaUJBQWdCLE9BQU8sR0FBRSxFQUFFLG9CQUFvQixLQUFLLE9BQU0sUUFBUSxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBR0EsRUFBQztBQUFBLE1BQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXQSxJQUFFO0FBQUMsVUFBRyxZQUFVLFFBQU9BLEtBQUUsTUFBTSxXQUFXQSxFQUFDLEdBQUcsYUFBVyxDQUFDLEVBQUVBLEdBQUUsU0FBUyxLQUFHLGNBQVksT0FBT0EsR0FBRSxVQUFVLHNCQUFzQixPQUFNLElBQUksVUFBVSxHQUFHLEdBQUcsWUFBWSxDQUFDLGdHQUFnRztBQUFFLGFBQU9BO0FBQUEsSUFBQztBQUFBLElBQUMsZ0JBQWU7QUFBQyxVQUFHLFdBQVMsR0FBRyxPQUFNLElBQUksVUFBVSx1RUFBdUU7QUFBRSxVQUFJQSxLQUFFLEtBQUs7QUFBUyxtQkFBVyxLQUFLLFFBQVEsWUFBVUEsS0FBRSxLQUFLLFVBQVEsRUFBRSxLQUFLLFFBQVEsU0FBUyxJQUFFQSxLQUFFLEVBQUUsS0FBSyxRQUFRLFNBQVMsSUFBRSxZQUFVLE9BQU8sS0FBSyxRQUFRLGNBQVlBLEtBQUUsS0FBSyxRQUFRO0FBQVcsWUFBTUosS0FBRSxLQUFLLGlCQUFpQjtBQUFFLFdBQUssVUFBUSxHQUFHSSxJQUFFLEtBQUssT0FBTUosRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVU7QUFBQyxhQUFPLEtBQUssTUFBTSxVQUFVLFNBQVMsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsWUFBTUksS0FBRSxLQUFLO0FBQVEsVUFBR0EsR0FBRSxVQUFVLFNBQVMsU0FBUyxFQUFFLFFBQU87QUFBRyxVQUFHQSxHQUFFLFVBQVUsU0FBUyxXQUFXLEVBQUUsUUFBTztBQUFHLFVBQUdBLEdBQUUsVUFBVSxTQUFTLGVBQWUsRUFBRSxRQUFNO0FBQU0sVUFBR0EsR0FBRSxVQUFVLFNBQVMsaUJBQWlCLEVBQUUsUUFBTTtBQUFTLFlBQU1KLEtBQUUsVUFBUSxpQkFBaUIsS0FBSyxLQUFLLEVBQUUsaUJBQWlCLGVBQWUsRUFBRSxLQUFLO0FBQUUsYUFBT0ksR0FBRSxVQUFVLFNBQVMsUUFBUSxJQUFFSixLQUFFLEtBQUcsS0FBR0EsS0FBRSxLQUFHO0FBQUEsSUFBRTtBQUFBLElBQUMsZ0JBQWU7QUFBQyxhQUFPLFNBQU8sS0FBSyxTQUFTLFFBQVEsU0FBUztBQUFBLElBQUM7QUFBQSxJQUFDLGFBQVk7QUFBQyxZQUFLLEVBQUMsUUFBT0ksR0FBQyxJQUFFLEtBQUs7QUFBUSxhQUFNLFlBQVUsT0FBT0EsS0FBRUEsR0FBRSxNQUFNLEdBQUcsRUFBRSxJQUFLLENBQUFBLE9BQUcsT0FBTyxTQUFTQSxJQUFFLEVBQUUsQ0FBRSxJQUFFLGNBQVksT0FBT0EsS0FBRSxDQUFBSixPQUFHSSxHQUFFSixJQUFFLEtBQUssUUFBUSxJQUFFSTtBQUFBLElBQUM7QUFBQSxJQUFDLG1CQUFrQjtBQUFDLFlBQU1BLEtBQUUsRUFBQyxXQUFVLEtBQUssY0FBYyxHQUFFLFdBQVUsQ0FBQyxFQUFDLE1BQUssbUJBQWtCLFNBQVEsRUFBQyxVQUFTLEtBQUssUUFBUSxTQUFRLEVBQUMsR0FBRSxFQUFDLE1BQUssVUFBUyxTQUFRLEVBQUMsUUFBTyxLQUFLLFdBQVcsRUFBQyxFQUFDLENBQUMsRUFBQztBQUFFLGNBQU8sS0FBSyxhQUFXLGFBQVcsS0FBSyxRQUFRLGFBQVcsRUFBRSxpQkFBaUIsS0FBSyxPQUFNLFVBQVMsUUFBUSxHQUFFQSxHQUFFLFlBQVUsQ0FBQyxFQUFDLE1BQUssZUFBYyxTQUFRLE1BQUUsQ0FBQyxJQUFHLEVBQUMsR0FBR0EsSUFBRSxHQUFHLEVBQUUsS0FBSyxRQUFRLGNBQWEsQ0FBQyxRQUFPQSxFQUFDLENBQUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFnQixFQUFDLEtBQUlBLElBQUUsUUFBT0osR0FBQyxHQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLEtBQUssK0RBQThELEtBQUssS0FBSyxFQUFFLE9BQVEsQ0FBQUcsT0FBRyxFQUFFQSxFQUFDLENBQUU7QUFBRSxNQUFBSCxHQUFFLFVBQVEsRUFBRUEsSUFBRUQsSUFBRUksT0FBSSxJQUFHLENBQUNILEdBQUUsU0FBU0QsRUFBQyxDQUFDLEVBQUUsTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCSSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQU0sV0FBVTtBQUFDLGNBQU1KLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0ksRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTSixHQUFFSSxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBSixHQUFFSSxFQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxXQUFXQSxJQUFFO0FBQUMsVUFBRyxNQUFJQSxHQUFFLFVBQVEsWUFBVUEsR0FBRSxRQUFNLFVBQVFBLEdBQUUsSUFBSTtBQUFPLFlBQU1KLEtBQUUsRUFBRSxLQUFLLEVBQUU7QUFBRSxpQkFBVUMsTUFBS0QsSUFBRTtBQUFDLGNBQU1BLEtBQUUsR0FBRyxZQUFZQyxFQUFDO0FBQUUsWUFBRyxDQUFDRCxNQUFHLFVBQUtBLEdBQUUsUUFBUSxVQUFVO0FBQVMsY0FBTUUsS0FBRUUsR0FBRSxhQUFhLEdBQUVELEtBQUVELEdBQUUsU0FBU0YsR0FBRSxLQUFLO0FBQUUsWUFBR0UsR0FBRSxTQUFTRixHQUFFLFFBQVEsS0FBRyxhQUFXQSxHQUFFLFFBQVEsYUFBVyxDQUFDRyxNQUFHLGNBQVlILEdBQUUsUUFBUSxhQUFXRyxHQUFFO0FBQVMsWUFBR0gsR0FBRSxNQUFNLFNBQVNJLEdBQUUsTUFBTSxNQUFJLFlBQVVBLEdBQUUsUUFBTSxVQUFRQSxHQUFFLE9BQUsscUNBQXFDLEtBQUtBLEdBQUUsT0FBTyxPQUFPLEdBQUc7QUFBUyxjQUFNQyxLQUFFLEVBQUMsZUFBY0wsR0FBRSxTQUFRO0FBQUUsb0JBQVVJLEdBQUUsU0FBT0MsR0FBRSxhQUFXRCxLQUFHSixHQUFFLGNBQWNLLEVBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxzQkFBc0JELElBQUU7QUFBQyxZQUFNSixLQUFFLGtCQUFrQixLQUFLSSxHQUFFLE9BQU8sT0FBTyxHQUFFSCxLQUFFLGFBQVdHLEdBQUUsS0FBSUYsS0FBRSxDQUFDLElBQUcsRUFBRSxFQUFFLFNBQVNFLEdBQUUsR0FBRztBQUFFLFVBQUcsQ0FBQ0YsTUFBRyxDQUFDRCxHQUFFO0FBQU8sVUFBR0QsTUFBRyxDQUFDQyxHQUFFO0FBQU8sTUFBQUcsR0FBRSxlQUFlO0FBQUUsWUFBTUQsS0FBRSxLQUFLLFFBQVEsRUFBRSxJQUFFLE9BQUssRUFBRSxLQUFLLE1BQUssRUFBRSxFQUFFLENBQUMsS0FBRyxFQUFFLEtBQUssTUFBSyxFQUFFLEVBQUUsQ0FBQyxLQUFHLEVBQUUsUUFBUSxJQUFHQyxHQUFFLGVBQWUsVUFBVSxHQUFFQyxLQUFFLEdBQUcsb0JBQW9CRixFQUFDO0FBQUUsVUFBR0QsR0FBRSxRQUFPRSxHQUFFLGdCQUFnQixHQUFFQyxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGdCQUFnQkQsRUFBQztBQUFFLE1BQUFDLEdBQUUsU0FBUyxNQUFJRCxHQUFFLGdCQUFnQixHQUFFQyxHQUFFLEtBQUssR0FBRUYsR0FBRSxNQUFNO0FBQUEsSUFBRTtBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLElBQUcsR0FBRyxxQkFBcUIsR0FBRSxFQUFFLEdBQUcsVUFBUyxJQUFHLElBQUcsR0FBRyxxQkFBcUIsR0FBRSxFQUFFLEdBQUcsVUFBUyxJQUFHLEdBQUcsVUFBVSxHQUFFLEVBQUUsR0FBRyxVQUFTLElBQUcsR0FBRyxVQUFVLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFJLFNBQVNDLElBQUU7QUFBQyxJQUFBQSxHQUFFLGVBQWUsR0FBRSxHQUFHLG9CQUFvQixJQUFJLEVBQUUsT0FBTztBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxZQUFXLEtBQUcsUUFBTyxLQUFHLGdCQUFnQixFQUFFLElBQUcsS0FBRyxFQUFDLFdBQVUsa0JBQWlCLGVBQWMsTUFBSyxZQUFXLE9BQUcsV0FBVSxNQUFHLGFBQVksT0FBTSxHQUFFLEtBQUcsRUFBQyxXQUFVLFVBQVMsZUFBYyxtQkFBa0IsWUFBVyxXQUFVLFdBQVUsV0FBVSxhQUFZLG1CQUFrQjtBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUU7QUFBQyxZQUFNLEdBQUUsS0FBSyxVQUFRLEtBQUssV0FBV0EsRUFBQyxHQUFFLEtBQUssY0FBWSxPQUFHLEtBQUssV0FBUztBQUFBLElBQUk7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLEtBQUtBLElBQUU7QUFBQyxVQUFHLENBQUMsS0FBSyxRQUFRLFVBQVUsUUFBTyxLQUFLLEVBQUVBLEVBQUM7QUFBRSxXQUFLLFFBQVE7QUFBRSxZQUFNSixLQUFFLEtBQUssWUFBWTtBQUFFLFdBQUssUUFBUSxjQUFZLEVBQUVBLEVBQUMsR0FBRUEsR0FBRSxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssa0JBQW1CLE1BQUk7QUFBQyxVQUFFSSxFQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsS0FBS0EsSUFBRTtBQUFDLFdBQUssUUFBUSxhQUFXLEtBQUssWUFBWSxFQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxrQkFBbUIsTUFBSTtBQUFDLGFBQUssUUFBUSxHQUFFLEVBQUVBLEVBQUM7QUFBQSxNQUFDLENBQUUsS0FBRyxFQUFFQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssZ0JBQWMsRUFBRSxJQUFJLEtBQUssVUFBUyxFQUFFLEdBQUUsS0FBSyxTQUFTLE9BQU8sR0FBRSxLQUFLLGNBQVk7QUFBQSxJQUFHO0FBQUEsSUFBQyxjQUFhO0FBQUMsVUFBRyxDQUFDLEtBQUssVUFBUztBQUFDLGNBQU1BLEtBQUUsU0FBUyxjQUFjLEtBQUs7QUFBRSxRQUFBQSxHQUFFLFlBQVUsS0FBSyxRQUFRLFdBQVUsS0FBSyxRQUFRLGNBQVlBLEdBQUUsVUFBVSxJQUFJLE1BQU0sR0FBRSxLQUFLLFdBQVNBO0FBQUEsTUFBQztBQUFDLGFBQU8sS0FBSztBQUFBLElBQVE7QUFBQSxJQUFDLGtCQUFrQkEsSUFBRTtBQUFDLGFBQU9BLEdBQUUsY0FBWSxFQUFFQSxHQUFFLFdBQVcsR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxVQUFTO0FBQUMsVUFBRyxLQUFLLFlBQVk7QUFBTyxZQUFNQSxLQUFFLEtBQUssWUFBWTtBQUFFLFdBQUssUUFBUSxZQUFZLE9BQU9BLEVBQUMsR0FBRSxFQUFFLEdBQUdBLElBQUUsSUFBSSxNQUFJO0FBQUMsVUFBRSxLQUFLLFFBQVEsYUFBYTtBQUFBLE1BQUMsQ0FBRSxHQUFFLEtBQUssY0FBWTtBQUFBLElBQUU7QUFBQSxJQUFDLGtCQUFrQkEsSUFBRTtBQUFDLFFBQUVBLElBQUUsS0FBSyxZQUFZLEdBQUUsS0FBSyxRQUFRLFVBQVU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLFFBQU0sS0FBRyxpQkFBZ0IsS0FBRyxVQUFVLEVBQUUsSUFBRyxLQUFHLGNBQWMsRUFBRSxJQUFHLEtBQUcsWUFBVyxLQUFHLEVBQUMsV0FBVSxNQUFHLGFBQVksS0FBSSxHQUFFLEtBQUcsRUFBQyxXQUFVLFdBQVUsYUFBWSxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUEsSUFBRTtBQUFDLFlBQU0sR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXQSxFQUFDLEdBQUUsS0FBSyxZQUFVLE9BQUcsS0FBSyx1QkFBcUI7QUFBQSxJQUFJO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFXO0FBQUEsSUFBQyxXQUFVO0FBQUMsV0FBSyxjQUFZLEtBQUssUUFBUSxhQUFXLEtBQUssUUFBUSxZQUFZLE1BQU0sR0FBRSxFQUFFLElBQUksVUFBUyxFQUFFLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBSSxDQUFBQSxPQUFHLEtBQUssZUFBZUEsRUFBQyxDQUFFLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBSSxDQUFBQSxPQUFHLEtBQUssZUFBZUEsRUFBQyxDQUFFLEdBQUUsS0FBSyxZQUFVO0FBQUEsSUFBRztBQUFBLElBQUMsYUFBWTtBQUFDLFdBQUssY0FBWSxLQUFLLFlBQVUsT0FBRyxFQUFFLElBQUksVUFBUyxFQUFFO0FBQUEsSUFBRTtBQUFBLElBQUMsZUFBZUEsSUFBRTtBQUFDLFlBQUssRUFBQyxhQUFZSixHQUFDLElBQUUsS0FBSztBQUFRLFVBQUdJLEdBQUUsV0FBUyxZQUFVQSxHQUFFLFdBQVNKLE1BQUdBLEdBQUUsU0FBU0ksR0FBRSxNQUFNLEVBQUU7QUFBTyxZQUFNSCxLQUFFLEVBQUUsa0JBQWtCRCxFQUFDO0FBQUUsWUFBSUMsR0FBRSxTQUFPRCxHQUFFLE1BQU0sSUFBRSxLQUFLLHlCQUF1QixLQUFHQyxHQUFFQSxHQUFFLFNBQU8sQ0FBQyxFQUFFLE1BQU0sSUFBRUEsR0FBRSxDQUFDLEVBQUUsTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLGVBQWVHLElBQUU7QUFBQyxnQkFBUUEsR0FBRSxRQUFNLEtBQUssdUJBQXFCQSxHQUFFLFdBQVMsS0FBRztBQUFBLElBQVU7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLHFEQUFvRCxLQUFHLGVBQWMsS0FBRyxpQkFBZ0IsS0FBRztBQUFBLEVBQWUsTUFBTSxHQUFFO0FBQUEsSUFBQyxjQUFhO0FBQUMsV0FBSyxXQUFTLFNBQVM7QUFBQSxJQUFJO0FBQUEsSUFBQyxXQUFVO0FBQUMsWUFBTUEsS0FBRSxTQUFTLGdCQUFnQjtBQUFZLGFBQU8sS0FBSyxJQUFJLE9BQU8sYUFBV0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxZQUFNQSxLQUFFLEtBQUssU0FBUztBQUFFLFdBQUssaUJBQWlCLEdBQUUsS0FBSyxzQkFBc0IsS0FBSyxVQUFTLElBQUksQ0FBQUosT0FBR0EsS0FBRUksRUFBRSxHQUFFLEtBQUssc0JBQXNCLElBQUcsSUFBSSxDQUFBSixPQUFHQSxLQUFFSSxFQUFFLEdBQUUsS0FBSyxzQkFBc0IsSUFBRyxJQUFJLENBQUFKLE9BQUdBLEtBQUVJLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxRQUFPO0FBQUMsV0FBSyx3QkFBd0IsS0FBSyxVQUFTLFVBQVUsR0FBRSxLQUFLLHdCQUF3QixLQUFLLFVBQVMsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsYUFBTyxLQUFLLFNBQVMsSUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLG1CQUFrQjtBQUFDLFdBQUssc0JBQXNCLEtBQUssVUFBUyxVQUFVLEdBQUUsS0FBSyxTQUFTLE1BQU0sV0FBUztBQUFBLElBQVE7QUFBQSxJQUFDLHNCQUFzQkEsSUFBRUosSUFBRUMsSUFBRTtBQUFDLFlBQU1DLEtBQUUsS0FBSyxTQUFTO0FBQUUsV0FBSywyQkFBMkJFLElBQUcsQ0FBQUEsT0FBRztBQUFDLFlBQUdBLE9BQUksS0FBSyxZQUFVLE9BQU8sYUFBV0EsR0FBRSxjQUFZRixHQUFFO0FBQU8sYUFBSyxzQkFBc0JFLElBQUVKLEVBQUM7QUFBRSxjQUFNRyxLQUFFLE9BQU8saUJBQWlCQyxFQUFDLEVBQUUsaUJBQWlCSixFQUFDO0FBQUUsUUFBQUksR0FBRSxNQUFNLFlBQVlKLElBQUUsR0FBR0MsR0FBRSxPQUFPLFdBQVdFLEVBQUMsQ0FBQyxDQUFDLElBQUk7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxzQkFBc0JDLElBQUVKLElBQUU7QUFBQyxZQUFNQyxLQUFFRyxHQUFFLE1BQU0saUJBQWlCSixFQUFDO0FBQUUsTUFBQUMsTUFBRyxFQUFFLGlCQUFpQkcsSUFBRUosSUFBRUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLHdCQUF3QkcsSUFBRUosSUFBRTtBQUFDLFdBQUssMkJBQTJCSSxJQUFHLENBQUFBLE9BQUc7QUFBQyxjQUFNSCxLQUFFLEVBQUUsaUJBQWlCRyxJQUFFSixFQUFDO0FBQUUsaUJBQU9DLE1BQUcsRUFBRSxvQkFBb0JHLElBQUVKLEVBQUMsR0FBRUksR0FBRSxNQUFNLFlBQVlKLElBQUVDLEVBQUMsS0FBR0csR0FBRSxNQUFNLGVBQWVKLEVBQUM7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQywyQkFBMkJJLElBQUVKLElBQUU7QUFBQyxVQUFHLEVBQUVJLEVBQUMsRUFBRSxDQUFBSixHQUFFSSxFQUFDO0FBQUEsVUFBTyxZQUFVSCxNQUFLLEVBQUUsS0FBS0csSUFBRSxLQUFLLFFBQVEsRUFBRSxDQUFBSixHQUFFQyxFQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxRQUFNLEtBQUcsYUFBWSxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsZ0JBQWdCLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsZ0JBQWdCLEVBQUUsSUFBRyxLQUFHLG9CQUFvQixFQUFFLElBQUcsS0FBRyxrQkFBa0IsRUFBRSxJQUFHLEtBQUcsUUFBUSxFQUFFLGFBQVksS0FBRyxjQUFhLEtBQUcsUUFBTyxLQUFHLGdCQUFlLEtBQUcsRUFBQyxVQUFTLE1BQUcsT0FBTSxNQUFHLFVBQVMsS0FBRSxHQUFFLEtBQUcsRUFBQyxVQUFTLG9CQUFtQixPQUFNLFdBQVUsVUFBUyxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUcsSUFBRUosSUFBRTtBQUFDLFlBQU1JLElBQUVKLEVBQUMsR0FBRSxLQUFLLFVBQVEsRUFBRSxRQUFRLGlCQUFnQixLQUFLLFFBQVEsR0FBRSxLQUFLLFlBQVUsS0FBSyxvQkFBb0IsR0FBRSxLQUFLLGFBQVcsS0FBSyxxQkFBcUIsR0FBRSxLQUFLLFdBQVMsT0FBRyxLQUFLLG1CQUFpQixPQUFHLEtBQUssYUFBVyxJQUFJLE1BQUcsS0FBSyxtQkFBbUI7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFPO0FBQUEsSUFBQyxPQUFPSSxJQUFFO0FBQUMsYUFBTyxLQUFLLFdBQVMsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsS0FBS0EsSUFBRTtBQUFDLFdBQUssWUFBVSxLQUFLLG9CQUFrQixFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjQSxHQUFDLENBQUMsRUFBRSxxQkFBbUIsS0FBSyxXQUFTLE1BQUcsS0FBSyxtQkFBaUIsTUFBRyxLQUFLLFdBQVcsS0FBSyxHQUFFLFNBQVMsS0FBSyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssY0FBYyxHQUFFLEtBQUssVUFBVSxLQUFNLE1BQUksS0FBSyxhQUFhQSxFQUFDLENBQUU7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFNO0FBQUMsV0FBSyxZQUFVLENBQUMsS0FBSyxxQkFBbUIsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUscUJBQW1CLEtBQUssV0FBUyxPQUFHLEtBQUssbUJBQWlCLE1BQUcsS0FBSyxXQUFXLFdBQVcsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxLQUFLLGVBQWdCLE1BQUksS0FBSyxXQUFXLEdBQUcsS0FBSyxVQUFTLEtBQUssWUFBWSxDQUFDO0FBQUEsSUFBRztBQUFBLElBQUMsVUFBUztBQUFDLFFBQUUsSUFBSSxRQUFPLEVBQUUsR0FBRSxFQUFFLElBQUksS0FBSyxTQUFRLEVBQUUsR0FBRSxLQUFLLFVBQVUsUUFBUSxHQUFFLEtBQUssV0FBVyxXQUFXLEdBQUUsTUFBTSxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsZUFBYztBQUFDLFdBQUssY0FBYztBQUFBLElBQUM7QUFBQSxJQUFDLHNCQUFxQjtBQUFDLGFBQU8sSUFBSSxHQUFHLEVBQUMsV0FBVSxRQUFRLEtBQUssUUFBUSxRQUFRLEdBQUUsWUFBVyxLQUFLLFlBQVksRUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsdUJBQXNCO0FBQUMsYUFBTyxJQUFJLEdBQUcsRUFBQyxhQUFZLEtBQUssU0FBUSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsYUFBYUEsSUFBRTtBQUFDLGVBQVMsS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFHLFNBQVMsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFFLEtBQUssU0FBUyxNQUFNLFVBQVEsU0FBUSxLQUFLLFNBQVMsZ0JBQWdCLGFBQWEsR0FBRSxLQUFLLFNBQVMsYUFBYSxjQUFhLElBQUUsR0FBRSxLQUFLLFNBQVMsYUFBYSxRQUFPLFFBQVEsR0FBRSxLQUFLLFNBQVMsWUFBVTtBQUFFLFlBQU1KLEtBQUUsRUFBRSxRQUFRLGVBQWMsS0FBSyxPQUFPO0FBQUUsTUFBQUEsT0FBSUEsR0FBRSxZQUFVLElBQUcsRUFBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGVBQWdCLE1BQUk7QUFBQyxhQUFLLFFBQVEsU0FBTyxLQUFLLFdBQVcsU0FBUyxHQUFFLEtBQUssbUJBQWlCLE9BQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHLEVBQUMsZUFBY0ksR0FBQyxDQUFDO0FBQUEsTUFBQyxHQUFHLEtBQUssU0FBUSxLQUFLLFlBQVksQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLHFCQUFvQjtBQUFDLFFBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxDQUFBQSxPQUFHO0FBQUMscUJBQVdBLEdBQUUsUUFBTSxLQUFLLFFBQVEsV0FBUyxLQUFLLEtBQUssSUFBRSxLQUFLLDJCQUEyQjtBQUFBLE1BQUUsQ0FBRSxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUksTUFBSTtBQUFDLGFBQUssWUFBVSxDQUFDLEtBQUssb0JBQWtCLEtBQUssY0FBYztBQUFBLE1BQUMsQ0FBRSxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxDQUFBQSxPQUFHO0FBQUMsVUFBRSxJQUFJLEtBQUssVUFBUyxJQUFJLENBQUFKLE9BQUc7QUFBQyxlQUFLLGFBQVdJLEdBQUUsVUFBUSxLQUFLLGFBQVdKLEdBQUUsV0FBUyxhQUFXLEtBQUssUUFBUSxXQUFTLEtBQUssUUFBUSxZQUFVLEtBQUssS0FBSyxJQUFFLEtBQUssMkJBQTJCO0FBQUEsUUFBRSxDQUFFO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsYUFBWTtBQUFDLFdBQUssU0FBUyxNQUFNLFVBQVEsUUFBTyxLQUFLLFNBQVMsYUFBYSxlQUFjLElBQUUsR0FBRSxLQUFLLFNBQVMsZ0JBQWdCLFlBQVksR0FBRSxLQUFLLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRSxLQUFLLG1CQUFpQixPQUFHLEtBQUssVUFBVSxLQUFNLE1BQUk7QUFBQyxpQkFBUyxLQUFLLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxrQkFBa0IsR0FBRSxLQUFLLFdBQVcsTUFBTSxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWE7QUFBQyxhQUFPLEtBQUssU0FBUyxVQUFVLFNBQVMsTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLDZCQUE0QjtBQUFDLFVBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUsaUJBQWlCO0FBQU8sWUFBTUksS0FBRSxLQUFLLFNBQVMsZUFBYSxTQUFTLGdCQUFnQixjQUFhSixLQUFFLEtBQUssU0FBUyxNQUFNO0FBQVUsbUJBQVdBLE1BQUcsS0FBSyxTQUFTLFVBQVUsU0FBUyxFQUFFLE1BQUlJLE9BQUksS0FBSyxTQUFTLE1BQU0sWUFBVSxXQUFVLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssZUFBZ0IsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssZUFBZ0IsTUFBSTtBQUFDLGVBQUssU0FBUyxNQUFNLFlBQVVKO0FBQUEsUUFBQyxHQUFHLEtBQUssT0FBTztBQUFBLE1BQUMsR0FBRyxLQUFLLE9BQU8sR0FBRSxLQUFLLFNBQVMsTUFBTTtBQUFBLElBQUU7QUFBQSxJQUFDLGdCQUFlO0FBQUMsWUFBTUksS0FBRSxLQUFLLFNBQVMsZUFBYSxTQUFTLGdCQUFnQixjQUFhSixLQUFFLEtBQUssV0FBVyxTQUFTLEdBQUVDLEtBQUVELEtBQUU7QUFBRSxVQUFHQyxNQUFHLENBQUNHLElBQUU7QUFBQyxjQUFNQSxLQUFFLEVBQUUsSUFBRSxnQkFBYztBQUFlLGFBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsR0FBR0osRUFBQztBQUFBLE1BQUk7QUFBQyxVQUFHLENBQUNDLE1BQUdHLElBQUU7QUFBQyxjQUFNQSxLQUFFLEVBQUUsSUFBRSxpQkFBZTtBQUFjLGFBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsR0FBR0osRUFBQztBQUFBLE1BQUk7QUFBQSxJQUFDO0FBQUEsSUFBQyxvQkFBbUI7QUFBQyxXQUFLLFNBQVMsTUFBTSxjQUFZLElBQUcsS0FBSyxTQUFTLE1BQU0sZUFBYTtBQUFBLElBQUU7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCSSxJQUFFSixJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQU0sV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0csRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTSCxHQUFFRyxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBSCxHQUFFRyxFQUFDLEVBQUVKLEVBQUM7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLDRCQUE0QixTQUFTSSxJQUFFO0FBQUMsVUFBTUosS0FBRSxFQUFFLHVCQUF1QixJQUFJO0FBQUUsS0FBQyxLQUFJLE1BQU0sRUFBRSxTQUFTLEtBQUssT0FBTyxLQUFHSSxHQUFFLGVBQWUsR0FBRSxFQUFFLElBQUlKLElBQUUsSUFBSSxDQUFBSSxPQUFHO0FBQUMsTUFBQUEsR0FBRSxvQkFBa0IsRUFBRSxJQUFJSixJQUFFLElBQUksTUFBSTtBQUFDLFVBQUUsSUFBSSxLQUFHLEtBQUssTUFBTTtBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUMsQ0FBRTtBQUFFLFVBQU1DLEtBQUUsRUFBRSxRQUFRLGFBQWE7QUFBRSxJQUFBQSxNQUFHLEdBQUcsWUFBWUEsRUFBQyxFQUFFLEtBQUssR0FBRSxHQUFHLG9CQUFvQkQsRUFBQyxFQUFFLE9BQU8sSUFBSTtBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsRUFBRSxHQUFFLEVBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxpQkFBZ0IsS0FBRyxhQUFZLEtBQUcsT0FBTyxFQUFFLEdBQUcsRUFBRSxJQUFHLEtBQUcsUUFBTyxLQUFHLFdBQVUsS0FBRyxVQUFTLEtBQUcsbUJBQWtCLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsZ0JBQWdCLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsU0FBUyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxrQkFBa0IsRUFBRSxJQUFHLEtBQUcsRUFBQyxVQUFTLE1BQUcsVUFBUyxNQUFHLFFBQU8sTUFBRSxHQUFFLEtBQUcsRUFBQyxVQUFTLG9CQUFtQixVQUFTLFdBQVUsUUFBTyxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUksSUFBRUosSUFBRTtBQUFDLFlBQU1JLElBQUVKLEVBQUMsR0FBRSxLQUFLLFdBQVMsT0FBRyxLQUFLLFlBQVUsS0FBSyxvQkFBb0IsR0FBRSxLQUFLLGFBQVcsS0FBSyxxQkFBcUIsR0FBRSxLQUFLLG1CQUFtQjtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQVc7QUFBQSxJQUFDLE9BQU9JLElBQUU7QUFBQyxhQUFPLEtBQUssV0FBUyxLQUFLLEtBQUssSUFBRSxLQUFLLEtBQUtBLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxLQUFLQSxJQUFFO0FBQUMsV0FBSyxZQUFVLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxFQUFDLGVBQWNBLEdBQUMsQ0FBQyxFQUFFLHFCQUFtQixLQUFLLFdBQVMsTUFBRyxLQUFLLFVBQVUsS0FBSyxHQUFFLEtBQUssUUFBUSxVQUFTLElBQUksS0FBSSxLQUFLLEdBQUUsS0FBSyxTQUFTLGFBQWEsY0FBYSxJQUFFLEdBQUUsS0FBSyxTQUFTLGFBQWEsUUFBTyxRQUFRLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxlQUFnQixNQUFJO0FBQUMsYUFBSyxRQUFRLFVBQVEsQ0FBQyxLQUFLLFFBQVEsWUFBVSxLQUFLLFdBQVcsU0FBUyxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxFQUFDLGVBQWNBLEdBQUMsQ0FBQztBQUFBLE1BQUMsR0FBRyxLQUFLLFVBQVMsSUFBRTtBQUFBLElBQUU7QUFBQSxJQUFDLE9BQU07QUFBQyxXQUFLLGFBQVcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUscUJBQW1CLEtBQUssV0FBVyxXQUFXLEdBQUUsS0FBSyxTQUFTLEtBQUssR0FBRSxLQUFLLFdBQVMsT0FBRyxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFVBQVUsS0FBSyxHQUFFLEtBQUssZUFBZ0IsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixZQUFZLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixNQUFNLEdBQUUsS0FBSyxRQUFRLFVBQVMsSUFBSSxLQUFJLE1BQU0sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLEdBQUcsS0FBSyxVQUFTLElBQUU7QUFBQSxJQUFHO0FBQUEsSUFBQyxVQUFTO0FBQUMsV0FBSyxVQUFVLFFBQVEsR0FBRSxLQUFLLFdBQVcsV0FBVyxHQUFFLE1BQU0sUUFBUTtBQUFBLElBQUM7QUFBQSxJQUFDLHNCQUFxQjtBQUFDLFlBQU1BLEtBQUUsUUFBUSxLQUFLLFFBQVEsUUFBUTtBQUFFLGFBQU8sSUFBSSxHQUFHLEVBQUMsV0FBVSxzQkFBcUIsV0FBVUEsSUFBRSxZQUFXLE1BQUcsYUFBWSxLQUFLLFNBQVMsWUFBVyxlQUFjQSxLQUFFLE1BQUk7QUFBQyxxQkFBVyxLQUFLLFFBQVEsV0FBUyxLQUFLLEtBQUssSUFBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLElBQUUsS0FBSSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsdUJBQXNCO0FBQUMsYUFBTyxJQUFJLEdBQUcsRUFBQyxhQUFZLEtBQUssU0FBUSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMscUJBQW9CO0FBQUMsUUFBRSxHQUFHLEtBQUssVUFBUyxJQUFJLENBQUFBLE9BQUc7QUFBQyxxQkFBV0EsR0FBRSxRQUFNLEtBQUssUUFBUSxXQUFTLEtBQUssS0FBSyxJQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtBQUFBLE1BQUUsQ0FBRTtBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQU0sV0FBVTtBQUFDLGNBQU1KLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0ksRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTSixHQUFFSSxFQUFDLEtBQUdBLEdBQUUsV0FBVyxHQUFHLEtBQUcsa0JBQWdCQSxHQUFFLE9BQU0sSUFBSSxVQUFVLG9CQUFvQkEsRUFBQyxHQUFHO0FBQUUsVUFBQUosR0FBRUksRUFBQyxFQUFFLElBQUk7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFFO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLGdDQUFnQyxTQUFTQSxJQUFFO0FBQUMsVUFBTUosS0FBRSxFQUFFLHVCQUF1QixJQUFJO0FBQUUsUUFBRyxDQUFDLEtBQUksTUFBTSxFQUFFLFNBQVMsS0FBSyxPQUFPLEtBQUdJLEdBQUUsZUFBZSxHQUFFLEVBQUUsSUFBSSxFQUFFO0FBQU8sTUFBRSxJQUFJSixJQUFFLElBQUksTUFBSTtBQUFDLFFBQUUsSUFBSSxLQUFHLEtBQUssTUFBTTtBQUFBLElBQUMsQ0FBRTtBQUFFLFVBQU1DLEtBQUUsRUFBRSxRQUFRLEVBQUU7QUFBRSxJQUFBQSxNQUFHQSxPQUFJRCxNQUFHLEdBQUcsWUFBWUMsRUFBQyxFQUFFLEtBQUssR0FBRSxHQUFHLG9CQUFvQkQsRUFBQyxFQUFFLE9BQU8sSUFBSTtBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUksTUFBSTtBQUFDLGVBQVVJLE1BQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxJQUFHLG9CQUFvQkEsRUFBQyxFQUFFLEtBQUs7QUFBQSxFQUFDLENBQUUsR0FBRSxFQUFFLEdBQUcsUUFBTyxJQUFJLE1BQUk7QUFBQyxlQUFVQSxNQUFLLEVBQUUsS0FBSyw4Q0FBOEMsRUFBRSxhQUFVLGlCQUFpQkEsRUFBQyxFQUFFLFlBQVUsR0FBRyxvQkFBb0JBLEVBQUMsRUFBRSxLQUFLO0FBQUEsRUFBQyxDQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsRUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLEVBQUMsS0FBSSxDQUFDLFNBQVEsT0FBTSxNQUFLLFFBQU8sUUFBTyxnQkFBZ0IsR0FBRSxHQUFFLENBQUMsVUFBUyxRQUFPLFNBQVEsS0FBSyxHQUFFLE1BQUssQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLE1BQUssQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUksQ0FBQyxPQUFNLFVBQVMsT0FBTSxTQUFRLFNBQVEsUUFBUSxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxHQUFFLE1BQUssQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLFFBQU8sQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxFQUFDLEdBQUUsS0FBRyxvQkFBSSxJQUFJLENBQUMsY0FBYSxRQUFPLFFBQU8sWUFBVyxZQUFXLFVBQVMsT0FBTSxZQUFZLENBQUMsR0FBRSxLQUFHLDJEQUEwRCxLQUFHLENBQUNBLElBQUVKLE9BQUk7QUFBQyxVQUFNQyxLQUFFRyxHQUFFLFNBQVMsWUFBWTtBQUFFLFdBQU9KLEdBQUUsU0FBU0MsRUFBQyxJQUFFLENBQUMsR0FBRyxJQUFJQSxFQUFDLEtBQUcsUUFBUSxHQUFHLEtBQUtHLEdBQUUsU0FBUyxDQUFDLElBQUVKLEdBQUUsT0FBUSxDQUFBSSxPQUFHQSxjQUFhLE1BQU8sRUFBRSxLQUFNLENBQUFBLE9BQUdBLEdBQUUsS0FBS0gsRUFBQyxDQUFFO0FBQUEsRUFBQyxHQUFFLEtBQUcsRUFBQyxXQUFVLElBQUcsU0FBUSxDQUFDLEdBQUUsWUFBVyxJQUFHLE1BQUssT0FBRyxVQUFTLE1BQUcsWUFBVyxNQUFLLFVBQVMsY0FBYSxHQUFFLEtBQUcsRUFBQyxXQUFVLFVBQVMsU0FBUSxVQUFTLFlBQVcscUJBQW9CLE1BQUssV0FBVSxVQUFTLFdBQVUsWUFBVyxtQkFBa0IsVUFBUyxTQUFRLEdBQUUsS0FBRyxFQUFDLE9BQU0sa0NBQWlDLFVBQVMsbUJBQWtCO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUcsSUFBRTtBQUFDLFlBQU0sR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBaUI7QUFBQSxJQUFDLGFBQVk7QUFBQyxhQUFPLE9BQU8sT0FBTyxLQUFLLFFBQVEsT0FBTyxFQUFFLElBQUssQ0FBQUEsT0FBRyxLQUFLLHlCQUF5QkEsRUFBQyxDQUFFLEVBQUUsT0FBTyxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsYUFBWTtBQUFDLGFBQU8sS0FBSyxXQUFXLEVBQUUsU0FBTztBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWNBLElBQUU7QUFBQyxhQUFPLEtBQUssY0FBY0EsRUFBQyxHQUFFLEtBQUssUUFBUSxVQUFRLEVBQUMsR0FBRyxLQUFLLFFBQVEsU0FBUSxHQUFHQSxHQUFDLEdBQUU7QUFBQSxJQUFJO0FBQUEsSUFBQyxTQUFRO0FBQUMsWUFBTUEsS0FBRSxTQUFTLGNBQWMsS0FBSztBQUFFLE1BQUFBLEdBQUUsWUFBVSxLQUFLLGVBQWUsS0FBSyxRQUFRLFFBQVE7QUFBRSxpQkFBUyxDQUFDSixJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxPQUFPLEVBQUUsTUFBSyxZQUFZRyxJQUFFSCxJQUFFRCxFQUFDO0FBQUUsWUFBTUEsS0FBRUksR0FBRSxTQUFTLENBQUMsR0FBRUgsS0FBRSxLQUFLLHlCQUF5QixLQUFLLFFBQVEsVUFBVTtBQUFFLGFBQU9BLE1BQUdELEdBQUUsVUFBVSxJQUFJLEdBQUdDLEdBQUUsTUFBTSxHQUFHLENBQUMsR0FBRUQ7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJJLElBQUU7QUFBQyxZQUFNLGlCQUFpQkEsRUFBQyxHQUFFLEtBQUssY0FBY0EsR0FBRSxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBY0EsSUFBRTtBQUFDLGlCQUFTLENBQUNKLElBQUVDLEVBQUMsS0FBSSxPQUFPLFFBQVFHLEVBQUMsRUFBRSxPQUFNLGlCQUFpQixFQUFDLFVBQVNKLElBQUUsT0FBTUMsR0FBQyxHQUFFLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFZRyxJQUFFSixJQUFFQyxJQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLFFBQVFELElBQUVHLEVBQUM7QUFBRSxNQUFBRixRQUFLRixLQUFFLEtBQUsseUJBQXlCQSxFQUFDLEtBQUcsRUFBRUEsRUFBQyxJQUFFLEtBQUssc0JBQXNCLEVBQUVBLEVBQUMsR0FBRUUsRUFBQyxJQUFFLEtBQUssUUFBUSxPQUFLQSxHQUFFLFlBQVUsS0FBSyxlQUFlRixFQUFDLElBQUVFLEdBQUUsY0FBWUYsS0FBRUUsR0FBRSxPQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsZUFBZUUsSUFBRTtBQUFDLGFBQU8sS0FBSyxRQUFRLFdBQVMsU0FBU0EsSUFBRUosSUFBRUMsSUFBRTtBQUFDLFlBQUcsQ0FBQ0csR0FBRSxPQUFPLFFBQU9BO0FBQUUsWUFBR0gsTUFBRyxjQUFZLE9BQU9BLEdBQUUsUUFBT0EsR0FBRUcsRUFBQztBQUFFLGNBQU1GLEtBQUcsSUFBSSxPQUFPLFlBQVcsZ0JBQWdCRSxJQUFFLFdBQVcsR0FBRUQsS0FBRSxDQUFDLEVBQUUsT0FBTyxHQUFHRCxHQUFFLEtBQUssaUJBQWlCLEdBQUcsQ0FBQztBQUFFLG1CQUFVRSxNQUFLRCxJQUFFO0FBQUMsZ0JBQU1GLEtBQUVHLEdBQUUsU0FBUyxZQUFZO0FBQUUsY0FBRyxDQUFDLE9BQU8sS0FBS0osRUFBQyxFQUFFLFNBQVNDLEVBQUMsR0FBRTtBQUFDLFlBQUFHLEdBQUUsT0FBTztBQUFFO0FBQUEsVUFBUTtBQUFDLGdCQUFNRixLQUFFLENBQUMsRUFBRSxPQUFPLEdBQUdFLEdBQUUsVUFBVSxHQUFFRCxLQUFFLENBQUMsRUFBRSxPQUFPSCxHQUFFLEdBQUcsS0FBRyxDQUFDLEdBQUVBLEdBQUVDLEVBQUMsS0FBRyxDQUFDLENBQUM7QUFBRSxxQkFBVUQsTUFBS0UsR0FBRSxJQUFHRixJQUFFRyxFQUFDLEtBQUdDLEdBQUUsZ0JBQWdCSixHQUFFLFFBQVE7QUFBQSxRQUFDO0FBQUMsZUFBT0UsR0FBRSxLQUFLO0FBQUEsTUFBUyxFQUFFRSxJQUFFLEtBQUssUUFBUSxXQUFVLEtBQUssUUFBUSxVQUFVLElBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMseUJBQXlCQSxJQUFFO0FBQUMsYUFBTyxFQUFFQSxJQUFFLENBQUMsUUFBTyxJQUFJLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxzQkFBc0JBLElBQUVKLElBQUU7QUFBQyxVQUFHLEtBQUssUUFBUSxLQUFLLFFBQU9BLEdBQUUsWUFBVSxJQUFHLEtBQUtBLEdBQUUsT0FBT0ksRUFBQztBQUFFLE1BQUFKLEdBQUUsY0FBWUksR0FBRTtBQUFBLElBQVc7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLG9CQUFJLElBQUksQ0FBQyxZQUFXLGFBQVksWUFBWSxDQUFDLEdBQUUsS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLGtCQUFpQixLQUFHLFVBQVMsS0FBRyxpQkFBZ0IsS0FBRyxTQUFRLEtBQUcsU0FBUSxLQUFHLEVBQUMsTUFBSyxRQUFPLEtBQUksT0FBTSxPQUFNLEVBQUUsSUFBRSxTQUFPLFNBQVEsUUFBTyxVQUFTLE1BQUssRUFBRSxJQUFFLFVBQVEsT0FBTSxHQUFFLEtBQUcsRUFBQyxXQUFVLElBQUcsV0FBVSxNQUFHLFVBQVMsbUJBQWtCLFdBQVUsT0FBRyxhQUFZLElBQUcsT0FBTSxHQUFFLG9CQUFtQixDQUFDLE9BQU0sU0FBUSxVQUFTLE1BQU0sR0FBRSxNQUFLLE9BQUcsUUFBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFLFdBQVUsT0FBTSxjQUFhLE1BQUssVUFBUyxNQUFHLFlBQVcsTUFBSyxVQUFTLE9BQUcsVUFBUyxnSEFBK0csT0FBTSxJQUFHLFNBQVEsY0FBYSxHQUFFLEtBQUcsRUFBQyxXQUFVLFVBQVMsV0FBVSxXQUFVLFVBQVMsb0JBQW1CLFdBQVUsNEJBQTJCLGFBQVkscUJBQW9CLE9BQU0sbUJBQWtCLG9CQUFtQixTQUFRLE1BQUssV0FBVSxRQUFPLDJCQUEwQixXQUFVLHFCQUFvQixjQUFhLDBCQUF5QixVQUFTLFdBQVUsWUFBVyxtQkFBa0IsVUFBUyxvQkFBbUIsVUFBUyxVQUFTLE9BQU0sNkJBQTRCLFNBQVEsU0FBUTtBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUVKLElBQUU7QUFBQyxVQUFHLFdBQVMsR0FBRyxPQUFNLElBQUksVUFBVSxzRUFBc0U7QUFBRSxZQUFNSSxJQUFFSixFQUFDLEdBQUUsS0FBSyxhQUFXLE1BQUcsS0FBSyxXQUFTLEdBQUUsS0FBSyxhQUFXLE1BQUssS0FBSyxpQkFBZSxDQUFDLEdBQUUsS0FBSyxVQUFRLE1BQUssS0FBSyxtQkFBaUIsTUFBSyxLQUFLLGNBQVksTUFBSyxLQUFLLE1BQUksTUFBSyxLQUFLLGNBQWMsR0FBRSxLQUFLLFFBQVEsWUFBVSxLQUFLLFVBQVU7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFTO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxhQUFXO0FBQUEsSUFBRTtBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssYUFBVztBQUFBLElBQUU7QUFBQSxJQUFDLGdCQUFlO0FBQUMsV0FBSyxhQUFXLENBQUMsS0FBSztBQUFBLElBQVU7QUFBQSxJQUFDLFNBQVE7QUFBQyxXQUFLLGVBQWEsS0FBSyxTQUFTLElBQUUsS0FBSyxPQUFPLElBQUUsS0FBSyxPQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsVUFBUztBQUFDLG1CQUFhLEtBQUssUUFBUSxHQUFFLEVBQUUsSUFBSSxLQUFLLFNBQVMsUUFBUSxFQUFFLEdBQUUsSUFBRyxLQUFLLGlCQUFpQixHQUFFLEtBQUssU0FBUyxhQUFhLHdCQUF3QixLQUFHLEtBQUssU0FBUyxhQUFhLFNBQVEsS0FBSyxTQUFTLGFBQWEsd0JBQXdCLENBQUMsR0FBRSxLQUFLLGVBQWUsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFNO0FBQUMsVUFBRyxXQUFTLEtBQUssU0FBUyxNQUFNLFFBQVEsT0FBTSxJQUFJLE1BQU0scUNBQXFDO0FBQUUsVUFBRyxDQUFDLEtBQUssZUFBZSxLQUFHLENBQUMsS0FBSyxXQUFXO0FBQU8sWUFBTUksS0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFVLE1BQU0sQ0FBQyxHQUFFSixNQUFHLEVBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxTQUFTLGNBQWMsaUJBQWlCLFNBQVMsS0FBSyxRQUFRO0FBQUUsVUFBR0ksR0FBRSxvQkFBa0IsQ0FBQ0osR0FBRTtBQUFPLFdBQUssZUFBZTtBQUFFLFlBQU1DLEtBQUUsS0FBSyxlQUFlO0FBQUUsV0FBSyxTQUFTLGFBQWEsb0JBQW1CQSxHQUFFLGFBQWEsSUFBSSxDQUFDO0FBQUUsWUFBSyxFQUFDLFdBQVVDLEdBQUMsSUFBRSxLQUFLO0FBQVEsVUFBRyxLQUFLLFNBQVMsY0FBYyxnQkFBZ0IsU0FBUyxLQUFLLEdBQUcsTUFBSUEsR0FBRSxPQUFPRCxFQUFDLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxVQUFVLENBQUMsSUFBRyxLQUFLLFVBQVEsS0FBSyxjQUFjQSxFQUFDLEdBQUVBLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxrQkFBaUIsU0FBUyxnQkFBZ0IsWUFBVUcsTUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLFNBQVMsS0FBSyxRQUFRLEVBQUUsR0FBRSxHQUFHQSxJQUFFLGFBQVksQ0FBQztBQUFFLFdBQUssZUFBZ0IsTUFBSTtBQUFDLFVBQUUsUUFBUSxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVUsT0FBTyxDQUFDLEdBQUUsVUFBSyxLQUFLLGNBQVksS0FBSyxPQUFPLEdBQUUsS0FBSyxhQUFXO0FBQUEsTUFBRSxHQUFHLEtBQUssS0FBSSxLQUFLLFlBQVksQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxVQUFHLEtBQUssU0FBUyxLQUFHLENBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxNQUFNLENBQUMsRUFBRSxrQkFBaUI7QUFBQyxZQUFHLEtBQUssZUFBZSxFQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUUsa0JBQWlCLFNBQVMsZ0JBQWdCLFlBQVVBLE1BQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxTQUFTLEtBQUssUUFBUSxFQUFFLEdBQUUsSUFBSUEsSUFBRSxhQUFZLENBQUM7QUFBRSxhQUFLLGVBQWUsUUFBTSxPQUFHLEtBQUssZUFBZSxFQUFFLElBQUUsT0FBRyxLQUFLLGVBQWUsRUFBRSxJQUFFLE9BQUcsS0FBSyxhQUFXLE1BQUssS0FBSyxlQUFnQixNQUFJO0FBQUMsZUFBSyxxQkFBcUIsTUFBSSxLQUFLLGNBQVksS0FBSyxlQUFlLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixrQkFBa0IsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFVLFFBQVEsQ0FBQztBQUFBLFFBQUUsR0FBRyxLQUFLLEtBQUksS0FBSyxZQUFZLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsU0FBUTtBQUFDLFdBQUssV0FBUyxLQUFLLFFBQVEsT0FBTztBQUFBLElBQUM7QUFBQSxJQUFDLGlCQUFnQjtBQUFDLGFBQU8sUUFBUSxLQUFLLFVBQVUsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLGlCQUFnQjtBQUFDLGFBQU8sS0FBSyxRQUFNLEtBQUssTUFBSSxLQUFLLGtCQUFrQixLQUFLLGVBQWEsS0FBSyx1QkFBdUIsQ0FBQyxJQUFHLEtBQUs7QUFBQSxJQUFHO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxZQUFNSixLQUFFLEtBQUssb0JBQW9CSSxFQUFDLEVBQUUsT0FBTztBQUFFLFVBQUcsQ0FBQ0osR0FBRSxRQUFPO0FBQUssTUFBQUEsR0FBRSxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUVBLEdBQUUsVUFBVSxJQUFJLE1BQU0sS0FBSyxZQUFZLElBQUksT0FBTztBQUFFLFlBQU1DLE1BQUcsQ0FBQUcsT0FBRztBQUFDLFdBQUU7QUFBQyxVQUFBQSxNQUFHLEtBQUssTUFBTSxNQUFJLEtBQUssT0FBTyxDQUFDO0FBQUEsUUFBQyxTQUFPLFNBQVMsZUFBZUEsRUFBQztBQUFHLGVBQU9BO0FBQUEsTUFBQyxHQUFHLEtBQUssWUFBWSxJQUFJLEVBQUUsU0FBUztBQUFFLGFBQU9KLEdBQUUsYUFBYSxNQUFLQyxFQUFDLEdBQUUsS0FBSyxZQUFZLEtBQUdELEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXSSxJQUFFO0FBQUMsV0FBSyxjQUFZQSxJQUFFLEtBQUssU0FBUyxNQUFJLEtBQUssZUFBZSxHQUFFLEtBQUssS0FBSztBQUFBLElBQUU7QUFBQSxJQUFDLG9CQUFvQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxtQkFBaUIsS0FBSyxpQkFBaUIsY0FBY0EsRUFBQyxJQUFFLEtBQUssbUJBQWlCLElBQUksR0FBRyxFQUFDLEdBQUcsS0FBSyxTQUFRLFNBQVFBLElBQUUsWUFBVyxLQUFLLHlCQUF5QixLQUFLLFFBQVEsV0FBVyxFQUFDLENBQUMsR0FBRSxLQUFLO0FBQUEsSUFBZ0I7QUFBQSxJQUFDLHlCQUF3QjtBQUFDLGFBQU0sRUFBQyxDQUFDLEVBQUUsR0FBRSxLQUFLLFVBQVUsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFlBQVc7QUFBQyxhQUFPLEtBQUsseUJBQXlCLEtBQUssUUFBUSxLQUFLLEtBQUcsS0FBSyxTQUFTLGFBQWEsd0JBQXdCO0FBQUEsSUFBQztBQUFBLElBQUMsNkJBQTZCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLFlBQVksb0JBQW9CQSxHQUFFLGdCQUFlLEtBQUssbUJBQW1CLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxjQUFhO0FBQUMsYUFBTyxLQUFLLFFBQVEsYUFBVyxLQUFLLE9BQUssS0FBSyxJQUFJLFVBQVUsU0FBUyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVTtBQUFDLGFBQU8sS0FBSyxPQUFLLEtBQUssSUFBSSxVQUFVLFNBQVMsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWNBLElBQUU7QUFBQyxZQUFNSixLQUFFLEVBQUUsS0FBSyxRQUFRLFdBQVUsQ0FBQyxNQUFLSSxJQUFFLEtBQUssUUFBUSxDQUFDLEdBQUVILEtBQUUsR0FBR0QsR0FBRSxZQUFZLENBQUM7QUFBRSxhQUFPLEdBQUcsS0FBSyxVQUFTSSxJQUFFLEtBQUssaUJBQWlCSCxFQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxhQUFZO0FBQUMsWUFBSyxFQUFDLFFBQU9HLEdBQUMsSUFBRSxLQUFLO0FBQVEsYUFBTSxZQUFVLE9BQU9BLEtBQUVBLEdBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSyxDQUFBQSxPQUFHLE9BQU8sU0FBU0EsSUFBRSxFQUFFLENBQUUsSUFBRSxjQUFZLE9BQU9BLEtBQUUsQ0FBQUosT0FBR0ksR0FBRUosSUFBRSxLQUFLLFFBQVEsSUFBRUk7QUFBQSxJQUFDO0FBQUEsSUFBQyx5QkFBeUJBLElBQUU7QUFBQyxhQUFPLEVBQUVBLElBQUUsQ0FBQyxLQUFLLFVBQVMsS0FBSyxRQUFRLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJBLElBQUU7QUFBQyxZQUFNSixLQUFFLEVBQUMsV0FBVUksSUFBRSxXQUFVLENBQUMsRUFBQyxNQUFLLFFBQU8sU0FBUSxFQUFDLG9CQUFtQixLQUFLLFFBQVEsbUJBQWtCLEVBQUMsR0FBRSxFQUFDLE1BQUssVUFBUyxTQUFRLEVBQUMsUUFBTyxLQUFLLFdBQVcsRUFBQyxFQUFDLEdBQUUsRUFBQyxNQUFLLG1CQUFrQixTQUFRLEVBQUMsVUFBUyxLQUFLLFFBQVEsU0FBUSxFQUFDLEdBQUUsRUFBQyxNQUFLLFNBQVEsU0FBUSxFQUFDLFNBQVEsSUFBSSxLQUFLLFlBQVksSUFBSSxTQUFRLEVBQUMsR0FBRSxFQUFDLE1BQUssbUJBQWtCLFNBQVEsTUFBRyxPQUFNLGNBQWEsSUFBRyxDQUFBQSxPQUFHO0FBQUMsYUFBSyxlQUFlLEVBQUUsYUFBYSx5QkFBd0JBLEdBQUUsTUFBTSxTQUFTO0FBQUEsTUFBQyxFQUFDLENBQUMsRUFBQztBQUFFLGFBQU0sRUFBQyxHQUFHSixJQUFFLEdBQUcsRUFBRSxLQUFLLFFBQVEsY0FBYSxDQUFDLFFBQU9BLEVBQUMsQ0FBQyxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsZ0JBQWU7QUFBQyxZQUFNSSxLQUFFLEtBQUssUUFBUSxRQUFRLE1BQU0sR0FBRztBQUFFLGlCQUFVSixNQUFLSSxHQUFFLEtBQUcsWUFBVUosR0FBRSxHQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFVLE9BQU8sR0FBRSxLQUFLLFFBQVEsVUFBVSxDQUFBSSxPQUFHO0FBQUMsYUFBSyw2QkFBNkJBLEVBQUMsRUFBRSxPQUFPO0FBQUEsTUFBQyxDQUFFO0FBQUEsZUFBVSxhQUFXSixJQUFFO0FBQUMsY0FBTUksS0FBRUosT0FBSSxLQUFHLEtBQUssWUFBWSxVQUFVLFlBQVksSUFBRSxLQUFLLFlBQVksVUFBVSxTQUFTLEdBQUVDLEtBQUVELE9BQUksS0FBRyxLQUFLLFlBQVksVUFBVSxZQUFZLElBQUUsS0FBSyxZQUFZLFVBQVUsVUFBVTtBQUFFLFVBQUUsR0FBRyxLQUFLLFVBQVNJLElBQUUsS0FBSyxRQUFRLFVBQVUsQ0FBQUEsT0FBRztBQUFDLGdCQUFNSixLQUFFLEtBQUssNkJBQTZCSSxFQUFDO0FBQUUsVUFBQUosR0FBRSxlQUFlLGNBQVlJLEdBQUUsT0FBSyxLQUFHLEVBQUUsSUFBRSxNQUFHSixHQUFFLE9BQU87QUFBQSxRQUFDLENBQUUsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTQyxJQUFFLEtBQUssUUFBUSxVQUFVLENBQUFHLE9BQUc7QUFBQyxnQkFBTUosS0FBRSxLQUFLLDZCQUE2QkksRUFBQztBQUFFLFVBQUFKLEdBQUUsZUFBZSxlQUFhSSxHQUFFLE9BQUssS0FBRyxFQUFFLElBQUVKLEdBQUUsU0FBUyxTQUFTSSxHQUFFLGFBQWEsR0FBRUosR0FBRSxPQUFPO0FBQUEsUUFBQyxDQUFFO0FBQUEsTUFBQztBQUFDLFdBQUssb0JBQWtCLE1BQUk7QUFBQyxhQUFLLFlBQVUsS0FBSyxLQUFLO0FBQUEsTUFBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFNBQVMsUUFBUSxFQUFFLEdBQUUsSUFBRyxLQUFLLGlCQUFpQjtBQUFBLElBQUM7QUFBQSxJQUFDLFlBQVc7QUFBQyxZQUFNSSxLQUFFLEtBQUssU0FBUyxhQUFhLE9BQU87QUFBRSxNQUFBQSxPQUFJLEtBQUssU0FBUyxhQUFhLFlBQVksS0FBRyxLQUFLLFNBQVMsWUFBWSxLQUFLLEtBQUcsS0FBSyxTQUFTLGFBQWEsY0FBYUEsRUFBQyxHQUFFLEtBQUssU0FBUyxhQUFhLDBCQUF5QkEsRUFBQyxHQUFFLEtBQUssU0FBUyxnQkFBZ0IsT0FBTztBQUFBLElBQUU7QUFBQSxJQUFDLFNBQVE7QUFBQyxXQUFLLFNBQVMsS0FBRyxLQUFLLGFBQVcsS0FBSyxhQUFXLFFBQUksS0FBSyxhQUFXLE1BQUcsS0FBSyxZQUFhLE1BQUk7QUFBQyxhQUFLLGNBQVksS0FBSyxLQUFLO0FBQUEsTUFBQyxHQUFHLEtBQUssUUFBUSxNQUFNLElBQUk7QUFBQSxJQUFFO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxxQkFBcUIsTUFBSSxLQUFLLGFBQVcsT0FBRyxLQUFLLFlBQWEsTUFBSTtBQUFDLGFBQUssY0FBWSxLQUFLLEtBQUs7QUFBQSxNQUFDLEdBQUcsS0FBSyxRQUFRLE1BQU0sSUFBSTtBQUFBLElBQUU7QUFBQSxJQUFDLFlBQVlBLElBQUVKLElBQUU7QUFBQyxtQkFBYSxLQUFLLFFBQVEsR0FBRSxLQUFLLFdBQVMsV0FBV0ksSUFBRUosRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLHVCQUFzQjtBQUFDLGFBQU8sT0FBTyxPQUFPLEtBQUssY0FBYyxFQUFFLFNBQVMsSUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVdJLElBQUU7QUFBQyxZQUFNSixLQUFFLEVBQUUsa0JBQWtCLEtBQUssUUFBUTtBQUFFLGlCQUFVSSxNQUFLLE9BQU8sS0FBS0osRUFBQyxFQUFFLElBQUcsSUFBSUksRUFBQyxLQUFHLE9BQU9KLEdBQUVJLEVBQUM7QUFBRSxhQUFPQSxLQUFFLEVBQUMsR0FBR0osSUFBRSxHQUFHLFlBQVUsT0FBT0ksTUFBR0EsS0FBRUEsS0FBRSxDQUFDLEVBQUMsR0FBRUEsS0FBRSxLQUFLLGdCQUFnQkEsRUFBQyxHQUFFQSxLQUFFLEtBQUssa0JBQWtCQSxFQUFDLEdBQUUsS0FBSyxpQkFBaUJBLEVBQUMsR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPQSxHQUFFLFlBQVUsVUFBS0EsR0FBRSxZQUFVLFNBQVMsT0FBSyxFQUFFQSxHQUFFLFNBQVMsR0FBRSxZQUFVLE9BQU9BLEdBQUUsVUFBUUEsR0FBRSxRQUFNLEVBQUMsTUFBS0EsR0FBRSxPQUFNLE1BQUtBLEdBQUUsTUFBSyxJQUFHLFlBQVUsT0FBT0EsR0FBRSxVQUFRQSxHQUFFLFFBQU1BLEdBQUUsTUFBTSxTQUFTLElBQUcsWUFBVSxPQUFPQSxHQUFFLFlBQVVBLEdBQUUsVUFBUUEsR0FBRSxRQUFRLFNBQVMsSUFBR0E7QUFBQSxJQUFDO0FBQUEsSUFBQyxxQkFBb0I7QUFBQyxZQUFNQSxLQUFFLENBQUM7QUFBRSxpQkFBUyxDQUFDSixJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRLEtBQUssT0FBTyxFQUFFLE1BQUssWUFBWSxRQUFRRCxFQUFDLE1BQUlDLE9BQUlHLEdBQUVKLEVBQUMsSUFBRUM7QUFBRyxhQUFPRyxHQUFFLFdBQVMsT0FBR0EsR0FBRSxVQUFRLFVBQVNBO0FBQUEsSUFBQztBQUFBLElBQUMsaUJBQWdCO0FBQUMsV0FBSyxZQUFVLEtBQUssUUFBUSxRQUFRLEdBQUUsS0FBSyxVQUFRLE9BQU0sS0FBSyxRQUFNLEtBQUssSUFBSSxPQUFPLEdBQUUsS0FBSyxNQUFJO0FBQUEsSUFBSztBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBTSxXQUFVO0FBQUMsY0FBTUosS0FBRSxHQUFHLG9CQUFvQixNQUFLSSxFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNKLEdBQUVJLEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFKLEdBQUVJLEVBQUMsRUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxtQkFBa0IsS0FBRyxpQkFBZ0IsS0FBRyxFQUFDLEdBQUcsR0FBRyxTQUFRLFNBQVEsSUFBRyxRQUFPLENBQUMsR0FBRSxDQUFDLEdBQUUsV0FBVSxTQUFRLFVBQVMsK0lBQThJLFNBQVEsUUFBTyxHQUFFLEtBQUcsRUFBQyxHQUFHLEdBQUcsYUFBWSxTQUFRLGlDQUFnQztBQUFBLEVBQUUsTUFBTSxXQUFXLEdBQUU7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQVM7QUFBQSxJQUFDLGlCQUFnQjtBQUFDLGFBQU8sS0FBSyxVQUFVLEtBQUcsS0FBSyxZQUFZO0FBQUEsSUFBQztBQUFBLElBQUMseUJBQXdCO0FBQUMsYUFBTSxFQUFDLENBQUMsRUFBRSxHQUFFLEtBQUssVUFBVSxHQUFFLENBQUMsRUFBRSxHQUFFLEtBQUssWUFBWSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBYTtBQUFDLGFBQU8sS0FBSyx5QkFBeUIsS0FBSyxRQUFRLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFNLFdBQVU7QUFBQyxjQUFNSixLQUFFLEdBQUcsb0JBQW9CLE1BQUtJLEVBQUM7QUFBRSxZQUFHLFlBQVUsT0FBT0EsSUFBRTtBQUFDLGNBQUcsV0FBU0osR0FBRUksRUFBQyxFQUFFLE9BQU0sSUFBSSxVQUFVLG9CQUFvQkEsRUFBQyxHQUFHO0FBQUUsVUFBQUosR0FBRUksRUFBQyxFQUFFO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsSUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLGlCQUFnQixLQUFHLFdBQVcsRUFBRSxJQUFHLEtBQUcsUUFBUSxFQUFFLElBQUcsS0FBRyxPQUFPLEVBQUUsYUFBWSxLQUFHLFVBQVMsS0FBRyxVQUFTLEtBQUcsYUFBWSxLQUFHLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxzQkFBcUIsS0FBRyxFQUFDLFFBQU8sTUFBSyxZQUFXLGdCQUFlLGNBQWEsT0FBRyxRQUFPLE1BQUssV0FBVSxDQUFDLEtBQUcsS0FBRyxDQUFDLEVBQUMsR0FBRSxLQUFHLEVBQUMsUUFBTyxpQkFBZ0IsWUFBVyxVQUFTLGNBQWEsV0FBVSxRQUFPLFdBQVUsV0FBVSxRQUFPO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUEsSUFBRUosSUFBRTtBQUFDLFlBQU1JLElBQUVKLEVBQUMsR0FBRSxLQUFLLGVBQWEsb0JBQUksT0FBSSxLQUFLLHNCQUFvQixvQkFBSSxPQUFJLEtBQUssZUFBYSxjQUFZLGlCQUFpQixLQUFLLFFBQVEsRUFBRSxZQUFVLE9BQUssS0FBSyxVQUFTLEtBQUssZ0JBQWMsTUFBSyxLQUFLLFlBQVUsTUFBSyxLQUFLLHNCQUFvQixFQUFDLGlCQUFnQixHQUFFLGlCQUFnQixFQUFDLEdBQUUsS0FBSyxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBVztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssaUNBQWlDLEdBQUUsS0FBSyx5QkFBeUIsR0FBRSxLQUFLLFlBQVUsS0FBSyxVQUFVLFdBQVcsSUFBRSxLQUFLLFlBQVUsS0FBSyxnQkFBZ0I7QUFBRSxpQkFBVUksTUFBSyxLQUFLLG9CQUFvQixPQUFPLEVBQUUsTUFBSyxVQUFVLFFBQVFBLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxVQUFTO0FBQUMsV0FBSyxVQUFVLFdBQVcsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPQSxHQUFFLFNBQU8sRUFBRUEsR0FBRSxNQUFNLEtBQUcsU0FBUyxNQUFLQSxHQUFFLGFBQVdBLEdBQUUsU0FBTyxHQUFHQSxHQUFFLE1BQU0sZ0JBQWNBLEdBQUUsWUFBVyxZQUFVLE9BQU9BLEdBQUUsY0FBWUEsR0FBRSxZQUFVQSxHQUFFLFVBQVUsTUFBTSxHQUFHLEVBQUUsSUFBSyxDQUFBQSxPQUFHLE9BQU8sV0FBV0EsRUFBQyxDQUFFLElBQUdBO0FBQUEsSUFBQztBQUFBLElBQUMsMkJBQTBCO0FBQUMsV0FBSyxRQUFRLGlCQUFlLEVBQUUsSUFBSSxLQUFLLFFBQVEsUUFBTyxFQUFFLEdBQUUsRUFBRSxHQUFHLEtBQUssUUFBUSxRQUFPLElBQUcsSUFBSSxDQUFBQSxPQUFHO0FBQUMsY0FBTUosS0FBRSxLQUFLLG9CQUFvQixJQUFJSSxHQUFFLE9BQU8sSUFBSTtBQUFFLFlBQUdKLElBQUU7QUFBQyxVQUFBSSxHQUFFLGVBQWU7QUFBRSxnQkFBTUgsS0FBRSxLQUFLLGdCQUFjLFFBQU9DLEtBQUVGLEdBQUUsWUFBVSxLQUFLLFNBQVM7QUFBVSxjQUFHQyxHQUFFLFNBQVMsUUFBTyxLQUFLQSxHQUFFLFNBQVMsRUFBQyxLQUFJQyxJQUFFLFVBQVMsU0FBUSxDQUFDO0FBQUUsVUFBQUQsR0FBRSxZQUFVQztBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFFO0FBQUEsSUFBQyxrQkFBaUI7QUFBQyxZQUFNRSxLQUFFLEVBQUMsTUFBSyxLQUFLLGNBQWEsV0FBVSxLQUFLLFFBQVEsV0FBVSxZQUFXLEtBQUssUUFBUSxXQUFVO0FBQUUsYUFBTyxJQUFJLHFCQUFzQixDQUFBQSxPQUFHLEtBQUssa0JBQWtCQSxFQUFDLEdBQUdBLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxZQUFNSixLQUFFLENBQUFJLE9BQUcsS0FBSyxhQUFhLElBQUksSUFBSUEsR0FBRSxPQUFPLEVBQUUsRUFBRSxHQUFFSCxLQUFFLENBQUFHLE9BQUc7QUFBQyxhQUFLLG9CQUFvQixrQkFBZ0JBLEdBQUUsT0FBTyxXQUFVLEtBQUssU0FBU0osR0FBRUksRUFBQyxDQUFDO0FBQUEsTUFBQyxHQUFFRixNQUFHLEtBQUssZ0JBQWMsU0FBUyxpQkFBaUIsV0FBVUMsS0FBRUQsTUFBRyxLQUFLLG9CQUFvQjtBQUFnQixXQUFLLG9CQUFvQixrQkFBZ0JBO0FBQUUsaUJBQVVHLE1BQUtELElBQUU7QUFBQyxZQUFHLENBQUNDLEdBQUUsZ0JBQWU7QUFBQyxlQUFLLGdCQUFjLE1BQUssS0FBSyxrQkFBa0JMLEdBQUVLLEVBQUMsQ0FBQztBQUFFO0FBQUEsUUFBUTtBQUFDLGNBQU1ELEtBQUVDLEdBQUUsT0FBTyxhQUFXLEtBQUssb0JBQW9CO0FBQWdCLFlBQUdGLE1BQUdDLElBQUU7QUFBQyxjQUFHSCxHQUFFSSxFQUFDLEdBQUUsQ0FBQ0gsR0FBRTtBQUFBLFFBQU0sTUFBTSxDQUFBQyxNQUFHQyxNQUFHSCxHQUFFSSxFQUFDO0FBQUEsTUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLG1DQUFrQztBQUFDLFdBQUssZUFBYSxvQkFBSSxPQUFJLEtBQUssc0JBQW9CLG9CQUFJO0FBQUksWUFBTUQsS0FBRSxFQUFFLEtBQUssSUFBRyxLQUFLLFFBQVEsTUFBTTtBQUFFLGlCQUFVSixNQUFLSSxJQUFFO0FBQUMsWUFBRyxDQUFDSixHQUFFLFFBQU0sRUFBRUEsRUFBQyxFQUFFO0FBQVMsY0FBTUksS0FBRSxFQUFFLFFBQVEsVUFBVUosR0FBRSxJQUFJLEdBQUUsS0FBSyxRQUFRO0FBQUUsVUFBRUksRUFBQyxNQUFJLEtBQUssYUFBYSxJQUFJLFVBQVVKLEdBQUUsSUFBSSxHQUFFQSxFQUFDLEdBQUUsS0FBSyxvQkFBb0IsSUFBSUEsR0FBRSxNQUFLSSxFQUFDO0FBQUEsTUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLFNBQVNBLElBQUU7QUFBQyxXQUFLLGtCQUFnQkEsT0FBSSxLQUFLLGtCQUFrQixLQUFLLFFBQVEsTUFBTSxHQUFFLEtBQUssZ0JBQWNBLElBQUVBLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGlCQUFpQkEsRUFBQyxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxFQUFDLGVBQWNBLEdBQUMsQ0FBQztBQUFBLElBQUU7QUFBQSxJQUFDLGlCQUFpQkEsSUFBRTtBQUFDLFVBQUdBLEdBQUUsVUFBVSxTQUFTLGVBQWUsRUFBRSxHQUFFLFFBQVEsb0JBQW1CQSxHQUFFLFFBQVEsV0FBVyxDQUFDLEVBQUUsVUFBVSxJQUFJLEVBQUU7QUFBQSxVQUFPLFlBQVVKLE1BQUssRUFBRSxRQUFRSSxJQUFFLG1CQUFtQixFQUFFLFlBQVVBLE1BQUssRUFBRSxLQUFLSixJQUFFLEVBQUUsRUFBRSxDQUFBSSxHQUFFLFVBQVUsSUFBSSxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsTUFBQUEsR0FBRSxVQUFVLE9BQU8sRUFBRTtBQUFFLFlBQU1KLEtBQUUsRUFBRSxLQUFLLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBR0ksRUFBQztBQUFFLGlCQUFVQSxNQUFLSixHQUFFLENBQUFJLEdBQUUsVUFBVSxPQUFPLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFNLFdBQVU7QUFBQyxjQUFNSixLQUFFLEdBQUcsb0JBQW9CLE1BQUtJLEVBQUM7QUFBRSxZQUFHLFlBQVUsT0FBT0EsSUFBRTtBQUFDLGNBQUcsV0FBU0osR0FBRUksRUFBQyxLQUFHQSxHQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQkEsR0FBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFKLEdBQUVJLEVBQUMsRUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsR0FBRyxRQUFPLElBQUksTUFBSTtBQUFDLGVBQVVBLE1BQUssRUFBRSxLQUFLLHdCQUF3QixFQUFFLElBQUcsb0JBQW9CQSxFQUFDO0FBQUEsRUFBQyxDQUFFLEdBQUUsRUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLFdBQVUsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsVUFBVSxFQUFFLElBQUcsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLGFBQVksS0FBRyxjQUFhLEtBQUcsV0FBVSxLQUFHLGFBQVksS0FBRyxRQUFPLEtBQUcsT0FBTSxLQUFHLFVBQVMsS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLG9CQUFtQixLQUFHLFFBQVEsRUFBRSxLQUFJLEtBQUcsNEVBQTJFLEtBQUcsWUFBWSxFQUFFLHFCQUFxQixFQUFFLGlCQUFpQixFQUFFLEtBQUssRUFBRSxJQUFHLEtBQUcsSUFBSSxFQUFFLDRCQUE0QixFQUFFLDZCQUE2QixFQUFFO0FBQUEsRUFBMEIsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUU7QUFBQyxZQUFNQSxFQUFDLEdBQUUsS0FBSyxVQUFRLEtBQUssU0FBUyxRQUFRLHFDQUFxQyxHQUFFLEtBQUssWUFBVSxLQUFLLHNCQUFzQixLQUFLLFNBQVEsS0FBSyxhQUFhLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUksQ0FBQUEsT0FBRyxLQUFLLFNBQVNBLEVBQUMsQ0FBRTtBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFLO0FBQUEsSUFBQyxPQUFNO0FBQUMsWUFBTUEsS0FBRSxLQUFLO0FBQVMsVUFBRyxLQUFLLGNBQWNBLEVBQUMsRUFBRTtBQUFPLFlBQU1KLEtBQUUsS0FBSyxlQUFlLEdBQUVDLEtBQUVELEtBQUUsRUFBRSxRQUFRQSxJQUFFLElBQUcsRUFBQyxlQUFjSSxHQUFDLENBQUMsSUFBRTtBQUFLLFFBQUUsUUFBUUEsSUFBRSxJQUFHLEVBQUMsZUFBY0osR0FBQyxDQUFDLEVBQUUsb0JBQWtCQyxNQUFHQSxHQUFFLHFCQUFtQixLQUFLLFlBQVlELElBQUVJLEVBQUMsR0FBRSxLQUFLLFVBQVVBLElBQUVKLEVBQUM7QUFBQSxJQUFFO0FBQUEsSUFBQyxVQUFVSSxJQUFFSixJQUFFO0FBQUMsTUFBQUksT0FBSUEsR0FBRSxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssVUFBVSxFQUFFLHVCQUF1QkEsRUFBQyxDQUFDLEdBQUUsS0FBSyxlQUFnQixNQUFJO0FBQUMsa0JBQVFBLEdBQUUsYUFBYSxNQUFNLEtBQUdBLEdBQUUsZ0JBQWdCLFVBQVUsR0FBRUEsR0FBRSxhQUFhLGlCQUFnQixJQUFFLEdBQUUsS0FBSyxnQkFBZ0JBLElBQUUsSUFBRSxHQUFFLEVBQUUsUUFBUUEsSUFBRSxJQUFHLEVBQUMsZUFBY0osR0FBQyxDQUFDLEtBQUdJLEdBQUUsVUFBVSxJQUFJLEVBQUU7QUFBQSxNQUFDLEdBQUdBLElBQUVBLEdBQUUsVUFBVSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQUU7QUFBQSxJQUFDLFlBQVlBLElBQUVKLElBQUU7QUFBQyxNQUFBSSxPQUFJQSxHQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUVBLEdBQUUsS0FBSyxHQUFFLEtBQUssWUFBWSxFQUFFLHVCQUF1QkEsRUFBQyxDQUFDLEdBQUUsS0FBSyxlQUFnQixNQUFJO0FBQUMsa0JBQVFBLEdBQUUsYUFBYSxNQUFNLEtBQUdBLEdBQUUsYUFBYSxpQkFBZ0IsS0FBRSxHQUFFQSxHQUFFLGFBQWEsWUFBVyxJQUFJLEdBQUUsS0FBSyxnQkFBZ0JBLElBQUUsS0FBRSxHQUFFLEVBQUUsUUFBUUEsSUFBRSxJQUFHLEVBQUMsZUFBY0osR0FBQyxDQUFDLEtBQUdJLEdBQUUsVUFBVSxPQUFPLEVBQUU7QUFBQSxNQUFDLEdBQUdBLElBQUVBLEdBQUUsVUFBVSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQUU7QUFBQSxJQUFDLFNBQVNBLElBQUU7QUFBQyxVQUFHLENBQUMsQ0FBQyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsRUFBRSxFQUFFLFNBQVNBLEdBQUUsR0FBRyxFQUFFO0FBQU8sTUFBQUEsR0FBRSxnQkFBZ0IsR0FBRUEsR0FBRSxlQUFlO0FBQUUsWUFBTUosS0FBRSxLQUFLLGFBQWEsRUFBRSxPQUFRLENBQUFJLE9BQUcsQ0FBQyxFQUFFQSxFQUFDLENBQUU7QUFBRSxVQUFJSDtBQUFFLFVBQUcsQ0FBQyxJQUFHLEVBQUUsRUFBRSxTQUFTRyxHQUFFLEdBQUcsRUFBRSxDQUFBSCxLQUFFRCxHQUFFSSxHQUFFLFFBQU0sS0FBRyxJQUFFSixHQUFFLFNBQU8sQ0FBQztBQUFBLFdBQU07QUFBQyxjQUFNRSxLQUFFLENBQUMsSUFBRyxFQUFFLEVBQUUsU0FBU0UsR0FBRSxHQUFHO0FBQUUsUUFBQUgsS0FBRSxFQUFFRCxJQUFFSSxHQUFFLFFBQU9GLElBQUUsSUFBRTtBQUFBLE1BQUM7QUFBQyxNQUFBRCxPQUFJQSxHQUFFLE1BQU0sRUFBQyxlQUFjLEtBQUUsQ0FBQyxHQUFFLEdBQUcsb0JBQW9CQSxFQUFDLEVBQUUsS0FBSztBQUFBLElBQUU7QUFBQSxJQUFDLGVBQWM7QUFBQyxhQUFPLEVBQUUsS0FBSyxJQUFHLEtBQUssT0FBTztBQUFBLElBQUM7QUFBQSxJQUFDLGlCQUFnQjtBQUFDLGFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBTSxDQUFBRyxPQUFHLEtBQUssY0FBY0EsRUFBQyxDQUFFLEtBQUc7QUFBQSxJQUFJO0FBQUEsSUFBQyxzQkFBc0JBLElBQUVKLElBQUU7QUFBQyxXQUFLLHlCQUF5QkksSUFBRSxRQUFPLFNBQVM7QUFBRSxpQkFBVUEsTUFBS0osR0FBRSxNQUFLLDZCQUE2QkksRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLDZCQUE2QkEsSUFBRTtBQUFDLE1BQUFBLEtBQUUsS0FBSyxpQkFBaUJBLEVBQUM7QUFBRSxZQUFNSixLQUFFLEtBQUssY0FBY0ksRUFBQyxHQUFFSCxLQUFFLEtBQUssaUJBQWlCRyxFQUFDO0FBQUUsTUFBQUEsR0FBRSxhQUFhLGlCQUFnQkosRUFBQyxHQUFFQyxPQUFJRyxNQUFHLEtBQUsseUJBQXlCSCxJQUFFLFFBQU8sY0FBYyxHQUFFRCxNQUFHSSxHQUFFLGFBQWEsWUFBVyxJQUFJLEdBQUUsS0FBSyx5QkFBeUJBLElBQUUsUUFBTyxLQUFLLEdBQUUsS0FBSyxtQ0FBbUNBLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxtQ0FBbUNBLElBQUU7QUFBQyxZQUFNSixLQUFFLEVBQUUsdUJBQXVCSSxFQUFDO0FBQUUsTUFBQUosT0FBSSxLQUFLLHlCQUF5QkEsSUFBRSxRQUFPLFVBQVUsR0FBRUksR0FBRSxNQUFJLEtBQUsseUJBQXlCSixJQUFFLG1CQUFrQixHQUFHSSxHQUFFLEVBQUUsRUFBRTtBQUFBLElBQUU7QUFBQSxJQUFDLGdCQUFnQkEsSUFBRUosSUFBRTtBQUFDLFlBQU1DLEtBQUUsS0FBSyxpQkFBaUJHLEVBQUM7QUFBRSxVQUFHLENBQUNILEdBQUUsVUFBVSxTQUFTLFVBQVUsRUFBRTtBQUFPLFlBQU1DLEtBQUUsQ0FBQ0UsSUFBRUYsT0FBSTtBQUFDLGNBQU1DLEtBQUUsRUFBRSxRQUFRQyxJQUFFSCxFQUFDO0FBQUUsUUFBQUUsTUFBR0EsR0FBRSxVQUFVLE9BQU9ELElBQUVGLEVBQUM7QUFBQSxNQUFDO0FBQUUsTUFBQUUsR0FBRSxJQUFHLEVBQUUsR0FBRUEsR0FBRSxrQkFBaUIsRUFBRSxHQUFFRCxHQUFFLGFBQWEsaUJBQWdCRCxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMseUJBQXlCSSxJQUFFSixJQUFFQyxJQUFFO0FBQUMsTUFBQUcsR0FBRSxhQUFhSixFQUFDLEtBQUdJLEdBQUUsYUFBYUosSUFBRUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWNHLElBQUU7QUFBQyxhQUFPQSxHQUFFLFVBQVUsU0FBUyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsaUJBQWlCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxRQUFRLEVBQUUsSUFBRUEsS0FBRSxFQUFFLFFBQVEsSUFBR0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGlCQUFpQkEsSUFBRTtBQUFDLGFBQU9BLEdBQUUsUUFBUSw2QkFBNkIsS0FBR0E7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFNLFdBQVU7QUFBQyxjQUFNSixLQUFFLEdBQUcsb0JBQW9CLElBQUk7QUFBRSxZQUFHLFlBQVUsT0FBT0ksSUFBRTtBQUFDLGNBQUcsV0FBU0osR0FBRUksRUFBQyxLQUFHQSxHQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQkEsR0FBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFKLEdBQUVJLEVBQUMsRUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsR0FBRyxVQUFTLElBQUcsSUFBSSxTQUFTQSxJQUFFO0FBQUMsS0FBQyxLQUFJLE1BQU0sRUFBRSxTQUFTLEtBQUssT0FBTyxLQUFHQSxHQUFFLGVBQWUsR0FBRSxFQUFFLElBQUksS0FBRyxHQUFHLG9CQUFvQixJQUFJLEVBQUUsS0FBSztBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUksTUFBSTtBQUFDLGVBQVVBLE1BQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxJQUFHLG9CQUFvQkEsRUFBQztBQUFBLEVBQUMsQ0FBRSxHQUFFLEVBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxhQUFZLEtBQUcsWUFBWSxFQUFFLElBQUcsS0FBRyxXQUFXLEVBQUUsSUFBRyxLQUFHLFVBQVUsRUFBRSxJQUFHLEtBQUcsV0FBVyxFQUFFLElBQUcsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFFBQU8sS0FBRyxRQUFPLEtBQUcsV0FBVSxLQUFHLEVBQUMsV0FBVSxXQUFVLFVBQVMsV0FBVSxPQUFNLFNBQVEsR0FBRSxLQUFHLEVBQUMsV0FBVSxNQUFHLFVBQVMsTUFBRyxPQUFNLElBQUc7QUFBQSxFQUFFLE1BQU0sV0FBVyxFQUFDO0FBQUEsSUFBQyxZQUFZQSxJQUFFSixJQUFFO0FBQUMsWUFBTUksSUFBRUosRUFBQyxHQUFFLEtBQUssV0FBUyxNQUFLLEtBQUssdUJBQXFCLE9BQUcsS0FBSywwQkFBd0IsT0FBRyxLQUFLLGNBQWM7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFPO0FBQUEsSUFBQyxPQUFNO0FBQUMsUUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUscUJBQW1CLEtBQUssY0FBYyxHQUFFLEtBQUssUUFBUSxhQUFXLEtBQUssU0FBUyxVQUFVLElBQUksTUFBTSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEVBQUUsS0FBSyxRQUFRLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxJQUFHLEVBQUUsR0FBRSxLQUFLLGVBQWdCLE1BQUk7QUFBQyxhQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsR0FBRSxLQUFLLG1CQUFtQjtBQUFBLE1BQUMsR0FBRyxLQUFLLFVBQVMsS0FBSyxRQUFRLFNBQVM7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFNO0FBQUMsV0FBSyxRQUFRLE1BQUksRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUscUJBQW1CLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssZUFBZ0IsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0FBQUEsTUFBQyxHQUFHLEtBQUssVUFBUyxLQUFLLFFBQVEsU0FBUztBQUFBLElBQUc7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLGNBQWMsR0FBRSxLQUFLLFFBQVEsS0FBRyxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxVQUFTO0FBQUMsYUFBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxxQkFBb0I7QUFBQyxXQUFLLFFBQVEsYUFBVyxLQUFLLHdCQUFzQixLQUFLLDRCQUEwQixLQUFLLFdBQVMsV0FBWSxNQUFJO0FBQUMsYUFBSyxLQUFLO0FBQUEsTUFBQyxHQUFHLEtBQUssUUFBUSxLQUFLO0FBQUEsSUFBRztBQUFBLElBQUMsZUFBZUksSUFBRUosSUFBRTtBQUFDLGNBQU9JLEdBQUUsTUFBSztBQUFBLFFBQUMsS0FBSTtBQUFBLFFBQVksS0FBSTtBQUFXLGVBQUssdUJBQXFCSjtBQUFFO0FBQUEsUUFBTSxLQUFJO0FBQUEsUUFBVSxLQUFJO0FBQVcsZUFBSywwQkFBd0JBO0FBQUEsTUFBQztBQUFDLFVBQUdBLEdBQUUsUUFBTyxLQUFLLEtBQUssY0FBYztBQUFFLFlBQU1DLEtBQUVHLEdBQUU7QUFBYyxXQUFLLGFBQVdILE1BQUcsS0FBSyxTQUFTLFNBQVNBLEVBQUMsS0FBRyxLQUFLLG1CQUFtQjtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsUUFBRSxHQUFHLEtBQUssVUFBUyxJQUFJLENBQUFHLE9BQUcsS0FBSyxlQUFlQSxJQUFFLElBQUUsQ0FBRSxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBSSxDQUFBQSxPQUFHLEtBQUssZUFBZUEsSUFBRSxLQUFFLENBQUUsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUksQ0FBQUEsT0FBRyxLQUFLLGVBQWVBLElBQUUsSUFBRSxDQUFFLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFJLENBQUFBLE9BQUcsS0FBSyxlQUFlQSxJQUFFLEtBQUUsQ0FBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsbUJBQWEsS0FBSyxRQUFRLEdBQUUsS0FBSyxXQUFTO0FBQUEsSUFBSTtBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBTSxXQUFVO0FBQUMsY0FBTUosS0FBRSxHQUFHLG9CQUFvQixNQUFLSSxFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNKLEdBQUVJLEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFKLEdBQUVJLEVBQUMsRUFBRSxJQUFJO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBRTtBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsU0FBTyxFQUFFLEVBQUUsR0FBRSxFQUFFLEVBQUUsR0FBRSxFQUFDLE9BQU0sR0FBRSxRQUFPLEdBQUUsVUFBUyxJQUFHLFVBQVMsSUFBRyxVQUFTLElBQUcsT0FBTSxJQUFHLFdBQVUsSUFBRyxTQUFRLElBQUcsV0FBVSxJQUFHLEtBQUksSUFBRyxPQUFNLElBQUcsU0FBUSxHQUFFO0FBQUMsQ0FBRTsiLCJuYW1lcyI6WyJlIiwiaSIsIm4iLCJzIiwidCIsIm8iLCJyIiwiYSIsImwiLCJjIiwiaCIsImQiLCJ1IiwiZiIsInAiLCJtIiwiZyIsIl8iLCJiIiwidiIsInkiLCJ3IiwiQSIsIkUiLCJUIiwiQyIsIk8iLCJ4IiwiayIsIkwiLCJTIiwiRCIsIiQiLCJJIiwiTiIsIlAiLCJqIiwiTSIsIkYiLCJIIiwiVyIsIkIiLCJ6IiwiUiIsInEiLCJWIiwiSyIsIlEiLCJYIiwiWSIsIlUiLCJHIiwiSiIsIloiLCJ0dCIsImV0IiwiaXQiLCJudCIsInN0Iiwib3QiLCJydCIsImF0IiwibHQiLCJjdCJdfQ==